import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});const p=await b.newPage();
p.on('pageerror',e=>console.log('ERR',e));
await p.goto('http://localhost:8123/dbg_dance.html');await p.waitForTimeout(500);
await p.click('#style button[data-v="satie"]');await p.click('#play');await p.waitForTimeout(40000);
console.log(await p.evaluate(()=>JSON.stringify([window.__sat,window.__sv])));
await b.close();
