import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const page=await browser.newPage({viewport:{width:400,height:820},hasTouch:true,isMobile:true,userAgent:'Mozilla/5.0 (Linux; Android 14) Mobile'});
const errs=[];page.on('pageerror',e=>errs.push(String(e)));
await page.addInitScript(()=>{
  const Orig=window.AudioContext;window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();}};
  const oc=AudioNode.prototype.connect;AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return res};
  // stand-in speech engine that "speaks" for 1.5 s, so the end-of-speech reset runs
  Object.defineProperty(window,'speechSynthesis',{configurable:true,value:{getVoices:()=>[{name:'English United Kingdom',lang:'en-GB',localService:true,default:true}],cancel(){},speak(u){setTimeout(()=>u.onstart&&u.onstart(),50);setTimeout(()=>u.onend&&u.onend(),1500)}}});
  window.SpeechSynthesisUtterance=function(t){this.text=t};
});
await page.goto('file:///home/claude/music-of-the-spheres.html');await page.waitForTimeout(800);
await page.click('#begin');await page.waitForTimeout(1500);
await page.click('.vrow[data-id="vesta"] .nm');
const lvl=()=>page.evaluate(()=>{const an=__ac.__an,b=new Float32Array(an.fftSize);an.getFloatTimeDomainData(b);let s=0;for(const x of b)s+=x*x;return __ac.state+' rms '+Math.sqrt(s/b.length).toFixed(4)});
for(let k=0;k<8;k++){await page.waitForTimeout(500);console.log((0.5*(k+1)).toFixed(1)+'s',await lvl())}
console.log('errors',errs);await browser.close();
