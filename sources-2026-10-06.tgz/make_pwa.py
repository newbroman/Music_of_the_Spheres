# writes the two app manifests and sw.js (with a precache list and a version taken from the files' contents)
import json,os,hashlib
R='/home/claude/music_of_the_spheres/'
icons=lambda pre:[{"src":pre+"icons/icon-192.png","sizes":"192x192","type":"image/png","purpose":"any"},{"src":pre+"icons/icon-512.png","sizes":"512x512","type":"image/png","purpose":"any"},
  {"src":pre+"icons/icon-192-maskable.png","sizes":"192x192","type":"image/png","purpose":"maskable"},{"src":pre+"icons/icon-512-maskable.png","sizes":"512x512","type":"image/png","purpose":"maskable"}]
SHOTS=[("store/1-dial.png","1080x1920","narrow","The dial: the solar system sung by the Greek gods"),("store/2-plato.png","1080x1920","narrow","Plato's spheres, heard from Athens"),
  ("store/3-dance.png","1080x1920","narrow","Dance of the Spheres: the planets play the band"),("store/4-flight.png","1080x1920","narrow","Fly through the solar system in 3D"),
  ("store/5-wide-dial.png","1920x1080","wide","Twelve thinkers, from Pythagoras to Kepler"),("store/6-wide-dance.png","1920x1080","wide","Club, ballroom and the composers")]
shots=lambda pre:[{"src":pre+f,"sizes":z,"type":"image/png","form_factor":ff,"label":l} for f,z,ff,l in SHOTS]
base=dict(start_url="./index.html",display="standalone",orientation="any",background_color="#090b18",theme_color="#090b18",categories=["music","education","entertainment"],dir="ltr",display_override=["standalone","minimal-ui"],prefer_related_applications=False,launch_handler={"client_mode":"focus-existing"},handle_links="preferred",edge_side_panel={"preferred_width":480})
en=dict(id="./",name="Music of the Spheres",short_name="Spheres",lang="en",scope="./",
  description="Hear the music of the spheres as each thinker imagined it, and the real solar system sung by the Greek gods.",icons=icons(""),screenshots=shots(""),
  shortcuts=[{"name":"Dance of the Spheres","url":"./dance.html"},{"name":"Fly through it in 3D","url":"./flight.html"},{"name":"How it works","url":"./help.html"}],**base)
pl=dict(id="./",name="Muzyka sfer",short_name="Sfery",lang="pl",scope="../",
  description="Posłuchaj muzyki sfer tak, jak wyobrażał ją sobie każdy myśliciel, i prawdziwego Układu Słonecznego śpiewanego przez greckich bogów.",icons=icons("../"),screenshots=shots("../"),
  shortcuts=[{"name":"Taniec sfer","url":"./dance.html"},{"name":"Lot przez sfery w 3D","url":"./flight.html"},{"name":"Jak to działa","url":"./help.html"}],**base)
for _m,_p in ((en,""),(pl,"../")):
    for _s in _m["shortcuts"]:_s["icons"]=[{"src":_p+"icons/icon-192.png","sizes":"192x192","type":"image/png"}]
json.dump(en,open(R+'manifest.webmanifest','w'),ensure_ascii=False,indent=1)
json.dump(pl,open(R+'pl/manifest.webmanifest','w'),ensure_ascii=False,indent=1)
cy=dict(id="./",name="Cerddoriaeth y Sfferau",short_name="Sfferau",lang="cy",scope="../",
  description="Clywch gerddoriaeth y sfferau fel y dychmygodd pob meddyliwr hi, a chysawd yr haul go iawn yn cael ei ganu gan y duwiau Groegaidd.",icons=icons("../"),screenshots=shots("../"),
  shortcuts=[{"name":"Dawns y Sfferau","url":"./dance.html"},{"name":"Hedfan drwy’r Sfferau","url":"./flight.html"},{"name":"Sut mae’n gweithio","url":"./help.html"}],**base)
for _s in cy["shortcuts"]:_s["icons"]=[{"src":"../icons/icon-192.png","sizes":"192x192","type":"image/png"}]
json.dump(cy,open(R+'cy/manifest.webmanifest','w'),ensure_ascii=False,indent=1)
NEW={'de':('Musik der Sphären','Sphären','Tanz der Sphären','Flug durch die Sphären','So funktioniert es','Die Sphärenmusik, wie jeder Denker sie sich vorstellte, und das echte Sonnensystem, gesungen von den griechischen Göttern.'),
 'es':('La música de las esferas','Esferas','La danza de las esferas','Vuelo por las esferas','Cómo funciona','La música de las esferas tal como la imaginó cada pensador, y el sistema solar real cantado por los dioses griegos.'),
 'fr':('La Musique des sphères','Sphères','La Danse des sphères','Vol à travers les sphères','Comment ça marche','La musique des sphères telle que chaque penseur l’imaginait, et le vrai système solaire chanté par les dieux grecs.'),
 'it':('La musica delle sfere','Sfere','La danza delle sfere','Volo tra le sfere','Come funziona','La musica delle sfere come la immaginava ogni pensatore, e il vero sistema solare cantato dagli dèi greci.'),
 'zh':('天球音乐','天球音乐','天球之舞','穿越天球','使用说明','按照每位思想家的想象聆听天球音乐，以及由希腊众神歌唱的真实太阳系。'),
 'ja':('天球の音楽','天球の音楽','天球の舞','天球をめぐる飛行','使い方','思想家たちが思い描いた天球の音楽と、ギリシアの神々が歌う本物の太陽系。')}
for c,(n,sn,d1,d2,d3,desc) in NEW.items():
    os.makedirs(R+c,exist_ok=True)
    json.dump(dict(id="./",name=n,short_name=sn,lang=c,scope="../",description=desc,icons=icons("../"),screenshots=shots("../"),shortcuts=[{"name":x,"url":y,"icons":[{"src":"../icons/icon-192.png","sizes":"192x192","type":"image/png"}]} for x,y in ((d1,"./dance.html"),(d2,"./flight.html"),(d3,"./help.html"))],**base),open(R+c+'/manifest.webmanifest','w'),ensure_ascii=False,indent=1)
pages=['./','index.html','flight.html','dance.html','help.html','manifest.webmanifest','pl/','pl/index.html','pl/flight.html','pl/dance.html','pl/help.html','pl/manifest.webmanifest','privacy.html','cy/','cy/index.html','cy/flight.html','cy/dance.html','cy/help.html','cy/manifest.webmanifest']
for c in ('de','es','fr','it','zh','ja'):pages+=[c+'/',c+'/index.html',c+'/flight.html',c+'/dance.html',c+'/help.html',c+'/manifest.webmanifest']
pages+=['icons/'+f for f in sorted(os.listdir(R+'icons'))]
pages+=['tour/'+l+'/'+f for l in sorted(os.listdir(R+'tour')) for f in sorted(os.listdir(R+'tour/'+l))]
samples=['samples/manifest.json']+sorted('samples/'+d+'/'+f for d in os.listdir(R+'samples') if os.path.isdir(R+'samples/'+d) for f in os.listdir(R+'samples/'+d))
h=hashlib.md5()
for f in pages+samples:
    fp=R+(f if not f.endswith('/') else f+'index.html');h.update(open(fp,'rb').read())
ver=h.hexdigest()[:10]
sw=open('/tmp/claude-0/sw_template.js').read().replace('__VER__',ver).replace('__CORE__',json.dumps(pages)).replace('__SAMPLES__',json.dumps(samples))
open(R+'sw.js','w').write(sw);print('sw',ver,len(pages),'core',len(samples),'samples')
