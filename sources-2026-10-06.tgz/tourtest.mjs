import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
for(const pre of ['','pl/','cy/']){
 for(const [w,h] of [[1300,900],[390,844]]){
  const p=await b.newPage({viewport:{width:w,height:h}});const errs=[];p.on('pageerror',e=>errs.push(String(e)));
  await p.goto('http://localhost:8123/'+pre);await p.waitForTimeout(1200);
  const st=await p.evaluate(()=>({tour:!!document.getElementById('tour'),h2:document.querySelector('#tour h2')?.textContent,hash:location.hash,chip:document.querySelector('.tl-chip[aria-pressed="true"]')?.dataset.t,interp:document.querySelector('#interpSeg button[aria-pressed="true"]')?.dataset.i}));
  await p.screenshot({path:`/tmp/claude-0/tour_${pre.replace('/','')||'en'}_${w}.png`});
  await p.click('#tour .next');await p.waitForTimeout(300);const h2b=await p.textContent('#tour h2');
  await p.click('#tour .go');await p.waitForTimeout(2500);
  const after=await p.evaluate(()=>({tour:!!document.getElementById('tour'),begin:document.getElementById('begin').getAttribute('aria-pressed'),chip:document.querySelector('.tl-chip[aria-pressed="true"]')?.dataset.t,interp:document.querySelector('#interpSeg button[aria-pressed="true"]')?.dataset.i,menu:document.querySelector('.extras .menu a')?.textContent}));
  console.log(pre||'en',w,JSON.stringify(st),'| next:',h2b,'| after:',JSON.stringify(after),'errors',errs.slice(0,2));
  await p.close();
 }
}
const p=await b.newPage();await p.goto('http://localhost:8123/#kepler');await p.waitForTimeout(800);console.log('hash kepler tour?',await p.evaluate(()=>!!document.getElementById('tour')),await p.evaluate(()=>document.querySelector('.tl-chip[aria-pressed="true"]')?.dataset.t));
await b.close();
