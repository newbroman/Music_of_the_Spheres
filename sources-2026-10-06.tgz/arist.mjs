import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});const p=await b.newPage();
await p.addInitScript(()=>{const O=window.AudioContext;window.AudioContext=class extends O{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();}};const oc=AudioNode.prototype.connect;AudioNode.prototype.connect=function(t,...r){const x=oc.call(this,t,...r);if(t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return x}});
await p.goto('http://localhost:8123/index.html?notour#aristotle');await p.waitForTimeout(800);await p.click('#begin');
const out=[];for(let k=0;k<15;k++){await p.waitForTimeout(5000);out.push((await p.evaluate(()=>{const a=__ac.__an,x=new Float32Array(2048);a.getFloatTimeDomainData(x);let q=0;for(const v of x)q+=v*v;return Math.sqrt(q/2048)})).toFixed(3))}
console.log('rms every 5 s:',out.join(' '));await b.close();
