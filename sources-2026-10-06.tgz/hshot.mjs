import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch();
for(const [w,h,n] of [[1280,900,'help_desk'],[400,860,'help_phone']]){const p=await b.newPage({viewport:{width:w,height:h},deviceScaleFactor:1});const errs=[];p.on('pageerror',e=>errs.push(String(e)));
await p.goto('file:///home/claude/help.html');await p.waitForTimeout(1200);
console.log(n,'hscroll:',await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),errs);
await p.screenshot({path:n+'.png',fullPage:false});
if(n==='help_desk'){await p.evaluate(()=>document.querySelector('#history figure:nth-of-type(2)').scrollIntoView());await p.waitForTimeout(300);await p.screenshot({path:'help_fig.png'})}}
await b.close();
