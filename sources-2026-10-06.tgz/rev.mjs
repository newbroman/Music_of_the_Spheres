import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch();const page=await browser.newPage();
const r=await page.evaluate(async()=>{
  async function run(q,fb){
    const sr=48000, ac=new OfflineAudioContext(2,sr*20,sr);
    const src=ac.createBufferSource();const b=ac.createBuffer(1,sr,sr);const d0=b.getChannelData(0);for(let i=0;i<sr;i++)d0[i]=Math.sin(i/sr*2*Math.PI*1970)*.3*(i<sr*.5?1:0);src.buffer=b;
    const out=ac.createGain();out.connect(ac.destination);
    const pre=ac.createGain();pre.gain.value=.5;src.connect(pre);
    [[.0437,-.8],[.0531,.8],[.0617,-.35],[.0719,.35]].forEach(([dt,pan])=>{const d=ac.createDelay(.2);d.delayTime.value=dt*1.9;const lp=ac.createBiquadFilter();lp.type='lowpass';lp.frequency.value=2600;if(q!==null)lp.Q.value=q;const f=ac.createGain();f.gain.value=fb;pre.connect(d);d.connect(lp);lp.connect(f);f.connect(d);const o=ac.createStereoPanner();o.pan.value=pan;lp.connect(o);o.connect(out)});
    src.start();const buf=await ac.startRendering();const x=buf.getChannelData(0);
    const seg=s=>{let m=0;for(let i=Math.floor(s*sr);i<Math.floor((s+1)*sr);i++)m=Math.max(m,Math.abs(x[i]));return m.toFixed(3)};
    return [1,3,6,10,19].map(s=>s+'s:'+seg(s)).join(' ');
  }
  return {current_Q_default:await run(null,.82), Q_minus3dB:await run(-3,.82), Q_minus3_fb075:await run(-3,.75)};
});
console.log(r);await browser.close();
