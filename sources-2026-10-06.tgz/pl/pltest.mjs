import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const R='file:///home/claude/music_of_the_spheres/pl/';
async function run(name,fn,vp={width:1280,height:900}){
  const page=await browser.newPage({viewport:vp});const errs=[];page.on('pageerror',e=>errs.push(String(e)));page.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
  await fn(page);console.log(name,'errors:',errs);await page.close();
}
await run('2d',async p=>{await p.goto(R+'index.html');await p.waitForTimeout(1200);await p.click('#begin');await p.waitForTimeout(1500);
  await p.click('#voices button[data-v="human"]');await p.waitForTimeout(800);
  await p.click('.vrow[data-id="jupiter"]');await p.waitForTimeout(1500);
  console.log('aud:',await p.innerText('#audTxt'),'| zod:',(await p.innerText('#zodTxt')).replace(/\n/g,' / '),'| date:',await p.innerText('#dateTxt'),await p.innerText('#speedTxt'));
  console.log('info:',(await p.innerText('#info')).replace(/\n+/g,' | ').slice(0,700));
  await p.screenshot({path:'pl_2d.png',fullPage:false});
  await p.click('#sysBtn');await p.waitForTimeout(1500);console.log('sys:',(await p.innerText('#info')).replace(/\n+/g,' | ').slice(0,400));await p.screenshot({path:'pl_2d_sys.png'});
});
await run('fly',async p=>{await p.goto(R+'flight.html');await p.waitForTimeout(2500);await p.click('#begin');await p.waitForTimeout(800);
  await p.click('#navBtn');await p.click('#dest button[data-id="saturn"]');await p.waitForTimeout(500);console.log('toast:',await p.innerText('#toast'));await p.waitForTimeout(9000);
  console.log('near:',await p.innerText('#nearTxt'),'|',await p.innerText('#speedTxt'),'| hud:',await p.innerText('#dateTxt'),await p.innerText('#timeTxt'),'|',(await p.innerText('#zodTxt')).replace(/\n/g,' / '));
  console.log('chips:',await p.innerText('#moonChips'),'|',await p.innerText('#courseChips'));
  await p.screenshot({path:'pl_fly.png'});
},{width:900,height:700});
await run('dance',async p=>{await p.goto(R+'dance.html');await p.waitForTimeout(1200);await p.click('#play');await p.waitForTimeout(4000);
  console.log('dance:',await p.innerText('#secTxt'),await p.innerText('#barTxt'),'|',await p.innerText('#keyTxt'),'|',await p.innerText('#aspTxt'),'|',await p.innerText('#dpbOut'),await p.innerText('#dateTxt'));
  console.log('mix:',(await p.innerText('#mix')).replace(/\n/g,' '));await p.screenshot({path:'pl_dance.png'});
});
await run('help',async p=>{await p.goto(R+'help.html');await p.waitForTimeout(800);await p.screenshot({path:'pl_help.png'});},{width:1100,height:800});
await browser.close();
