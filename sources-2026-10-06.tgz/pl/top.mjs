import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch();const p=await b.newPage({viewport:{width:1280,height:1000}});
await p.goto('file:///home/claude/music_of_the_spheres/pl/index.html');await p.waitForTimeout(1500);
await p.evaluate(()=>{document.querySelector('.vrow[data-id="earth"]').click()});await p.waitForTimeout(800);
await p.evaluate(()=>scrollTo(0,0));await p.waitForTimeout(300);await p.screenshot({path:'pl_2d_top.png'});
const m=await b.newPage({viewport:{width:390,height:844}});await m.goto('file:///home/claude/music_of_the_spheres/pl/flight.html');await m.waitForTimeout(2500);await m.screenshot({path:'pl_fly_phone.png'});
await b.close();
