import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const mock=()=>{Object.defineProperty(AudioDestinationNode.prototype,'maxChannelCount',{get(){return 6}});const d=Object.getOwnPropertyDescriptor(AudioNode.prototype,'channelCount');
  Object.defineProperty(AudioNode.prototype,'channelCount',{get(){return d.get.call(this)},set(v){if(this instanceof AudioDestinationNode&&v>2){this.__cc=v;return}d.set.call(this,v)}});};
const p=await b.newPage();p.on('pageerror',e=>console.log('ERR',e));p.on('console',m=>console.log('console',m.text()));await p.addInitScript(mock);
await p.goto('http://localhost:8123/flight.html');await p.waitForTimeout(800);await p.click('#begin');await p.waitForTimeout(2000);
await p.evaluate(()=>MOTS.setOut('5.1'));await p.waitForTimeout(500);
const r=await p.evaluate(()=>{const S=MOTS.surround._s;const c=S.cfg.ctx,sp=c.createChannelSplitter(6);S.merger.connect(sp);window.__an=[0,1,2,3,4,5].map(k=>{const a=c.createAnalyser();sp.connect(a,k);return a});return [MOTS.surround.test(),c.state]});
console.log(r);
for(let k=0;k<14;k++){await p.waitForTimeout(450);console.log(JSON.stringify(await p.evaluate(()=>window.__an.map(a=>{const x=new Float32Array(2048);a.getFloatTimeDomainData(x);let q=0;for(const v of x)q+=v*v;return +Math.sqrt(q/2048).toFixed(3)}))))}
await b.close();
