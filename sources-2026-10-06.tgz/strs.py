import re,sys
src=open(sys.argv[1]).read()
js=src[src.index('<script>'):] if '<script>' in src else ''
# string literals ('..', "..", `..`) that contain a run of English words
lits=re.findall(r"'((?:[^'\\\n]|\\.)*)'|\"((?:[^\"\\\n]|\\.)*)\"|`((?:[^`\\]|\\.)*)`",js)
seen=set()
for t in lits:
    s=next(x for x in t if x is not None) if any(t) else ''
    s=s or ''
    if re.search(r"[A-Za-z]{3,}\s+[A-Za-z]{2,}",s) or re.search(r"^[A-Z][a-z]+$",s):
        if s not in seen and not re.search(r"(rgba|translate|px|function|=>|font|\.toFixed|setAttribute)",s[:80]):
            seen.add(s);print(repr(s[:220]))
