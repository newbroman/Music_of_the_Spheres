import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required','--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});
const p=await b.newPage({viewport:{width:1280,height:720}});const errs=[];p.on('pageerror',e=>errs.push(String(e).slice(0,200)));
await p.goto('http://localhost:8123/'+(process.argv[2]||'')+'index.html?notour');await p.waitForTimeout(800);
await p.click('#showBtn');
const n=await p.evaluate(()=>MOTS.show.scenes.length);console.log('scenes',n,'total',await p.evaluate(()=>MOTS.show.total));
const rms=()=>p.evaluate(()=>{const ac=(document.querySelector('#motsShow iframe')?.contentWindow||window).MOTS.audioCtx();if(!ac)return 'noctx';if(!ac.__an){ac.__an=ac.createAnalyser();}
  return ac.state});
for(let k=0;k<n;k++){
  await p.waitForTimeout(k>=29&&k<=32||k>=34&&k<=46?3500:2200);
  const st=await p.evaluate(()=>{const s=document.getElementById('motsShow');const f=s.querySelector('iframe');return [s.querySelector('.card.on h1')?.textContent||s.querySelector('.cap.on h2')?.textContent||'(none)',f?f.dataset.pg:'dial',(f?f.contentWindow:window).MOTS.audioCtx()?.state]});
  console.log(String(k).padStart(2),st[1].padEnd(6),st[2],'|',st[0].slice(0,60));
  if([0,14,19,30,33,40,49].includes(k))await p.screenshot({path:`/tmp/claude-0/show_${k}.png`});
  await p.keyboard.press('ArrowRight');
}
console.log('errors',errs.slice(0,5));await b.close();
