#!/bin/bash
# rebuild every page in all three languages, and the offline cache list
set -e
cd /tmp/claude-0
python3 mklang.py
python3 - <<'PY'
# keep the shared stage and tour modules in the 2D master in step with their source files
p='/home/claude/music-of-the-spheres.html';s=open(p).read()
for a,b,f in [('/*STAGE-START*/','/*STAGE-END*/','/tmp/claude-0/stage.js'),('/*TOUR-START*/','/*TOUR-END*/','/tmp/claude-0/tour.js'),('/*LANG-START*/','/*LANG-END*/','/tmp/claude-0/lang_built.js'),('/*SHOW-START*/','/*SHOW-END*/','/tmp/claude-0/show.js')]:
    if a not in s:continue
    i=s.index(a)+len(a);j=s.index(b);s=s[:i]+open(f).read()+s[j:]
open(p,'w').write(s)
p='/tmp/claude-0/help_head.html';s=open(p).read();a,b='/*LANG-START*/','/*LANG-END*/'
i=s.index(a)+len(a);j=s.index(b);s=s[:i]+open('/tmp/claude-0/lang_built.js').read()+s[j:];open(p,'w').write(s)
PY
python3 -c "
h=open('ball_head.js').read();sy=open('ball_synth_part.js').read().split('\n');pp=open('ball_pat.js').read();s=open('composers.js').read()
open('dance_ball.js','w').write(h+'\n'.join(sy[:64])+'\n'+pp+s)"
python3 build_dance.py; python3 build_fly.py
cat help_head.html help_body.html > /home/claude/help.html
python3 wrap.py
(cd pl && python3 pl.py)
(cd cy && python3 cy.py)
for l in de es fr it zh ja; do (cd i18n && python3 build.py $l); done
python3 make_pwa.py
