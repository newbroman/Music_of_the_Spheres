import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const page=await browser.newPage({viewport:{width:1300,height:950}});
const errs=[];page.on('pageerror',e=>errs.push(String(e)));
await page.goto('file:///home/claude/music-of-the-spheres.html');await page.waitForTimeout(1200);
await page.click('#begin');await page.waitForTimeout(2500);
console.log('today:',await page.innerText('#zodTxt'));
// jump ahead in time to see the key turn
await page.fill('#speed','1000');await page.dispatchEvent('#speed','input');await page.waitForTimeout(1500);
for(let k=0;k<4;k++){await page.waitForTimeout(900);console.log(await page.textContent('#dateTxt'),'|',(await page.innerText('#zodTxt')).replace(/\n/g,' / '))}
await page.fill('#speed','460');await page.dispatchEvent('#speed','input');await page.waitForTimeout(800);
await page.locator('.dial').screenshot({path:'z2d.png'});
console.log('errors',errs);await browser.close();
