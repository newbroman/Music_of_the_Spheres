import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch();const p=await b.newPage({viewport:{width:1300,height:900}});
await p.goto('http://localhost:8123/index.html#'+(process.argv[2]||'plato'));await p.waitForTimeout(1500);
const el=await p.$('#info');await el.screenshot({path:'card_'+(process.argv[2]||'plato')+'.png'});
const m=await b.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});await m.goto('http://localhost:8123/index.html#'+(process.argv[3]||'ptolemy'));await m.waitForTimeout(1500);await m.screenshot({path:'phone_think.png',fullPage:false});
await m.evaluate(()=>scrollTo(0,700));await m.waitForTimeout(400);await m.screenshot({path:'phone_think2.png'});
await b.close();
