import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const styles=(process.argv[2]||'waltz,tango,samba,chacha,swing,jive,fandango').split(',');
const IDS=['sun','mercury','earth','mars','jupiter','jupiter-moons','saturn','venus','neptune'];
async function one(st){
  const page=await browser.newPage();
  await page.addInitScript(()=>{const Orig=window.AudioContext;window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();this.__an.fftSize=2048;}};const oc=AudioNode.prototype.connect;AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return res};});
  await page.goto('http://localhost:8123/dance.html');await page.waitForTimeout(500);
  await page.click(`#style button[data-v="${st}"]`);await page.click('#play');
  for(let k=0;k<60;k++){await page.waitForTimeout(500);if((await page.textContent('#secTxt'))==='groove')break}
  const rms=async ms=>{let s=0,n=0;for(let k=0;k<ms/100;k++){await page.waitForTimeout(100);s+=await page.evaluate(()=>{const an=__ac.__an,b=new Float32Array(an.fftSize);an.getFloatTimeDomainData(b);let q=0;for(const x of b)q+=x*x;return Math.sqrt(q/b.length)});n++}return s/n};
  const all=await rms(2500);const out={all:all.toFixed(3)};
  const btn=id=>page.locator(`.mrow[data-id="${id}"] .mb`);
  for(const id of IDS){for(const o of IDS)if(o!==id)await btn(o).click();await page.waitForTimeout(400);out[id]=(await rms(2200)).toFixed(3);for(const o of IDS)if(o!==id)await btn(o).click()}
  await page.close();return st+' '+JSON.stringify(out);
}
for(const r of await Promise.all(styles.map(one)))console.log(r);
await browser.close();
