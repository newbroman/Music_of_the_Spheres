#!/bin/bash
curl -s -o /dev/null http://localhost:8123/ || { cd /home/claude/music_of_the_spheres && (nohup python3 -m http.server 8123 >/tmp/srv.log 2>&1 &); sleep 1; }
