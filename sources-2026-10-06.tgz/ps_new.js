function playStep(s,t){
  const st=STY(), spb=SPB(), pos=s%spb, bar=Math.floor(s/spb), L=LAYERS[D.section], into=bar-D.secBar, m=id=>!D.mute.has(id);
  if(pos===0)atBar(bar,t);
  const deg=D.prog[bar%4], stepT=barDur()/spb;
  if(st.fam==='ball'){ballStep(s,pos,bar,t,st,L,deg,stepT,m,into,spb);return}
  // Apollo's kick, four to the floor
  if(L.kick&&m('sun')&&pos%4===0){if(!(D.style==='house'&&D.section==='build'&&into===D.secLen-1))kick(t)}
  if(D.style==='techno'&&D.section==='build'&&m('sun')&&pos%4===0)kick(t);
  // Gaia's claps and the build's snare roll
  if(L.clap&&m('earth')&&(pos===4||pos===12))clap(t,1);
  if(D.style==='techno'&&L.clap&&m('earth')&&pos===14&&bar%2)clap(t,.6);
  if(D.section==='build'&&m('earth')){const prog=(into+pos/16)/D.secLen, every=prog<.5?4:prog<.75?2:1;if(pos%every===0)snare(t,.3+.7*prog)}
  // Hermes' hats: busier when Mercury runs fast near perihelion
  if(L.hats&&m('mercury')){const fast=P.mercury.om/(TAU/87.97)>1.12, slow=P.mercury.om/(TAU/87.97)<.88;
    if(st.hats==='trance'){if(pos%4===2)hat(t,true,L.hats);else if(!slow&&(fast||pos%2===0))hat(t,false,.45*L.hats)}
    else if(st.hats==='house'){if(pos%4===2)hat(t,bar%2===0,L.hats);else if(!slow||pos%2===0)hat(t,false,.5*L.hats)}
    else{if(!slow||pos%2===0)hat(t,pos%4===2&&fast,(pos%4===2?.9:.5)*L.hats)}}
  // Zeus' bass
  if(L.bass&&m('jupiter')){
    if(st.bass==='rolling'){if(pos%4!==0)bass(t,noteF(deg,2),stepT*.85)}
    else if(st.bass==='house'){const hits={2:[0,1.6],3:null,6:[7,.9],10:[0,1.6],13:[0,.9],14:[4,.9]};const h=hits[pos];if(h)bass(t,noteF(deg+h[0],2),stepT*h[1])}
    else{const a=D.acid[pos];if(a.on)bass(t,noteF(deg+a.deg,2),stepT*(a.acc?.95:.7),{acc:a.acc})}}
  // Kronos' house stabs
  if(st.pads==='stab'&&L.pads&&m('saturn')&&[2,6,11,14].includes(pos)&&(pos!==11||bar%2))stab(t,chordTones(deg),stepT*1.6);
  // Jupiter's moons: Io, Europa and Ganymede in their 1:2:4 resonance
  if(L.arp&&m('jupiter-moons')){const lv=L.arp*st.arp, tones=chordTones(deg), up=moonWaxing();
    const io=tones[(up?pos:15-pos)%3], eu=tones[(up?pos/2:7-pos/2)%3|0];
    pluck(t,noteF(io,5),.085*lv,'square',stepT*.6,'io');
    if(pos%2===0)pluck(t,noteF(eu,4),.1*lv,'triangle',stepT*1.4,'europa');
    if(pos%4===0)pluck(t,noteF(tones[(pos/4|0)%3],6),.06*lv,'sine',stepT*4,'ganymede');}
  // Aphrodite's vocal chops
  if(L.lead*st.lead>.2&&m('venus')){const mm=D.motif[(bar%2)*16+pos];if(mm&&(L.lead>=.9||pos%8===0))chop(t,noteF(deg+mm.deg,5),barDur()*mm.len,mm.vow)}
  // Ares' toms
  if(L.toms*st.toms>.2&&m('mars')){const tp=D.tomPat[pos];if(tp!==null&&(st.toms>.5||bar%2))tom(t,noteF(deg+tp,3))}
}
function moonWaxing(){const e=P.earth,m=byId.earth.moons[0];const th=TAU*((S.jd-J2000)/m.P+m.ph0),sun=Math.atan2(-e.y,-e.x);return (((th-sun)/TAU)%1+1)%1<.5}
