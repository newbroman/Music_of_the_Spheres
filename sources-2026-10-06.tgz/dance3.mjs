import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const page=await browser.newPage({viewport:{width:400,height:860},hasTouch:true,isMobile:true,deviceScaleFactor:2,userAgent:'Mozilla/5.0 (Linux; Android 14) Mobile'});
const errs=[];page.on('pageerror',e=>errs.push(String(e)));
await page.addInitScript(()=>{const Orig=window.AudioContext;window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();this.__an.fftSize=4096;}};const oc=AudioNode.prototype.connect;AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return res};});
await page.goto('file:///tmp/claude-0/dance_wrapped.html');await page.waitForTimeout(800);
await page.click('#style button[data-v="techno"]');await page.click('#play');
const rows=[];for(let k=0;k<60;k++){await page.waitForTimeout(1000);if(k%6===5)rows.push(await page.evaluate(()=>{const an=__ac.__an,b=new Float32Array(an.fftSize);an.getFloatTimeDomainData(b);let s=0;for(const x of b)s+=x*x;return Math.sqrt(s/b.length).toFixed(3)}))}
console.log('phone techno rms every 6s:',rows.join(' '),'| section',await page.textContent('#secTxt'),await page.textContent('#barTxt'));
await page.screenshot({path:'d_phone.png'});console.log('errors',errs);await browser.close();
