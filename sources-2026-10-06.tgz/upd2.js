// loudness follows apparent size: radius divided by distance from your post, as a body looks in the sky.
// a comet's size is its coma, which only exists near the Sun.
function apparentSize(b,p,d){const R=b.kind==='comet'?Math.max(b.R,120000*(p.act||0)):b.R;return R/Math.max(d,1e-3)}
function loudness(b,p,a){
  if(a.self)return .55;
  const law=.25+.85*S.dist;
  return Math.min(1.6,Math.pow(apparentSize(b,p,a.d)/12000,law));
}
const WOB={};let lastWob=0;
// dwarf planets and asteroids are not voices by default: each tugs the pitch of the planet nearest to it
function computeWobble(now,dt){
  BODIES.forEach(b=>{if(b.kind!=='minor')WOB[b.id]={c:0,a:0,by:[]}});
  const planets=BODIES.filter(b=>b.kind==='planet');
  BODIES.filter(b=>b.kind==='minor').forEach((m,k)=>{
    m.wobTarget=null;
    if(S.minorMode!=='wobble'||!S.groups.minor.on||S.muted.has(m.id)||S.audition===m.id)return;
    const p=P[m.id];let best=null,bd=1e9;
    planets.forEach(q=>{const r=P[q.id],d=Math.hypot(p.x-r.x,p.y-r.y,p.z-r.z);if(d<bd){bd=d;best=q}});
    const depth=30*S.groups.minor.vol*Math.pow(m.R/500,.6)/(.3+bd);
    const syn=S.playing?Math.abs(p.om-P[best.id].om)/TAU*S.speed:0;
    const rate=.09+.05*(k%5)+Math.min(3,syn);
    m.wph=(m.wph||Math.random()*TAU)+dt*TAU*rate;
    const c=depth*Math.sin(m.wph);
    const w=WOB[best.id];w.c+=c;w.a+=.004*c;w.by.push(m.id);
    m.wobTarget=best.id;m.wobDepth=depth;
  });
  // comets and planets also sway with their own orbital inclination as they rise and fall through the ecliptic
  BODIES.forEach(b=>{if(b.kind==='minor')return;const p=P[b.id];WOB[b.id].c+=60*(p.r>0?p.z/p.r:0)});
}

function updateAudio(){
  const L=listenerPos(), ang=facingAngle(), now=AC.currentTime;setListener(ang);
  const fwd={x:Math.cos(ang),y:0,z:-Math.sin(ang)};
  const dt=Math.min(.2,now-(lastWob||now));lastWob=now;
  computeWobble(now,dt);
  syncPool();
  let builds=0;
  BODIES.forEach(b=>{
    const v=V[b.id], p=P[b.id], aud=S.audition===b.id;
    // auditioning: the body sings just ahead of you, at full presence
    const a=aud?{...fwd,d:0}:audioDir(p,L);
    setPos(v.pan,a.x,a.y,a.z);
    const on=audible(b), grp=aud?1:S.groups[b.kind].vol;
    const asWobble=b.kind==='minor'&&S.minorMode==='wobble'&&!aud;
    const g=v.gRel=loudness(b,p,a);
    // only voices loud enough to hear are kept running (with a little hysteresis)
    const want=aud||(on&&!asWobble&&g>(v.part?.025:.035));
    if(want&&!v.part&&builds<3){buildPart(b,v);builds++}
    else if(!want&&v.part&&now-(v.born||0)>2.5){killPart(v.part);v.part=null;v.mode=null}
    v.culled=!v.part;
    const I=v.mode==='instrument'?v.part:null, Hp=v.mode==='human'?v.part:null, W=WOB[b.id]||{c:0,a:0};
    const duck=aud&&S.speaking?.3:1;
    if(v.part&&v.part.osc)v.part.osc.forEach(([o,base])=>tgt(o.detune,base+W.c,.05));
    let vol=0;
    if(b.kind==='comet'){
      if(I){tgt(I.bp1.frequency,Math.min(4000,p.f*2),.1);tgt(I.bp2.frequency,Math.min(8000,p.f*3),.1)}
      vol=aud?.1*Math.max(.4,Math.min(1,g)):.05*g*grp;
    }else{
      if(I){tgt(I.o1.frequency,p.f,.07);tgt(I.o2.frequency,p.f,.07);if(I.o3)tgt(I.o3.frequency,p.f,.07);tgt(I.vd.gain,p.f*.004,.2);
        const sb=p.r>0?p.z/p.r:0;tgt(I.lp.frequency,Math.max(300,Math.min(12000,2600*Math.pow(2,3*sb))),.2);}
      vol=aud?.1*(.55+.45*b.sizeG):(b.kind==='planet'?.075:.06)*g*grp;
    }
    tgt(v.vol.gain,v.part&&(on||aud)?vol*duck*(1+W.a):0,.12);
    if(Hp&&(on||aud))humanTick(Hp.h,p.f,1,now);
    // moons follow their planet: silent when it is
    const mOn=(on||aud)&&!!v.part&&(S.groups.moons.on||aud);
    tgt(v.moonVol.gain,mOn&&!aud?S.groups.moons.vol*Math.min(1,g):0,.12);
    (b.moons||[]).forEach(m=>{
      const rate=S.playing?S.speed/Math.abs(m.P):0;
      if(aud&&m.slot!==undefined){
        const slot=POOL[m.slot];tgt(slot.g.gain,mOn?1.4:0,.12);
        // slow moons circle you at their true phase; fast ones hold a place so the panner never whips round
        const th=rate>.5?ang+Math.PI*(.25+m.rank*.27):TAU*((S.jd-J2000)/m.P+m.ph0);
        setPos(slot.p,Math.cos(th),.1,-Math.sin(th),.12);
      }
      tgt(m.hum.frequency,moonPitch(m.P),.1);
      tgt(m.hg.gain,mOn&&rate>1.2?Math.min(1,(rate-1.2)/4)*.018*(.4+.6*m.sizeN):0,.25);
    });
  });
  POOL.forEach((s,k)=>{if(!poolOwner||k>=byId[poolOwner].moons.length)tgt(s.g.gain,0,.1)});
  // sun
  const sa=audioDir({x:0,y:0,z:0},L);setPos(sunV.pan,sa.x,sa.y,sa.z);
  const [d1,d2,d3]=droneFreqs(), sp=sunV.part;
  if(sunV.mode==='instrument'){tgt(sp.d1.frequency,d1,.3);tgt(sp.d2.frequency,d2,.3);tgt(sp.d3.frequency,d3,.3)}
  else if(sp&&S.drone){humanTick(sp.hums[0],d3,1,now);humanTick(sp.hums[1],d2,1,now)}
  tgt(sunV.vol.gain,S.drone&&!S.solo.size?(S.audition?.025:.07*(sa.self?.7:Math.max(.3,1-S.dist*.6*Math.min(1,sa.d/20)))):0,.3);
}
