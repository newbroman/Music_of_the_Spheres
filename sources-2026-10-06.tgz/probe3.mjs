import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const page = await browser.newPage();
const errs=[];page.on('pageerror',e=>errs.push(String(e)));page.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
await page.addInitScript(()=>{
  const Orig=window.AudioContext;
  window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();this.__an.fftSize=4096;}};
  const oc=AudioNode.prototype.connect;
  AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return res};
});
await page.goto('file:///tmp/claude-0/mots-v3.html');
await page.waitForTimeout(500);
async function measure(label,secs){
  const out=await page.evaluate(async(secs)=>{
    const an=window.__ac.__an, buf=new Float32Array(an.fftSize), rows=[];
    for(let k=0;k<secs*4;k++){await new Promise(r=>setTimeout(r,250));an.getFloatTimeDomainData(buf);
      let s=0,mx=0,jump=0;for(let i=0;i<buf.length;i++){s+=buf[i]*buf[i];mx=Math.max(mx,Math.abs(buf[i]));if(i>1){const d2=Math.abs(buf[i]-2*buf[i-1]+buf[i-2]);jump=Math.max(jump,d2)}}
      rows.push([+(Math.sqrt(s/buf.length)).toFixed(4),+mx.toFixed(3),+jump.toFixed(4)]);}
    return {rows,state:window.__ac.state};
  },secs);
  const rms=out.rows.map(r=>r[0]);const silent=rms.filter(x=>x<0.002).length;
  console.log(label,'state',out.state,'min rms',Math.min(...rms).toFixed(4),'mean',(rms.reduce((a,b)=>a+b)/rms.length).toFixed(4),'silent windows',silent,'/',rms.length,'max 2nd-diff',Math.max(...out.rows.map(r=>r[2])).toFixed(4));
  console.log('  rms trace',rms.filter((_,i)=>i%4==0).join(' '));
}
await page.click('#begin');await page.waitForTimeout(1500);
await measure('instrument',8);
await page.click('#voices button[data-v="human"]');await page.waitForTimeout(1000);
await measure('human choir',20);
await page.click('.vrow[data-id="jupiter"] .nm');await page.waitForTimeout(800);
await measure('human audition jupiter',15);
console.log('errors',errs);
await browser.close();
