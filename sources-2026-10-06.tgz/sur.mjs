import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const mock=()=>{Object.defineProperty(AudioDestinationNode.prototype,'maxChannelCount',{get(){return 6}});const d=Object.getOwnPropertyDescriptor(AudioNode.prototype,'channelCount');
  Object.defineProperty(AudioNode.prototype,'channelCount',{get(){return d.get.call(this)},set(v){if(this instanceof AudioDestinationNode&&v>2){this.__cc=v;return}d.set.call(this,v)}});};
const probe=()=>{const S=MOTS.surround._s;if(!S.merger)return null;if(!window.__an){const c=S.cfg.ctx,sp=c.createChannelSplitter(6);S.merger.connect(sp);window.__an=[0,1,2,3,4,5].map(k=>{const a=c.createAnalyser();a.fftSize=2048;sp.connect(a,k);return a})}
  return window.__an.map(a=>{const x=new Float32Array(2048);a.getFloatTimeDomainData(x);let q=0;for(const v of x)q+=v*v;return Math.sqrt(q/2048)})};
const avg=async(p,n=10)=>{let s=[0,0,0,0,0,0];for(let k=0;k<n;k++){const r=await p.evaluate(probe);if(r)s=s.map((v,i)=>v+r[i]/n);await p.waitForTimeout(150)}return s.map(v=>+v.toFixed(4))};
// unsupported device first
{const p=await b.newPage();await p.goto('http://localhost:8123/index.html?notour#today');await p.click('#begin');await p.waitForTimeout(800);await p.click('#stageBtn');await p.click('#stOut button[data-v="5.1"]');await p.waitForTimeout(200);
 console.log('no 5.1 device:',await p.evaluate(()=>[MOTS.outMode(),document.getElementById('stOutNote').textContent.slice(0,60)]));await p.close()}
for(const [url,start] of [['index.html?notour#today','#begin'],['flight.html','#begin'],['dance.html','#play']]){
  const p=await b.newPage();const errs=[];p.on('pageerror',e=>errs.push(String(e)));await p.addInitScript(mock);
  await p.goto('http://localhost:8123/'+url);await p.waitForTimeout(800);await p.click(start).catch(()=>{});await p.waitForTimeout(2500);
  await p.click('#stageBtn');await p.click('#stOut button[data-v="5.1"]');await p.waitForTimeout(1500);
  const a=await avg(p);let extra='';
  if(url.startsWith('index')){await p.evaluate(()=>{const t=document.getElementById('turn');t.value=180;t.dispatchEvent(new Event('input'))});await p.waitForTimeout(1500);extra='after turning 180: '+JSON.stringify(await avg(p))}
  const st=await p.evaluate(()=>[MOTS.outMode(),!document.getElementById('stTest').hidden,document.querySelector('#stOut button[aria-pressed="true"]')?.dataset.v]);
  await p.click('#stTest');const seq=[];for(let k=0;k<12;k++){await p.waitForTimeout(500);const r=await p.evaluate(probe);seq.push(r.indexOf(Math.max(...r)))}
  await p.click('#stOut button[data-v="stereo"]');await p.waitForTimeout(800);const back=await p.evaluate(()=>[MOTS.outMode(),MOTS.surround._s.on]);
  console.log(url,'\n  5.1 channels L,R,C,LFE,Ls,Rs:',JSON.stringify(a),'\n ',extra,'\n  state',JSON.stringify(st),'test loudest ch seq',seq.join(''),' back to stereo',JSON.stringify(back),'errors',errs.slice(0,3));
  await p.close();
}
await b.close();
