import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
const page = await browser.newPage({viewport:{width:1200,height:760}});
const errs=[];page.on('pageerror',e=>errs.push(String(e)));page.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
await page.addInitScript(()=>{const Orig=window.AudioContext;window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();this.__an.fftSize=4096;}};const oc=AudioNode.prototype.connect;AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return res};});
await page.goto('file:///home/claude/flight.html');await page.waitForTimeout(2500);
async function rms(secs){return page.evaluate(async(secs)=>{const an=window.__ac.__an,b=new Float32Array(an.fftSize),o=[];for(let k=0;k<secs*4;k++){await new Promise(r=>setTimeout(r,250));an.getFloatTimeDomainData(b);let s=0;for(const x of b)s+=x*x;o.push(Math.sqrt(s/b.length))}return {min:Math.min(...o).toFixed(4),mean:(o.reduce((a,c)=>a+c)/o.length).toFixed(4)}},secs)}
await page.click('#voices button[data-v="human"]',{force:true}).catch(()=>{});
await page.click('#begin');await page.waitForTimeout(1000);
await page.click('#navBtn');await page.click('#voices button[data-v="human"]');await page.click('#dest button[data-id="jupiter"]');
await page.waitForTimeout(9000);
console.log(await page.textContent('#nearTxt'),'|',await page.textContent('#speedTxt'),'| chips',await page.textContent('#moonChips'));
await page.screenshot({path:'f_jup.png'});
console.log('Jupiter human',JSON.stringify(await rms(8)));
// fly away from Jupiter manually with W held
await page.keyboard.down('KeyS');for(let k=0;k<3;k++){await page.waitForTimeout(1500);console.log(' backing off:',await page.textContent('#nearTxt'),'|',await page.textContent('#speedTxt'))}await page.keyboard.up('KeyS');
await page.waitForTimeout(1500);
console.log('deep space audio',JSON.stringify(await rms(4)),'|',await page.textContent('#nearTxt'));
console.log('errors',errs.slice(0,10));
await browser.close();
