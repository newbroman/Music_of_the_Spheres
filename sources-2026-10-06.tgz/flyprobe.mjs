import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});const p=await b.newPage();p.on('pageerror',e=>console.log('ERR',e));
await p.goto('http://localhost:8123/flight.html');await p.waitForTimeout(800);
console.log(await p.evaluate(()=>[...document.querySelectorAll('button')].map(x=>x.id+':'+x.textContent.trim().slice(0,20)).slice(0,12).join(' | ')));
await p.click('#begin').catch(e=>console.log('no begin'));await p.waitForTimeout(1500);
await p.evaluate(()=>{window.__h={};MOTS.midi.on=true;const h=MOTS.midi.hold;MOTS.midi.hold=(id,f,l)=>{window.__h[id]=[Math.round(f),+l.toFixed(3)]}});
await p.waitForTimeout(3000);console.log(JSON.stringify(await p.evaluate(()=>window.__h)));
await b.close();
