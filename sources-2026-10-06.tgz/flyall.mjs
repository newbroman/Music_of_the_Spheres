import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required','--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});
for(const l of ['','pl/','cy/','de/','es/','fr/','it/','zh/','ja/']){const p=await b.newPage();const errs=[];p.on('pageerror',e=>errs.push(String(e)));
await p.goto(`http://localhost:8123/${l}flight.html`);await p.waitForTimeout(800);await p.click('#begin').catch(()=>{});await p.waitForTimeout(2500);
const t=await p.evaluate(()=>[document.getElementById('speedTxt')?.textContent,document.getElementById('speedOut')?.textContent]);console.log(l||'en/',JSON.stringify(t),errs.slice(0,2));await p.close()}
await b.close();
