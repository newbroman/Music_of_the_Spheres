// voices are built only while they can be heard; switching mode clears them and they rebuild in the new style
function applyVoiceMode(){
  if(!AC)return;const mode=S.voices;
  BODIES.forEach(b=>{const v=V[b.id];if(v.part&&v.mode!==mode){killPart(v.part);v.part=null;v.mode=null}});
  if(sunV.mode!==mode){
    killPart(sunV.part);
    if(mode==='human'){const part={g:mkGain(0,sunV.vol)};part.g.gain.setTargetAtTime(.9,AC.currentTime,.15);
      part.hums=APOLLO.map(sp=>{const h=makeHuman(sp,part.g,false);h.next=AC.currentTime+.6;return h});sunV.part=part;}
    else sunV.part=buildSunInst(sunV,sunV.mode!==null);
    sunV.mode=mode;
  }
}
const ensureHuman=applyVoiceMode;
function buildPart(b,v){v.part=S.voices==='human'?buildHumanPart(b,v):buildInst(b,v,true);v.mode=S.voices;v.born=AC.currentTime}
