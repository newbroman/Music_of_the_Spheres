import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
async function session(url){
  const page = await browser.newPage({viewport:{width:1200,height:800}});
  const errs=[];page.on('pageerror',e=>errs.push(String(e)));
  await page.addInitScript(()=>{
    const Orig=window.AudioContext;
    window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();this.__an.fftSize=8192;}};
    const oc=AudioNode.prototype.connect;
    AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return res};
  });
  await page.goto(url);await page.waitForTimeout(1500);
  return {page,errs};
}
// jumps: largest sample-to-sample step relative to the signal's typical step; clipping: samples near full scale
async function scan(page,secs){return page.evaluate(async(secs)=>{
  const an=window.__ac.__an,b=new Float32Array(an.fftSize);let worst=0,clip=0,rmsS=0,n=0;
  for(let k=0;k<secs*5;k++){await new Promise(r=>setTimeout(r,200));an.getFloatTimeDomainData(b);
    let s=0,mean=0;const d=[];for(let i=1;i<b.length;i++){const x=Math.abs(b[i]-b[i-1]);d.push(x);mean+=x;s+=b[i]*b[i];if(Math.abs(b[i])>.98)clip++}
    mean/=d.length;const mx=Math.max(...d);worst=Math.max(worst,mean>0?mx/mean:0);rmsS+=Math.sqrt(s/b.length);n++}
  return {rms:(rmsS/n).toFixed(4),worstJumpRatio:worst.toFixed(1),clippedSamples:clip};
},secs)}
for(const mode of ['instrument','human']){
  const {page,errs}=await session('file:///home/claude/music-of-the-spheres.html');
  await page.click('#begin');await page.waitForTimeout(800);
  await page.click(`#voices button[data-v="${mode}"]`);await page.waitForTimeout(2500);
  console.log(`2D ${mode} full choir`,JSON.stringify(await scan(page,5)));
  await page.click('.vrow[data-id="earth"] .nm');await page.waitForTimeout(2500);
  console.log(`2D ${mode} audition Gaia`,JSON.stringify(await scan(page,6)));
  await page.click('.vrow[data-id="earth"] .nm');await page.waitForTimeout(500);
  await page.click('.vrow[data-id="vesta"] .nm');await page.waitForTimeout(2500);
  console.log(`2D ${mode} audition Hestia`,JSON.stringify(await scan(page,8)),errs);
  await page.close();
}
{
  const {page,errs}=await session('file:///home/claude/flight.html');
  await page.click('#begin');await page.waitForTimeout(2000);
  console.log('3D near Earth',JSON.stringify(await scan(page,5)));
  await page.click('#navBtn');await page.click('#dest button[data-id="vesta"]');
  console.log('3D travelling to Hestia',JSON.stringify(await scan(page,8)));
  console.log('3D at Hestia',JSON.stringify(await scan(page,6)),errs);
}
await browser.close();
