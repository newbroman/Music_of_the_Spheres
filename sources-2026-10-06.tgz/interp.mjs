import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const page=await browser.newPage({viewport:{width:1300,height:1000}});const errs=[];page.on('pageerror',e=>errs.push(String(e)));
await page.addInitScript(()=>{const Orig=window.AudioContext;window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();this.__an.fftSize=2048;}};const oc=AudioNode.prototype.connect;AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return res};});
await page.goto('http://localhost:8123/index.html');await page.waitForTimeout(800);await page.click('#begin');await page.waitForTimeout(500);
const series=async(n)=>{const out=[];for(let k=0;k<n;k++){await page.waitForTimeout(500);out.push(await page.evaluate(()=>{const an=__ac.__an,b=new Float32Array(an.fftSize);an.getFloatTimeDomainData(b);let q=0;for(const x of b)q+=x*x;return Math.sqrt(q/b.length)}))}return out};
const fmt=a=>a.map(x=>x.toFixed(3)).join(' ');
for(const id of ['pythagoras','ptolemy','nicomachus','fludd','aristotle']){
  await page.click(`.tl-chip[data-t="${id}"]`);
  for(const mode of ['athens','text']){await page.click(`#interpSeg button[data-i="${mode}"]`);await page.waitForTimeout(600);
    const s=await series(id==='aristotle'?24:10);console.log(id.padEnd(11),mode.padEnd(7),'speed',await page.textContent('#speedTxt'),'|',fmt(s))}}
await page.click('.tl-chip[data-t="ptolemy"]');await page.click('#interpSeg button[data-i="athens"]');await page.waitForTimeout(3000);await page.screenshot({path:'th_ptolemy_athens.png'});
await page.click('.tl-chip[data-t="plato"]');await page.waitForTimeout(2500);await page.screenshot({path:'th_plato_athens.png'});
const card=await page.$('#info');await card.screenshot({path:'card_toggle.png'});
console.log('errors',errs);await browser.close();
