import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const [st,who,secs]=[process.argv[2],process.argv[3],+(process.argv[4]||12)];
const IDS=['sun','mercury','earth','mars','jupiter','jupiter-moons','saturn','venus','uranus','neptune'];
const page=await browser.newPage();page.on('pageerror',e=>console.log('ERR',String(e)));
await page.addInitScript(()=>{const Orig=window.AudioContext;window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();this.__an.fftSize=2048;}};const oc=AudioNode.prototype.connect;AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return res};
 window.__starts=0;const os=AudioBufferSourceNode.prototype.start;AudioBufferSourceNode.prototype.start=function(...a){if(this.buffer&&this.buffer.duration>2&&this.buffer.duration<2.7)window.__starts++;return os.apply(this,a)}});
await page.goto('http://localhost:8123/dance.html');await page.waitForTimeout(500);
await page.click(`#style button[data-v="${st}"]`);
for(const o of IDS)if(o!==who)await page.locator(`.mrow[data-id="${o}"] .mb`).click();
await page.click('#play');let mx=0,s=0,n=0;const secs2=[];
for(let k=0;k<secs*5;k++){await page.waitForTimeout(200);const r=await page.evaluate(()=>{const an=__ac.__an,b=new Float32Array(an.fftSize);an.getFloatTimeDomainData(b);let q=0;for(const x of b)q+=x*x;return Math.sqrt(q/b.length)});mx=Math.max(mx,r);s+=r;n++;const sc=await page.textContent('#secTxt');if(secs2.at(-1)!==sc)secs2.push(sc)}
console.log(st,who,'avg',(s/n).toFixed(3),'max',mx.toFixed(3),'sample notes',await page.evaluate(()=>__starts),secs2.join('→'));await browser.close();
