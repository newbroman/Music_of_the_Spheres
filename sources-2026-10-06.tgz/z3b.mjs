import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1200,height:760}});
await page.goto('file:///home/claude/flight.html');await page.waitForTimeout(2500);
await page.screenshot({path:'z_hud.png',clip:{x:0,y:0,width:600,height:200}});await browser.close();
