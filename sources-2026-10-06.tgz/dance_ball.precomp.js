
/* ================= BALLROOM & LATIN: each dance played by its own band ================= */
// Recorded instruments come from the Fluid R3 General MIDI SoundFont (Frank Wen, CC BY 3.0), loaded per style.
// Until they arrive, or if they cannot be fetched, the synthesised instruments below stand in.
const CADENCE='cadence';
const BALL_INST={
  waltz:{sun:'Bass drum and cymbals',mercury:'Triangle',earth:'Pizzicato strings',mars:'Timpani',jupiter:'Double basses','jupiter-moons':'Harp, 1 : 2 : 4',saturn:'Horns and strings',venus:'Solo violin and flute',uranus:'Cymbal roll and string swell',neptune:'Cellos'},
  tango:{sun:'Golpe on the bass',mercury:'Violin chicharra',earth:'Piano chords',mars:'Piano left hand',jupiter:'Double bass, 3-3-2','jupiter-moons':'Piano arpeggio, 1 : 2 : 4',saturn:'Bandoneons and strings',venus:'Solo violin',uranus:'Bandoneon swell',neptune:'Cellos'},
  samba:{sun:'Surdo',mercury:'Ganzá shaker',earth:'Tamborim',mars:'Agogô bells',jupiter:'Seven-string guitar','jupiter-moons':'Guitar, 1 : 2 : 4',saturn:'Cavaquinho',venus:'Flute',uranus:'Cymbal swell',neptune:'Sub'},
  chacha:{sun:'Timbales',mercury:'Güiro',earth:'Claves, son clave',mars:'Congas',jupiter:'Tumbao bass','jupiter-moons':'Pizzicato violins, 1 : 2 : 4',saturn:'Piano montuno and violins',venus:'Charanga flute',uranus:'Cymbal swell',neptune:'Sub'},
  swing:{sun:'Feathered bass drum',mercury:'Ride cymbal',earth:'Brushes',mars:'Tom fills',jupiter:'Walking bass','jupiter-moons':'Vibraphone, 1 : 2 : 4',saturn:'Saxophone section and piano',venus:'Muted trumpet',uranus:'Trombones and brass shouts',neptune:'Sub'},
  jive:{sun:'Bass drum',mercury:'Ride cymbal',earth:'Snare backbeat',mars:'Tom fills',jupiter:'Walking bass','jupiter-moons':'Electric guitar, 1 : 2 : 4',saturn:'Piano and saxophones',venus:'Tenor saxophone',uranus:'Trombones and brass shouts',neptune:'Sub'},
  fandango:{sun:'Cajón bass',mercury:'Castanets',earth:'Palmas (hand claps)',mars:'Cajón slaps',jupiter:'Guitar thumb','jupiter-moons':'Guitar picado, 1 : 2 : 4',saturn:'Rasgueado guitar',venus:'Cante (voice)',uranus:'Cymbal swell',neptune:'Sub'}
};
const BALL_SAMPLES={
  waltz:['string_ensemble_1','violin','contrabass','french_horn','pizzicato_strings','orchestral_harp','timpani','flute'],
  tango:['tango_accordion','violin','contrabass','acoustic_grand_piano','string_ensemble_1'],
  samba:['acoustic_guitar_nylon','acoustic_guitar_steel','agogo','flute'],
  chacha:['acoustic_grand_piano','acoustic_bass','flute','string_ensemble_1','pizzicato_strings'],
  swing:['acoustic_bass','acoustic_grand_piano','alto_sax','tenor_sax','muted_trumpet','trombone','trumpet','vibraphone'],
  jive:['acoustic_bass','acoustic_grand_piano','alto_sax','tenor_sax','trumpet','trombone','electric_guitar_clean'],
  fandango:['acoustic_guitar_nylon']
};
Object.assign(STYLES,{
  waltz:{gain:2.3,name:'Waltz',fam:'ball',beats:3,bpm:174,mode:'C',swing:0,kickF:[95,48,.45],kickLvl:.25,duck:.92,arp:.55,arpV:'harp',lead:.9,leadLen:1.6,pads:'strings',buildBars:8},
  tango:{gain:2.8,name:'Tango',fam:'ball',beats:4,bpm:118,mode:'A',swing:0,kickF:[110,50,.4],kickLvl:.5,duck:.9,arp:.45,arpV:'piano',lead:.9,leadLen:1.3,pads:'strings',buildBars:4},
  samba:{gain:1.65,name:'Samba',fam:'ball',beats:4,bpm:104,mode:'G',swing:.08,kickF:[95,55,.3],kickLvl:.6,duck:.85,arp:.5,arpV:'guitar',lead:.8,pads:'none',buildBars:4},
  chacha:{gain:2.6,name:'Cha-cha',fam:'ball',beats:4,bpm:120,mode:'D',swing:0,kickF:[120,52,.35],kickLvl:.55,duck:.85,arp:.45,arpV:'pizz',lead:1,pads:'none',buildBars:4},
  swing:{gain:1.9,name:'Swing',fam:'ball',beats:4,bpm:140,mode:'G',swing:0,swing8:.667,kickF:[90,50,.35],kickLvl:.18,duck:.97,arp:.45,arpV:'vibes',lead:.85,leadLen:1.2,pads:'none',buildBars:4},
  jive:{gain:1.5,name:'Jive',fam:'ball',beats:4,bpm:172,mode:'G',swing:0,swing8:.667,kickF:[100,50,.35],kickLvl:.5,duck:.9,arp:.45,arpV:'eguitar',lead:.85,pads:'none',buildBars:8},
  fandango:{gain:1.45,name:'Fandango',fam:'ball',beats:3,bpm:168,mode:'E',swing:0,kickF:[100,50,.3],kickLvl:.6,duck:.85,arp:.5,arpV:'guitar',lead:.9,leadLen:1.8,pads:'none',buildBars:8,cadence:true}
});
// jungle (with the club styles), the slow waltz, and Bach-style counterpoint
Object.assign(BALL_INST,{
  jungle:{sun:'Breakbeat kick',mercury:'Break hats',earth:'Break snares',mars:'Break edits',jupiter:'Reese bass','jupiter-moons':'Arpeggio, 1 : 2 : 4',saturn:'Pads',venus:'Ragga chops',uranus:'Risers',neptune:'Sub'},
  slowwaltz:BALL_INST.waltz,
  baroque:{sun:'Timpani (in the climax)',mercury:'Countersubject (harpsichord)',earth:'Trumpet (in the climax)',mars:'The answer (oboe)',jupiter:'Continuo bass (cello)','jupiter-moons':'Harpsichord, 1 : 2 : 4',saturn:'Continuo harpsichord, then organ',venus:'The subject (violin)',uranus:'Organ swell',neptune:'Organ pedal'}
});
Object.assign(BALL_SAMPLES,{jungle:[],slowwaltz:BALL_SAMPLES.waltz,baroque:['harpsichord','church_organ','cello','violin','oboe','trumpet','timpani']});
Object.assign(STYLES,{
  jungle:{gain:1,name:'Jungle',fam:'ball',beats:4,bpm:166,mode:'A',swing:0,kickF:[160,48,.22],kickLvl:.9,duck:.45,arp:.35,arpV:'synth',lead:.6,pads:'saw',buildBars:8},
  slowwaltz:{gain:2.8,name:'Slow waltz',fam:'ball',beats:3,bpm:90,mode:'C',swing:0,kickF:[90,48,.45],kickLvl:.2,duck:.95,arp:.5,arpV:'harp',lead:.9,leadLen:1.3,pads:'strings',buildBars:4},
  baroque:{gain:3.2,name:'Bach',fam:'ball',beats:4,bpm:80,mode:'A',swing:0,kickF:[90,48,.4],kickLvl:.3,duck:.95,arp:.25,arpV:'harpsi',lead:0,pads:'none',buildBars:4,noSub:true}
});
Object.keys(BALL_INST).forEach(k=>{STYLES[k].inst=BALL_INST[k];STYLES[k].samples=BALL_SAMPLES[k]});

/* ---- the sampler ---- */
const SMP={man:null,base:null,buf:{},ready:{},loading:{},tried:false};
const SMP_ABS='https://newbroman.github.io/Music_of_the_Spheres/samples/';
const smpReady=n=>!!SMP.ready[n];
async function smpManifest(){
  if(SMP.man)return true;if(SMP.tried)return false;SMP.tried=true;
  const rel=(location.pathname.includes('/pl/')?'../':'')+'samples/';
  for(const b of location.protocol==='file:'?[SMP_ABS]:[rel,SMP_ABS]){try{const u=new URL(b,location.href).href,r=await fetch(u+'manifest.json');if(r.ok){SMP.man=await r.json();SMP.base=u;return true}}catch(e){}}
  return false;
}
function smpLoad(n){
  if(SMP.loading[n])return SMP.loading[n];const info=SMP.man&&SMP.man[n];if(!info)return Promise.resolve(false);
  const list=[];
  return SMP.loading[n]=Promise.all(info.notes.map(m=>fetch(`${SMP.base}${n}/${m}.mp3`).then(r=>{if(!r.ok)throw 0;return r.arrayBuffer()}).then(ab=>new Promise((ok,no)=>AC.decodeAudioData(ab,ok,no))).then(buf=>list.push({m,buf}))))
    .then(()=>{list.sort((a,c)=>a.m-c.m);SMP.buf[n]=list;SMP.ready[n]=true;return true}).catch(()=>{delete SMP.loading[n];return false});
}
let smpMsg='';
async function loadStyleSamples(){
  const st=STY(),names=st.samples;if(!AC||!names)return;
  if(names.every(smpReady))return;
  const k=D.style;smpMsg=k;toast(SMPTXT.tuning);
  if(!(await smpManifest())){if(smpMsg===k)toast(SMPTXT.synth);return}
  const ok=await Promise.all(names.map(smpLoad));
  if(smpMsg===k&&D.style===k)toast(ok.every(Boolean)?SMPTXT.ready:SMPTXT.synth);
}
const SMPTXT={tuning:'The band is tuning up…',ready:'The band is ready',synth:'Recorded instruments unavailable: playing synthesised ones'};
// play one recorded note at any frequency: the nearest sample, re-pitched
function samp(n,t,f,len,lvl,id,o={}){
  if(!SMP.ready[n])return false;
  const L=SMP.buf[n],midi=69+12*Math.log2(f/440);let best=L[0];for(const x of L)if(Math.abs(x.m-midi)<Math.abs(best.m-midi))best=x;
  const src=AC.createBufferSource();src.buffer=best.buf;const rate=Math.pow(2,(midi-best.m)/12);src.playbackRate.value=rate;
  const g=AC.createGain(),pk=lvl*SMP.man[n].gain,att=o.att||.004,rel=o.rel||.12;
  const end=Math.max(t+att,Math.min(t+len,t+best.buf.duration/rate-rel));
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(pk,t+att);g.gain.setValueAtTime(pk,end);g.gain.linearRampToValueAtTime(0,end+rel);
  src.connect(g);g.connect(toPan(id));const rv=o.rev===undefined?.25:o.rev;if(rv)g.connect(mkG(rv,revSend));
  src.start(t);src.stop(end+rel+.05);if(o.flash!==false)flash(id,t);return true;
}
function sChord(n,t,degs,oct,len,lvl,id,o={}){if(!SMP.ready[n])return false;degs.forEach((d,k)=>samp(n,t+(o.spread||0)*k,noteF(d,oct),len,lvl,id,{...o,flash:false}));flash(id,t);return true}
/* ---- instruments ---- */
const toPan=id=>PAN[id]||drumBus;
// a hammered string: a triangle body with a little sawtooth brightness, the felt closing quickly
function piano(t,f,len,lvl,id){
  const g=mkG(0,toPan(id)),lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.setValueAtTime(Math.min(8000,f*9),t);lp.frequency.setTargetAtTime(Math.max(600,f*2.5),t,.15);
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(lvl,t+.004);g.gain.setTargetAtTime(lvl*.35,t+.004,.09);g.gain.setTargetAtTime(0,t+len,.08);
  const o1=AC.createOscillator(),o2=AC.createOscillator();o1.type='triangle';o2.type='sawtooth';o1.frequency.value=f;o2.frequency.value=f*1.0015;
  o1.connect(lp);o2.connect(mkG(.16,lp));lp.connect(g);g.connect(mkG(.3,revSend));
  const end=t+len+.6;o1.start(t);o2.start(t);o1.stop(end);o2.stop(end);
}
function pchord(t,degs,oct,len,lvl,id){degs.forEach((d,k)=>piano(t+k*.004,noteF(d,oct),len,lvl,id));flash(id,t)}
// a plucked nylon string
function nylon(t,f,lvl,dec,id){
  const o=AC.createOscillator();o.type='sawtooth';o.frequency.value=f;const lp=AC.createBiquadFilter();lp.type='lowpass';lp.Q.value=1;
  lp.frequency.setValueAtTime(Math.min(7000,f*7),t);lp.frequency.setTargetAtTime(f*1.3,t,dec*.25);
  const g=mkG(0,toPan(id));env(g,t,lvl,.002,dec);o.connect(lp);lp.connect(g);g.connect(mkG(.25,revSend));o.start(t);o.stop(t+dec*5+.05);
}
function strum(t,degs,oct,lvl,gap,up,id,dec=.35){const d=up?[...degs].reverse():degs;d.forEach((x,k)=>nylon(t+k*gap,noteF(x,oct),lvl*(up?.8:1),dec,id));flash(id,t)}
// the bandoneon: two reeds a few cents apart and a lower reed, through a soft bellows filter
function reed(t,degs,len,lvl,swell){
  degs.forEach(d=>{const f=noteF(d,4),g=mkG(0,PAN.saturn);g.connect(mkG(.3,revSend));
    const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=2300;lp.Q.value=.7;lp.connect(g);
    [-7,7].forEach(c=>{const o=AC.createOscillator();o.type='sawtooth';o.frequency.value=f;o.detune.value=c;o.connect(lp);o.start(t);o.stop(t+len+.15)});
    if(!LOWPOWER){const sq=AC.createOscillator();sq.type='square';sq.frequency.value=f/2;sq.connect(mkG(.3,lp));sq.start(t);sq.stop(t+len+.15)}
    const a=swell?len*.9:.012;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(lvl,t+a);g.gain.setValueAtTime(lvl,t+Math.max(a,len*.85));g.gain.linearRampToValueAtTime(0,t+len+.03)});
  flash('saturn',t);
}
// a plucked double bass
function abass(t,f,len,lvl=.5){
  const o=AC.createOscillator(),o2=AC.createOscillator();o.type='sine';o2.type='triangle';o.frequency.setValueAtTime(f*1.03,t);o.frequency.setTargetAtTime(f,t,.015);o2.frequency.value=f;
  const g=mkG(0,PAN.jupiter);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(lvl,t+.006);g.gain.setTargetAtTime(lvl*.45,t+.006,.12);g.gain.setTargetAtTime(0,t+len,.05);
  o.connect(g);o2.connect(mkG(.35,g));const end=t+len+.4;o.start(t);o2.start(t);o.stop(end);o2.stop(end);flash('jupiter',t);
}
// percussion
function noiseHit(t,dur,type,f,q,lvl,att,dec,id,rev=.15){const n=noise(t,dur),fl=AC.createBiquadFilter();fl.type=type;fl.frequency.value=f;fl.Q.value=q;const g=mkG(0,toPan(id));env(g,t,lvl,att,dec);n.connect(fl);fl.connect(g);if(rev)g.connect(mkG(rev,revSend))}
function toneHit(t,f0,f1,type,lvl,dec,id,glide=.05){const o=AC.createOscillator();o.type=type;o.frequency.setValueAtTime(f0,t);if(f1!==f0)o.frequency.exponentialRampToValueAtTime(f1,t+glide);const g=mkG(0,toPan(id));env(g,t,lvl,.001,dec);o.connect(g);o.start(t);o.stop(t+dec*6+.05)}
function shaker(t,v){noiseHit(t,.12,'highpass',5200,.7,.13*v,.006,.022,'mercury',.05);flash('mercury',t)}
function castanet(t,v){[0,.013].forEach(d=>noiseHit(t+d,.03,'bandpass',3200,5,.32*v,.0005,.005,'mercury',.1));flash('mercury',t)}
function claves(t,v){toneHit(t,2500,2500,'sine',.2*v,.03,'earth');flash('earth',t)}
function tamborim(t,v){toneHit(t,900,820,'sine',.2*v,.04,'earth');noiseHit(t,.03,'bandpass',4000,2,.14*v,.0005,.006,'earth',0);flash('earth',t)}
function brush(t,v,long){noiseHit(t,long?.3:.15,'bandpass',3600,.6,.16*v,long?.03:.008,long?.09:.035,'earth',.2);flash('earth',t)}
function agogo(t,hi,v){const f=hi?905:678;[[1,.15,.09],[2.74,.05,.03]].forEach(([r,a,d])=>{const o=AC.createOscillator();o.type='sine';o.frequency.value=f*r;const g=mkG(0,PAN.mars);env(g,t,a*v,.001,d);o.connect(g);o.start(t);o.stop(t+.6)});flash('mars',t)}
function conga(t,kind,v){
  if(kind==='slap'){noiseHit(t,.06,'bandpass',1900,1.4,.32*v,.0008,.018,'mars',.1);toneHit(t,420,380,'sine',.14*v,.03,'mars')}
  else toneHit(t,kind==='open'?330:250,kind==='open'?300:230,'sine',(kind==='mute'?.12:.32)*v,kind==='mute'?.03:.13,'mars');
  flash('mars',t);
}
function surdo(t,open,v){toneHit(t,95,58,'sine',(open?.75:.38)*v,open?.28:.07,'sun',.08);noiseHit(t,.03,'lowpass',600,.7,.14*v,.001,.01,'sun',0);flash('sun',t);if(open)duckIt(t)}
function cajon(t,low,v){
  if(low){toneHit(t,120,70,'sine',.7*v,.12,'sun',.04);noiseHit(t,.08,'lowpass',500,.7,.25*v,.001,.03,'sun',.05);flash('sun',t);duckIt(t)}
  else{noiseHit(t,.1,'bandpass',2300,1,.4*v,.0008,.03,'mars',.15);toneHit(t,240,200,'triangle',.12*v,.03,'mars');flash('mars',t)}
}
function ride(t,v){
  noiseHit(t,.5,'highpass',7000,.7,.07*v,.001,.12,'mercury',.15);
  if(!LOWPOWER)[523,797].forEach(f=>{const o=AC.createOscillator();o.type='square';o.frequency.value=f*2.3;const hp=AC.createBiquadFilter();hp.type='highpass';hp.frequency.value=4000;const g=mkG(0,PAN.mercury);env(g,t,.018*v,.001,.15);o.connect(hp);hp.connect(g);o.start(t);o.stop(t+.9)});
  flash('mercury',t);
}
function chick(t,v){noiseHit(t,.05,'highpass',8000,.7,.09*v,.001,.01,'mercury',0)}
function timp(t,f,v){toneHit(t,f*1.03,f,'sine',.42*v,.45,'mars',.06);toneHit(t,f*2.01,f*2,'sine',.09*v,.2,'mars',.06);flash('mars',t)}
function guiro(t,long,v){
  const n=noise(t,long?.2:.08),bp=AC.createBiquadFilter();bp.type='bandpass';bp.Q.value=3;bp.frequency.setValueAtTime(2600,t);bp.frequency.linearRampToValueAtTime(3600,t+(long?.16:.06));
  const am=AC.createGain();am.gain.value=.5;const lfo=AC.createOscillator();lfo.type='square';lfo.frequency.value=46;lfo.connect(mkG(.5,am.gain));
  const g=mkG(0,PAN.mercury);env(g,t,.2*v,.005,long?.07:.025);n.connect(bp);bp.connect(am);am.connect(g);lfo.start(t);lfo.stop(t+(long?.25:.12));flash('mercury',t);
}


/* ---- a few more synthesised sounds for the bands ---- */
function triangleBell(t,v){[[5400,.06,.6],[7930,.03,.4],[11800,.015,.3]].forEach(([f,a,d])=>toneHit(t,f,f,'sine',a*v,d,'mercury'));flash('mercury',t)}
function timbale(t,v){toneHit(t,380,350,'sine',.22*v,.12,'sun');noiseHit(t,.08,'bandpass',3000,1.2,.2*v,.0008,.03,'sun',.15);flash('sun',t)}
function golpe(t,v){toneHit(t,85,60,'sine',.4*v,.06,'sun',.03);noiseHit(t,.05,'lowpass',900,.7,.12*v,.001,.02,'sun',.05);flash('sun',t)}
function chicharra(t,v){
  const n=noise(t,.12),bp=AC.createBiquadFilter();bp.type='bandpass';bp.frequency.value=1500;bp.Q.value=2.5;
  const am=AC.createGain();am.gain.value=.5;const lfo=AC.createOscillator();lfo.type='sawtooth';lfo.frequency.value=72;lfo.connect(mkG(.5,am.gain));
  const g=mkG(0,PAN.mercury);env(g,t,.16*v,.004,.04);n.connect(bp);bp.connect(am);am.connect(g);lfo.start(t);lfo.stop(t+.15);flash('mercury',t);
}
function cymbalSwell(t,dur,v){
  const n=AC.createBufferSource();n.buffer=noiseBuf;n.loop=true;const hp=AC.createBiquadFilter();hp.type='highpass';hp.frequency.value=5500;
  const g=mkG(0,PAN.uranus);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.001,t+dur*.3);g.gain.exponentialRampToValueAtTime(.16*v,t+dur);g.gain.setTargetAtTime(0,t+dur,.25);
  n.connect(hp);hp.connect(g);g.connect(mkG(.4,revSend));n.start(t);n.stop(t+dur+1.2);flash('uranus',t);
}
// the trumpets and trombones together, for shouts at the drop
function brassShout(t,deg,len){
  const ok=sChord('trumpet',t,chordTones(deg),4,len,.42,'uranus',{att:.012,rel:.15});
  sChord('trombone',t,[deg,deg+4],3,len,.42,'uranus',{att:.015,rel:.15});return ok;
}
// Ouranos' build: each band swells in its own way
function ballRiser(t,dur){
  const deg=D.prog[0], k=D.style;
  if(k==='waltz'){cymbalSwell(t,dur,1);sChord('string_ensemble_1',t,chordTones(deg),4,dur,.3,'uranus',{att:dur*.9,rel:.2})}
  else if(k==='tango'){if(!sChord('tango_accordion',t,chordTones(deg),4,dur,.4,'uranus',{att:dur*.9,rel:.1}))reed(t,chordTones(deg),dur,.06,true)}
  else if(k==='swing'||k==='jive'){cymbalSwell(t,dur,.8);sChord('trombone',t,[deg,deg+2,deg+4],3,dur,.38,'uranus',{att:dur*.85,rel:.12})}
  else if(k==='jungle')riser(t,dur);
  else if(k==='baroque'){if(!sChord('church_organ',t,[deg-7,deg,deg+2,deg+4],3,dur,.3,'uranus',{att:dur*.9,rel:.15}))cymbalSwell(t,dur,.4)}
  else cymbalSwell(t,dur,k==='fandango'?.6:1);
  flash('uranus',t);
}

// the jungle bass: two detuned saws through a slowly moving filter, with a sine sub beneath
function reese(t,f,len){
  const g=mkG(0,PAN.jupiter),lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=420;lp.Q.value=3;lp.connect(g);
  const lfo=AC.createOscillator();lfo.frequency.value=.6;lfo.connect(mkG(240,lp.frequency));lfo.start(t);lfo.stop(t+len+.2);
  [-16,16].forEach(c=>{const o=AC.createOscillator();o.type='sawtooth';o.frequency.value=f*2;o.detune.value=c;o.connect(lp);o.start(t);o.stop(t+len+.15)});
  const sub=AC.createOscillator();sub.type='sine';sub.frequency.value=f;sub.connect(mkG(1.2,g));sub.start(t);sub.stop(t+len+.15);
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.32,t+.015);g.gain.setValueAtTime(.32,t+len*.9);g.gain.linearRampToValueAtTime(0,t+len+.1);
  flash('jupiter',t);
}
// a two-bar fugue subject the sky composes from Aphrodite's sign: chord tones on the beats, stepwise motion between,
// in a mix of quavers and semiquavers, ending on a long note
function bachSubject(){
  const key=signOf('venus');if(D.subjKey===key)return D.subj;D.subjKey=key;
  const r=rng(key*41+11),RH=[[1,0,1,0],[1,1,1,1],[1,0,1,1],[1,1,1,0],[1,0,0,0]],CT=[-3,0,2,4,7,9],S=new Array(32).fill(null);
  let cur=[0,2,4][Math.floor(r()*3)],last=null;
  for(let b=0;b<8;b++){const p=b===7?[1,0,0,0]:b===0?[1,0,1,0]:RH[Math.floor(r()*4)];
    for(let i=0;i<4;i++){if(!p[i])continue;
      if(i===0){const near=CT.filter(c=>Math.abs(c-cur)<=2&&c!==cur);cur=b===7?(Math.abs(cur)<Math.abs(cur-7)?0:7):near.length?near[Math.floor(r()*near.length)]:0}
      else cur+=(r()<.55?1:-1)*(r()<.85?1:2);
      cur=Math.max(-3,Math.min(8,cur));if(cur===last&&b<7)cur+=cur<3?1:-1;S[b*4+i]=last=cur}}
  return D.subj=S;
}
function bachVoice(S,idx,t,deg,oct,inst,lvl,id,stepT,inv){
  const v=S[idx];if(v===null)return;let n=1;while(n<8&&S[(idx+n)%32]===null)n++;
  const f=noteF(deg+(inv?4-v:v),oct),hp=inst==='harpsichord';
  samp(inst,t,f,stepT*n*(hp?1.2:.95),lvl,id,{att:hp?.002:.03,rel:hp?.25:.08})||pluck(t,f,lvl*.15,'triangle',stepT*n,id);
}

/* ---- the patterns: the same planets, a different band ---- */
function ballStep(s,pos,bar,t,st,L,deg,stepT,m,into,spb){
  const nxt=D.prog[(bar+1)%4], sec=D.section, sw=!!st.swing8, drop=sec==='drop', bd=barDur();
  const dropStart=drop&&into===0&&pos===0;
  switch(D.style){
  case 'waltz':case 'slowwaltz':
    // a Viennese orchestra: basses on the one, horns and pizzicato on two and three, strings singing over all
    if(L.kick&&m('sun')&&pos===0){kick(t);if(dropStart||(drop&&bar%4===0))noiseHit(t,1.6,'highpass',5000,.7,.14,.002,.5,'sun',.3)}
    if(L.bass&&m('jupiter')&&pos===0){const f=noteF(bar%2?deg-3:deg,2);samp('contrabass',t,f,stepT*3.6,.7,'jupiter',{att:.012,rel:.18})||abass(t,f,stepT*3.8)}
    if(L.pads&&m('saturn')){
      if(pos===4||pos===8)sChord('french_horn',t,chordTones(deg),3,stepT*2.4,pos===4?.28:.22,'saturn',{att:.02,rel:.12})||pchord(t,chordTones(deg),4,stepT*2.2,pos===4?.085:.07,'saturn');
      if(pos===0)sChord('string_ensemble_1',t,[deg-7,deg,deg+2,deg+4],4,bd*1.02,.2*L.pads,'saturn',{att:.12,rel:.35,flash:false})}
    if(L.clap&&m('earth')&&(pos===4||pos===8))sChord('pizzicato_strings',t,chordTones(deg),4,stepT*2,.3*L.clap,'earth',{rel:.08})||brush(t,.7*L.clap,false);
    if(L.hats&&m('mercury')&&pos===0&&bar%2===0&&sec!=='intro')triangleBell(t,L.hats);
    if(L.toms&&m('mars')&&pos===0&&bar%4===0){const f=noteF(deg,2);samp('timpani',t,f,bd,.6,'mars',{rel:.3})||timp(t,f,.9)}
    break;
  case 'tango':{
    // an orquesta típica: bandoneons in marcato, the bass on the 3-3-2, piano chords and a solo violin
    if(L.kick&&m('sun')&&(pos===0||pos===8))golpe(t,pos===0?1:.7);
    if(L.bass&&m('jupiter')){const h={0:[0,5],6:[0,5],12:[4,3],14:drop?[nxt-deg-1,2]:null}[pos];if(h){const f=noteF(deg+h[0],2);samp('contrabass',t,f,stepT*h[1]*.8,1,'jupiter',{att:.008,rel:.1})||abass(t,f,stepT*h[1]*.9)}}
    const drag=bar%2===1&&sec!=='intro';
    if(L.pads&&m('saturn')){
      if(pos%4===0&&!(drag&&pos===12)){const len=stepT*(pos%8===0?1.6:1.1),lv=pos%8===0?.4:.3;sChord('tango_accordion',t,chordTones(deg),4,len,lv,'saturn',{att:.008,rel:.06})||reed(t,chordTones(deg),len,lv*.16,false)}
      if(drag&&pos===12)sChord('tango_accordion',t,chordTones(nxt),4,stepT*3.8,.4,'saturn',{att:stepT*3.4,rel:.05})||reed(t,chordTones(nxt),stepT*3.6,.065,true);
      if(pos===0)sChord('string_ensemble_1',t,chordTones(deg),4,bd*1.02,.14*L.pads,'saturn',{att:.15,rel:.3,flash:false})}
    if(L.clap&&m('earth')&&(pos===4||pos===12))sChord('acoustic_grand_piano',t,chordTones(deg),4,stepT*1.2,.32*L.clap,'earth',{rel:.1})||brush(t,.6*L.clap,false);
    if(L.hats&&m('mercury')&&(drop||sec==='groove')&&pos%4===2&&bar%2===0)chicharra(t,L.hats);
    if(L.toms&&m('mars')){const tp=D.tomPat[pos];if(tp!==null&&bar%2){const f=noteF(deg+tp,2);if(samp('acoustic_grand_piano',t,f,stepT*1.4,.6,'mars',{rel:.1}))samp('acoustic_grand_piano',t,f*2,stepT*1.4,.45,'mars',{rel:.1,flash:false});else{piano(t,f,stepT*1.5,.16,'mars');flash('mars',t)}}}
    break;}
  case 'samba':
    // a roda de samba: surdo, ganzá, tamborim and agogô, with seven-string guitar and cavaquinho
    if(L.kick&&m('sun')&&pos%4===0)surdo(t,pos===4||pos===12,1);
    if(L.hats&&m('mercury'))shaker(t,[.55,.25,.35,.85][pos%4]*L.hats*2.5);
    if(L.clap&&m('earth')&&[0,3,6,10,12].includes(pos))tamborim(t,L.clap*(pos===0?2.5:1.9));
    if(L.toms&&m('mars')){const hi=[0,3,6,10].includes(pos),lo=[8,12,14].includes(pos);if(hi||lo){if(!samp('agogo',t,hi?905:678,.3,.8,'mars',{rel:.05,rev:.15}))agogo(t,hi,.8)}}
    if(L.bass&&m('jupiter')){const h={0:[0,.8],3:[0,.6],4:[4,1.8],8:[0,.8],11:[0,.6],12:[-3,1.8]}[pos];if(h){const f=noteF(deg+h[0],2);samp('acoustic_guitar_nylon',t,f,stepT*h[1]*2,.35,'jupiter',{rel:.08})||abass(t,f,stepT*h[1]*2)}}
    if(L.pads&&m('saturn')&&[0,3,6,10,13].includes(pos)){const up=pos%2===1,V=chordTones(deg).concat([deg+7]);
      if(smpReady('acoustic_guitar_steel')){(up?[...V].reverse():V).forEach((d,k)=>samp('acoustic_guitar_steel',t+k*.008,noteF(d,4),stepT*1.6,up?.16:.2,'saturn',{rel:.06,flash:false}));flash('saturn',t)}
      else strum(t,V,4,.055,.008,up,'saturn',.18)}
    break;
  case 'chacha':
    // a charanga: flute and violins over piano montuno, tumbao bass, güiro, claves, congas and timbales
    if(L.kick&&m('sun')&&(pos===0||pos===14||(drop&&pos===6)))timbale(t,pos===0?1:.75);
    if(L.bass&&m('jupiter')){const f=pos===6?noteF(deg,2):pos===12?noteF(nxt,2):0;if(f)samp('acoustic_bass',t,f,stepT*(pos===6?5.5:4),.6,'jupiter',{rel:.1})||abass(t,f,stepT*(pos===6?5.5:4))}
    if(L.pads&&m('saturn')){
      if([0,3,6,8,11,14].includes(pos))sChord('acoustic_grand_piano',t,chordTones(deg),4,stepT*1.3,.28,'saturn',{rel:.08})||pchord(t,chordTones(deg),4,stepT*1.3,.07,'saturn');
      if((sec==='groove'||drop)&&(pos===0||pos===8))sChord('string_ensemble_1',t,chordTones(deg),5,stepT*2.5,.16,'saturn',{att:.02,rel:.12,flash:false})}
    if(L.hats&&m('mercury')){if(pos===0||pos===4||pos===8)guiro(t,true,L.hats);else if(pos===12||pos===14)guiro(t,false,L.hats)}
    if(L.clap&&m('earth')&&(bar%2===0?[4,8]:[0,6,12]).includes(pos))claves(t,L.clap);
    if(L.toms&&m('mars')){if(pos===4)conga(t,'slap',1);else if(pos===12||pos===14)conga(t,'open',1);else if(pos===0||pos===8)conga(t,'mute',1)}
    break;
  case 'swing':case 'jive':{
    // a big band (swing) and a jump-blues band (jive): swung eighths, walking bass, saxes, brass and drums
    if(pos%2)break;
    const jive=D.style==='jive';
    if(L.kick&&m('sun')&&pos%4===0)kick(t);
    if(L.hats&&m('mercury')){if([0,4,6,8,12,14].includes(pos))ride(t,L.hats*(pos===6||pos===14?.6:1));if(pos===4||pos===12)chick(t,.8)}
    if(L.clap&&m('earth')&&(pos===4||pos===12)){if(jive)snare(t,.85*L.clap);else brush(t,2.6*L.clap,true)}
    if(L.bass&&m('jupiter')&&pos%4===0){const wl=[deg,deg+2,deg+4,nxt+((bar+signOf('jupiter'))%2?1:-1)],f=noteF(wl[pos/4],2);samp('acoustic_bass',t,f,stepT*3.4,.5,'jupiter',{rel:.08})||abass(t,f,stepT*3.6,.48)}
    if(L.pads&&m('saturn')){
      if(!jive&&(pos===0||pos===6)){const len=stepT*(pos===0?3:5);const a=sChord('tenor_sax',t,[deg,deg+2],3,len,.28,'saturn',{att:.02,rel:.1});sChord('alto_sax',t,[deg+4,deg+6],3,len,.26,'saturn',{att:.02,rel:.1,flash:false});if(!a)pchord(t,chordTones(deg),4,stepT*2.5,.07,'saturn')}
      if(!jive&&pos===14&&bar%2)sChord('acoustic_grand_piano',t,chordTones(deg),5,stepT*1.2,.22,'saturn',{rel:.08,flash:false});
      if(jive&&[4,12,14].includes(pos))sChord('acoustic_grand_piano',t,chordTones(deg),4,stepT*1.4,.3,'saturn',{rel:.08})||pchord(t,chordTones(deg),4,stepT*1.4,.07,'saturn');
      if(jive&&drop&&(pos===0||pos===6)){sChord('tenor_sax',t,[deg,deg+4],3,stepT*(pos===0?2:1.6),.22,'saturn',{att:.01,rel:.08,flash:false});sChord('alto_sax',t,[deg+2],4,stepT*(pos===0?2:1.6),.2,'saturn',{att:.01,rel:.08,flash:false})}}
    if(dropStart&&m('uranus'))brassShout(t,deg,stepT*5);
    if(drop&&m('uranus')&&bar%4===3&&pos===12)brassShout(t,nxt,stepT*3);
    if(L.toms&&m('mars')&&bar%4===3&&pos>=8&&sec!=='intro')tom(t,noteF(deg+(14-pos)/2,3),.8);
    break;}
  case 'fandango':{
    // flamenco: cajón, castanets, palmas and the guitar, with the cante over it
    if(L.kick&&m('sun')&&(pos===0||(pos===8&&drop)))cajon(t,true,1);
    if(L.toms&&m('mars')&&(pos===4||pos===8||(pos===10&&bar%2)))cajon(t,false,pos===10?.6:1);
    if(L.clap&&m('earth')&&(sec==='groove'||drop)){if(pos%4===0)clap(t,pos===0?.9:.65);else if(pos%4===2&&drop)clap(t,.3)}
    if(L.hats&&m('mercury')){if(pos%2===0)castanet(t,L.hats*(pos%4===0?1:.6));if(pos===10){castanet(t+stepT*.66,.5*L.hats);castanet(t+stepT*1.33,.6*L.hats)}}
    if(L.bass&&m('jupiter')&&(pos===0||pos===8)){const f=noteF(pos===0?deg:deg-3,2);if(!samp('acoustic_guitar_nylon',t,f,stepT*4,.4,'jupiter',{rel:.1})){nylon(t,f,.32,.5,'jupiter');flash('jupiter',t)}}
    if(L.pads&&m('saturn')){const V=[deg-7,deg-3,deg,deg+2,deg+4,deg+7],g=smpReady('acoustic_guitar_nylon');
      const st2=(tt,vs,lv,gap,up,len)=>{if(g){(up?[...vs].reverse():vs).forEach((d,k)=>samp('acoustic_guitar_nylon',tt+k*gap,noteF(d,3),len,lv,'saturn',{rel:.06,flash:false}));flash('saturn',tt)}else strum(tt,vs,3,lv*.12,gap,up,'saturn',len*.4)};
      if(pos===0){st2(t,V,.3,.018,false,stepT*4);if(drop){st2(t+.045,V.slice(2),.25,.009,false,stepT*2);st2(t+.09,V.slice(2),.3,.009,false,stepT*3)}}
      else if(pos===4||pos===6)st2(t,V.slice(2),.24,.01,pos===6,stepT*2);
      else if(pos===8)st2(t,V,.27,.014,false,stepT*3)}
    break;}
  case 'jungle':{
    // a chopped breakbeat at 166: kick and snares from the break, Ares stuttering it from his sign, a Reese bass rolling underneath
    const edit=sec!=='intro'&&bar%2===1&&D.tomPat[pos]!==null;
    if(L.kick&&m('sun')&&(pos===0||pos===10||(pos===2&&bar%4===1)))kick(t);
    if(L.clap&&m('earth')){if(pos===4||pos===12)snare(t,1);else if([7,9,15].includes(pos))snare(t,.28)}
    if(L.hats&&m('mercury')&&pos%2===0)hat(t,pos%8===6,.55*L.hats);
    if(L.toms&&m('mars')&&edit){[0,.33,.66].forEach(d=>snare(t+stepT*d,.35));flash('mars',t)}
    if(L.bass&&m('jupiter')&&(pos===0||(pos===8&&bar%2===1)))reese(t,noteF(pos===0?deg:deg-3,1),stepT*(pos===0&&bar%2===0?15.5:7.5));
    break;}
  case 'baroque':{
    // counterpoint: the sky's subject, its answer, an inverted countersubject and a walking continuo
    const S=bachSubject(),org=drop,ex=sec==='intro',idx=(bar%2)*16+pos;
    const lag=sec==='build'?8:16;   // stretto: in the build the answer crowds in after half a bar
    if(m('venus'))bachVoice(S,idx,t,deg,5,org?'church_organ':'violin',org?.3:.45,'venus',stepT);
    if(m('mars')&&!(ex&&into<2)&&sec!=='break')bachVoice(S,(idx-lag+32)%32,t,deg,4,org?'church_organ':'oboe',org?.26:.42,'mars',stepT);
    if(m('mercury')&&!(ex&&into<4))bachVoice(S,(idx+8)%32,t,deg,4,org?'church_organ':'harpsichord',org?.24:.4,'mercury',stepT,true);
    if(m('jupiter')&&!(ex&&into<4)&&pos%2===0){const BL=[0,2,4,2,-3,-1,1];const k=pos/2,d=k===7?nxt-1:deg+BL[k],f=noteF(d,2);samp('cello',t,f,stepT*1.8,.5,'jupiter',{att:.02,rel:.06})||abass(t,f,stepT*1.8,.4)}
    if(m('saturn')&&!(ex&&into<4)){if(org){if(pos===0)sChord('church_organ',t,chordTones(deg),4,bd,.2,'saturn',{att:.04,rel:.15})}else if(pos===0||pos===8)sChord('harpsichord',t,[deg-7,deg,deg+2,deg+4],3,stepT*7,.26,'saturn',{spread:.025})}
    if(org&&m('neptune')&&pos===0)samp('church_organ',t,noteF(deg,1),bd,.4,'neptune',{att:.05,rel:.2});
    if(org&&m('earth')&&(pos===0||pos===8))samp('trumpet',t,noteF(deg+4,4),stepT*6,.3,'earth',{att:.02,rel:.15});
    if(org&&m('sun')&&(pos===0||pos===8||(pos===14&&bar%2)))samp('timpani',t,noteF(pos===8?deg-3:deg,2),stepT*4,.5,'sun',{rel:.25});
    break;}
  }
  // the build: a timpani roll from Ares that quickens toward the drop (jungle rolls its snare; Bach builds by stretto instead)
  if(D.style==='jungle'){if(sec==='build'&&m('earth')){const prog=(into+pos/spb)/D.secLen,every=prog<.5?4:prog<.75?2:1;if(pos%every===0)snare(t,.3+.7*prog)}}
  else if(D.style==='baroque'){}
  else {
    if(sec==='build'&&m('mars')&&!(sw&&pos%2)){const prog=(into+pos/spb)/D.secLen,every=prog<.5?4:prog<.75?2:1;if(pos%every===0){const f=noteF(0,2),v=.2+.55*prog;samp('timpani',t,f,stepT*every*1.5,v*.7,'mars',{rel:.15})||timp(t,f,v)}}
  }
  // Jupiter's moons, still in their 1:2:4 resonance, counted across the bar lines
  if(L.arp&&m('jupiter-moons')&&!(sw&&pos%2)){const lv=L.arp*st.arp,tones=chordTones(deg).concat([deg+7]),up=moonWaxing(),k=s>>1;
    if(s%2===0)moonNote(t,noteF(tones[up?k%4:3-k%4],5),.06*lv,stepT*3,'io',st.arpV);
    if(s%4===0)moonNote(t,noteF(tones[((s>>2)+1)%3],4),.07*lv,stepT*5,'europa',st.arpV);
    if(s%8===0)moonNote(t,noteF(tones[(s>>3)%3],6),.045*lv,stepT*7,'ganymede',st.arpV);}
  // Aphrodite's line, played by the band's solo instrument
  if(L.lead*st.lead>.2&&D.style!=='baroque'&&m('venus')&&!(sw&&pos%2)){const mm=D.motif[(bar%2)*16+pos];if(mm&&(L.lead>=.3||pos%8===0)){
    const f=noteF(deg+mm.deg,5),len=bd*mm.len*(st.leadLen||1),li=LEADS[D.style];
    if(!(li&&samp(li[0],t,f*(li[2]||1),len,li[1],'venus',{att:li[3]||.03,rel:.18,rev:.35})))chop(t,f,len,mm.vow);
    if((D.style==='waltz'||D.style==='slowwaltz')&&drop)samp('flute',t,f*2,len,.22,'venus',{att:.03,rel:.15,flash:false})}}
}
// each band's solo instrument: [sample, level, octave shift, attack]
const LEADS={waltz:['violin',.5,1,.05],slowwaltz:['violin',.5,1,.08],tango:['violin',.5,1,.04],samba:['flute',.5,1,.02],chacha:['flute',.55,1,.02],swing:['muted_trumpet',.4,.5,.02],jive:['tenor_sax',.45,.5,.02]};
const MOONSMP={harpsi:'harpsichord',harp:'orchestral_harp',piano:'acoustic_grand_piano',guitar:'acoustic_guitar_nylon',pizz:'pizzicato_strings',vibes:'vibraphone',eguitar:'electric_guitar_clean'};
function moonNote(t,f,lvl,dec,id,v){
  const n=MOONSMP[v];if(n&&samp(n,t,f,dec*1.6,lvl*5.5,'jupiter',{rel:.12,flash:false})){flash(id,t);return}
  if(v==='guitar'){nylon(t,f,lvl*1.6,dec,'jupiter');flash(id,t)}
  else if(v==='piano'){piano(t,f,dec,lvl*1.3,'jupiter');flash(id,t)}
  else pluck(t,f,lvl,v==='vibes'?'sine':'triangle',dec,id);
}
