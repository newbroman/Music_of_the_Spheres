import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:400,height:820},hasTouch:true,isMobile:true,deviceScaleFactor:2,userAgent:'Mozilla/5.0 (Linux; Android 14) Mobile'});
const errs=[];page.on('pageerror',e=>errs.push(String(e)));
await page.goto('file:///tmp/claude-0/flight_dbg.html');await page.waitForTimeout(1500);
await page.click('#speak',{force:true}).catch(()=>{});
await page.click('#begin');await page.waitForTimeout(2000);
for(const id of ['venus','saturn']){await page.click('#navBtn');await page.click(`#dest button[data-id="${id}"]`);await page.waitForTimeout(10000);console.log(id,':',await page.evaluate(()=>__dbg()),'|',await page.textContent('#nearTxt'))}
await page.screenshot({path:'h_saturn.png'});console.log('errors',errs);await browser.close();
