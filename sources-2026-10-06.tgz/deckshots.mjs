import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
import { execSync } from 'child_process';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const ctx=await b.newContext({viewport:{width:1280,height:900}});
for(const t of ['pythagoras','philolaus','plato','aristotle','cicero','nicomachus','ptolemy','boethius','copernicus','fludd','kepler','today']){
  const p=await ctx.newPage();await p.goto('http://localhost:8123/index.html?notour#'+t);await p.waitForTimeout(700);await p.click('#begin');await p.waitForTimeout(t==='kepler'||t==='copernicus'?3500:2500);
  const r=await p.evaluate(()=>{const c=document.getElementById('orrery');window.scrollTo(0,c.getBoundingClientRect().top+scrollY-10);const b=c.getBoundingClientRect();return {x:b.left,y:b.top,w:b.width,h:b.height}});
  await p.waitForTimeout(500);const f=`/tmp/claude-0/deck/img/${t}.png`;await p.screenshot({path:f,clip:{x:r.x,y:r.y,width:r.w,height:Math.min(r.h,880)}});
  execSync(`python3 -c "from PIL import Image;im=Image.open('${f}').convert('RGB');im.thumbnail((1100,1100));im.save('${f.replace('.png','.webp')}','WEBP',quality=80)"`);await p.close();
}
await b.close();
