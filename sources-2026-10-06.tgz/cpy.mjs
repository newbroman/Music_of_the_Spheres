import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch();const errs=[];
for(const u of ['index.html','dance.html','help.html','flight.html','cy/index.html','ja/help.html','show-none']){ if(u==='show-none')continue;
  const p=await b.newPage({viewport:{width:412,height:860}});p.on('pageerror',e=>errs.push(u+': '+e.message));
  await p.goto('http://localhost:8123/'+u+'?notour');await p.waitForTimeout(900);
  const t=await p.evaluate(()=>{const f=document.getElementById('motsCopy');return f?f.innerText.replace(/\n/g,' | '):'(none)'});console.log(u,'→',t);
  if(u==='dance.html'){await p.evaluate(()=>scrollTo(0,1e6));await p.waitForTimeout(300);await p.screenshot({path:'/tmp/claude-0/-home-claude-music-of-the-spheres/808fb75a-4c88-5877-9823-ab514d31a639/scratchpad/foot.png'})}
  await p.close()}
console.log('errors',errs);await b.close();
