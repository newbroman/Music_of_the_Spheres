import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch();
for(const [w,h,n] of [[390,844,'phone'],[1300,900,'desk']]){const p=await b.newPage({viewport:{width:w,height:h}});
await p.goto('http://localhost:8123/index.html');await p.waitForTimeout(500);await p.click('.extras summary');await p.waitForTimeout(200);
const r=await p.evaluate(()=>{const r=document.querySelector('.extras .menu').getBoundingClientRect();return [r.left,r.right,r.top,innerWidth]});console.log(n,r.map(Math.round));
await p.screenshot({path:`ex_${n}.png`});await p.close()}
await b.close();
