
/* ---- the dance floor: the orrery seen from above ---- */
const BAND=[
  {id:'sun',god:'Apollo',inst:'Kick',color:'#ffd98a'},
  {id:'mercury',god:'Hermes',inst:'Hi-hats'},
  {id:'earth',god:'Gaia',inst:'Claps and snares'},
  {id:'mars',god:'Ares',inst:'Toms'},
  {id:'jupiter',god:'Zeus',inst:'Bass'},
  {id:'jupiter-moons',god:'Io · Europa · Ganymede',inst:'Arpeggio, 1 : 2 : 4',color:'#efe6cf'},
  {id:'saturn',god:'Kronos',inst:'Pads and chords'},
  {id:'venus',god:'Aphrodite',inst:'Vocal chops'},
  {id:'uranus',god:'Ouranos',inst:'Risers'},
  {id:'neptune',god:'Poseidon',inst:'Sub and atmosphere'}];
BAND.forEach(x=>{if(!x.color)x.color=byId[x.id].color});
function renderMixer(){
  $('mix').innerHTML=BAND.map(x=>`<div class="mrow${D.mute.has(x.id)?' off':''}" data-id="${x.id}"><span class="sw" id="sw_${x.id}" style="background:${x.color};color:${x.color}"></span><span class="nm">${x.god} <span>${(STY().inst&&STY().inst[x.id])||x.inst}</span></span><button class="mb" aria-pressed="${D.mute.has(x.id)}" title="Mute ${x.god}">M</button></div>`).join('');
}
$('mix').onclick=e=>{const r=e.target.closest('.mrow');if(!r||!e.target.closest('.mb'))return;const id=r.dataset.id;D.mute.has(id)?D.mute.delete(id):D.mute.add(id);renderMixer()};
const cv=$('dial'),g=cv.getContext('2d');let W=0,H=0,DPR=1,CX=0,CY=0,RR=0;
function resize(){DPR=Math.min(2,devicePixelRatio||1);const r=cv.getBoundingClientRect();W=r.width;H=r.height;cv.width=Math.round(W*DPR);cv.height=Math.round(H*DPR);CX=W/2;CY=H/2;RR=Math.min(W,H)/2*.8}
new ResizeObserver(resize).observe(cv);
const RMAX=34,R0=.45;
const sr=r=>RR*Math.log(1+r/R0)/Math.log(1+RMAX/R0);
function pr(x,y){const r=Math.hypot(x,y),s=r>0?sr(r)/r:0;return {x:CX+x*s,y:CY-y*s}}
const hexA=(h,a)=>{const n=parseInt(h.slice(1),16);return `rgba(${n>>16&255},${n>>8&255},${n&255},${a})`};
let starSeed=3;const srnd=()=>{starSeed=(starSeed*16807)%2147483647;return (starSeed-1)/2147483646};
const DSTARS=Array.from({length:380},()=>({x:srnd(),y:srnd(),m:srnd()}));
function draw(){
  g.setTransform(DPR,0,0,DPR,0,0);g.clearRect(0,0,W,H);
  DSTARS.forEach(s=>{g.fillStyle=`rgba(233,225,204,${.1+s.m*.3})`;g.fillRect(s.x*W,s.y*H,1,1)});
  // zodiac ring, with the Sun's current sign lit
  const Rz=RR*1.07, sun=sunSign();
  for(let k=0;k<12;k++){const a0=k*30*DEG,a1=(k+1)*30*DEG;g.strokeStyle=k===sun?'rgba(201,152,79,.9)':'rgba(201,152,79,.28)';g.lineWidth=k===sun?3:1;g.beginPath();g.arc(CX,CY,Rz,-a1,-a0);g.stroke();
    const am=(k*30+15)*DEG;g.fillStyle=k===sun?'rgba(201,152,79,1)':'rgba(201,152,79,.55)';g.font=`${Math.max(10,RR*.033)}px "GFS Didot",Georgia,serif`;g.textAlign='center';g.textBaseline='middle';g.fillText(SIGNS[k][0],CX+Math.cos(am)*Rz*1.075,CY-Math.sin(am)*Rz*1.075)}
  // orbits
  BODIES.filter(b=>b.kind==='planet').forEach(b=>{g.strokeStyle=hexA(b.color,.18);g.lineWidth=1;g.beginPath();b.orbit.forEach((o,k)=>{const q=pr(o.x,o.y);k?g.lineTo(q.x,q.y):g.moveTo(q.x,q.y)});g.stroke()});
  // aspect lines
  ASPNOW.slice(0,3).forEach(a=>{const p=pr(P[a.a.id].x,P[a.a.id].y),q=pr(P[a.b.id].x,P[a.b.id].y);g.strokeStyle=`rgba(201,152,79,${.15+.6*a.str})`;g.lineWidth=1+a.str*2;g.beginPath();g.moveTo(p.x,p.y);g.lineTo(q.x,q.y);g.stroke()});
  // the Sun pulses with the kick
  const sp=pr(0,0),k=FL.sun||0,sr2=16+k*14;const sg=g.createRadialGradient(sp.x,sp.y,0,sp.x,sp.y,sr2*1.7);sg.addColorStop(0,'rgba(255,236,190,1)');sg.addColorStop(.3,`rgba(232,180,95,${.7+.3*k})`);sg.addColorStop(1,'rgba(201,152,79,0)');g.fillStyle=sg;g.beginPath();g.arc(sp.x,sp.y,sr2*1.7,0,TAU);g.fill();
  // comets near the Sun
  BODIES.filter(b=>b.kind==='comet'&&P[b.id].r<3).forEach(b=>{const q=pr(P[b.id].x,P[b.id].y);g.fillStyle='rgba(200,230,255,.8)';g.beginPath();g.arc(q.x,q.y,2,0,TAU);g.fill()});
  // planets, flaring as they play
  BODIES.filter(b=>b.kind==='planet').forEach(b=>{
    const q=pr(P[b.id].x,P[b.id].y),f=FL[b.id]||0,r=Math.max(3,Math.min(9,1.4+2.1*Math.log10(b.R/120)));
    if(f>.02){g.strokeStyle=hexA(b.color,.5*f);g.lineWidth=2;g.beginPath();g.arc(q.x,q.y,r+4+(1-f)*16,0,TAU);g.stroke();const gl=g.createRadialGradient(q.x,q.y,0,q.x,q.y,r*3.5);gl.addColorStop(0,hexA(b.color,.6*f));gl.addColorStop(1,hexA(b.color,0));g.fillStyle=gl;g.beginPath();g.arc(q.x,q.y,r*3.5,0,TAU);g.fill()}
    g.fillStyle=b.color;g.beginPath();g.arc(q.x,q.y,r*(1+.35*f),0,TAU);g.fill();
    if(b.id==='saturn'){g.strokeStyle=hexA(b.color,.7);g.lineWidth=1.2;g.beginPath();g.ellipse(q.x,q.y,r*2.1,r*.8,-.35,0,TAU);g.stroke()}
    if(b.id==='jupiter'){['io','europa','ganymede'].forEach((id,k)=>{const m=b.moons[k+1],th=TAU*((S.jd-J2000)/m.P+m.ph0),rad=r+6+k*5,mf=FL[id]||0;g.fillStyle=`rgba(239,230,207,${.5+.5*mf})`;g.beginPath();g.arc(q.x+rad*Math.cos(th),q.y-rad*Math.sin(th),1.4+mf*2.6,0,TAU);g.fill()})}
    g.font='13px "GFS Didot",Georgia,serif';g.textAlign='left';g.textBaseline='middle';g.fillStyle=`rgba(233,225,204,${.75+.25*f})`;g.fillText(b.god,q.x+r+7,q.y-1);
  });
  Object.keys(FL).forEach(id=>{FL[id]*=.86;const sw=$('sw_'+(['io','europa','ganymede'].includes(id)?'jupiter-moons':id));if(sw)sw.style.boxShadow=FL[id]>.05?`0 0 ${4+10*FL[id]}px ${2*FL[id]}px currentColor`:'none'});
}
// mixer swatches glow in their own colour
function tintSwatches(){BAND.forEach(x=>{const el=$('sw_'+x.id);if(el)el.style.color=x.color})}

/* ---- readouts ---- */
function toast(t){const el=$('toast');el.textContent=t;el.style.opacity=1;clearTimeout(toast.h);toast.h=setTimeout(()=>el.style.opacity=0,3500)}
function renderSection(){const el=$('secTxt');el.textContent=D.section;el.className='sec '+D.section}
const MODENAME={trance:'Hypodorian (minor)',house:'Phrygian (modern Dorian)',techno:'Dorian (modern Phrygian)',waltz:'Lydian (the modern major)',tango:'Hypodorian (minor)',samba:'Hypophrygian (modern Mixolydian)',chacha:'Phrygian (modern Dorian)',swing:'Hypophrygian (modern Mixolydian)',jive:'Hypophrygian (modern Mixolydian)',fandango:'Dorian (modern Phrygian), Andalusian cadence'};
Object.assign(MODENAME,{jungle:'Hypodorian (minor)',slowwaltz:'Lydian (the modern major)',baroque:'Hypodorian (minor), in counterpoint'});
Object.assign(MODENAME,{mozart:'Lydian (the modern major)',satie:'Hypolydian (modern Lydian)',debussy:'whole-tone and pentatonic',part:'Hypodorian (minor), on the home triad',reich:'Phrygian (modern Dorian)',glass:'Hypodorian (minor)'});
const PROGNOTE={sky:'Home, then the chords that Zeus, Kronos and Poseidon stand on in the zodiac, seen from Earth.',cadence:'The Andalusian cadence: Zeus and Kronos choose the first two chords from where they stand in the zodiac, then the Phrygian second leads home.'};
function renderProg(){
  if(!D.progInfo.length)return;
  $('progNote').textContent=STY().cadence?PROGNOTE.cadence:PROGNOTE.sky;
  const cur=Math.floor(D.step/SPB())%4;
  $('prog').innerHTML=D.progInfo.map((c,k)=>`<div class="chord${D.playing&&k===cur?' on':''}"><div class="r">${ROMAN[c.deg]}</div><div class="w">${c.who}${c.sign!==null?' · '+SIGNS[c.sign][0]:''}</div></div>`).join('');
}
function fmtDays(d){return d<1?(d*24).toFixed(0)+' hours / bar':d<60?d.toFixed(d<10?1:0)+' days / bar':(d/30.44).toFixed(1)+' months / bar'}
function dateStr(jd){const d=new Date((jd-2440587.5)*86400000);const M=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];return `${d.getUTCDate()} ${M[d.getUTCMonth()]} ${d.getUTCFullYear()}`}
function readouts(){
  if(!DEG7)DEG7=modeDeg();
  const i=sunSign(),tonic=noteF(0,3),m=69+12*Math.log2(tonic/440),nm=['C','C♯','D','E♭','E','F','F♯','G','G♯','A','B♭','B'][((Math.round(m)%12)+12)%12];
  $('keyTxt').innerHTML=`Key of <b>${nm}</b>, ${MODENAME[D.style]} · Sun in <b>${SIGNS[i][0]}</b> (${SIGNS[i][1]})`;
  $('aspTxt').innerHTML=ASPNOW.length?ASPNOW.slice(0,2).map(a=>`${a.a.god} ${a.asp.sym}︎ ${a.b.god} <span style="opacity:.7">${a.asp.name}, ${Math.round(a.str*100)}%</span>`).join('<br>'):'No aspects at the moment: the band grooves.';
  $('energy').style.width=Math.round(D.energy*100)+'%';
  $('barTxt').textContent=D.playing?`bar ${Math.floor(D.step/SPB())+1}`:'stopped';
  $('dateTxt').textContent=dateStr(S.jd);
  renderProg();
}

/* ---- controls ---- */
window.recName=()=>RECBASE+D.style;
function syncPlay(){$('play').setAttribute('aria-pressed',String(D.playing));$('play').textContent=D.playing?'Stop':'Play'}
$('play').onclick=()=>D.playing?stopDance():startDance();
document.querySelectorAll('#style button').forEach(b=>b.onclick=()=>setStyle(b.dataset.v));
$('bpm').oninput=e=>{D.bpm=+e.target.value;$('bpmOut').textContent=D.bpm+' BPM';if(window.MOTS&&MOTS.midi.transport)MOTS.midi.transport(D.playing,D.bpm)};
if(window.MOTS&&MOTS.defaultOut)MOTS.defaultOut('stereo');
$('dpb').oninput=e=>{D.dpb=Math.pow(10,-.6+e.target.value/1000*2.4);$('dpbOut').textContent=fmtDays(D.dpb)};$('dpb').oninput({target:$('dpb')});
try{const v=localStorage.getItem('mots.vol.dance');if(v!==null)$('vol').value=v}catch(e){}
$('vol').oninput=e=>{D.vol=e.target.value/100;$('volOut').textContent=e.target.value+'%';if(AC&&D.playing)master.gain.setTargetAtTime(outGain(),AC.currentTime,.05);try{localStorage.setItem('mots.vol.dance',e.target.value)}catch(e){}};$('vol').oninput({target:$('vol')});
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&AC&&D.playing&&AC.state!=='running')AC.resume()});

/* ---- main loop ---- */
S.mode=STYLES[D.style].mode;
computePositions();computeAspectsD();updateProgression();renderMixer();tintSwatches();renderSection();
let last=performance.now(),lastUI=0;
function frame(t){
  const dt=Math.min(.1,(t-last)/1000);last=t;
  // the sky moves a set number of days per bar while playing, and drifts slowly when stopped
  S.jd+=dt*(D.playing?1/barDur():.5)*D.dpb;
  computePositions();pumpFlashes();
  if(!D.playing&&t-lastUI>240){computeAspectsD();updateProgression()}
  draw();
  if(t-lastUI>240){lastUI=t;readouts()}
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
