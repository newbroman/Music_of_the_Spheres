def LANG_JS():
    import re as _r,json as _j
    av=open('/tmp/claude-0/langs.txt').read().split()
    s=open('/tmp/claude-0/lang.js').read()
    return '<script>\n'+_r.sub(r"/\*LANGS\*/.*?/\*LANGS-END\*/","/*LANGS*/"+_j.dumps(av)+"/*LANGS-END*/",s)+'</script>\n'
PWA_HEAD='<link rel="manifest" href="manifest.webmanifest">\n<meta name="theme-color" content="#090b18">\n<link rel="icon" type="image/png" href="icons/favicon-48.png">\n<link rel="apple-touch-icon" href="icons/apple-touch-icon.png">\n<script>if(\'serviceWorker\' in navigator){const h=location.hostname,b=h===\'newbroman.github.io\'?\'/Music_of_the_Spheres/\':(h===\'localhost\'||h===\'127.0.0.1\')?\'/\':null;if(b)navigator.serviceWorker.register(b+\'sw.js\',{scope:b}).then(()=>navigator.serviceWorker.ready).then(r=>r.active&&r.active.postMessage(\'warm\')).catch(()=>{})}</script>\n'
import sys
def wrap(src,split,desc,dst,alt=None):
    s=open(src).read();i=s.index(split);head,body=s[:i],s[i:]
    if '[hidden]{display:none!important}' not in head:
        head=head.replace('<style>','<style>\n[hidden]{display:none!important}\nhtml,body{margin:0}\n',1)
    out=('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'+PWA_HEAD
         +(''.join(f'<link rel="alternate" hreflang="{c}" href="https://newbroman.github.io/Music_of_the_Spheres/{c}/{alt}">\n' for c in open('/tmp/claude-0/langs.txt').read().split() if c!='en') if alt is not None else '')+f'<meta name="description" content="{desc}">\n'+head+'</head>\n<body>\n'+body+'\n</body>\n</html>\n')
    open(dst,'w').write(out)
R='/home/claude/music_of_the_spheres/'
wrap('/home/claude/music-of-the-spheres.html','<div class="wrap">','Hear the music of the spheres as each thinker imagined it, from Pythagoras, Plato and Ptolemy to Kepler, drawn from the real sky of the moment, and the whole solar system today sung by the Greek gods.',R+'index.html','')
wrap('/home/claude/flight.html','<canvas id="scene"','Fly a spaceship through a 3D solar system while the planets and moons sing around you, voiced by the Greek gods and pitched by their orbits.',R+'flight.html','flight.html')
import re
def _d(f):return re.search(r'<meta name="description" content="([^"]*)"',open(R+f).read()).group(1)
_dd,_dh=_d('dance.html'),_d('help.html')
wrap('/home/claude/dance.html','<div class="wrap">',_dd,R+'dance.html','dance.html')
wrap('/home/claude/help.html','<div class="wrap">',_dh,R+'help.html','help.html')
