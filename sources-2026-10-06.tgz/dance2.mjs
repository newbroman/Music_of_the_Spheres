import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const page=await browser.newPage({viewport:{width:1300,height:950}});
const errs=[];page.on('pageerror',e=>errs.push(String(e)));
await page.addInitScript(()=>{const Orig=window.AudioContext;window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();this.__an.fftSize=4096;}};const oc=AudioNode.prototype.connect;AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return res};});
await page.goto('file:///home/claude/dance.html');await page.waitForTimeout(800);
await page.click('#play');
let last='',maxr=0,shots=0;const changes=[];
for(let k=0;k<100;k++){await page.waitForTimeout(1000);
  const sec=await page.textContent('#secTxt'),bar=await page.textContent('#barTxt');
  const r=+(await page.evaluate(()=>{const an=__ac.__an,b=new Float32Array(an.fftSize);an.getFloatTimeDomainData(b);let s=0;for(const x of b)s+=x*x;return Math.sqrt(s/b.length)}));maxr=Math.max(maxr,r);
  if(sec!==last){changes.push(`${sec}@${bar}`);last=sec;if(sec==='drop'&&!shots++){await page.waitForTimeout(600);await page.screenshot({path:'d_drop.png'})}}
}
console.log('sections:',changes.join(' → '));console.log('max rms',maxr.toFixed(3),'| aspects:',(await page.innerText('#aspTxt')).replace(/\n/g,' / '));
console.log('errors',errs);await browser.close();
