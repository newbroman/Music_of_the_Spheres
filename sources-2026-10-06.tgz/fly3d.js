
/* ================= FLIGHT: the 3D solar system ================= */
const $=id=>document.getElementById(id);
const AU_KM=1.495978707e8, MAG=40, SUN_MAG=10;
// ecliptic (x,y,z) <-> three.js / Web Audio world (x, z, -y): the same axes the audio engine already uses
const toV=e=>new THREE.Vector3(e.x,e.z,-e.y);
const toE=v=>({x:v.x,y:-v.z,z:v.y});
const visR=b=>Math.max(b.R,3)/AU_KM*MAG;
const SUN_R=696000/AU_KM*SUN_MAG;

const canvas=$('scene');
// phones: lighter graphics so the audio thread keeps its headroom
const MOBILE=matchMedia('(hover:none)').matches||/Android|iPhone|iPad/i.test(navigator.userAgent);
const renderer=new THREE.WebGLRenderer({canvas,antialias:!MOBILE,logarithmicDepthBuffer:true});
renderer.setPixelRatio(Math.min(MOBILE?1:2,window.devicePixelRatio||1));
S.hrtf=!MOBILE;
const scene=new THREE.Scene();
const camera=new THREE.PerspectiveCamera(62,1,1e-7,2e4);
scene.add(new THREE.AmbientLight(0x404660,.55));
const sunLight=new THREE.PointLight(0xfff2dd,1.35,0);scene.add(sunLight);
function resize3d(){const w=innerWidth,h=innerHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()}
addEventListener('resize',resize3d);resize3d();

/* ---- procedural textures ---- */
let tseed=11;const trnd=()=>{tseed=(tseed*16807)%2147483647;return (tseed-1)/2147483646};
function cvs(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;return [c,c.getContext('2d')]}
function bands(cols,opt={}){
  const [c,g]=cvs(512,256);
  const ph=[trnd()*6,trnd()*6,trnd()*6];
  for(let y=0;y<256;y++){
    const t=y/256, n=(Math.sin(t*opt.k1*TAU+ph[0])+.6*Math.sin(t*opt.k2*TAU+ph[1])+.3*Math.sin(t*opt.k3*TAU+ph[2]))/1.9;
    const i=Math.max(0,Math.min(cols.length-1,Math.floor((n*.5+.5)*cols.length)));
    g.fillStyle=cols[i];g.fillRect(0,y,512,1);
  }
  // gentle turbulence along the belts
  for(let k=0;k<(opt.swirl||220);k++){g.fillStyle=cols[(trnd()*cols.length)|0];g.globalAlpha=.18;const y=trnd()*256;g.beginPath();g.ellipse(trnd()*512,y,8+trnd()*40,1+trnd()*3,0,0,TAU);g.fill()}
  g.globalAlpha=1;
  if(opt.spot){g.fillStyle=opt.spot[0];g.globalAlpha=.9;g.beginPath();g.ellipse(opt.spot[1]*512,opt.spot[2]*256,opt.spot[3],opt.spot[3]*.55,0,0,TAU);g.fill();g.globalAlpha=1}
  return tex(c);
}
function rocky(base,spots,opt={}){
  const [c,g]=cvs(512,256);g.fillStyle=base;g.fillRect(0,0,512,256);
  for(let k=0;k<(opt.n||260);k++){g.fillStyle=spots[(trnd()*spots.length)|0];g.globalAlpha=.12+trnd()*.3;g.beginPath();const r=2+Math.pow(trnd(),2.2)*(opt.big||40);g.ellipse(trnd()*512,trnd()*256,r,r*(.5+trnd()*.5),trnd()*3,0,TAU);g.fill()}
  g.globalAlpha=1;
  if(opt.caps){g.fillStyle=opt.caps;g.fillRect(0,0,512,10);g.fillRect(0,246,512,10)}
  return tex(c);
}
function earthTex(){
  const [c,g]=cvs(512,256);g.fillStyle='#21508f';g.fillRect(0,0,512,256);
  const lands=[[80,70],[110,150],[250,80],[270,160],[380,90],[420,175],[470,120]];
  lands.forEach(([x,y])=>{for(let k=0;k<26;k++){g.fillStyle=['#3f7a3a','#6b8f45','#8c7b4f','#4d6a33'][(trnd()*4)|0];g.globalAlpha=.75;g.beginPath();g.ellipse(x+(trnd()-.5)*90,y+(trnd()-.5)*55,6+trnd()*20,4+trnd()*14,trnd()*3,0,TAU);g.fill()}});
  g.globalAlpha=.92;g.fillStyle='#eef3f6';g.fillRect(0,0,512,14);g.fillRect(0,240,512,16);
  for(let k=0;k<70;k++){g.globalAlpha=.12;g.beginPath();g.ellipse(trnd()*512,20+trnd()*216,8+trnd()*24,4+trnd()*9,trnd()*3,0,TAU);g.fill()}
  g.globalAlpha=1;return tex(c);
}
function tex(c){const t=new THREE.CanvasTexture(c);t.anisotropy=4;return t}
const TEX={
  mercury:()=>rocky('#8e8983',['#6d6862','#b0aaa2','#5a5651'],{n:420,big:22}),
  venus:()=>bands(['#e2cc98','#d9c08a','#ecdcb5','#cfb57d'],{k1:2,k2:5,k3:11,swirl:300}),
  earth:earthTex,
  mars:()=>rocky('#b65a33',['#8a3f22','#cf7a4c','#6e331d','#d89065'],{n:300,big:46,caps:'#f1e9e1'}),
  jupiter:()=>bands(['#c4936a','#dcc3a0','#b8875f','#e6d5ba','#ad7a55','#d2b28e'],{k1:4,k2:9,k3:17,swirl:520,spot:['#b5604a',.62,.62,24]}),
  saturn:()=>bands(['#e2cd96','#d3b77e','#ecdcb3','#c6a86f','#e7d6a6'],{k1:4,k2:9,k3:19,swirl:260}),
  uranus:()=>bands(['#a6dbdb','#9ed2d5','#b2e2e0'],{k1:2,k2:3,k3:7,swirl:60}),
  neptune:()=>bands(['#4f6fd6','#5d7ee0','#3f5cc0','#7290ea'],{k1:3,k2:7,k3:13,swirl:160,spot:['#22336e',.4,.58,14]}),
  pluto:()=>rocky('#c7a68f',['#a2826c','#eadbc9','#8c6a56'],{n:200,big:60}),
  io:()=>rocky('#d9c55a',['#b58a2e','#f2e9a0','#8a5a2a','#e07a2a'],{n:300,big:18}),
  europa:()=>rocky('#e9e1d2',['#b48b67','#cdb59a'],{n:160,big:6}),
  titan:()=>bands(['#d79a4a','#c98a3c','#e0a85a'],{k1:1,k2:2,k3:3,swirl:20}),
  moon:()=>rocky('#9b9893',['#6f6c68','#c4c1bb','#55524f'],{n:300,big:30}),
  grey:()=>rocky('#8f8a84',['#6b6762','#aaa59e'],{n:160,big:20}),
  ice:()=>rocky('#cfd3d6',['#a9aeb2','#e9ecee'],{n:140,big:20})
};
function moonTexKey(name){const n=name.toLowerCase();if(n.startsWith('io'))return 'io';if(n.startsWith('europa'))return 'europa';if(n.startsWith('titan'))return 'titan';if(n.startsWith('selene'))return 'moon';
  return /enceladus|tethys|dione|rhea|mimas|ariel|miranda|titania|oberon|umbriel|triton|charon|ganymede|callisto|iapetus|nereid|proteus|dysnomia/.test(n)?'ice':'grey'}
function ringTex(){
  const [c,g]=cvs(512,512);const cx=256;
  for(let r=256;r>0;r--){const t=r/256;if(t<1.24/2.27)break;
    const f=(t-1.24/2.27)/(1-1.24/2.27);
    const gap=Math.abs(f-.62)<.025?.1:1, a=(.35+.5*Math.sin(f*40)*Math.sin(f*7)*.5+.3*(f<.3?.5:1))*gap;
    g.strokeStyle=`rgba(${210+30*f|0},${190+20*f|0},${150+20*f|0},${Math.max(0,Math.min(.9,a))})`;g.lineWidth=1.2;g.beginPath();g.arc(cx,cx,r,0,TAU);g.stroke()}
  return tex(c);
}
function glowTex(inner,outer){const [c,g]=cvs(128,128);const gr=g.createRadialGradient(64,64,0,64,64,64);gr.addColorStop(0,inner);gr.addColorStop(.25,outer);gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(0,0,128,128);return tex(c)}

/* ---- stars ---- */
{const n=3500,pos=new Float32Array(n*3),col=new Float32Array(n*3);
 for(let k=0;k<n;k++){const u=trnd()*2-1,th=trnd()*TAU,s=Math.sqrt(1-u*u),R=9000;pos.set([R*s*Math.cos(th),R*u,R*s*Math.sin(th)],k*3);const w=.55+trnd()*.45,tint=trnd();col.set([w*(tint>.8?1:.85),w*.88,w*(tint<.2?1:.8)],k*3)}
 const gm=new THREE.BufferGeometry();gm.setAttribute('position',new THREE.BufferAttribute(pos,3));gm.setAttribute('color',new THREE.BufferAttribute(col,3));
 scene.add(new THREE.Points(gm,new THREE.PointsMaterial({size:1.6,sizeAttenuation:false,vertexColors:true,depthWrite:false})));}

/* ---- the Sun ---- */
const sunMesh=new THREE.Mesh(new THREE.SphereGeometry(SUN_R,48,32),new THREE.MeshBasicMaterial({color:0xffe6b0}));scene.add(sunMesh);
const sunGlow=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTex('rgba(255,236,190,1)','rgba(232,170,80,.45)'),blending:THREE.AdditiveBlending,depthWrite:false,transparent:true}));
sunGlow.scale.set(SUN_R*14,SUN_R*14,1);scene.add(sunGlow);

/* ---- bodies ---- */
const OBJ={};
BODIES.forEach(b=>{
  const o={b,grp:new THREE.Group(),tilt:new THREE.Group(),r:visR(b)};
  scene.add(o.grp);o.grp.add(o.tilt);o.tilt.rotation.x=(b.obl||0)*DEG;
  if(b.kind!=='comet'){
    const key=TEX[b.id]?b.id:(b.kind==='minor'?'grey':'grey');
    const mat=new THREE.MeshLambertMaterial({map:TEX[key]()});
    o.mesh=new THREE.Mesh(new THREE.SphereGeometry(o.r,b.kind==='planet'?48:20,b.kind==='planet'?32:14),mat);o.tilt.add(o.mesh);
  }else{
    o.coma=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTex('rgba(220,240,255,1)','rgba(150,200,255,.35)'),blending:THREE.AdditiveBlending,depthWrite:false,transparent:true}));o.grp.add(o.coma);
    const tg=new THREE.BufferGeometry();tg.setAttribute('position',new THREE.BufferAttribute(new Float32Array(6),3));tg.setAttribute('color',new THREE.BufferAttribute(new Float32Array([.8,.9,1,0,0,0]),3));
    o.tail=new THREE.Line(tg,new THREE.LineBasicMaterial({vertexColors:true,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false}));scene.add(o.tail);
  }
  if(b.id==='saturn'){const rg=new THREE.Mesh(new THREE.RingGeometry(o.r*1.24,o.r*2.27,160),new THREE.MeshLambertMaterial({map:ringTex(),transparent:true,side:THREE.DoubleSide,depthWrite:false}));rg.rotation.x=-Math.PI/2;o.tilt.add(rg)}
  // moons live in the planet's equatorial plane, at the same magnification as the planet
  o.moons=(b.moons||[]).map(m=>{
    const mm=new THREE.Mesh(new THREE.SphereGeometry(Math.max(m.R,4)/AU_KM*MAG,16,12),new THREE.MeshLambertMaterial({map:TEX[moonTexKey(m.k||m.name)]()}));o.tilt.add(mm);
    const ring=new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(Array.from({length:96},(_,k)=>new THREE.Vector3(Math.cos(k/96*TAU),0,Math.sin(k/96*TAU)).multiplyScalar(m.a/AU_KM*MAG))),new THREE.LineBasicMaterial({color:0xe9e1cc,transparent:true,opacity:.12,depthWrite:false}));
    o.tilt.add(ring);return {m,mesh:mm,ring};
  });
  o.outer=o.moons.length?Math.max(...b.moons.map(m=>m.a))/AU_KM*MAG:0;
  o.soi=Math.max(o.r*25,o.outer*1.6);
  // orbit line
  const pts=b.orbit.map(p=>toV(p));
  const ol=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:new THREE.Color(b.color),transparent:true,opacity:b.kind==='planet'?.2:b.kind==='minor'?.09:.08,depthWrite:false}));
  scene.add(ol);o.orbit=ol;
  OBJ[b.id]=o;
});
// a fixed-size marker for every body so the small ones can be found from afar
const DOTS=new THREE.Points(new THREE.BufferGeometry(),new THREE.PointsMaterial({size:3.2,sizeAttenuation:false,vertexColors:true,depthWrite:false,transparent:true,opacity:.9}));
{const n=BODIES.length,pos=new Float32Array(n*3),col=new Float32Array(n*3);BODIES.forEach((b,k)=>{const c=new THREE.Color(b.color);col.set([c.r,c.g,c.b],k*3)});
 DOTS.geometry.setAttribute('position',new THREE.BufferAttribute(pos,3));DOTS.geometry.setAttribute('color',new THREE.BufferAttribute(col,3));scene.add(DOTS);}
// markers for the moons, so they show as points of light when the spheres are too small to see
const MOONREF=[];BODIES.forEach(b=>OBJ[b.id].moons.forEach((mm,k)=>MOONREF.push([b.id,k])));
const MOONDOTS=new THREE.Points(new THREE.BufferGeometry(),new THREE.PointsMaterial({size:2.6,sizeAttenuation:false,color:0xe9e1cc,transparent:true,opacity:.85,depthWrite:false}));
MOONDOTS.geometry.setAttribute('position',new THREE.BufferAttribute(new Float32Array(MOONREF.length*3),3));scene.add(MOONDOTS);
// asteroid belt
const BELTPTS=new THREE.Points(new THREE.BufferGeometry(),new THREE.PointsMaterial({size:1.5,sizeAttenuation:false,color:0xa39c89,transparent:true,opacity:.55,depthWrite:false}));
BELTPTS.geometry.setAttribute('position',new THREE.BufferAttribute(new Float32Array(BELT.length*3),3));scene.add(BELTPTS);

function moonLocal(o,mm){const th=TAU*((S.jd-J2000)/mm.m.P+mm.m.ph0),a=mm.m.a/AU_KM*MAG;return new THREE.Vector3(a*Math.cos(th),0,-a*Math.sin(th))}
function moonWorld(o,k){return o.moons[k].mesh.getWorldPosition(new THREE.Vector3())}
const prevPos={};
function updateScene(dtSim){
  BODIES.forEach((b,k)=>{
    const o=OBJ[b.id],p=P[b.id],v=toV(p);
    prevPos[b.id]=prevPos[b.id]||v.clone();
    o.prev=prevPos[b.id].clone();prevPos[b.id].copy(v);
    o.grp.position.copy(v);o.pos=v;
    DOTS.geometry.attributes.position.setXYZ(k,v.x,v.y,v.z);
    if(o.mesh){const spin=b.rot?TAU*24/b.rot*dtSim:0;o.mesh.rotation.y+=Math.max(-.3,Math.min(.3,spin))}
    o.moons.forEach(mm=>mm.mesh.position.copy(moonLocal(o,mm)));
    if(b.kind==='comet'){
      const act=Math.min(1,Math.pow(1/p.r,2)), away=v.clone().normalize(), len=.01+act*.7;
      o.coma.scale.setScalar(.004+act*.08);o.coma.material.opacity=.25+act*.75;
      const a=o.tail.geometry.attributes.position;a.setXYZ(0,v.x,v.y,v.z);a.setXYZ(1,v.x+away.x*len,v.y+away.y*len,v.z+away.z*len);a.needsUpdate=true;
    }
  });
  DOTS.geometry.attributes.position.needsUpdate=true;
  scene.updateMatrixWorld();
  const md=MOONDOTS.geometry.attributes.position;MOONREF.forEach(([id,k],i)=>{const w=moonWorld(OBJ[id],k);md.setXYZ(i,w.x,w.y,w.z)});md.needsUpdate=true;
  const bp=BELTPTS.geometry.attributes.position;BELT.forEach((q,k)=>{const e=beltPos(q,S.jd);bp.setXYZ(k,e.x,e.z,-e.y)});bp.needsUpdate=true;
}

/* ---- the ship ---- */
const ship={pos:new THREE.Vector3(),vel:new THREE.Vector3(),anchor:null,ap:null};
const keys=new Set();let hold=0, lookDrag=null;
function placeNear(id,dist){
  const o=OBJ[id],v=toV(P[id]);
  const off=v.clone().normalize().multiplyScalar(-1).add(new THREE.Vector3(0,.35,0)).normalize().multiplyScalar(dist);
  ship.pos.copy(v).add(off);camera.position.copy(ship.pos);camera.lookAt(v);
}
function nearestSurface(){
  let best=ship.pos.length()-SUN_R, who='sun';
  BODIES.forEach(b=>{const o=OBJ[b.id];const d=ship.pos.distanceTo(o.pos)-o.r;if(d<best){best=d;who=b.id}
    o.moons.forEach((mm,k)=>{const d2=ship.pos.distanceTo(moonWorld(o,k))-mm.mesh.geometry.parameters.radius;if(d2<best){best=d2;who=b.id+':'+k}})});
  return {d:Math.max(best,1e-7),who};
}
function travelTo(id){
  const b=id.includes(':')||id==='sun'?null:byId[id];
  const name=id==='sun'?'Helios, the Sun':id.includes(':')?moonName(id):(b.kind==='comet'?b.name:b.god);
  ship.ap={id,name};ship.cruise=false;ship.vel.set(0,0,0);
  if(b&&S.speak&&audioOn)speakGod(b);
  toast(`Setting course for ${name}`);
  closeNav();
}
function moonName(id){const [pid,k]=id.split(':');return byId[pid].moons[+k].name.split(' ')[0]}
function targetInfo(id){
  if(id==='sun')return {pos:new THREE.Vector3(),r:SUN_R};
  if(id.includes(':')){const [pid,k]=id.split(':');const o=OBJ[pid];return {pos:moonWorld(o,+k),r:o.moons[+k].mesh.geometry.parameters.radius}}
  const o=OBJ[id];return {pos:o.pos.clone(),r:o.r,o};
}
const tmpQ=new THREE.Quaternion(), tmpM=new THREE.Matrix4();
function flight(dt){
  const ns=nearestSurface();
  // the ship rides along with whichever planet's neighbourhood it is in
  let anchor=null,ad=1e9;
  BODIES.forEach(b=>{const o=OBJ[b.id];if(b.kind==='comet')return;const d=ship.pos.distanceTo(o.pos);if(d<o.soi&&d<ad){ad=d;anchor=b.id}});
  ship.anchor=anchor;
  if(anchor){const o=OBJ[anchor];ship.pos.add(o.pos.clone().sub(o.prev))}
  if(ship.ap){
    const above=ship.ap.id==='above';
    const T=above?{pos:new THREE.Vector3(),r:SUN_R}:targetInfo(ship.ap.id);
    const stand=above?ship.ap.goal.length():ship.ap.id==='sun'?SUN_R*9:T.r*(T.o&&T.o.b.id==='saturn'?11:7);
    const dirOff=T.pos.clone().normalize().multiplyScalar(-1);if(!isFinite(dirOff.x)||ship.ap.id==='sun')dirOff.copy(ship.pos).normalize();
    const goal=above?ship.ap.goal.clone():T.pos.clone().add(dirOff.add(new THREE.Vector3(0,.35,0)).normalize().multiplyScalar(stand));
    const d=goal.clone().sub(ship.pos), D=d.length();
    ship.pos.add(d.multiplyScalar(1-Math.exp(-dt*1.3)));
    tmpM.lookAt(ship.pos,T.pos,new THREE.Vector3(0,1,0));tmpQ.setFromRotationMatrix(tmpM);
    camera.quaternion.slerp(tmpQ,1-Math.exp(-dt*2.6));
    if(D<stand*(above?.01:.04)){toast(above?'Above the plane of the planets':`Arrived at ${ship.ap.name}`);ship.ap=null}
  }else{
    const base=Math.min(40,Math.max(2e-6,ns.d*.55))*(keys.has('Shift')?5:1);
    const f=new THREE.Vector3(0,0,-1).applyQuaternion(camera.quaternion), r=new THREE.Vector3(1,0,0).applyQuaternion(camera.quaternion), u=new THREE.Vector3(0,1,0).applyQuaternion(camera.quaternion);
    const th=(keys.has('w')||keys.has('ArrowUp')?1:0)-(keys.has('s')||keys.has('ArrowDown')?1:0)+hold+(ship.cruise?1:0);
    const st=(keys.has('d')?1:0)-(keys.has('a')?1:0), vt=(keys.has('r')?1:0)-(keys.has('f')?1:0);
    const want=f.multiplyScalar(th).add(r.multiplyScalar(st)).add(u.multiplyScalar(vt)).multiplyScalar(base);
    ship.vel.lerp(want,1-Math.exp(-dt*4));
    ship.pos.addScaledVector(ship.vel,dt);
    const roll=(keys.has('q')?1:0)-(keys.has('e')?1:0);if(roll)camera.rotateZ(roll*dt*1.2);
    if(keys.has('ArrowLeft'))camera.rotateY(dt*1.2);if(keys.has('ArrowRight'))camera.rotateY(-dt*1.2);
  }
  // never fly into a body
  const push=(c,r)=>{const d=ship.pos.distanceTo(c);if(d<r*1.15){ship.pos.copy(c).add(ship.pos.clone().sub(c).normalize().multiplyScalar(r*1.15))}};
  push(new THREE.Vector3(),SUN_R);BODIES.forEach(b=>{const o=OBJ[b.id];push(o.pos,o.r);o.moons.forEach((mm,k)=>push(moonWorld(o,k),mm.mesh.geometry.parameters.radius))});
  camera.position.copy(ship.pos);
  // speed relative to the neighbourhood you are in, from how far the ship actually moved
  const fr=ship.anchor?OBJ[ship.anchor].pos.clone().sub(OBJ[ship.anchor].prev):new THREE.Vector3();
  if(ship.last&&dt>0){const inst=ship.pos.clone().sub(ship.last).sub(fr).length()/dt;ship.speed=(ship.speed||0)+(inst-(ship.speed||0))*Math.min(1,dt*4)}
  ship.last=ship.pos.clone();
  return ns;
}
// looking around: drag with mouse or finger
canvas.addEventListener('pointerdown',e=>{canvas.setPointerCapture(e.pointerId);lookDrag={x:e.clientX,y:e.clientY};resumeAudio()});
canvas.addEventListener('pointermove',e=>{if(!lookDrag)return;const dx=e.clientX-lookDrag.x,dy=e.clientY-lookDrag.y;lookDrag={x:e.clientX,y:e.clientY};
  if(ship.ap&&Math.hypot(dx,dy)>3){ship.ap=null}
  camera.rotateY(-dx*.0035);camera.rotateX(-dy*.0035)});
const endLook=()=>{lookDrag=null};canvas.addEventListener('pointerup',endLook);canvas.addEventListener('pointercancel',endLook);
addEventListener('keydown',e=>{if(e.target.tagName==='INPUT')return;const k=e.key.length===1?e.key.toLowerCase():e.key;keys.add(k);
  if(['w','s','a','d','r','f','q','e','ArrowUp','ArrowDown'].includes(k))ship.ap=null;
  if(k==='s'||k==='ArrowDown')ship.cruise=false;
  if(k==='c')toggleCruise();
  if(k==='t')toggleNav();if(k==='Escape')closeNav();if(k.startsWith('Arrow'))e.preventDefault()});
addEventListener('keyup',e=>{const k=e.key.length===1?e.key.toLowerCase():e.key;keys.delete(k)});
addEventListener('blur',()=>keys.clear());
function bindHold(el,v){
  const on=e=>{e.preventDefault();hold=v;ship.ap=null;if(v<0)ship.cruise=false;el.classList.add('on');resumeAudio()}, off=()=>{hold=0;el.classList.remove('on')};
  el.addEventListener('pointerdown',on);el.addEventListener('pointerup',off);el.addEventListener('pointerleave',off);el.addEventListener('pointercancel',off);
}
bindHold($('fwd'),1);bindHold($('bwd'),-1);

/* ---- labels ---- */
const LBL={};
function lbl(id,text,cls){const d=document.createElement('div');d.className='lbl '+(cls||'');d.innerHTML=text;d.onclick=()=>travelTo(id);$('labels').appendChild(d);LBL[id]=d;return d}
lbl('sun','Helios <small>Sun</small>','');
BODIES.forEach(b=>{lbl(b.id,b.kind==='comet'?b.name.split(' ')[0]:b.god,b.kind==='planet'?'':'minor');(b.moons||[]).forEach((m,k)=>lbl(b.id+':'+k,m.name.split(' ')[0],'moon'))});
const pv=new THREE.Vector3();
function placeLabel(id,pos,show){
  const el=LBL[id];if(!show){el.hidden=true;return}
  pv.copy(pos).project(camera);
  if(pv.z>1||pv.z<-1||Math.abs(pv.x)>1.1||Math.abs(pv.y)>1.1){el.hidden=true;return}
  el.hidden=false;el.style.transform=`translate3d(${((pv.x*.5+.5)*innerWidth+10).toFixed(1)}px,${((-pv.y*.5+.5)*innerHeight).toFixed(1)}px,0) translateY(-50%)`;
  el.classList.toggle('target',!!(ship.ap&&ship.ap.id===id));
}
function updateLabels(){
  placeLabel('sun',new THREE.Vector3(),true);
  ZODIAC.forEach((z,i)=>placeLabel('zod:'+i,z.centre,S.showZod));
  BODIES.forEach(b=>{const o=OBJ[b.id],d=ship.pos.distanceTo(o.pos);
    placeLabel(b.id,o.pos,b.kind==='planet'||d<4||(ship.ap&&ship.ap.id===b.id));
    o.moons.forEach((mm,k)=>placeLabel(b.id+':'+k,moonWorld(o,k),ship.anchor===b.id||(ship.ap&&ship.ap.id===b.id+':'+k)));
  });
}


/* ---- the zodiac in the sky: the twelve constellations along the ecliptic ---- */
// main stars as [right ascension h, declination deg, magnitude], and the lines that join them
const ZODIAC=[
 ['Κριός','Aries',[[2.1195,23.462,2.0],[1.9106,20.808,2.6],[1.8921,19.294,3.9],[2.8330,27.261,3.6]],[[3,0],[0,1],[1,2]]],
 ['Ταῦρος','Taurus',[[4.5987,16.509,.9],[5.4382,28.608,1.7],[5.6274,21.143,3.0],[4.4769,19.180,3.5],[4.3299,15.628,3.7],[4.3822,17.543,3.8],[4.0109,12.490,3.4],[3.7914,24.105,2.9]],[[1,3],[3,5],[5,4],[4,0],[0,2],[4,6]]],
 ['Δίδυμοι','Gemini',[[7.5767,31.888,1.6],[7.7553,28.026,1.1],[6.6285,16.399,1.9],[6.3827,22.514,2.9],[6.7322,25.131,3.0],[7.3354,21.982,3.5],[7.0686,20.570,3.9],[6.2479,22.507,3.3]],[[0,4],[4,3],[3,7],[1,5],[5,6],[6,2],[0,1]]],
 ['Καρκίνος','Cancer',[[8.9748,11.858,4.3],[8.7448,18.154,3.9],[8.7215,21.469,4.7],[8.2753,9.186,3.5],[8.7779,28.760,4.0]],[[4,2],[2,1],[1,0],[1,3]]],
 ['Λέων','Leo',[[10.1395,11.967,1.4],[11.8177,14.572,2.1],[10.3329,19.842,2.0],[11.2351,20.524,2.6],[11.2373,15.430,3.3],[10.1222,16.763,3.5],[10.2782,23.417,3.4],[9.8794,26.007,3.9],[9.7642,23.774,3.0]],[[0,5],[5,2],[2,6],[6,7],[7,8],[2,3],[3,1],[1,4],[4,0],[3,4]]],
 ['Παρθένος','Virgo',[[13.4199,-11.161,1.0],[12.6943,-1.449,2.7],[13.0363,10.959,2.8],[12.9268,3.397,3.4],[13.5783,-.596,3.4],[11.8448,1.765,3.6],[12.3318,-.667,3.9]],[[5,6],[6,1],[1,0],[1,3],[3,2],[3,4],[4,0]]],
 ['Ζυγός','Libra',[[14.8480,-16.042,2.8],[15.2835,-9.383,2.6],[15.0679,-25.282,3.3],[15.5921,-14.789,3.9]],[[2,0],[0,1],[1,3],[3,0]]],
 ['Σκορπίος','Scorpius',[[16.4901,-26.432,1.0],[16.0056,-22.622,2.3],[16.0906,-19.806,2.6],[15.9809,-26.114,2.9],[16.3531,-25.593,2.9],[16.5980,-28.216,2.8],[16.8361,-34.293,2.3],[16.8645,-38.048,3.0],[16.9097,-42.362,3.6],[17.2026,-43.239,3.3],[17.6220,-42.998,1.9],[17.7930,-40.127,3.0],[17.7081,-39.030,2.4],[17.5601,-37.104,1.6]],[[2,1],[1,3],[1,4],[4,0],[0,5],[5,6],[6,7],[7,8],[8,9],[9,10],[10,11],[11,12],[12,13]]],
 ['Τοξότης','Sagittarius',[[18.4029,-34.385,1.8],[18.3499,-29.828,2.7],[18.4662,-25.422,2.8],[18.9211,-26.297,2.0],[19.0435,-29.880,2.6],[19.1157,-27.671,3.3],[18.7609,-26.991,3.2],[18.0968,-30.424,3.0],[18.2938,-36.761,3.1]],[[7,1],[1,0],[0,4],[4,6],[6,1],[1,2],[2,6],[6,3],[3,5],[5,4],[0,8]]],
 ['Αἰγόκερως','Capricornus',[[20.3007,-12.545,3.6],[20.3502,-14.781,3.1],[20.7684,-25.271,4.1],[20.8636,-26.919,4.1],[21.4441,-22.411,3.7],[21.7840,-16.127,2.8],[21.6682,-16.662,3.7],[21.0990,-17.233,4.1]],[[0,1],[1,2],[2,3],[3,4],[4,5],[5,6],[6,7],[7,1]]],
 ['Ὑδροχόος','Aquarius',[[21.5260,-5.571,2.9],[22.0964,-.320,2.9],[22.9108,-15.821,3.3],[22.4807,-.020,3.6],[22.3609,-1.387,3.8],[22.5893,-.117,4.0],[22.8769,-7.580,3.7],[20.7946,-9.496,3.8]],[[7,0],[0,1],[1,4],[4,3],[3,5],[4,6],[6,2]]],
 ['Ἰχθύες','Pisces',[[2.0340,2.764,3.8],[1.5247,15.346,3.6],[1.7565,9.158,4.3],[23.2861,3.282,3.7],[23.4489,1.256,4.9],[23.7002,1.780,4.5],[23.6658,5.626,4.1],[23.4661,6.379,4.3],[23.9886,6.863,4.0],[.8114,7.585,4.4],[1.0491,7.890,4.3]],[[3,4],[4,5],[5,6],[6,7],[7,3],[6,8],[8,9],[9,10],[10,0],[0,2],[2,1]]]
];
const ZR=8000, OBLQ=23.4393*DEG;
// equatorial (RA, Dec) to ecliptic, then into the scene's axes
function skyPos(ra,dec,r){
  const a=ra*15*DEG,d=dec*DEG,xq=Math.cos(d)*Math.cos(a),yq=Math.cos(d)*Math.sin(a),zq=Math.sin(d);
  return toV({x:xq,y:yq*Math.cos(OBLQ)+zq*Math.sin(OBLQ),z:-yq*Math.sin(OBLQ)+zq*Math.cos(OBLQ)}).multiplyScalar(r);
}
const ZOD3=new THREE.Group();scene.add(ZOD3);
{
  const bright=[],faint=[],seg=[];
  ZODIAC.forEach(([gr,la,stars,lines],i)=>{
    const P3=stars.map(([ra,dec])=>skyPos(ra,dec,ZR));
    stars.forEach((s,k)=>(s[2]<2.6?bright:faint).push(P3[k]));
    lines.forEach(([a,b])=>seg.push(P3[a],P3[b]));
    const c=P3.reduce((acc,v)=>acc.add(v),new THREE.Vector3()).multiplyScalar(1/P3.length);
    ZODIAC[i].centre=c;
  });
  const pts=(arr,size,op)=>new THREE.Points(new THREE.BufferGeometry().setFromPoints(arr),new THREE.PointsMaterial({size,sizeAttenuation:false,color:0xf3e6c4,transparent:true,opacity:op,depthWrite:false}));
  ZOD3.add(pts(bright,4.2,1),pts(faint,2.8,.85));
  ZOD3.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(seg),new THREE.LineBasicMaterial({color:0xc9984f,transparent:true,opacity:.42,depthWrite:false})));
  // the ecliptic itself, with a tick at each sign's boundary
  const ring=[];for(let k=0;k<=360;k+=2)ring.push(toV({x:Math.cos(k*DEG),y:Math.sin(k*DEG),z:0}).multiplyScalar(ZR*1.02));
  ZOD3.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(ring),new THREE.LineBasicMaterial({color:0xc9984f,transparent:true,opacity:.18,depthWrite:false})));
  const ticks=[];for(let k=0;k<12;k++){const a=k*30*DEG;ticks.push(toV({x:Math.cos(a),y:Math.sin(a),z:-.035}).multiplyScalar(ZR*1.02),toV({x:Math.cos(a),y:Math.sin(a),z:.035}).multiplyScalar(ZR*1.02))}
  ZOD3.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(ticks),new THREE.LineBasicMaterial({color:0xc9984f,transparent:true,opacity:.35,depthWrite:false})));
}
ZODIAC.forEach(([gr,la],i)=>{const d=lbl('zod:'+i,`${gr} <small>${la}</small>`,'zod');d.onclick=null;d.style.pointerEvents='none'});
// aspect lines between planets, drawn in space
const ASPLINES=[0,1,2,3].map(()=>{const l=new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(),new THREE.Vector3()]),new THREE.LineBasicMaterial({color:0xc9984f,transparent:true,opacity:0,depthWrite:false}));scene.add(l);return l});
function updateAspectLines(){
  ASPLINES.forEach((l,k)=>{const a=S.aspects&&ASPNOW[k];
    if(!a){l.visible=false;return}
    l.visible=true;const pa=l.geometry.attributes.position;const A=OBJ[a.a.id].pos,B=OBJ[a.b.id].pos;
    pa.setXYZ(0,A.x,A.y,A.z);pa.setXYZ(1,B.x,B.y,B.z);pa.needsUpdate=true;l.geometry.computeBoundingSphere();l.material.opacity=.12+.5*a.str;});
}

/* ---- audio: the ship is the listener ---- */
function resumeAudio(){if(audioOn&&AC&&AC.state!=='running')AC.resume().catch(()=>{})}
function startAudio3D(){
  if(!AC)initAudio();
  applyVoiceMode();audioOn=true;AC.resume();
  if(SYS.id)buildSystemVoices();
  tgt(master.gain,S.vol,.3);syncBegin();
}
function stopAudio3D(){audioOn=false;tgt(master.gain,0,.15);setTimeout(()=>{if(!audioOn)AC.suspend()},600);syncBegin()}
function syncBegin(){$('begin').setAttribute('aria-pressed',String(audioOn));$('begin').textContent=audioOn?'Silence':'Begin the harmony'}
$('begin').onclick=()=>audioOn?stopAudio3D():startAudio3D();
// enter a planet's moon system when the ship is among its moons
function sysEnter3D(id){
  const b=byId[id];SYS.id=id;SYS.vp='centre';SYS.moons=b.moons.map((m,k)=>({m,k,id:'moon:'+id+':'+k,pos:moonPos(b,m,S.jd)}));
  if(AC)buildSystemVoices();
  if($('slowMoons').checked){const minP=Math.min(...b.moons.map(m=>Math.abs(m.P)));if(S.speed>minP/4){SYS.savedSpeed=S.speed;setTime(minP/4);toast(`Among the moons of ${b.god}: time slowed to ${fmtSpeed(S.speed)}`)}}
  renderMoonChips();
}
function sysLeave3D(){if(AC)killSystemVoices();SYS.id=null;SYS.moons=[];if(SYS.savedSpeed){setTime(SYS.savedSpeed);SYS.savedSpeed=null}renderMoonChips()}
function renderMoonChips(){
  const el=$('moonChips');
  if(!ship.anchor||!byId[ship.anchor].moons.length){el.innerHTML='';return}
  const b=byId[ship.anchor];el.innerHTML=b.moons.map((m,k)=>`<button class="chip" data-id="${b.id}:${k}">${m.name.split(' ')[0]}</button>`).join('')+`<button class="chip" data-id="${b.id}">${b.god}</button>`;
}
$('moonChips').onclick=e=>{const c=e.target.closest('.chip');if(c)travelTo(c.dataset.id)};
// leaving a planet: inward, outward, cruise straight ahead, or rise above the plane
const PLANETS=BODIES.filter(b=>b.kind==='planet').sort((a,c)=>a.el.a-c.el.a);
function neighbours(){
  const r=ship.pos.length();
  if(ship.anchor&&byId[ship.anchor].kind==='planet'){const i=PLANETS.findIndex(b=>b.id===ship.anchor);return {inn:PLANETS[i-1]||null,out:PLANETS[i+1]||null}}
  return {inn:[...PLANETS].reverse().find(b=>P[b.id].r<r*.98)||null,out:PLANETS.find(b=>P[b.id].r>r*1.02)||null};
}
function toggleCruise(){ship.cruise=!ship.cruise;if(ship.cruise){ship.ap=null;toast('Cruising ahead: drag to steer, ▼ or S to stop')}renderCourse()}
function riseAbove(){
  const H=Math.max(4,ship.pos.length()*1.6);
  ship.ap={id:'above',name:'above the planets',goal:new THREE.Vector3(ship.pos.x*.15,H,ship.pos.z*.15+H*.3)};ship.cruise=false;ship.vel.set(0,0,0);
  toast('Rising out of the plane of the planets');
}
let courseKey='';
function renderCourse(){
  const n=neighbours(), key=(n.inn?n.inn.id:'')+'|'+(n.out?n.out.id:'')+'|'+!!ship.cruise;
  if(key===courseKey)return;courseKey=key;
  $('courseChips').innerHTML=(n.inn?`<button class="chip" data-c="${n.inn.id}">◀ ${n.inn.god}</button>`:'')+
    `<button class="chip${ship.cruise?' on':''}" data-c="cruise">${ship.cruise?'Stop cruising':'Cruise ahead'}</button>`+
    `<button class="chip" data-c="above">Rise above</button>`+
    (n.out?`<button class="chip" data-c="${n.out.id}">${n.out.god} ▶</button>`:'');
}
$('courseChips').onclick=e=>{const c=e.target.closest('.chip');if(!c)return;const v=c.dataset.c;resumeAudio();
  if(v==='cruise')toggleCruise();else if(v==='above')riseAbove();else travelTo(v);};
let lastAnchor=null;
function audioTick(){
  // inside a moon system the moons sing; outside, the whole choir
  const inSys=ship.anchor&&byId[ship.anchor].moons.length&&ship.pos.distanceTo(OBJ[ship.anchor].pos)<OBJ[ship.anchor].outer*1.6;
  if(inSys&&SYS.id!==ship.anchor){if(SYS.id)sysLeave3D();sysEnter3D(ship.anchor)}
  else if(!inSys&&SYS.id)sysLeave3D();
  if(ship.anchor!==lastAnchor){lastAnchor=ship.anchor;renderMoonChips()}
  if(!AC||!audioOn)return;
  if(SYS.id){SYS.moons.forEach(sm=>sm.pos=moonPos(byId[SYS.id],sm.m,S.jd));updateSystemAudio();if(window.MOTS&&MOTS.midi.on)midiHolds()}
  else updateAudio();
}

/* ---- HUD, panel, time ---- */
function toast(t){const el=$('toast');el.textContent=t;el.style.opacity=1;clearTimeout(toast.h);toast.h=setTimeout(()=>el.style.opacity=0,3200)}
function fmtSpeed(d){
  if(d*86400<1.5)return 'real time';
  if(d*1440<1)return Math.round(d*86400)+'× real time';
  if(d<1/24)return (d*1440).toFixed(d*1440<10?1:0)+' min / s';
  if(d<1)return (d*24).toFixed(d*24<10?1:0)+' hours / s';
  if(d<60)return d.toFixed(d<10?1:0)+' days / s';
  if(d<730)return (d/30.44).toFixed(d<304?1:0)+' months / s';
  const y=d/365.25;return (y<10?y.toFixed(1):Math.round(y))+' years / s';
}
function setTime(d){S.speed=d;$('speed').value=Math.max(0,Math.min(1000,Math.round((Math.log10(d)-SPMIN)/(SPMAX-SPMIN)*1000)));$('speedOut').textContent=fmtSpeed(d)}
$('speed').oninput=e=>{S.speed=Math.pow(10,SPMIN+e.target.value/1000*(SPMAX-SPMIN));SYS.savedSpeed=null;$('speedOut').textContent=fmtSpeed(S.speed)};
// the 3D page keeps its own volume, separate from the 2D dial
try{const sv=localStorage.getItem('mots.vol.3d');if(sv!==null)$('vol').value=sv}catch(e){}
$('vol').oninput=e=>{S.vol=e.target.value/100;$('volOut').textContent=e.target.value+'%';if(AC&&audioOn)tgt(master.gain,S.vol,.05);try{localStorage.setItem('mots.vol.3d',e.target.value)}catch(e){}};$('vol').oninput({target:$('vol')});
$('verb').oninput=e=>{S.verb=e.target.value/100;$('verbOut').textContent=e.target.value+'%';setVerb()};$('verb').oninput({target:$('verb')});
// headphones, speakers, PA or mono: shared with the Stage panel and remembered
const setOutF=m=>{S.hrtf=m==='hrtf';$('hrtf').checked=S.hrtf;if(AC)PANNERS.forEach(({p,hrtfOK})=>{if(hrtfOK)p.panningModel=S.hrtf?'HRTF':'equalpower'})};
if(window.MOTS&&MOTS.onOut){MOTS.defaultOut(S.hrtf?'hrtf':'stereo');setOutF(MOTS.outMode());MOTS.onOut(setOutF)}else setOutF(S.hrtf?'hrtf':'stereo');
$('hrtf').onchange=e=>{const m=e.target.checked?'hrtf':'stereo';if(window.MOTS&&MOTS.setOut)MOTS.setOut(m);else setOutF(m)};
$('zodKey').onchange=e=>{S.zodiacKey=e.target.checked};
$('aspects').onchange=e=>{S.aspects=e.target.checked};
$('zodShow').onchange=e=>{S.showZod=e.target.checked;ZOD3.visible=S.showZod};
$('speak').onchange=e=>{S.speak=e.target.checked;if(!S.speak&&SYN)SYN.cancel()};
document.querySelectorAll('#voices button').forEach(btn=>btn.onclick=()=>{S.voices=btn.dataset.v;document.querySelectorAll('#voices button').forEach(x=>x.setAttribute('aria-pressed',String(x===btn)));if(!audioOn)startAudio3D();applyVoiceMode()});
function toggleNav(){$('panel').hidden?openNav():closeNav()}
function openNav(){$('panel').hidden=false;$('navBtn').setAttribute('aria-expanded','true')}
function closeNav(){$('panel').hidden=true;$('navBtn').setAttribute('aria-expanded','false')}
$('navBtn').onclick=toggleNav;$('closeNav').onclick=closeNav;
{
  const grp=(t,list)=>`<h3 style="grid-column:1/-1">${t}</h3>`+list.map(b=>`<button data-id="${b.id}"><span class="sw" style="background:${b.color}"></span><span class="nm">${b.kind==='comet'?b.name.split(' ')[0]:b.god} <span>${b.kind==='comet'?'':b.name}</span></span></button>`).join('');
  $('dest').innerHTML=`<button data-id="sun"><span class="sw" style="background:#ffe6b0"></span><span class="nm">Helios <span>Sun</span></span></button>`+
    grp('Planets',BODIES.filter(b=>b.kind==='planet'))+grp('Dwarf planets &amp; asteroids',BODIES.filter(b=>b.kind==='minor'))+grp('Comets',BODIES.filter(b=>b.kind==='comet'));
  $('dest').onclick=e=>{const c=e.target.closest('button');if(c)travelTo(c.dataset.id)};
}
function readout(ns){
  const near=ns.who==='sun'?'Helios':ns.who.includes(':')?moonName(ns.who):(byId[ns.who].kind==='comet'?byId[ns.who].name.split(' ')[0]:byId[ns.who].god);
  const anc=ship.anchor?byId[ship.anchor]:null;
  let txt=ship.ap?(ship.ap.id==='above'?'<em>Rising above the planets</em>':`Travelling to <em>${ship.ap.name}</em>`):ship.cruise?'<em>Cruising</em> · drag to steer':
    anc?`In orbit with <em>${anc.god}</em>`:`Nearest: <em>${near}</em>`;
  if(SYS.id)txt+=` · ${byId[SYS.id].moons.length} moon${byId[SYS.id].moons.length>1?'s':''} singing`;
  $('nearTxt').innerHTML=txt;renderCourse();
  const v=(ship.speed||0)*AU_KM/MAG*(ship.anchor?1:MAG), c=299792.458;
  const sp=v>c?(v/c).toFixed(v/c<10?1:0)+'× light speed':Math.round(v).toLocaleString('en-GB')+' km/s';
  const dist=ship.pos.length();
  $('speedTxt').textContent=`${sp} · ${dist.toFixed(dist<2?3:1)} AU from the Sun`;
}
function dateStr(jd){const d=new Date((jd-2440587.5)*86400000);if(isNaN(d))return '—';const M=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];const y=d.getUTCFullYear();return `${d.getUTCDate()} ${M[d.getUTCMonth()]} ${y<0?(-y+1)+' BCE':y}`}

/* ---- main loop ---- */
S.speed=1;setTime(1);S.vp='ship';S.showZod=true;
computePositions();updateScene(0);
placeNear('earth',OBJ.earth.r*9);
let last3=performance.now(), lastA=0, lastU=0, lastR=0, labelTick=0;
function frame3(t){
  const dt=Math.min(.1,(t-last3)/1000);last3=t;
  const dtSim=S.playing?dt*S.speed:0;S.jd+=dtSim;
  computePositions();updateScene(dtSim);
  const ns=flight(dt);
  if(!MOBILE||(++labelTick&1))updateLabels();
  updateAspectLines();
  if(t-lastA>45){audioTick();lastA=t}
  if(t-lastU>250){lastU=t;computeAspects();$('dateTxt').textContent=dateStr(S.jd);$('zodTxt').innerHTML=zodiacLine();$('timeTxt').textContent=fmtSpeed(S.speed);readout(ns);resumeAudio()}
  if(!MOBILE||t-lastR>=32){renderer.render(scene,camera);lastR=t}
  requestAnimationFrame(frame3);
}
requestAnimationFrame(frame3);
// hooks for the self-running show
window.MOTS=window.MOTS||{};
MOTS.app={start:()=>audioOn?Promise.resolve():startAudio3D(),stop:()=>{if(audioOn)stopAudio3D()},
  travel:id=>{resumeAudio();travelTo(id)},cruise:()=>{resumeAudio();if(!ship.cruise)toggleCruise()},uncruise:()=>{if(ship.cruise)toggleCruise()},above:()=>{resumeAudio();riseAbove()}};
