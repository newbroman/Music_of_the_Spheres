/* ---------- stage: sound output for headphones, speakers or a PA; MIDI out for lights; projector view ---------- */
(()=>{
"use strict";
const T={stage:'Stage',title:'Live and stage',output:'Output',hrtf:'Headphones',stereo:'Speakers',pa:'PA',mono:'Mono','5.1':'5.1',s51No:'5.1 needs an output with six channels, and this device offers {n}. Connect a computer to a 5.1 receiver over HDMI (set to multichannel PCM) or use a 5.1 USB sound card. Phones give the browser stereo only.',test:'Test speakers',
  outNote:{hrtf:'Full 3D placement, for headphones.',stereo:'Plain left and right, for a pair of speakers.',pa:'For a PA in a room: the stereo is narrowed so people near one speaker still hear every god.','5.1':'True surround: each god comes from its own direction around the room, front, sides or behind, with the bass in the subwoofer. Speakers in the standard 5.1 layout; use Test speakers to check the wiring.',mono:'Everything in both speakers: for a mono PA, or a single speaker.'},
  midi:'MIDI out',midiOff:'Off',midiConnect:'Connect MIDI',midiNone:'No MIDI devices found. Plug one in, then press Connect again.',midiNo:'This browser has no Web MIDI. Use Chrome or Edge on Android, Windows, Mac or Linux (not iPhone).',midiDenied:'MIDI permission was refused.',
  clock:'Send MIDI clock',midiMap:'What is sent',
  map:'Each god plays on its own MIDI channel, with its real pitch: 1 Helios (Sun), 2 Hermes, 3 Aphrodite, 4 Gaia, 5 Ares, 6 Zeus, 7 Kronos, 8 Ouranos, 9 Poseidon, 10 Jupiter’s moons, 11 everything else. On a lighting desk, any note on a channel can fire that god’s cue. Channel 16 carries the show: CC 20 the section (intro 0, groove 32, build 64, drop 96, break 127), CC 21 the overall loudness, and a note at each section change (36 intro, 37 groove, 38 build, 39 drop, 40 break). Drones on the dial also send CC 20 on their own channel for their loudness.',
  proj:'Projector view',projNote:'Full screen with the controls hidden. Tap the corner button or press Esc to come back.',exit:'Exit projector view',
  awake:'Keep the screen awake',close:'Close'};
const LS={get:k=>{try{return localStorage.getItem(k)}catch(e){return null}},set:(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}}};
const MOTS=window.MOTS=window.MOTS||{};

/* --- output stage: every connection to the speakers passes through a width matrix --- */
let ctx=null,mode=LS.get('mots.out'),inNode=null,an=null,G=null;const outFns=[];
const _c=AudioNode.prototype.connect;
function build(c){
  ctx=c;inNode=c.createGain();inNode.channelCount=2;inNode.channelCountMode='explicit';inNode.channelInterpretation='speakers';
  const sp=c.createChannelSplitter(2),mg=c.createChannelMerger(2);_c.call(inNode,sp);
  G={ll:c.createGain(),lr:c.createGain(),rl:c.createGain(),rr:c.createGain()};
  _c.call(sp,G.ll,0);_c.call(sp,G.lr,0);_c.call(sp,G.rl,1);_c.call(sp,G.rr,1);
  _c.call(G.ll,mg,0,0);_c.call(G.rl,mg,0,0);_c.call(G.lr,mg,0,1);_c.call(G.rr,mg,0,1);
  _c.call(mg,c.destination);an=c.createAnalyser();an.fftSize=1024;_c.call(inNode,an);setWidth(true);
}
const WIDTH={hrtf:1,stereo:1,pa:.55,mono:0};
function setWidth(now){if(!G)return;const w=WIDTH[mode]??1,a=(1+w)/2,b=(1-w)/2,t=ctx.currentTime,tc=now?.001:.08;
  G.ll.gain.setTargetAtTime(a,t,tc);G.rr.gain.setTargetAtTime(a,t,tc);G.lr.gain.setTargetAtTime(b,t,tc);G.rl.gain.setTargetAtTime(b,t,tc)}
AudioNode.prototype.connect=function(t,...r){
  try{if(t instanceof AudioDestinationNode&&!r.length){if(!inNode||ctx!==this.context)build(this.context);return _c.call(this,inNode)}}catch(e){}
  return _c.call(this,t,...r);
};
MOTS.onOut=fn=>{outFns.push(fn);if(mode)fn(mode)};
MOTS.setOut=m=>{if(m==='5.1'&&!surOK()){msgOut(T.s51No.replace('{n}',MOTS.surround?MOTS.surround.channels():2));return}mode=m;LS.set('mots.out',m);if(MOTS.surround&&SUR.cfg)surApply(m==='5.1');setWidth();outFns.forEach(f=>f(m));syncOut()};
MOTS.outMode=()=>mode;MOTS.audioCtx=()=>ctx;
MOTS.defaultOut=m=>{if(!mode)mode=m;syncOut()};

/* --- 5.1 surround: each registered voice is placed among five speakers by its direction from the listener --- */
// channel order (Web Audio 5.1): 0 L, 1 R, 2 C, 3 LFE, 4 Ls, 5 Rs. Speaker angles, left positive: C 0, L 30, Ls 110, Rs -110, R -30
const RING=[[0,2],[30,0],[110,4],[250,5],[330,1],[360,2]];
let maxCh=0;try{const tc=new (window.AudioContext||window.webkitAudioContext)();maxCh=tc.destination.maxChannelCount||2;tc.close&&tc.close()}catch(e){}
const SUR={cfg:null,items:[],merger:null,out6:null,lfe:null,timer:null,on:false};
const surOK=()=>(SUR.cfg?SUR.cfg.ctx.destination.maxChannelCount:maxCh)>=6;
function surGains(az,spread){ // az in degrees, left positive; returns gains for channels 0..5
  az=((az%360)+360)%360;const g=[0,0,0,0,0,0];
  for(let k=0;k<RING.length-1;k++){const [a0,c0]=RING[k],[a1,c1]=RING[k+1];if(az>=a0&&az<=a1){const t=(az-a0)/(a1-a0);g[c0]+=Math.cos(t*Math.PI/2);g[c1]+=Math.sin(t*Math.PI/2);break}}
  if(spread>0)for(const c of [0,1,2,4,5])g[c]=Math.sqrt((1-spread)*g[c]*g[c]+spread/5);
  return g;
}
function lv(prm,def){try{return prm?prm.value:def}catch(e){return def}}
function azOf(it){
  if(it.az){const a=it.az();return a==null?null:[a,0]}
  const p=it.node,L=SUR.cfg.ctx.listener;
  const x=lv(p.positionX,0),y=lv(p.positionY,0),z=lv(p.positionZ,0);
  let fx=lv(L.forwardX,0),fy=lv(L.forwardY,0),fz=lv(L.forwardZ,-1);const ux=lv(L.upX,0),uy=lv(L.upY,1),uz=lv(L.upZ,0);
  const rx=fy*uz-fz*uy,ry=fz*ux-fx*uz,rz=fx*uy-fy*ux;
  const front=x*fx+y*fy+z*fz,right=x*rx+y*ry+z*rz,len=Math.hypot(front,right);
  return [Math.atan2(-right,front)*180/Math.PI,Math.max(0,Math.min(1,1-len/.15))];
}
function surTick(){if(!SUR.on)return;const t=SUR.cfg.ctx.currentTime;
  for(const it of SUR.items){const r=azOf(it);if(!r)continue;const g=surGains(r[0],r[1]);it.g.forEach((n,k)=>{if(n)n.gain.setTargetAtTime(g[k],t,.06)})}}
function surBuild(){const c=SUR.cfg.ctx;if(SUR.merger)return;
  SUR.merger=c.createChannelMerger(6);
  SUR.lfeIn=c.createGain();const lp=c.createBiquadFilter();lp.type='lowpass';lp.frequency.value=110;_c.call(SUR.lfeIn,lp);_c.call(lp,(SUR.lfeG=c.createGain()));SUR.lfeG.gain.value=.6;_c.call(SUR.lfeG,SUR.merger,0,3);
  // a soft safety clip replaces the stereo limiter, which cannot carry six channels
  SUR.out6=c.createWaveShaper();const n=1024,cv=new Float32Array(n);for(let i=0;i<n;i++){const x=i/(n-1)*2-1;cv[i]=Math.tanh(x*1.6)/Math.tanh(1.6)}SUR.out6.curve=cv;
  SUR.items.forEach(wire);
}
function wire(it){const c=SUR.cfg.ctx;if(it.g||!SUR.merger)return;
  it.gR=c.createGain();it.gR.gain.value=SUR.on?1:0;_c.call(it.in,it.gR);
  it.g=[0,1,2,3,4,5].map(k=>{if(k===3)return null;const n=c.createGain();n.gain.value=0;_c.call(it.gR,n);_c.call(n,SUR.merger,0,k);return n});
  _c.call(it.gR,SUR.lfeIn);
  if(SUR.cfg.verb){it.gV=c.createGain();it.gV.gain.value=SUR.on?.7:0;_c.call(it.in,it.gV);_c.call(it.gV,SUR.cfg.verb)}
}
MOTS.surround={
  supported:surOK,channels:()=>SUR.cfg?SUR.cfg.ctx.destination.maxChannelCount:maxCh,
  // a page hands over its output chain: master (volume), lim (its stereo limiter), entry (where six-channel voices join), verb (reverb input), bypass [[from,to,alt]] links to reroute in 5.1
  attach(cfg){SUR.cfg=cfg;if(mode==='5.1'&&!surApply(true)){mode='stereo';outFns.forEach(f=>f(mode));syncOut()}},
  // a voice's panner: sources connected to it are split between its stereo path and the surround speakers
  add(node,opts={}){const c=node.context,it={node,az:opts.az||null};it.in=c.createGain();it.gS=c.createGain();_c.call(it.in,it.gS);_c.call(it.gS,node);it.gS.gain.value=SUR.on?0:1;
    node.__sur=it;SUR.items.push(it);if(SUR.merger)wire(it);return node}
};
function surApply(on){const C=SUR.cfg;if(!C)return;const c=C.ctx,t=c.currentTime;
  if(on&&!surOK())return false;
  surBuild();
  if(on===SUR.on)return true;
  SUR.on=on;const d=c.destination;
  if(on){d.channelCount=6;d.channelCountMode='explicit';d.channelInterpretation='speakers';
    try{C.master.disconnect(C.lim)}catch(e){}(C.bypass||[]).forEach(([a,b,alt])=>{try{a.disconnect(b)}catch(e){}a.connect(alt)});
    _c.call(SUR.merger,C.entry);C.master.connect(SUR.out6);_c.call(SUR.out6,d);if(c.__rec)_c.call(SUR.out6,c.__rec);
    SUR.timer=setInterval(surTick,50);surTick()}
  else{clearInterval(SUR.timer);try{SUR.merger.disconnect()}catch(e){}try{C.master.disconnect(SUR.out6)}catch(e){}try{SUR.out6.disconnect()}catch(e){}
    (C.bypass||[]).forEach(([a,b,alt])=>{try{a.disconnect(alt)}catch(e){}a.connect(b)});C.master.connect(C.lim);
    d.channelCount=2;d.channelCountMode='explicit';d.channelInterpretation='speakers'}
  SUR.items.forEach(it=>{it.gS.gain.setTargetAtTime(on?0:1,t,.05);if(it.gR)it.gR.gain.setTargetAtTime(on?1:0,t,.05);if(it.gV)it.gV.gain.setTargetAtTime(on?.7:0,t,.05)});
  return true;
}
// a soft chime in each speaker in turn, to check the wiring: L, C, R, Rs, Ls, then the subwoofer
MOTS.surround._s=SUR;
MOTS.surround.test=()=>{const C=SUR.cfg;if(!C||!SUR.on)return false;const c=C.ctx;let t=c.currentTime+.1;
  [[0,880],[2,880],[1,880],[5,660],[4,660],[3,55]].forEach(([ch,f])=>{const o=c.createOscillator(),g=c.createGain();o.frequency.value=f;o.type=ch===3?'sine':'triangle';
    g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.35,t+.03);g.gain.setValueAtTime(.35,t+.6);g.gain.exponentialRampToValueAtTime(.001,t+.95);o.connect(g);_c.call(g,SUR.merger,0,ch);o.start(t);o.stop(t+1);t+=1.1});
  return true};
// redirect connections into a registered panner to its splitter
const _c2=AudioNode.prototype.connect;
AudioNode.prototype.connect=function(t,...r){if(t&&t.__sur&&this!==t.__sur.gS)return _c.call(this,t.__sur.in,...r);return _c2.call(this,t,...r)};

/* --- MIDI out --- */
const CH={sun:0,mercury:1,venus:2,earth:3,mars:4,jupiter:5,saturn:6,uranus:7,neptune:8,'jupiter-moons':9,io:9,europa:9,ganymede:9,callisto:9};
const CTL=15,SEC={intro:0,groove:1,build:2,drop:3,break:4};
let access=null,out=null,clockOn=LS.get('mots.clock')==='1';
const M=MOTS.midi={on:false};
const chOf=id=>CH[id]??10;
const toMs=t=>{if(!ctx||t==null)return performance.now();try{const o=ctx.getOutputTimestamp();if(o&&o.performanceTime)return o.performanceTime+(t-o.contextTime)*1000}catch(e){}return performance.now()+(t-ctx.currentTime)*1000};
const send=(d,ms)=>{if(!out)return;try{out.send(d,ms&&ms>performance.now()?ms:undefined)}catch(e){}};
const noteOf=f=>Math.max(0,Math.min(127,Math.round(69+12*Math.log2(f/440))));
const lastPitched={};
M.hit=(id,t,f,lvl,len)=>{if(!out)return;const ch=chOf(id),ms=toMs(t);
  if(!f){if(Math.abs((lastPitched[ch]||-1e9)-ms)<12)return}else lastPitched[ch]=ms;
  const n=f?noteOf(f):60,v=Math.max(1,Math.min(127,Math.round(30+(lvl||.5)*160)));
  send([0x90|ch,n,v],ms);send([0x80|ch,n,0],ms+Math.max(60,Math.min(4000,(len||.2)*1000)))};
const held={};
M.hold=(id,f,level)=>{if(!out||!(id in CH))return;const ch=chOf(id),h=held[id]||(held[id]={n:-1,cc:-1});
  const on=level>.02&&f>0,n=on?noteOf(f):-1;
  if(n!==h.n){if(h.n>=0)send([0x80|ch,h.n,0]);if(n>=0)send([0x90|ch,n,Math.max(1,Math.min(127,Math.round(40+level*120)))]);h.n=n}
  const cc=Math.min(127,Math.round(Math.min(1,level*1.6)*127));if(Math.abs(cc-h.cc)>=3||(cc===0&&h.cc!==0)){send([0xB0|ch,20,cc]);h.cc=cc}};
M.section=(name,t)=>{if(!out)return;const k=SEC[name];if(k==null)return;const ms=toMs(t);send([0xB0|CTL,20,[0,32,64,96,127][k]],ms);send([0x90|CTL,36+k,100],ms);send([0x80|CTL,36+k,0],ms+200)};
let tempo=0,running=false,clockT=null,nextTick=0;
M.transport=(play,bpm)=>{tempo=bpm||tempo;if(play&&!running){running=true;if(out&&clockOn)send([0xFA]);nextTick=performance.now()+20;startClock()}
  else if(!play&&running){running=false;if(out&&clockOn)send([0xFC]);stopClock()}};
function startClock(){stopClock();if(!clockOn||!out||!tempo)return;clockT=setInterval(()=>{const now=performance.now(),per=60000/tempo/24;if(nextTick<now-200)nextTick=now;while(nextTick<now+100){send([0xF8],nextTick);nextTick+=per}},25)}
function stopClock(){if(clockT){clearInterval(clockT);clockT=null}}
function allOff(){if(!out)return;for(let c=0;c<16;c++){send([0xB0|c,123,0]);send([0xB0|c,20,0])}Object.keys(held).forEach(k=>delete held[k])}
// overall loudness on channel 16, CC 21
let lastL=-1;setInterval(()=>{if(!out||!an)return;const b=new Float32Array(an.fftSize);an.getFloatTimeDomainData(b);let q=0;for(const x of b)q+=x*x;
  const v=Math.min(127,Math.round(Math.sqrt(q/b.length)*700));if(Math.abs(v-lastL)>=2){send([0xB0|CTL,21,v]);lastL=v}},50);
async function connectMIDI(){
  if(!navigator.requestMIDIAccess){msg(T.midiNo);return}
  try{access=access||await navigator.requestMIDIAccess({sysex:false});access.onstatechange=fillOuts;fillOuts();if(!access.outputs.size)msg(T.midiNone);else msg('')}
  catch(e){msg(T.midiDenied)}
}
function pickOut(id){allOff();stopClock();out=null;M.on=false;
  if(access&&id){out=access.outputs.get(id)||null;if(out){M.on=true;LS.set('mots.midiOut',out.name);if(running&&clockOn){send([0xFA]);startClock()}}}
  else LS.set('mots.midiOut','');}
function fillOuts(){const s=document.getElementById('stMidi');if(!s||!access)return;const want=LS.get('mots.midiOut');
  s.innerHTML=`<option value="">${T.midiOff}</option>`+[...access.outputs.values()].map(o=>`<option value="${o.id}">${o.name.replace(/</g,'&lt;')}</option>`).join('');
  const m=[...access.outputs.values()].find(o=>out?o.id===out.id:o.name===want);if(m){s.value=m.id;if(!out)pickOut(m.id)}s.hidden=false}
function msg(t){const e=document.getElementById('stMidiMsg');if(e){e.textContent=t;e.hidden=!t}}

/* --- projector view and screen wake lock --- */
const CANVAS=['orrery','dial','scene'].map(i=>document.getElementById(i)).find(Boolean);
const css=document.createElement('style');
css.textContent=`html.mots-proj,html.mots-proj body{overflow:hidden!important}
html.mots-proj body *{visibility:hidden!important}
html.mots-proj #${CANVAS?CANVAS.id:'none'}{visibility:visible!important;position:fixed!important;inset:0!important;width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;margin:0!important;border:0!important;border-radius:0!important;aspect-ratio:auto!important;z-index:9000!important;background:#05060c!important}
#motsProjX{position:fixed;top:12px;right:12px;z-index:9001;appearance:none;border:1px solid #c9984f;background:rgba(10,12,24,.7);color:#e9e1cc;border-radius:999px;width:44px;height:44px;font:20px/1 system-ui,sans-serif;cursor:pointer;transition:opacity .6s;display:none}
html.mots-proj #motsProjX{display:block;visibility:visible!important}html.mots-proj.idle #motsProjX{opacity:0}html.mots-proj.idle{cursor:none}
#stPanel{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:60;width:min(460px,calc(100% - 32px));max-height:calc(100% - 32px);overflow:auto;background:#13162a;color:#e9e1cc;border:1px solid #c9984f;border-radius:12px;padding:14px 16px;font:15px/1.45 "Alegreya Sans",system-ui,sans-serif;box-shadow:0 10px 40px rgba(0,0,0,.6)}
#stPanel h2{font:600 20px/1.2 "Cormorant Garamond",Georgia,serif;margin:0 0 10px;color:#e9d093}#stPanel h3{font:600 12px/1 system-ui,sans-serif;letter-spacing:.12em;text-transform:uppercase;color:#a39c89;margin:14px 0 6px}
#stPanel .seg{display:flex;flex-wrap:wrap;border:1px solid #2b3050;border-radius:8px;overflow:hidden}#stPanel .seg button{flex:1 1 auto;appearance:none;border:0;border-right:1px solid #2b3050;background:transparent;color:#e9e1cc;padding:9px 10px;font:inherit;cursor:pointer;min-height:40px}
#stPanel .seg button:last-child{border-right:0}#stPanel .seg button[aria-pressed="true"]{background:#2a2414;color:#e9d093}
#stPanel .b{appearance:none;border:1px solid #c9984f;background:transparent;color:#e9d093;border-radius:999px;padding:9px 16px;font:inherit;cursor:pointer;min-height:40px}
#stPanel select{width:100%;margin-top:6px;background:#0c0e1c;color:#e9e1cc;border:1px solid #2b3050;border-radius:8px;padding:8px;font:inherit}
#stPanel .n{color:#a39c89;font-size:14px;margin:6px 0 0}#stPanel label{display:flex;gap:8px;align-items:center;margin-top:8px;cursor:pointer}#stPanel details{margin-top:8px;color:#a39c89;font-size:14px}#stPanel summary{cursor:pointer;color:#e9e1cc}
#stPanel .row{display:flex;justify-content:space-between;gap:10px;align-items:center;margin-top:14px}`;
document.head.appendChild(css);
const X=document.createElement('button');X.id='motsProjX';X.type='button';X.textContent='✕';X.title=X.ariaLabel=T.exit;document.body.appendChild(X);
let idleT=null;const wake=()=>{document.documentElement.classList.remove('idle');clearTimeout(idleT);idleT=setTimeout(()=>document.documentElement.classList.add('idle'),3000)};
function proj(on,o={}){const h=document.documentElement;h.classList.toggle('mots-proj',on);
  if(on){const p=document.getElementById('stPanel');if(p)p.remove();wake();addEventListener('pointermove',wake);if(!o.noFS&&h.requestFullscreen&&!document.fullscreenElement)h.requestFullscreen().catch(()=>{});lock(true)}
  else{removeEventListener('pointermove',wake);h.classList.remove('idle');if(!o.noFS&&document.fullscreenElement&&document.exitFullscreen)document.exitFullscreen().catch(()=>{});lock(awakeOn)}
  dispatchEvent(new Event('resize'))}
X.onclick=()=>proj(false);
addEventListener('keydown',e=>{if(e.key==='Escape'&&document.documentElement.classList.contains('mots-proj'))proj(false)});
document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement&&document.documentElement.classList.contains('mots-proj'))proj(false)});
let awakeOn=LS.get('mots.awake')!=='0',sentinel=null;
async function lock(on){try{if(on&&!sentinel&&navigator.wakeLock){sentinel=await navigator.wakeLock.request('screen');sentinel.addEventListener('release',()=>{sentinel=null})}else if(!on&&sentinel){await sentinel.release();sentinel=null}}catch(e){}}
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&(awakeOn||document.documentElement.classList.contains('mots-proj')))lock(true)});
// the screen stays awake once sound has started, if asked
addEventListener('pointerdown',()=>{if(awakeOn)lock(true)},{once:true});
MOTS.projector=proj;

/* --- the Stage button and panel --- */
function msgOut(t){const n=document.getElementById('stOutNote');if(n)n.textContent=t}
function syncOut(){const tb=document.getElementById('stTest');if(tb)tb.hidden=mode!=='5.1';document.querySelectorAll('#stOut button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.v===mode)));const n=document.getElementById('stOutNote');if(n)n.textContent=T.outNote[mode]||''}
/* --- supporters: in the Google Play app the Stage panel opens with a one-off supporter purchase (the website keeps it free) --- */
const TS={
 en:{t:'Become a supporter',b:'In the app, the Stage panel (PA and 5.1 sound, MIDI for lights, the projector view) is for supporters. Choose any amount: each one opens the panel for good on this device and helps keep the project going.',s:'Supporter',m:'Friend',l:'Patron',ok:'Thank you! The Stage panel is open.',fail:'The purchase didn’t go through, and nothing was charged.',na:'Purchases aren’t available just now. Check you are online and signed in to Google Play.',c:'Not now'},
 pl:{t:'Zostań wspierającym',b:'W aplikacji panel Scena (dźwięk na nagłośnienie i 5.1, MIDI do świateł, widok projektora) jest dla wspierających. Wybierz dowolną kwotę: każda otwiera panel na stałe na tym urządzeniu i pomaga rozwijać projekt.',s:'Wspierający',m:'Przyjaciel',l:'Mecenas',ok:'Dziękuję! Panel Scena jest otwarty.',fail:'Zakup się nie udał i nic nie zostało pobrane.',na:'Zakupy są teraz niedostępne. Sprawdź połączenie z internetem i logowanie do Google Play.',c:'Nie teraz'},
 cy:{t:'Dewch yn gefnogwr',b:'Yn yr ap, mae’r panel Llwyfan (sain PA a 5.1, MIDI ar gyfer goleuadau, golwg taflunydd) ar gyfer cefnogwyr. Dewiswch unrhyw swm: mae pob un yn agor y panel am byth ar y ddyfais hon ac yn helpu i gadw’r prosiect i fynd.',s:'Cefnogwr',m:'Cyfaill',l:'Noddwr',ok:'Diolch! Mae’r panel Llwyfan ar agor.',fail:'Ni aeth y pryniant drwodd, ac ni chodwyd dim.',na:'Nid oes modd prynu ar hyn o bryd. Gwiriwch eich bod ar-lein ac wedi mewngofnodi i Google Play.',c:'Dim nawr'},
 de:{t:'Unterstützer werden',b:'In der App ist das Bühnen-Panel (PA- und 5.1-Ton, MIDI für Licht, Projektoransicht) für Unterstützer. Wählen Sie einen beliebigen Betrag: Jeder öffnet das Panel dauerhaft auf diesem Gerät und hilft, das Projekt weiterzuführen.',s:'Unterstützer',m:'Freund',l:'Mäzen',ok:'Danke! Das Bühnen-Panel ist geöffnet.',fail:'Der Kauf ist nicht zustande gekommen; es wurde nichts berechnet.',na:'Käufe sind gerade nicht möglich. Prüfen Sie, ob Sie online und bei Google Play angemeldet sind.',c:'Nicht jetzt'},
 es:{t:'Hazte mecenas',b:'En la aplicación, el panel Escenario (sonido para PA y 5.1, MIDI para luces, vista de proyector) es para quienes apoyan el proyecto. Elige cualquier cantidad: cada una abre el panel para siempre en este dispositivo y ayuda a mantener el proyecto.',s:'Apoyo',m:'Amigo',l:'Mecenas',ok:'¡Gracias! El panel Escenario está abierto.',fail:'La compra no se completó y no se ha cobrado nada.',na:'Las compras no están disponibles ahora. Comprueba que tienes conexión y has iniciado sesión en Google Play.',c:'Ahora no'},
 fr:{t:'Devenir soutien',b:'Dans l’application, le panneau Scène (son pour sono et 5.1, MIDI pour les lumières, vue projecteur) est réservé aux soutiens. Choisissez un montant : chacun ouvre le panneau pour de bon sur cet appareil et aide à faire vivre le projet.',s:'Soutien',m:'Ami',l:'Mécène',ok:'Merci ! Le panneau Scène est ouvert.',fail:'L’achat n’a pas abouti, et rien n’a été débité.',na:'Les achats sont indisponibles pour le moment. Vérifiez que vous êtes en ligne et connecté à Google Play.',c:'Plus tard'},
 it:{t:'Diventa sostenitore',b:'Nell’app, il pannello Palco (suono per impianto PA e 5.1, MIDI per le luci, vista proiettore) è per i sostenitori. Scegli un importo qualsiasi: ognuno apre il pannello per sempre su questo dispositivo e aiuta a portare avanti il progetto.',s:'Sostenitore',m:'Amico',l:'Mecenate',ok:'Grazie! Il pannello Palco è aperto.',fail:'L’acquisto non è andato a buon fine e non è stato addebitato nulla.',na:'Gli acquisti non sono disponibili ora. Controlla di essere online e di aver eseguito l’accesso a Google Play.',c:'Non ora'},
 zh:{t:'成为支持者',b:'在应用中，舞台面板（扩声与 5.1 声音、灯光 MIDI、投影视图）供支持者使用。任选一个金额：每一个都会在此设备上永久打开该面板，并帮助项目继续发展。',s:'支持者',m:'朋友',l:'赞助人',ok:'谢谢！舞台面板已打开。',fail:'购买未完成，未产生任何扣款。',na:'目前无法购买。请确认已联网并登录 Google Play。',c:'以后再说'},
 ja:{t:'サポーターになる',b:'アプリでは、ステージパネル（PA・5.1 サラウンド、照明用 MIDI、プロジェクター表示）はサポーター向けです。金額はどれでもかまいません。どれを選んでも、この端末でパネルがずっと使えるようになり、プロジェクトの継続を支えます。',s:'サポーター',m:'フレンド',l:'パトロン',ok:'ありがとうございます！ステージパネルが使えるようになりました。',fail:'購入は完了しませんでした。料金は請求されていません。',na:'現在は購入できません。オンラインで Google Play にログインしているか確認してください。',c:'今はしない'}};
const SUP={pkg:'io.github.newbroman.spheres',bill:'https://play.google.com/billing',skus:[['supporter_small','s','£1.99'],['supporter_medium','m','£4.99'],['supporter_large','l','£9.99']],svc:null};
const ts=()=>TS[(document.documentElement.lang||'en').slice(0,2)]||TS.en;
// the Play app opens the site with an android-app referrer; remembered for this visit only, so the same site in Chrome stays free
const SS={get:k=>{try{return sessionStorage.getItem(k)}catch(e){return null}},set:(k,v)=>{try{sessionStorage.setItem(k,v)}catch(e){}}};
if(document.referrer.startsWith('android-app://'+SUP.pkg))SS.set('mots.play','1');
const inPlayApp=()=>SS.get('mots.play')==='1'||/[?&]playapp=1/.test(location.search);
const isSupporter=()=>LS.get('mots.supporter')==='1';
MOTS.stageLocked=()=>inPlayApp()&&!isSupporter();
async function billing(){if(SUP.svc)return SUP.svc;if(!('getDigitalGoodsService' in window))return null;try{SUP.svc=await window.getDigitalGoodsService(SUP.bill)}catch(e){SUP.svc=null}return SUP.svc}
// purchases are consumed at once: Google counts that as acknowledgement (no server needed), and the device remembers the supporter
async function settle(svc){try{const ps=await svc.listPurchases();let any=false;for(const p of ps){if(SUP.skus.some(s=>s[0]===p.itemId)){try{await svc.consume(p.purchaseToken)}catch(e){}any=true}}if(any)LS.set('mots.supporter','1');return any}catch(e){return false}}
async function buy(sku,msg){
  const svc=await billing();if(!svc){msg(ts().na);return false}
  try{const rq=new PaymentRequest([{supportedMethods:SUP.bill,data:{sku}}],{total:{label:'Total',amount:{currency:'GBP',value:'0'}}});
    const r=await rq.show();const tok=r.details&&r.details.purchaseToken;
    try{if(tok)await svc.consume(tok)}catch(e){}
    LS.set('mots.supporter','1');await r.complete('success');return true}
  catch(e){msg(ts().fail);return false}
}
function supportPanel(){
  let p=document.getElementById('stPanel');if(p){p.remove();return}
  const S=ts();p=document.createElement('div');p.id='stPanel';p.setAttribute('role','dialog');p.setAttribute('aria-label',S.t);
  p.innerHTML=`<h2>${S.t}</h2><p class="n" style="margin-top:0">${S.b}</p><div class="row" id="stTiers">${SUP.skus.map(([id,k,pr])=>`<button type="button" class="b" data-sku="${id}"><b>${S[k]}</b> <span>${pr}</span></button>`).join('')}</div><p class="n" id="stSupMsg" hidden></p><div class="row"><button type="button" class="b" id="stClose">${S.c}</button></div>`;
  document.body.appendChild(p);
  const msg=t=>{const m=p.querySelector('#stSupMsg');m.textContent=t;m.hidden=false};
  p.querySelector('#stClose').onclick=()=>p.remove();
  p.querySelectorAll('#stTiers button').forEach(b=>b.onclick=async()=>{p.querySelectorAll('#stTiers button').forEach(x=>x.disabled=true);
    if(await buy(b.dataset.sku,msg)){msg(S.ok);setTimeout(()=>{p.remove();openPanel()},1400)}else p.querySelectorAll('#stTiers button').forEach(x=>x.disabled=false)});
  // the store's own prices (in the buyer's currency), and any purchase left unfinished last time
  billing().then(async svc=>{if(!svc)return;if(await settle(svc)){p.remove();openPanel();return}
    try{const d=await svc.getDetails(SUP.skus.map(s=>s[0]));for(const it of d){const b=p.querySelector(`[data-sku="${it.itemId}"] span`);if(b&&it.price)b.textContent=new Intl.NumberFormat(document.documentElement.lang||'en',{style:'currency',currency:it.price.currency}).format(it.price.value)}}catch(e){}});
}
function openPanel(){
  let p=document.getElementById('stPanel');if(p){p.remove();return}
  if(MOTS.stageLocked()){supportPanel();return}
  p=document.createElement('div');p.id='stPanel';p.setAttribute('role','dialog');p.setAttribute('aria-label',T.title);
  p.innerHTML=`<h2>${T.title}</h2>
  <h3>${T.output}</h3><div class="seg" id="stOut">${['hrtf','stereo','pa','mono','5.1'].map(v=>`<button type="button" data-v="${v}" aria-pressed="false">${T[v]}</button>`).join('')}</div><p class="n" id="stOutNote"></p><button type="button" class="b" id="stTest" hidden style="margin-top:8px">${T.test}</button>
  <h3>${T.midi}</h3><button type="button" class="b" id="stMidiGo">${T.midiConnect}</button><select id="stMidi" hidden aria-label="${T.midi}"></select><p class="n" id="stMidiMsg" hidden></p>
  <label><input type="checkbox" id="stClock"${clockOn?' checked':''}> ${T.clock}</label>
  <details><summary>${T.midiMap}</summary><p>${T.map}</p></details>
  <h3>${T.proj}</h3><p class="n" style="margin-top:0">${T.projNote}</p>
  <label><input type="checkbox" id="stAwake"${awakeOn?' checked':''}> ${T.awake}</label>
  <div class="row"><button type="button" class="b" id="stProj">${T.proj}</button><button type="button" class="b" id="stClose">${T.close}</button></div>`;
  document.body.appendChild(p);syncOut();
  p.querySelectorAll('#stOut button').forEach(b=>b.onclick=()=>MOTS.setOut(b.dataset.v));p.querySelector('#stTest').onclick=()=>MOTS.surround.test();
  p.querySelector('#stMidiGo').onclick=connectMIDI;if(access)fillOuts();
  p.querySelector('#stMidi').onchange=e=>pickOut(e.target.value);
  p.querySelector('#stClock').onchange=e=>{clockOn=e.target.checked;LS.set('mots.clock',clockOn?'1':'0');if(clockOn&&running){send([0xFA]);startClock()}else{if(running)send([0xFC]);stopClock()}};
  p.querySelector('#stAwake').onchange=e=>{awakeOn=e.target.checked;LS.set('mots.awake',awakeOn?'1':'0');lock(awakeOn)};
  p.querySelector('#stProj').onclick=()=>proj(true);
  p.querySelector('#stClose').onclick=()=>p.remove();
}
addEventListener('keydown',e=>{if(e.key==='Escape'){const p=document.getElementById('stPanel');if(p)p.remove()}});
const rec=document.getElementById('recBtn');
if(rec){const b=document.createElement('button');b.type='button';b.id='stageBtn';b.className=rec.className.replace(/\brec\b/,'').trim();b.textContent=T.stage;b.setAttribute('aria-haspopup','dialog');b.onclick=openPanel;rec.insertAdjacentElement('afterend',b);{const cs=getComputedStyle(rec);['border','borderRadius','padding','font','color','background','letterSpacing','textTransform','minHeight','lineHeight'].forEach(k=>b.style[k]=cs[k])}}
// remember a MIDI device chosen earlier: reconnect quietly if the browser already allows it
if(LS.get('mots.midiOut')&&navigator.permissions&&navigator.requestMIDIAccess)navigator.permissions.query({name:'midi'}).then(s=>{if(s.state==='granted')connectMIDI()}).catch(()=>{});
})();
