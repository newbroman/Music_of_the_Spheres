import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const page = await browser.newPage({viewport:{width:1300,height:950}});
await page.goto('file:///home/claude/music-of-the-spheres.html');await page.waitForTimeout(400);
await page.click('.vrow[data-id="jupiter"] .nm');await page.waitForTimeout(600);
await page.click('#sysBtn');await page.waitForTimeout(2500);
await page.locator('.dial').screenshot({path:'sysdial.png'});
await browser.close();
