(()=>{
'use strict';

const DEG=Math.PI/180, TAU=Math.PI*2, J2000=2451545.0;
const jdNow=()=>Date.now()/86400000+2440587.5;
const jdOf=(y,m,d)=>Date.UTC(y,m-1,d)/86400000+2440587.5;
const OM_EARTH=TAU/365.256;

/* ---------- elements ---------- */
const pl=(a,e,I,L,varpi,Om,Lrate)=>({a,e,i:I,Om,w:varpi-Om,M0:L-varpi,epoch:J2000,n:Lrate/36525});
const pe=(a,e,i,Om,w,Tp)=>({a,e,i,Om,w,M0:0,epoch:Tp,n:360/(365.25*Math.pow(a,1.5))});

const VOWELS={
  a:[[700,1],[1100,.5],[2550,.22]],
  ah:[[800,1],[1150,.55],[2900,.25]],
  e:[[450,1],[1750,.32],[2500,.22]],
  i:[[290,1],[2250,.25],[2950,.2]],
  o:[[430,1],[780,.38],[2500,.08]],
  u:[[320,1],[700,.15],[2300,.05]],
  uh:[[620,1],[1200,.4],[2400,.12]],
  ae:[[660,1],[1700,.4],[2400,.15]]
};

const BODIES=[
 {id:'mercury',name:'Mercury',god:'Hermes',greek:'Ἑρμῆς',ancient:'Stilbōn, the Gleaming',kind:'planet',color:'#bdb3a5',R:2440,rot:1407.6,vowel:'i',
  voice:'Hermes, the messenger: a bright, quick “ee”, darting with his eccentric orbit.',
  el:pl(0.38709927,0.20563593,7.00497902,252.25032350,77.45779628,48.33076593,149472.67411175),moons:[]},
 {id:'venus',name:'Venus',god:'Aphrodite',greek:'Ἀφροδίτη',ancient:'Phōsphoros at dawn, Hesperos at dusk',kind:'planet',color:'#e9d093',R:6052,rot:-5832.5,vowel:'ah',
  voice:'Aphrodite: an open, sustained “ah”, its slow pulse reversed by her backward spin.',
  el:pl(0.72333566,0.00677672,3.39467605,181.97909950,131.60246718,76.67984255,58517.81538729),moons:[]},
 {id:'earth',name:'Earth',god:'Gaia',greek:'Γαῖα',ancient:'the hearth of the cosmos',kind:'planet',color:'#74abdc',R:6371,rot:23.934,vowel:'o',
  voice:'Gaia: a round, warm “oh”, with Selene singing above her.',
  el:pl(1.00000261,0.01671123,-0.00001531,100.46457166,102.93768193,0.0,35999.37244981),
  moons:[{name:'Selene (Moon)',k:'selene',P:27.3217,a:384400,R:1737}]},
 {id:'mars',name:'Mars',god:'Ares',greek:'Ἄρης',ancient:'Pyroeis, the Fiery',kind:'planet',color:'#d46e4f',R:3390,rot:24.623,vowel:'e',
  voice:'Ares: a hard, forward “eh”, his sons Phobos and Deimos rattling around him.',
  el:pl(1.52371034,0.09339410,1.84969142,-4.55343205,-23.94362959,49.55953891,19140.30268499),
  moons:[{name:'Phobos',k:'phobos',P:0.31891,a:9376,R:11},{name:'Deimos',k:'deimos',P:1.26244,a:23463,R:6}]},
 {id:'jupiter',name:'Jupiter',god:'Zeus',greek:'Ζεύς',ancient:'Phaethōn, the Shining',kind:'planet',color:'#dcae7c',R:69911,rot:9.925,vowel:'a',
  voice:'Zeus: a broad bass “aw”, the widest chorus in the sky.',
  el:pl(5.20288700,0.04838624,1.30439695,34.39644051,14.72847983,100.47390909,3034.74612775),
  moons:[{name:'Amalthea',k:'amalthea',P:0.4982,a:181366,R:84},{name:'Io',k:'io',P:1.769,a:421700,R:1822},{name:'Europa',k:'europa',P:3.551,a:671034,R:1561},{name:'Ganymede',k:'ganymede',P:7.155,a:1070412,R:2634},{name:'Callisto',k:'callisto',P:16.689,a:1882709,R:2410}]},
 {id:'saturn',name:'Saturn',god:'Kronos',greek:'Κρόνος',ancient:'Phainōn, the Bright',kind:'planet',color:'#e6d08f',R:58232,rot:10.656,vowel:'u',
  voice:'Kronos, father of time: a dark, hollow “oo”, ringed by eight moons.',
  el:pl(9.53667594,0.05386179,2.48599187,49.95424423,92.59887831,113.66242448,1222.49362201),
  moons:[{name:'Mimas',k:'mimas',P:0.942,a:185539,R:198},{name:'Enceladus',k:'enceladus',P:1.370,a:237948,R:252},{name:'Tethys',k:'tethys',P:1.888,a:294619,R:531},{name:'Dione',k:'dione',P:2.737,a:377396,R:561},{name:'Rhea',k:'rhea',P:4.518,a:527108,R:764},{name:'Titan',k:'titan',P:15.945,a:1221870,R:2575},{name:'Hyperion',k:'hyperion',P:21.28,a:1500880,R:135},{name:'Iapetus',k:'iapetus',P:79.32,a:3560820,R:735}]},
 {id:'uranus',name:'Uranus',god:'Ouranos',greek:'Οὐρανός',ancient:'the sky itself',kind:'planet',color:'#a3d9d8',R:25362,rot:-17.24,vowel:'uh',
  voice:'Ouranos: a deep, muffled “uh” that pulses backward, as the planet rolls on its side.',
  el:pl(19.18916464,0.04725744,0.77263783,313.23810451,170.95427630,74.01692503,428.48202785),
  moons:[{name:'Miranda',k:'miranda',P:1.413,a:129390,R:236},{name:'Ariel',k:'ariel',P:2.520,a:191020,R:579},{name:'Umbriel',k:'umbriel',P:4.144,a:266000,R:585},{name:'Titania',k:'titania',P:8.706,a:435910,R:789},{name:'Oberon',k:'oberon',P:13.463,a:583520,R:761}]},
 {id:'neptune',name:'Neptune',god:'Poseidon',greek:'Ποσειδῶν',ancient:'lord of the deep',kind:'planet',color:'#7389e2',R:24622,rot:16.11,vowel:'o',
  voice:'Poseidon: the lowest “oh” of the planets, with Triton circling against the current.',
  el:pl(30.06992276,0.00859048,1.77004347,-55.12002969,44.96476227,131.78422574,218.45945325),
  moons:[{name:'Proteus',k:'proteus',P:1.122,a:117647,R:210},{name:'Triton',k:'triton',P:-5.877,a:354759,R:1353},{name:'Nereid',k:'nereid',P:360.13,a:5513818,R:170}]},
 {id:'pluto',name:'Pluto',god:'Hades',greek:'Ἅιδης',ancient:'the unseen one',kind:'minor',color:'#cdae98',R:1188,rot:-153.3,vowel:'u',
  voice:'Hades: a low “oo” that climbs as Pluto nears the Sun and sinks again, Charon beside him.',
  el:pl(39.48211675,0.24882730,17.14001206,238.92903833,224.06891629,110.30393684,145.20780515),
  moons:[{name:'Charon',k:'charon',P:6.387,a:19591,R:606},{name:'Nix',k:'nix',P:24.85,a:48694,R:25},{name:'Hydra',k:'hydra',P:38.20,a:64738,R:26}]},
 {id:'ceres',name:'Ceres',god:'Demeter',greek:'Δημήτηρ',ancient:'goddess of the harvest',kind:'minor',color:'#b9b19f',R:470,rot:9.07,vowel:'ah',
  voice:'Demeter: a soft “ah” from the heart of the asteroid belt.', el:pe(2.7675,0.0785,10.59,80.27,73.6,jdOf(2022,12,7)),moons:[]},
 {id:'vesta',name:'Vesta',god:'Hestia',greek:'Ἑστία',ancient:'keeper of the hearth',kind:'minor',color:'#c8bfae',R:263,rot:5.342,vowel:'e',
  voice:'Hestia: a small, steady “eh”, pulsing with Vesta’s five-hour day.', el:pe(2.3615,0.0887,7.14,103.81,151.2,jdOf(2021,12,26)),moons:[]},
 {id:'pallas',name:'Pallas',god:'Athena',greek:'Ἀθηνᾶ',ancient:'Pallas, the grey-eyed',kind:'minor',color:'#a9a598',R:256,rot:7.81,vowel:'i',
  voice:'Athena: a keen “ee” that soars high above the ecliptic on Pallas’s steep orbit.', el:pe(2.773,0.2302,34.84,173.08,310.15,jdOf(2022,7,20)),moons:[]},
 {id:'juno',name:'Juno',god:'Hera',greek:'Ἥρα',ancient:'queen of Olympus',kind:'minor',color:'#b6ab97',R:127,rot:7.21,vowel:'ah',
  voice:'Hera: a proud, light “ah”.', el:pe(2.669,0.2562,12.99,169.85,248.1,jdOf(2023,6,1)),moons:[]},
 {id:'hygiea',name:'Hygiea',god:'Hygieia',greek:'Ὑγίεια',ancient:'goddess of health',kind:'minor',color:'#9d968a',R:217,rot:13.8,vowel:'i',
  voice:'Hygieia: a calm, small “ee”.', el:pe(3.142,0.1125,3.83,283.2,312.3,jdOf(2021,11,10)),moons:[]},
 {id:'eros',name:'Eros',god:'Eros',greek:'Ἔρως',ancient:'the near-Earth wanderer',kind:'minor',color:'#d9a7a0',R:8.4,rot:5.27,vowel:'ae',
  voice:'Eros: a slender thread of “ae” that swings in close to Gaia.', el:pe(1.458,0.2229,10.83,304.3,178.9,jdOf(2024,4,1)),moons:[]},
 {id:'eris',name:'Eris',god:'Eris',greek:'Ἔρις',ancient:'goddess of strife',kind:'minor',color:'#d8d4cc',R:1163,rot:378.9,vowel:'e',
  voice:'Eris: a distant, discordant “eh” from beyond Hades.', el:pe(67.86,0.4361,44.04,35.95,151.6,jdOf(2257,1,1)),
  moons:[{name:'Dysnomia',k:'dysnomia',P:15.786,a:37300,R:350}]},
 {id:'haumea',name:'Haumea',god:'Haumea',greek:'Hawaiian goddess',ancient:'named outside the Greek pantheon',kind:'minor',color:'#c2c9cf',R:780,rot:3.915,vowel:'ae',
  voice:'A guest voice from the Hawaiian pantheon: the fastest pulse in the choir, from a four-hour day.', el:pe(43.1,0.195,28.2,122.2,239.0,jdOf(2133,1,1)),moons:[]},
 {id:'makemake',name:'Makemake',god:'Makemake',greek:'Rapa Nui creator',ancient:'named outside the Greek pantheon',kind:'minor',color:'#c99f86',R:715,rot:22.83,vowel:'o',
  voice:'A guest voice from Rapa Nui: a low, remote “oh”.', el:pe(45.4,0.161,29.0,79.6,294.8,jdOf(2186,1,1)),moons:[]},
 {id:'sedna',name:'Sedna',god:'Sedna',greek:'Inuit sea goddess',ancient:'named outside the Greek pantheon',kind:'minor',color:'#c9705a',R:500,rot:10.3,vowel:'u',
  voice:'A guest voice from the Inuit sea: the slowest wanderer here, folded up into hearing.', el:pe(506,0.855,11.93,144.4,311.3,jdOf(2076,3,1)),moons:[]},
 {id:'halley',name:'1P/Halley',god:'Halley',greek:'κομήτης',ancient:'the long-haired star',kind:'comet',color:'#bfe1ff',R:5.5,rot:52.8,
  voice:'A breath of wind that roars past the Sun every 76 years, travelling against the planets.', el:pe(17.83,0.96714,162.26,58.42,111.33,jdOf(1986,2,9)),moons:[]},
 {id:'encke',name:'2P/Encke',god:'Encke',greek:'κομήτης',ancient:'the long-haired star',kind:'comet',color:'#c9e6ff',R:2.4,rot:11,
  voice:'The quickest comet: a whisper that returns every 3.3 years.', el:pe(2.215,0.848,11.78,334.57,186.54,jdOf(2023,10,22)),moons:[]},
 {id:'cg67p',name:'67P/Churyumov–Gerasimenko',god:'67P',greek:'κομήτης',ancient:'the long-haired star',kind:'comet',color:'#d3eaff',R:2,rot:12.4,
  voice:'Rosetta’s comet: a faint breath every six and a half years.', el:pe(3.46,0.641,7.04,50.1,12.8,jdOf(2021,11,2)),moons:[]},
 {id:'swift',name:'109P/Swift–Tuttle',god:'Swift–Tuttle',greek:'κομήτης',ancient:'parent of the Perseids',kind:'comet',color:'#b8dcff',R:13,rot:70,
  voice:'Mother of the Perseid meteors, steeply tilted; next close pass in 2126.', el:pe(26.09,0.963,113.45,139.38,152.98,jdOf(1992,12,12)),moons:[]},
 {id:'tempel',name:'55P/Tempel–Tuttle',god:'Tempel–Tuttle',greek:'κομήτης',ancient:'parent of the Leonids',kind:'comet',color:'#c4e0ff',R:1.8,rot:15,
  voice:'Mother of the Leonids, orbiting backward every 33 years.', el:pe(10.33,0.906,162.5,235.3,172.5,jdOf(1998,2,28)),moons:[]},
 {id:'halebopp',name:'C/1995 O1 Hale–Bopp',god:'Hale–Bopp',greek:'κομήτης',ancient:'the great comet of 1997',kind:'comet',color:'#e2f0ff',R:30,rot:11.3,
  voice:'A huge, slow comet whose breath last swelled in 1997 and returns in about 2,500 years.', el:pe(186,0.995,89.4,282.47,130.59,jdOf(1997,4,1)),moons:[]}
];
// human voices: the gods' characters. Dwarf planets and asteroids are children; comets whisper.
// type, glottal tilt (higher = darker), vibrato [Hz, depth], breath, jitter, syllable s, rest s, ensemble, words, speech
const HV={
 mercury:{type:'ct',tilt:1.0,vib:[6.2,.03],breath:.06,jit:.004,syl:.42,rest:1.4,ens:.2,words:'h e r m e: s',say:['m',1.3,1.2,"I am Hermes the messenger of the gods, Stilbon the Gleaming. I run my circuit of the Sun in eighty-eight days and no wanderer is swifter."]},
 venus:{type:'soprano',tilt:1.15,vib:[5.2,.035],breath:.1,jit:.004,syl:.8,rest:2.5,ens:.2,words:'a f r o d i t e:',say:['f',1.1,.9,"I am Aphrodite the morning and the evening star. My day is longer than my year and I turn backward against all the others."]},
 earth:{type:'alto',tilt:1.2,vib:[5.0,.025],breath:.08,jit:.004,syl:.9,rest:2.6,ens:.3,words:'g a i a:',say:['f',.95,.88,"I am Gaia the mother of all things. You are standing upon me, and Selene my Moon keeps me company each month."]},
 mars:{type:'tenor',tilt:.95,vib:[5.8,.035],breath:.05,jit:.008,syl:.55,rest:1.8,ens:.25,words:'a r e: s',say:['m',.85,1.05,"I am Ares the Fiery, and Fear and Dread run at my side."]},
 jupiter:{type:'bass',tilt:1.0,vib:[5.0,.03],breath:.04,jit:.004,syl:1.1,rest:2.8,ens:.6,words:'z e u: s',say:['m',.55,.85,"I am Zeus the Shining king of Olympus. Twelve years I take to walk the zodiac and my moons are many."]},
 saturn:{type:'bass',tilt:1.3,vib:[4.4,.045],breath:.12,jit:.009,syl:1.5,rest:3.5,ens:.4,words:'k r o n o: s',say:['m',.45,.75,"I am Kronos the father of time. I walk slowly in my rings, twenty-nine years to a circuit."]},
 uranus:{type:'bass',tilt:1.35,vib:[4.6,.03],breath:.15,jit:.005,syl:1.6,rest:3.8,ens:.4,words:'u r a n o: s',say:['m',.5,.7,"I am Ouranos the sky itself and the first of all the fathers. I roll upon my side, eighty-four years to a turn."]},
 neptune:{type:'bass',tilt:1.2,vib:[4.8,.04],breath:.1,jit:.006,syl:1.4,rest:3.4,ens:.4,words:'p o s e i d o: n',say:['m',.55,.78,"I am Poseidon the lord of the deep. One hundred and sixty-five years I take to circle the Sun."]},
 pluto:{type:'child',tilt:1.35,vib:[4.6,.02],breath:.16,jit:.004,syl:1.3,rest:3.6,ens:0,words:'h a i d e: s',say:['m',1.35,.85,"I am little Hades the unseen one. I keep to the cold edge and Charon keeps me company."]},
 ceres:{type:'child',tilt:1.15,vib:[5.4,.025],breath:.08,jit:.004,syl:.75,rest:2.4,ens:0,words:'d e m e t e: r',say:['f',1.55,1.0,"I am Demeter the harvest child and the biggest of the stones between Ares and Zeus."]},
 vesta:{type:'child',tilt:1.15,vib:[5.6,.02],breath:.1,jit:.004,syl:.6,rest:2.2,ens:0,words:'h e s t i a:',say:['f',1.6,1.0,"I am Hestia the keeper of the hearth. I tend the fire out in the belt of stones."]},
 pallas:{type:'child',tilt:1.05,vib:[5.8,.015],breath:.05,jit:.003,syl:.55,rest:2.0,ens:0,words:'a th e n a:',say:['f',1.55,1.05,"I am Pallas Athena the grey-eyed. My path climbs steeply above all the others."]},
 juno:{type:'child',tilt:1.1,vib:[5.6,.025],breath:.06,jit:.004,syl:.65,rest:2.2,ens:0,words:'h e r a:',say:['f',1.6,1.0,"I am Hera the little queen. I walk the belt of stones in four and a half years."]},
 hygiea:{type:'child',tilt:1.15,vib:[5.8,.02],breath:.1,jit:.004,syl:.6,rest:2.3,ens:0,words:'h u g i e i a:',say:['f',1.65,.95,"I am Hygieia the healing child. I keep quietly to the outer edge of the belt."]},
 eros:{type:'child',tilt:1.0,vib:[6.2,.025],breath:.07,jit:.004,syl:.4,rest:1.5,ens:0,words:'e r o: s',say:['m',1.7,1.15,"I am little Eros and I swing close to Gaia, where every heart notices."]},
 eris:{type:'child',tilt:.95,vib:[6.4,.04],breath:.07,jit:.014,syl:.45,rest:1.7,ens:0,words:'e r i: s',say:['f',1.5,1.15,"I am Eris the troublemaker. When they found me Hades lost his place among the planets."]},
 haumea:{type:'child',tilt:1.1,vib:[5.8,.025],breath:.08,jit:.004,syl:.32,rest:1.4,ens:0,words:'h a u m e a:',say:['f',1.55,1.1,"I am Haumea the guest from the Hawaiian islands. I spin all the way round every four hours."]},
 makemake:{type:'child',tilt:1.2,vib:[5.2,.025],breath:.1,jit:.004,syl:.7,rest:2.6,ens:0,words:'m a k e m a k e:',say:['m',1.4,.95,"I am Makemake the guest from Rapa Nui, playing far out in the Kuiper belt."]},
 sedna:{type:'child',tilt:1.35,vib:[4.8,.025],breath:.18,jit:.004,syl:1.3,rest:4.0,ens:0,words:'s e d n a:',say:['f',1.4,.85,"I am Sedna from the Inuit sea. One of my years is longer than eleven thousand of yours."]},
 halley:{type:'tenor',syl:.5,rest:2.6,words:'k o m e t e: s',say:['m',1,1,"I am Halley's comet the long-haired star. I come back every seventy-six years travelling against the planets."]},
 encke:{type:'alto',syl:.4,rest:2.0,words:'k o m e t e: s',say:['f',1.05,1.05,"I am Encke's comet the quickest of all. I return every three years and a little more."]},
 cg67p:{type:'alto',syl:.45,rest:2.4,words:'k o m e t e: s',say:['f',1,1,"I am comet sixty-seven P and a spacecraft called Rosetta once came to live beside me."]},
 swift:{type:'tenor',syl:.55,rest:2.8,words:'k o m e t e: s',say:['m',.95,.95,"I am Swift-Tuttle the mother of the Perseid meteors. I will pass close again in twenty-one twenty-six."]},
 tempel:{type:'alto',syl:.5,rest:2.6,words:'k o m e t e: s',say:['f',1,1,"I am Tempel-Tuttle the mother of the Leonid meteors. I circle backward every thirty-three years."]},
 halebopp:{type:'bass',syl:.7,rest:3.2,words:'k o m e t e: s',say:['m',.9,.9,"I am Hale-Bopp the great comet of nineteen ninety-seven. I will not return for two and a half thousand years."]}
};
BODIES.forEach(b=>b.hv=HV[b.id]);
// axial tilt in degrees (over 90 means the body spins backward)
const OBLIQ={mercury:.03,venus:177.4,earth:23.44,mars:25.19,jupiter:3.13,saturn:26.73,uranus:97.77,neptune:28.32,pluto:122.5};
const byId=Object.fromEntries(BODIES.map(b=>[b.id,b]));
BODIES.forEach(b=>{
  const lr=Math.log10(Math.max(b.R,1))/Math.log10(70000);
  b.sizeN=Math.max(0,Math.min(1,lr));
  b.sizeG=b.kind==='comet'?1:0.15+0.85*b.sizeN*b.sizeN;
  b.obl=OBLIQ[b.id];b.tiltWob=b.obl===undefined?0:22*Math.abs(Math.sin(b.obl*DEG));
  b.Pyears=360/b.el.n/365.25;
  (b.moons||[]).forEach((m,k)=>{m.ph0=((k*0.618034+b.R*0.0001)%1);m.rank=k;m.sizeN=Math.log10(m.R/5)/Math.log10(2634/5);m.flash=0});
  // sort moon ranks by distance
  const sorted=[...b.moons].sort((x,y)=>x.a-y.a); sorted.forEach((m,k)=>m.rank=k);
});

/* ---------- state ---------- */
const S={
  jd:jdNow(), playing:true, dir:1, speed:20,
  vp:'sun', face:'vernal', turn:0, hrtf:!(matchMedia('(hover:none)').matches||/Android|iPhone|iPad/i.test(navigator.userAgent)),
  tuning:'dia', mode:'E', drone:true, F:330, dist:0.5, verb:0.4, vol:0.7,
  groups:{planet:{on:true,vol:1,label:'Planets'},minor:{on:true,vol:.8,label:'Dwarfs & asteroids'},comet:{on:true,vol:.9,label:'Comets'},moons:{on:true,vol:.8,label:'Moons'},belt:{on:true,vol:.7,label:'Belt bells'}},
  thinker:'today', interp:(()=>{try{return localStorage.getItem('mots.interp')||'athens'}catch(e){return 'athens'}})(), muted:new Set(), solo:new Set(), sel:'earth', audition:null, voices:'instrument', minorMode:'wobble', zodiacKey:true, aspects:true, speak:true, speaking:false,
  az:-0.35, tilt:58*DEG, rmax:40, labelsAll:false
};

/* ---------- orbital mechanics ---------- */
function kepler(M,e){
  M=((M%TAU)+TAU)%TAU;
  let E=e<0.8?M:Math.PI;
  for(let k=0;k<60;k++){const d=(E-e*Math.sin(E)-M)/(1-e*Math.cos(E));E-=d;if(Math.abs(d)<1e-11)break;}
  return E;
}
function rotate(el,xp,yp){
  const co=Math.cos(el.w*DEG),so=Math.sin(el.w*DEG),cO=Math.cos(el.Om*DEG),sO=Math.sin(el.Om*DEG),ci=Math.cos(el.i*DEG),si=Math.sin(el.i*DEG);
  return {
    x:(co*cO-so*sO*ci)*xp+(-so*cO-co*sO*ci)*yp,
    y:(co*sO+so*cO*ci)*xp+(-so*sO+co*cO*ci)*yp,
    z:(so*si)*xp+(co*si)*yp
  };
}
function posAt(el,jd){
  const M=(el.M0+el.n*(jd-el.epoch))*DEG, E=kepler(M,el.e), cE=Math.cos(E), sE=Math.sin(E);
  const xp=el.a*(cE-el.e), yp=el.a*Math.sqrt(1-el.e*el.e)*sE;
  const p=rotate(el,xp,yp);
  const cnu=(cE-el.e)/(1-el.e*cE);
  p.om=el.n*DEG*Math.pow(1+el.e*cnu,2)/Math.pow(1-el.e*el.e,1.5);
  p.r=Math.hypot(p.x,p.y,p.z);
  return p;
}
BODIES.forEach(b=>{
  const pts=[];const N=b.el.e>0.8?360:200;
  for(let k=0;k<=N;k++){
    // eccentric orbits: sample densely near perihelion (E near 0 and 2π)
    const u=k/N, E=b.el.e>0.8?Math.PI*(1-Math.cos(Math.PI*u)):TAU*u;
    const xp=b.el.a*(Math.cos(E)-b.el.e), yp=b.el.a*Math.sqrt(1-b.el.e*b.el.e)*Math.sin(E);
    pts.push(rotate(b.el,xp,yp));
  }
  b.orbit=pts;
});

// asteroid belt
let seed=7; const rnd=()=>{seed=(seed*16807)%2147483647;return (seed-1)/2147483646};
const BELT=[];
for(let k=0;k<520;k++){
  const a=2.15+Math.pow(rnd(),0.9)*1.2, i=(rnd()-.5)*24*DEG*rnd(), Om=rnd()*TAU, th0=rnd()*TAU;
  BELT.push({a,i,Om,th0,n:TAU/(365.25*Math.pow(a,1.5)),flash:0});
}
function beltPos(p,jd){
  const th=p.th0+p.n*(jd-J2000);
  const x=p.a*Math.cos(th), y=p.a*Math.sin(th), z=p.a*Math.sin(p.i)*Math.sin(th-p.Om);
  return {x,y,z,om:p.n,r:p.a};
}
const STARS=[];for(let k=0;k<420;k++)STARS.push({x:rnd(),y:rnd(),m:rnd()});

/* ---------- pitch ---------- */
const NOTE=['C','C♯','D','E♭','E','F','F♯','G','G♯','A','B♭','B'];
const PY={C:1,D:9/8,E:81/64,F:4/3,G:3/2,A:27/16,B:243/128};
const C_BASE=440*16/27/16; // Pythagorean C0 relative to A=440
const SETS={dia:['C','D','E','F','G','A','B'],pent:['C','D','E','G','A']};
function quantize(f){
  if(S.tuning==='free')return f;
  const set=SETS[S.tuning].map(n=>Math.log2(PY[n]));set.push(1);
  const sh=keyShift(), l=Math.log2(f/C_BASE)-sh, o=Math.floor(l), fr=l-o;
  let best=set[0],bd=9;for(const s of set){const d=Math.abs(s-fr);if(d<bd){bd=d;best=s}}
  return C_BASE*Math.pow(2,o+best+sh);
}
/* ---------- the zodiac ---------- */
const SIGNS=[['Κριός','Aries','♈'],['Ταῦρος','Taurus','♉'],['Δίδυμοι','Gemini','♊'],['Καρκίνος','Cancer','♋'],['Λέων','Leo','♌'],['Παρθένος','Virgo','♍'],['Ζυγός','Libra','♎'],['Σκορπίος','Scorpio','♏'],['Τοξότης','Sagittarius','♐'],['Αἰγόκερως','Capricorn','♑'],['Ὑδροχόος','Aquarius','♒'],['Ἰχθύες','Pisces','♓']];
// the Sun's longitude as seen from Earth, which is Earth's own heliocentric longitude turned round by 180 degrees
const KS={jd:null,lon:0};
function sunLon(){if(KS.jd!==S.jd){const e=posAt(byId.earth.el,S.jd);KS.lon=((Math.atan2(-e.y,-e.x)/DEG)%360+360)%360;KS.jd=S.jd}return KS.lon}
function sunSign(){return Math.floor(sunLon()/30)%12}
// the Sun's sign sets the key: each sign a Pythagorean fifth above the last, so the year turns once round the circle of fifths.
// Aries is home; Libra, at the autumn equinox, is the furthest key away. Kept within half an octave either way.
function keyName(){return noteName(droneFreqs()[0]).replace(/-?\d.*$/,'')}
function zodiacLine(){
  const i=sunSign();let t=`Sun in <b>${SIGNS[i][0]}</b> (${SIGNS[i][1]})`+(S.zodiacKey?` · key of ${keyName()}`:'');
  if(ASPNOW.length)t+='<span class="asp"><br>'+ASPNOW.slice(0,3).map(a=>`${a.a.god} ${a.asp.sym}\uFE0E ${a.b.god}: ${a.asp.name}, ${a.asp.iv}`).join('<br>')+'</span>';
  return t;
}
function keyShift(){if(!S.zodiacKey||S.thinker!=='today')return 0;let v=(sunSign()*Math.log2(1.5))%1;if(v>=.5)v-=1;return v}
function rawPitch(om){let f=S.F*Math.pow(om/OM_EARTH,0.353);while(f<40)f*=2;while(f>2400)f/=2;return f}
function moonPitch(P){let f=1760*Math.pow(Math.abs(P)/0.3,-0.294)*(S.F/330);while(f<120)f*=2;return quantize(f)}
function noteName(f){
  if(!f||!isFinite(f))return '—';
  const m=69+12*Math.log2(f/440), r=Math.round(m), c=Math.round((m-r)*100);
  return NOTE[((r%12)+12)%12]+(Math.floor(r/12)-1)+(c===0?'':(c>0?' +':' −')+Math.abs(c)+'¢');
}

/* ---------- frame state ---------- */
const P={}; // positions this frame
function computePositions(){BODIES.forEach(b=>{const p=posAt(b.el,S.jd);p.f=S.thinker==='kepler'&&KEP6.has(b.id)?kepF(b,p.om):S.thinker==='copernicus'&&KEP6.has(b.id)?copF(b):quantize(rawPitch(p.om));if(b.kind==='comet')p.act=Math.min(1,Math.pow(1.6/p.r,2));P[b.id]=p});}
function listenerPos(){return S.vp==='sun'?{x:0,y:0,z:0}:P[S.vp]}
function facingAngle(){
  const L=listenerPos();let ang=0;
  if(S.face==='sun'){ if(S.vp==='sun')ang=0; else ang=Math.atan2(-L.y,-L.x); }
  else if(S.face==='vernal')ang=0;
  else { const T=S.face==='sun'?{x:0,y:0}:P[S.face]; if(S.face===S.vp)ang=0; else ang=Math.atan2(T.y-L.y,T.x-L.x); }
  return ang+S.turn*DEG;
}
function audible(b){
  if(S.thinker!=='today'){if(!KEP6.has(b.id)||THINK[S.thinker].model!=='bodies')return false;return S.audition?b.id===S.audition:true}
  if(S.audition)return b.id===S.audition;
  if(!S.groups[b.kind].on)return false;
  if(S.muted.has(b.id))return false;
  if(S.solo.size&&!S.solo.has(b.id))return false;
  return true;
}


/* ================= DANCE: the sky plays the band ================= */
const $=id=>document.getElementById(id);
const LOWPOWER=matchMedia('(hover:none)').matches||/Android|iPhone|iPad/i.test(navigator.userAgent);
const STYLES={
  trance:{name:'Trance',bpm:138,mode:'A',swing:0,kickF:[165,46,.30],arp:1,lead:1,pads:'saw',bass:'rolling',hats:'trance',toms:.25,buildBars:8,clap:'clap'},
  house:{name:'House',bpm:124,mode:'D',swing:.17,kickF:[130,50,.36],arp:.45,lead:.9,pads:'stab',bass:'house',hats:'house',toms:.55,buildBars:4,clap:'clap'},
  techno:{name:'Techno',bpm:130,mode:'E',swing:0,kickF:[175,42,.52],arp:.3,lead:.25,pads:'drone',bass:'acid',hats:'techno',toms:1,buildBars:8,clap:'rim'}
};
const D={style:'trance',bpm:138,dpb:3,vol:.7,playing:false,step:0,section:'intro',secBar:0,secLen:8,energy:.4,lastDrop:-99,prevMax:0,
  mute:new Set(),prog:[0,5,3,4],progInfo:[],motif:null,motifKey:'',tomPat:null,tomKey:'',acid:null,acidKey:''};
const STY=()=>STYLES[D.style];
const RECBASE='dance-of-the-spheres-';
// each style's output level, so the acoustic styles sit as loud as the club ones
const outGain=()=>D.vol*.42*(STY().gain||1);
// steps per bar: four sixteenths per beat, three beats for the waltz and fandango
const SPB=()=>(STY().beats||4)*(STY().sub||4);

/* ---- scale and harmony, in Pythagorean tuning, transposed by the Sun's sign ---- */
function modeDeg(){const t=Math.log2(PY[S.mode]);return Object.values(PY).map(r=>((Math.log2(r)-t)%1+1)%1).sort((a,c)=>a-c)}
let DEG7=null;
function noteF(deg,oct){const d=DEG7,t=Math.log2(PY[S.mode])+keyShift();const o=Math.floor(deg/7),i=((deg%7)+7)%7;const f=C_BASE*Math.pow(2,t+oct+o+d[i]);return D.raise3&&i===2?f*2187/2048:f}
// geocentric zodiac sign of a body: the sign it stands in, seen from Earth
function signOf(id){const p=P[id],e=P.earth;return Math.floor(((Math.atan2(p.y-e.y,p.x-e.x)/DEG)%360+360)%360/30)%12}
const DEGFOR=[0,5,3,4,2,6,0,5,3,4,2,6];
const ROMAN=['i','ii','iii','iv','v','vi','vii'];
// four-bar progression: home, then the chords Zeus, Kronos and Poseidon stand on
function updateProgression(){
  const who=['jupiter','saturn','neptune'];
  const prog=[0];const info=[{deg:0,who:'Apollo',sign:null}];
  who.forEach(id=>{let d=DEGFOR[signOf(id)];if(d===prog[prog.length-1])d=(d+3)%7;prog.push(d);info.push({deg:d,who:byId[id].god,sign:signOf(id)})});
  if(STY().cadence){
    // the Andalusian cadence: the sky picks the first two chords, then the Phrygian second and home
    let dz=info[1].deg,dk=info[2].deg;if(dz<=1)dz=3;if(dk<=1||dk===dz)dk=dz===2?3:2;
    D.prog=[dz,dk,1,0];D.progInfo=[{deg:dz,who:info[1].who,sign:info[1].sign},{deg:dk,who:info[2].who,sign:info[2].sign},{deg:1,who:CADENCE,sign:null},{deg:0,who:'Apollo',sign:null}];return}
  D.prog=prog;D.progInfo=info;
}
const chordTones=(deg)=>[deg,deg+2,deg+4];

/* ---- aspects, heliocentric: they drive builds and drops ---- */
const ASPS=[{ang:0,name:'conjunction',sym:'☌',orb:7},{ang:60,name:'sextile',sym:'⚹',orb:4},{ang:90,name:'square',sym:'□',orb:6},{ang:120,name:'trine',sym:'△',orb:6},{ang:180,name:'opposition',sym:'☍',orb:7}];
let ASPNOW=[];
function computeAspectsD(){
  ASPNOW=[];const pl=BODIES.filter(b=>b.kind==='planet').map(b=>({b,lon:Math.atan2(P[b.id].y,P[b.id].x)/DEG}));
  for(let i=0;i<pl.length;i++)for(let j=i+1;j<pl.length;j++){let s=Math.abs(pl[i].lon-pl[j].lon)%360;if(s>180)s=360-s;
    for(const a of ASPS){const dv=Math.abs(s-a.ang);if(dv<a.orb){ASPNOW.push({a:pl[i].b,b:pl[j].b,asp:a,str:Math.pow(1-dv/a.orb,2)});break}}}
  ASPNOW.sort((x,y)=>y.str-x.str);
}

/* ---- seeded patterns that follow the planets' signs ---- */
function rng(seed){let s=seed*9301+49297;return ()=>{s=(s*16807)%2147483647;return (s-1)/2147483646}}
function ensurePatterns(){
  const vk=signOf('venus')+'/'+D.style;
  if(D.motifKey!==vk){D.motifKey=vk;const r=rng(signOf('venus')*31+7);const m=[];
    for(let k=0;k<32;k++){const hit=(k%4===0&&r()<.75)||(k%4===2&&r()<.45)||(k%2===1&&r()<.12);m.push(hit?{deg:[0,2,4,7,4,2,1,5][Math.floor(r()*8)],len:k%4===0?.38:.2,vow:r()<.5?'a':'o'}:null)}D.motif=m}
  const tk=signOf('mars')+'/'+D.style;
  if(D.tomKey!==tk){D.tomKey=tk;const r=rng(signOf('mars')*17+3);D.tomPat=Array.from({length:16},(_,k)=>k%4!==0&&r()<.16?(r()<.5?0:2):null)}
  const ak=signOf('jupiter')+'/'+D.style;
  if(D.acidKey!==ak){D.acidKey=ak;const r=rng(signOf('jupiter')*13+5);D.acid=Array.from({length:16},(_,k)=>({deg:[0,0,0,7,3,0,5,-2][Math.floor(r()*8)],acc:r()<.3,on:k%4===0||r()<.7}))}
}

/* ---- audio graph ---- */
let AC=null,master,lim,musicBus,duck,musicLP,drumBus,revSend,dlySend,noiseBuf,PAN={},padV=[],subV=null,audioOn=false;
const mkG=(v,to)=>{const g=AC.createGain();g.gain.value=v;if(to)g.connect(to);return g};
function makeTemple(input,output){
  const pre=mkG(.5);input.connect(pre);
  [[.0437,-.8],[.0531,.8],[.0617,-.35],[.0719,.35]].forEach(([dt,pan])=>{
    const d=AC.createDelay(.2);d.delayTime.value=dt*1.9;
    const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=2600;lp.Q.value=-3;
    const fb=mkG(.78),out=AC.createStereoPanner();out.pan.value=pan;
    pre.connect(d);d.connect(lp);lp.connect(fb);fb.connect(d);lp.connect(out);out.connect(output);
  });
}
function initDanceAudio(){
  const C=window.AudioContext||window.webkitAudioContext;try{AC=new C({latencyHint:'playback'})}catch(e){AC=new C()}
  master=mkG(0);
  lim=AC.createDynamicsCompressor();lim.threshold.value=-6;lim.knee.value=0;lim.ratio.value=20;lim.attack.value=.002;lim.release.value=.15;
  const glue=AC.createDynamicsCompressor();glue.threshold.value=-16;glue.ratio.value=3;glue.attack.value=.01;glue.release.value=.2;
  glue.connect(master);master.connect(lim);lim.connect(AC.destination);
  drumBus=mkG(.9,glue);
  musicLP=AC.createBiquadFilter();musicLP.type='lowpass';musicLP.frequency.value=3000;musicLP.Q.value=.3;
  duck=mkG(1,musicLP);musicBus=duck;musicLP.connect(glue);
  // shared space: a light reverb and a dotted-eighth echo
  const wet=mkG(.55,glue);revSend=mkG(1);makeTemple(revSend,wet);
  const dl=AC.createDelay(1.5);const dfb=mkG(.33);const dlp=AC.createBiquadFilter();dlp.type='lowpass';dlp.frequency.value=3200;dlp.Q.value=-3;
  dlySend=mkG(1);dlySend.connect(dl);dl.connect(dlp);dlp.connect(dfb);dfb.connect(dl);dlp.connect(mkG(.45,glue));D.delayNode=dl;
  noiseBuf=AC.createBuffer(1,AC.sampleRate*2,AC.sampleRate);const nd=noiseBuf.getChannelData(0);for(let i=0;i<nd.length;i++)nd[i]=Math.random()*2-1;
  // one stereo position per planet, from where it stands around the Sun
  BODIES.filter(b=>b.kind==='planet').concat([{id:'sun'}]).forEach(b=>{const p=AC.createStereoPanner();PAN[b.id]=p});
  ['sun','mercury','earth','mars'].forEach(id=>PAN[id].connect(drumBus));
  ['jupiter','saturn','venus','uranus','neptune'].forEach(id=>PAN[id].connect(musicBus));
  // 5.1: the band's gods circle the room with their planets (the vernal point ahead); drums and bass stay at the front
  if(window.MOTS&&MOTS.surround){['jupiter','saturn','venus','uranus','neptune'].forEach(id=>MOTS.surround.add(PAN[id],{az:()=>P[id]?Math.atan2(P[id].y,P[id].x)*180/Math.PI:null}));
    MOTS.surround.attach({ctx:AC,master,lim,entry:duck,bypass:[[musicLP,glue,master]]})}
  buildPads();buildSub();
}
function noise(t,dur){const s=AC.createBufferSource();s.buffer=noiseBuf;s.start(t,Math.random()*1.5,dur+.05);return s}
const env=(g,t,peak,att,dec)=>{g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(peak,t+att);g.gain.setTargetAtTime(0,t+att,dec)};

/* drums */
function kick(t){
  const [f0,f1,dec]=STY().kickF, o=AC.createOscillator(), g=mkG(0,PAN.sun);
  o.frequency.setValueAtTime(f0,t);o.frequency.exponentialRampToValueAtTime(f1,t+.11);
  env(g,t,1.1*(STY().kickLvl||1),.002,dec*.42);o.connect(g);o.start(t);o.stop(t+dec*3);
  const c=noise(t,.02),hp=AC.createBiquadFilter();hp.type='highpass';hp.frequency.value=2500;const cg=mkG(0,PAN.sun);env(cg,t,.25,.001,.006);c.connect(hp);hp.connect(cg);
  if(D.style==='techno'){const rg=mkG(0);env(rg,t+.05,.5,.01,.18);const rl=AC.createBiquadFilter();rl.type='lowpass';rl.frequency.value=160;o.connect(rg);rg.connect(rl);rl.connect(revSend)}
  // sidechain: the music breathes with the kick
  duckIt(t);
  flash('sun',t);
}
function duckIt(t){const d=STY().duck||.32;duck.gain.cancelScheduledValues(t);duck.gain.setTargetAtTime(d,t,.004);duck.gain.setTargetAtTime(1,t+.06,.09)}
function clap(t,v=1){
  const n=noise(t,.25),bp=AC.createBiquadFilter();bp.type='bandpass';bp.frequency.value=STY().clap==='rim'?2600:1300;bp.Q.value=STY().clap==='rim'?6:1.2;
  const g=mkG(0,PAN.earth);n.connect(bp);bp.connect(g);
  if(STY().clap==='rim'){env(g,t,.5*v,.001,.018)}else{[0,.011,.022].forEach(d=>{g.gain.setValueAtTime(.55*v,t+d);g.gain.setTargetAtTime(.05,t+d+.002,.004)});g.gain.setValueAtTime(.45*v,t+.03);g.gain.setTargetAtTime(0,t+.03,.06)}
  bp.connect(mkG(.2,revSend));flash('earth',t);
}
function snare(t,v){
  const n=noise(t,.2),bp=AC.createBiquadFilter();bp.type='bandpass';bp.frequency.value=1900;bp.Q.value=.9;const g=mkG(0,PAN.earth);env(g,t,.42*v,.001,.045);n.connect(bp);bp.connect(g);
  const o=AC.createOscillator();o.type='triangle';o.frequency.setValueAtTime(200,t);o.frequency.exponentialRampToValueAtTime(150,t+.08);const og=mkG(0,PAN.earth);env(og,t,.25*v,.001,.03);o.connect(og);o.start(t);o.stop(t+.25);
  bp.connect(mkG(.25,revSend));flash('earth',t);
}
function hat(t,open,v){
  const n=noise(t,open?.35:.08),hp=AC.createBiquadFilter();hp.type='highpass';hp.frequency.value=open?6500:7800;
  const g=mkG(0,PAN.mercury);env(g,t,(open?.2:.16)*v,.001,open?.07:.014);n.connect(hp);hp.connect(g);flash('mercury',t);
}
function tom(t,f,v=1){const o=AC.createOscillator();o.frequency.setValueAtTime(f,t);o.frequency.exponentialRampToValueAtTime(f*.55,t+.22);const g=mkG(0,PAN.mars);env(g,t,.42*v,.002,.09);o.connect(g);o.start(t);o.stop(t+.5);o.connect(mkG(.12,revSend));flash('mars',t)}
// the composers and Bach have no noise effects: no cymbal crash at the climax, no comet whoosh
const classical=()=>!!(STY().own||D.style==='baroque');
function crash(t){const n=noise(t,1.8),hp=AC.createBiquadFilter();hp.type='highpass';hp.frequency.value=4200;const g=mkG(0,drumBus);env(g,t,.22,.002,.55);n.connect(hp);hp.connect(g);hp.connect(mkG(.3,revSend))}

/* bass: Zeus */
function bass(t,f,len,opt={}){
  const o=AC.createOscillator();o.type='sawtooth';o.frequency.setValueAtTime(f,t);
  const o2=D.style==='house'?AC.createOscillator():null;if(o2){o2.type='square';o2.frequency.setValueAtTime(f/2,t)}
  const lp=AC.createBiquadFilter();lp.type='lowpass';
  const acid=D.style==='techno';lp.Q.value=acid?14:(D.style==='trance'?2:4);
  const base=acid?260:(D.style==='trance'?380:300),top=acid?(opt.acc?2600:1200):(D.style==='trance'?1400:900);
  lp.frequency.setValueAtTime(top,t);lp.frequency.setTargetAtTime(base,t+.005,acid?.07:.05);
  const g=mkG(0,PAN.jupiter);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(acid?(opt.acc?.42:.3):.42,t+.004);g.gain.setValueAtTime(acid?(opt.acc?.42:.3):.42,t+len*.85);g.gain.linearRampToValueAtTime(0,t+len);
  o.connect(lp);if(o2){const g2=mkG(.5,lp);o2.connect(g2);o2.start(t);o2.stop(t+len+.05)}lp.connect(g);o.start(t);o.stop(t+len+.05);
  flash('jupiter',t);
}
/* pads: Kronos */
let padVib=null;
function buildPads(){
  const n=LOWPOWER?2:3;const lfo=AC.createOscillator();lfo.frequency.value=5.3;padVib=mkG(0);lfo.connect(padVib);lfo.start();
  padV=[0,1,2].map(()=>{const g=mkG(0),lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=1800;lp.Q.value=.5;g.connect(lp);lp.connect(PAN.saturn);lp.connect(mkG(.35,revSend));
    const os=Array.from({length:n},(_,k)=>{const o=AC.createOscillator();o.type='sawtooth';o.detune.value=(k-(n-1)/2)*14;padVib.connect(o.detune);o.connect(g);o.start();return o});return {g,lp,os}});
}
function setPads(t,degs,level,cut){
  padV.forEach((v,k)=>{const f=noteF(degs[k],4);v.os.forEach(o=>o.frequency.setTargetAtTime(f,t,.03));v.g.gain.setTargetAtTime(level*.1,t,.25);v.lp.frequency.setTargetAtTime(cut,t,.3)});
}
function stab(t,degs,len){
  degs.forEach(d=>{const f=noteF(d,4);const o=AC.createOscillator();o.type='sawtooth';o.frequency.value=f;const o2=AC.createOscillator();o2.type='square';o2.frequency.value=f*1.004;
    const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.setValueAtTime(3200,t);lp.frequency.setTargetAtTime(700,t,.06);
    const g=mkG(0,PAN.saturn);env(g,t,.085,.003,len*.4);o.connect(lp);o2.connect(lp);lp.connect(g);g.connect(mkG(.4,revSend));o.start(t);o2.start(t);o.stop(t+len*2.5);o2.stop(t+len*2.5)});
  flash('saturn',t);
}
/* arpeggio: Jupiter's moons in their 1:2:4 resonance */
function pluck(t,f,lvl,type,dec,id){
  const o=AC.createOscillator();o.type=type;o.frequency.value=f;const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.setValueAtTime(Math.min(9000,f*6),t);lp.frequency.setTargetAtTime(f*1.5,t,dec*.6);
  const g=mkG(0,PAN.jupiter);env(g,t,lvl,.002,dec);o.connect(lp);lp.connect(g);g.connect(mkG(.35,dlySend));g.connect(mkG(.25,revSend));o.start(t);o.stop(t+dec*6);if(id)flash(id,t);
}
/* lead: Aphrodite's vocal chops */
const VOW={a:[[800,1],[1150,.5],[2900,.2]],o:[[450,1],[800,.4],[2830,.12]]};
function chop(t,f,len,vow){
  const o=AC.createOscillator();o.type='sawtooth';o.frequency.setValueAtTime(f*.985,t);o.frequency.setTargetAtTime(f,t,.02);
  const vib=AC.createOscillator();vib.frequency.value=5.5;const vd=mkG(0);vd.gain.setValueAtTime(0,t);vd.gain.linearRampToValueAtTime(f*.012,t+len);vib.connect(vd);vd.connect(o.frequency);
  const g=mkG(0,PAN.venus);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.32,t+.012);g.gain.setValueAtTime(.32,t+len*.8);g.gain.linearRampToValueAtTime(0,t+len);
  VOW[vow].forEach(([F,a])=>{const bp=AC.createBiquadFilter();bp.type='bandpass';bp.frequency.value=F;bp.Q.value=F/90;o.connect(bp);bp.connect(mkG(a*1.6,g))});
  g.connect(mkG(.4,dlySend));g.connect(mkG(.4,revSend));o.start(t);vib.start(t);o.stop(t+len+.05);vib.stop(t+len+.05);flash('venus',t);
}
/* Ouranos' riser and Poseidon's sub */
function riser(t,dur){
  const n=AC.createBufferSource();n.buffer=noiseBuf;n.loop=true;const bp=AC.createBiquadFilter();bp.type='bandpass';bp.Q.value=2.5;bp.frequency.setValueAtTime(250,t);bp.frequency.exponentialRampToValueAtTime(7000,t+dur);
  const g=mkG(0,PAN.uranus);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.22,t+dur);g.gain.setValueAtTime(0,t+dur+.01);
  n.connect(bp);bp.connect(g);g.connect(mkG(.4,revSend));n.start(t);n.stop(t+dur+.05);
  const o=AC.createOscillator();o.type='sine';o.frequency.setValueAtTime(110,t);o.frequency.exponentialRampToValueAtTime(880,t+dur);const og=mkG(0,PAN.uranus);og.gain.setValueAtTime(0,t);og.gain.linearRampToValueAtTime(.06,t+dur);og.gain.setValueAtTime(0,t+dur+.01);o.connect(og);o.start(t);o.stop(t+dur+.05);
  flash('uranus',t);
}
function buildSub(){const o=AC.createOscillator();o.type='sine';const g=mkG(0,PAN.neptune);o.connect(g);o.start();subV={o,g}}
function whoosh(t){const n=noise(t,3.2),bp=AC.createBiquadFilter();bp.type='bandpass';bp.Q.value=1.4;bp.frequency.setValueAtTime(5000,t);bp.frequency.exponentialRampToValueAtTime(300,t+3);const g=mkG(0,drumBus);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.12,t+.6);g.gain.linearRampToValueAtTime(0,t+3);n.connect(bp);bp.connect(g);g.connect(mkG(.5,revSend))}

/* ---- arrangement: the sky decides when to build, drop and break ---- */
// which instruments play in each section
const LAYERS={
  intro:{kick:1,clap:0,hats:.6,bass:0,pads:.6,arp:.5,lead:0,toms:0,sub:.4},
  groove:{kick:1,clap:1,hats:1,bass:1,pads:.8,arp:.7,lead:.35,toms:1,sub:0},
  build:{kick:0,clap:0,hats:.8,bass:0,pads:1,arp:1,lead:0,toms:0,sub:0},
  drop:{kick:1,clap:1,hats:1,bass:1,pads:1,arp:1,lead:1,toms:1,sub:0},
  break:{kick:0,clap:0,hats:.3,bass:0,pads:1,arp:.8,lead:.5,toms:0,sub:1}
};
function setSection(name,len,bar){D.section=name;D.secLen=len;D.secBar=bar;renderSection();if(window.MOTS&&MOTS.midi.on)MOTS.midi.section(name,nextT)}
function atBar(bar,t){
  computeAspectsD();updateProgression();ensurePatterns();
  const max=ASPNOW.length?ASPNOW[0].str:0, rising=max>D.prevMax+.01;D.prevMax=max;
  D.energy+=((.35+Math.min(.65,ASPNOW.reduce((a,x)=>a+x.str,0)*.35))-D.energy)*.35;
  const into=bar-D.secBar, st=STY();
  if(D.section==='intro'&&into>=D.secLen)setSection('groove',16,bar);
  else if(D.section==='groove'&&into>=8&&bar%4===0&&((max>.55&&rising)||into>=32)&&bar-D.lastDrop>20){setSection('build',st.buildBars,bar);if(st.fam==='ball')ballRiser(t,st.buildBars*barDur());else riser(t,st.buildBars*barDur())}
  else if(D.section==='build'&&into>=D.secLen){setSection('drop',16,bar);D.lastDrop=bar;if(!classical())crash(t);toast('Drop: '+(ASPNOW[0]?`${ASPNOW[0].a.god} ${ASPNOW[0].asp.sym}︎ ${ASPNOW[0].b.god}`:'the spheres align'))}
  else if(D.section==='drop'&&into>=D.secLen)setSection('break',8,bar);
  else if(D.section==='break'&&into>=D.secLen)setSection('groove',16,bar);
  // the music filter opens and closes with the section
  const cut={intro:1400,groove:4200,build:900,drop:14000,break:1600}[D.section];
  if(D.section==='build'&&bar===D.secBar){musicLP.frequency.cancelScheduledValues(t);musicLP.frequency.setValueAtTime(700,t);musicLP.frequency.exponentialRampToValueAtTime(9000,t+D.secLen*barDur())}
  else if(D.section!=='build'&&bar===D.secBar){musicLP.frequency.cancelScheduledValues(t);musicLP.frequency.setTargetAtTime(cut,t,.4)}
  // stereo: each planet sits where it stands around the Sun
  Object.keys(PAN).forEach(id=>{if(id==='sun')return;const p=P[id];PAN[id].pan.setTargetAtTime(Math.sin(Math.atan2(p.y,p.x))*.75,t,.5)});
  // pads change chord each bar
  const deg=D.prog[bar%4], L=LAYERS[D.section], pm=STY().pads==='strings'&&smpReady('string_ensemble_1')?'none':STY().pads;
  D.raise3=!!STY().cadence&&((deg%7)+7)%7===0;
  const padsOn=!D.mute.has('saturn')&&pm!=='stab'&&pm!=='none';
  padVib.gain.setTargetAtTime(pm==='strings'?9:0,t,.2);
  setPads(t,pm==='drone'?[deg-7,deg-3,deg]:chordTones(deg),padsOn?L.pads*(pm==='drone'?.6:pm==='strings'?.5:1):0,pm==='strings'?(D.section==='drop'?2600:1500):D.section==='drop'?5000:D.section==='break'?1500:2600);
  if(padsOn)flash('saturn',t);
  subV.o.frequency.setTargetAtTime(noteF(deg,1),t,.1);subV.g.gain.setTargetAtTime(D.mute.has('neptune')||STY().noSub?0:L.sub*.22,t,.6);if(L.sub)flash('neptune',t);
  // a comet near the Sun sweeps through every eight bars
  if(bar%8===0&&!classical()&&BODIES.some(b=>b.kind==='comet'&&P[b.id].r<1.6))whoosh(t);
  D.delayNode.delayTime.setValueAtTime(45/D.bpm,t);
  renderProg();
}
const barDur=()=>(STY().beats||4)*60/D.bpm;
function playStep(s,t){
  const st=STY(), spb=SPB(), pos=s%spb, bar=Math.floor(s/spb), L=LAYERS[D.section], into=bar-D.secBar, m=id=>!D.mute.has(id);
  if(pos===0)atBar(bar,t);
  const deg=D.prog[bar%4], stepT=barDur()/spb;
  if(st.fam==='ball'){ballStep(s,pos,bar,t,st,L,deg,stepT,m,into,spb);return}
  // Apollo's kick, four to the floor
  if(L.kick&&m('sun')&&pos%4===0){if(!(D.style==='house'&&D.section==='build'&&into===D.secLen-1))kick(t)}
  if(D.style==='techno'&&D.section==='build'&&m('sun')&&pos%4===0)kick(t);
  // Gaia's claps and the build's snare roll
  if(L.clap&&m('earth')&&(pos===4||pos===12))clap(t,1);
  if(D.style==='techno'&&L.clap&&m('earth')&&pos===14&&bar%2)clap(t,.6);
  if(D.section==='build'&&m('earth')){const prog=(into+pos/16)/D.secLen, every=prog<.5?4:prog<.75?2:1;if(pos%every===0)snare(t,.3+.7*prog)}
  // Hermes' hats: busier when Mercury runs fast near perihelion
  if(L.hats&&m('mercury')){const fast=P.mercury.om/(TAU/87.97)>1.12, slow=P.mercury.om/(TAU/87.97)<.88;
    if(st.hats==='trance'){if(pos%4===2)hat(t,true,L.hats);else if(!slow&&(fast||pos%2===0))hat(t,false,.45*L.hats)}
    else if(st.hats==='house'){if(pos%4===2)hat(t,bar%2===0,L.hats);else if(!slow||pos%2===0)hat(t,false,.5*L.hats)}
    else{if(!slow||pos%2===0)hat(t,pos%4===2&&fast,(pos%4===2?.9:.5)*L.hats)}}
  // Zeus' bass
  if(L.bass&&m('jupiter')){
    if(st.bass==='rolling'){if(pos%4!==0)bass(t,noteF(deg,2),stepT*.85)}
    else if(st.bass==='house'){const hits={2:[0,1.6],3:null,6:[7,.9],10:[0,1.6],13:[0,.9],14:[4,.9]};const h=hits[pos];if(h)bass(t,noteF(deg+h[0],2),stepT*h[1])}
    else{const a=D.acid[pos];if(a.on)bass(t,noteF(deg+a.deg,2),stepT*(a.acc?.95:.7),{acc:a.acc})}}
  // Kronos' house stabs
  if(st.pads==='stab'&&L.pads&&m('saturn')&&[2,6,11,14].includes(pos)&&(pos!==11||bar%2))stab(t,chordTones(deg),stepT*1.6);
  // Jupiter's moons: Io, Europa and Ganymede in their 1:2:4 resonance
  if(L.arp&&m('jupiter-moons')){const lv=L.arp*st.arp, tones=chordTones(deg), up=moonWaxing();
    const io=tones[(up?pos:15-pos)%3], eu=tones[(up?pos/2:7-pos/2)%3|0];
    pluck(t,noteF(io,5),.085*lv,'square',stepT*.6,'io');
    if(pos%2===0)pluck(t,noteF(eu,4),.1*lv,'triangle',stepT*1.4,'europa');
    if(pos%4===0)pluck(t,noteF(tones[(pos/4|0)%3],6),.06*lv,'sine',stepT*4,'ganymede');}
  // Aphrodite's vocal chops
  if(L.lead*st.lead>.2&&m('venus')){const mm=D.motif[(bar%2)*16+pos];if(mm&&(L.lead>=.9||pos%8===0))chop(t,noteF(deg+mm.deg,5),barDur()*mm.len,mm.vow)}
  // Ares' toms
  if(L.toms*st.toms>.2&&m('mars')){const tp=D.tomPat[pos];if(tp!==null&&(st.toms>.5||bar%2))tom(t,noteF(deg+tp,3))}
}
function moonWaxing(){const e=P.earth,m=byId.earth.moons[0];const th=TAU*((S.jd-J2000)/m.P+m.ph0),sun=Math.atan2(-e.y,-e.x);return (((th-sun)/TAU)%1+1)%1<.5}

/* ---- the scheduler: a short look-ahead keeps timing tight ---- */
let nextT=0,schedTimer=null;
function scheduler(){
  const ahead=LOWPOWER?.2:.12;
  while(nextT<AC.currentTime+ahead){
    const st=STY(), pos=D.step%SPB(), sd=barDur()/SPB(), sw=st.swing8?(pos%4===2?st.swing8*sd:0):(pos%2===1)?st.swing*sd:0;
    playStep(D.step,nextT+sw);D.step++;nextT+=sd;
  }
}
function startDance(){
  if(!AC)initDanceAudio();
  AC.resume();DEG7=modeDeg();loadStyleSamples();
  D.playing=true;D.step=0;nextT=AC.currentTime+.1;if(window.MOTS&&MOTS.midi.transport)MOTS.midi.transport(true,D.bpm);setSection('intro',8,0);D.lastDrop=-99;
  master.gain.setTargetAtTime(outGain(),AC.currentTime,.05);
  clearInterval(schedTimer);schedTimer=setInterval(scheduler,25);scheduler();syncPlay();
}
function stopDance(){D.playing=false;if(window.MOTS&&MOTS.midi.transport)MOTS.midi.transport(false);clearInterval(schedTimer);if(AC){master.gain.setTargetAtTime(0,AC.currentTime,.05);padV.forEach(v=>v.g.gain.setTargetAtTime(0,AC.currentTime,.1));subV.g.gain.setTargetAtTime(0,AC.currentTime,.1)}syncPlay()}
function setStyle(k){const old=SPB();D.style=k;loadStyleSamples();if(D.playing)D.step=(Math.floor(D.step/old)+1)*SPB();S.mode=STYLES[k].mode;DEG7=AC?modeDeg():null;D.bpm=STYLES[k].bpm;if(window.MOTS&&MOTS.midi.transport)MOTS.midi.transport(D.playing,D.bpm);$('bpm').value=D.bpm;$('bpmOut').textContent=D.bpm+' BPM';
  document.querySelectorAll('#style button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.v===k)));renderMixer();renderProg();if(AC&&D.playing)master.gain.setTargetAtTime(outGain(),AC.currentTime,.1)}

/* ---- visuals: flashes when a planet's instrument sounds ---- */
const FL={},FQ=[];
function flash(id,t){FQ.push([id,t]);if(window.MOTS&&MOTS.midi.on)MOTS.midi.hit(id,t,0,.6,.15)}
function pumpFlashes(){if(!AC)return;const now=AC.currentTime;while(FQ.length&&FQ[0][1]<=now){FL[FQ.shift()[0]]=1}if(FQ.length>400)FQ.splice(0,FQ.length-400)}

/* ================= BALLROOM & LATIN: each dance played by its own band ================= */
// Recorded instruments come from the Fluid R3 General MIDI SoundFont (Frank Wen, CC BY 3.0), loaded per style.
// Until they arrive, or if they cannot be fetched, the synthesised instruments below stand in.
const CADENCE='cadence';
const BALL_INST={
  waltz:{sun:'Bass drum and cymbals',mercury:'Triangle',earth:'Pizzicato strings',mars:'Timpani',jupiter:'Double basses','jupiter-moons':'Harp, 1 : 2 : 4',saturn:'Horns and strings',venus:'Solo violin and flute',uranus:'Cymbal roll and string swell',neptune:'Cellos'},
  tango:{sun:'Golpe on the bass',mercury:'Violin chicharra',earth:'Piano chords',mars:'Piano left hand',jupiter:'Double bass, 3-3-2','jupiter-moons':'Piano arpeggio, 1 : 2 : 4',saturn:'Bandoneons and strings',venus:'Solo violin',uranus:'Bandoneon swell',neptune:'Cellos'},
  samba:{sun:'Surdo',mercury:'Ganzá shaker',earth:'Tamborim',mars:'Agogô bells',jupiter:'Seven-string guitar','jupiter-moons':'Guitar, 1 : 2 : 4',saturn:'Cavaquinho',venus:'Flute',uranus:'Cymbal swell',neptune:'Sub'},
  chacha:{sun:'Timbales',mercury:'Güiro',earth:'Claves, son clave',mars:'Congas',jupiter:'Tumbao bass','jupiter-moons':'Pizzicato violins, 1 : 2 : 4',saturn:'Piano montuno and violins',venus:'Charanga flute',uranus:'Cymbal swell',neptune:'Sub'},
  swing:{sun:'Feathered bass drum',mercury:'Ride cymbal',earth:'Brushes',mars:'Tom fills',jupiter:'Walking bass','jupiter-moons':'Vibraphone, 1 : 2 : 4',saturn:'Saxophone section and piano',venus:'Muted trumpet',uranus:'Trombones and brass shouts',neptune:'Sub'},
  jive:{sun:'Bass drum',mercury:'Ride cymbal',earth:'Snare backbeat',mars:'Tom fills',jupiter:'Walking bass','jupiter-moons':'Electric guitar, 1 : 2 : 4',saturn:'Piano and saxophones',venus:'Tenor saxophone',uranus:'Trombones and brass shouts',neptune:'Sub'},
  fandango:{sun:'Cajón bass',mercury:'Castanets',earth:'Palmas (hand claps)',mars:'Cajón slaps',jupiter:'Guitar thumb','jupiter-moons':'Guitar picado, 1 : 2 : 4',saturn:'Rasgueado guitar',venus:'Cante (voice)',uranus:'Cymbal swell',neptune:'Sub'}
};
const BALL_SAMPLES={
  waltz:['string_ensemble_1','violin','contrabass','french_horn','pizzicato_strings','orchestral_harp','timpani','flute'],
  tango:['tango_accordion','violin','contrabass','acoustic_grand_piano','string_ensemble_1'],
  samba:['acoustic_guitar_nylon','acoustic_guitar_steel','agogo','flute'],
  chacha:['acoustic_grand_piano','acoustic_bass','flute','string_ensemble_1','pizzicato_strings'],
  swing:['acoustic_bass','acoustic_grand_piano','alto_sax','tenor_sax','muted_trumpet','trombone','trumpet','vibraphone'],
  jive:['acoustic_bass','acoustic_grand_piano','alto_sax','tenor_sax','trumpet','trombone','electric_guitar_clean'],
  fandango:['acoustic_guitar_nylon']
};
Object.assign(STYLES,{
  waltz:{gain:2.3,name:'Waltz',fam:'ball',beats:3,bpm:174,mode:'C',swing:0,kickF:[95,48,.45],kickLvl:.25,duck:.92,arp:.55,arpV:'harp',lead:.9,leadLen:1.6,pads:'strings',buildBars:8},
  tango:{gain:2.8,name:'Tango',fam:'ball',beats:4,bpm:118,mode:'A',swing:0,kickF:[110,50,.4],kickLvl:.5,duck:.9,arp:.45,arpV:'piano',lead:.9,leadLen:1.3,pads:'strings',buildBars:4},
  samba:{gain:1.65,name:'Samba',fam:'ball',beats:4,bpm:104,mode:'G',swing:.08,kickF:[95,55,.3],kickLvl:.6,duck:.85,arp:.5,arpV:'guitar',lead:.8,pads:'none',buildBars:4},
  chacha:{gain:2.6,name:'Cha-cha',fam:'ball',beats:4,bpm:120,mode:'D',swing:0,kickF:[120,52,.35],kickLvl:.55,duck:.85,arp:.45,arpV:'pizz',lead:1,pads:'none',buildBars:4},
  swing:{gain:1.9,name:'Swing',fam:'ball',beats:4,bpm:140,mode:'G',swing:0,swing8:.667,kickF:[90,50,.35],kickLvl:.18,duck:.97,arp:.45,arpV:'vibes',lead:.85,leadLen:1.2,pads:'none',buildBars:4},
  jive:{gain:1.5,name:'Jive',fam:'ball',beats:4,bpm:172,mode:'G',swing:0,swing8:.667,kickF:[100,50,.35],kickLvl:.5,duck:.9,arp:.45,arpV:'eguitar',lead:.85,pads:'none',buildBars:8},
  fandango:{gain:1.45,name:'Fandango',fam:'ball',beats:3,bpm:168,mode:'E',swing:0,kickF:[100,50,.3],kickLvl:.6,duck:.85,arp:.5,arpV:'guitar',lead:.9,leadLen:1.8,pads:'none',buildBars:8,cadence:true}
});
// jungle (with the club styles), the slow waltz, and Bach-style counterpoint
Object.assign(BALL_INST,{
  jungle:{sun:'Breakbeat kick',mercury:'Break hats',earth:'Break snares',mars:'Break edits',jupiter:'Reese bass','jupiter-moons':'Arpeggio, 1 : 2 : 4',saturn:'Pads',venus:'Ragga chops',uranus:'Risers',neptune:'Sub'},
  slowwaltz:BALL_INST.waltz,
  baroque:{sun:'Timpani (in the climax)',mercury:'Countersubject (harpsichord)',earth:'Trumpet (in the climax)',mars:'The answer (oboe)',jupiter:'Continuo bass (cello)','jupiter-moons':'Harpsichord, 1 : 2 : 4',saturn:'Continuo harpsichord, then organ',venus:'The subject (violin)',uranus:'Organ swell',neptune:'Organ pedal'}
});
Object.assign(BALL_SAMPLES,{jungle:[],slowwaltz:BALL_SAMPLES.waltz,baroque:['harpsichord','church_organ','cello','violin','oboe','trumpet','timpani']});
Object.assign(STYLES,{
  jungle:{gain:1,name:'Jungle',fam:'ball',beats:4,bpm:166,mode:'A',swing:0,kickF:[160,48,.22],kickLvl:.9,duck:.45,arp:.35,arpV:'synth',lead:.6,pads:'saw',buildBars:8},
  slowwaltz:{gain:2.8,name:'Slow waltz',fam:'ball',beats:3,bpm:90,mode:'C',swing:0,kickF:[90,48,.45],kickLvl:.2,duck:.95,arp:.5,arpV:'harp',lead:.9,leadLen:1.3,pads:'strings',buildBars:4},
  baroque:{gain:3.2,name:'Bach',fam:'ball',beats:4,bpm:80,mode:'A',swing:0,kickF:[90,48,.4],kickLvl:.3,duck:.95,arp:.25,arpV:'harpsi',lead:0,pads:'none',buildBars:4,noSub:true}
});
Object.keys(BALL_INST).forEach(k=>{STYLES[k].inst=BALL_INST[k];STYLES[k].samples=BALL_SAMPLES[k]});

/* ---- the sampler ---- */
const SMP={man:null,base:null,buf:{},ready:{},loading:{},tried:false};
const SMP_ABS='https://newbroman.github.io/Music_of_the_Spheres/samples/';
const smpReady=n=>!!SMP.ready[n];
async function smpManifest(){
  if(SMP.man)return true;if(SMP.tried)return false;SMP.tried=true;
  const rel=(/\/(pl|cy|de|es|fr|it|zh|ja)\//.test(location.pathname)?'../':'')+'samples/';
  for(const b of location.protocol==='file:'?[SMP_ABS]:[rel,SMP_ABS]){try{const u=new URL(b,location.href).href,r=await fetch(u+'manifest.json');if(r.ok){SMP.man=await r.json();SMP.base=u;return true}}catch(e){}}
  return false;
}
function smpLoad(n){
  if(SMP.loading[n])return SMP.loading[n];const info=SMP.man&&SMP.man[n];if(!info)return Promise.resolve(false);
  const list=[];
  return SMP.loading[n]=Promise.all(info.notes.map(m=>fetch(`${SMP.base}${n}/${m}.mp3`).then(r=>{if(!r.ok)throw 0;return r.arrayBuffer()}).then(ab=>new Promise((ok,no)=>AC.decodeAudioData(ab,ok,no))).then(buf=>list.push({m,buf}))))
    .then(()=>{list.sort((a,c)=>a.m-c.m);SMP.buf[n]=list;SMP.ready[n]=true;return true}).catch(()=>{delete SMP.loading[n];return false});
}
let smpMsg='';
async function loadStyleSamples(){
  const st=STY(),names=st.samples;if(!AC||!names)return;
  if(names.every(smpReady))return;
  const k=D.style;smpMsg=k;toast(SMPTXT.tuning);
  if(!(await smpManifest())){if(smpMsg===k)toast(SMPTXT.synth);return}
  const ok=await Promise.all(names.map(smpLoad));
  if(smpMsg===k&&D.style===k)toast(ok.every(Boolean)?SMPTXT.ready:SMPTXT.synth);
}
const SMPTXT={tuning:'The band is tuning up…',ready:'The band is ready',synth:'Recorded instruments unavailable: playing synthesised ones'};
// play one recorded note at any frequency: the nearest sample, re-pitched
function samp(n,t,f,len,lvl,id,o={}){
  if(!SMP.ready[n])return false;
  const L=SMP.buf[n],midi=69+12*Math.log2(f/440);let best=L[0];for(const x of L)if(Math.abs(x.m-midi)<Math.abs(best.m-midi))best=x;
  const src=AC.createBufferSource();src.buffer=best.buf;const rate=Math.pow(2,(midi-best.m)/12);src.playbackRate.value=rate;
  const g=AC.createGain(),pk=lvl*SMP.man[n].gain,att=o.att||.004,rel=o.rel||.12;
  const end=Math.max(t+att,Math.min(t+len,t+best.buf.duration/rate-rel));
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(pk,t+att);g.gain.setValueAtTime(pk,end);g.gain.linearRampToValueAtTime(0,end+rel);
  src.connect(g);g.connect(toPan(id));const rv=o.rev===undefined?.25:o.rev;if(rv)g.connect(mkG(rv,revSend));
  src.start(t);src.stop(end+rel+.05);if(window.MOTS&&MOTS.midi.on)MOTS.midi.hit(id,t,f,lvl,end-t);if(o.flash!==false)flash(id,t);return true;
}
function sChord(n,t,degs,oct,len,lvl,id,o={}){if(!SMP.ready[n])return false;degs.forEach((d,k)=>samp(n,t+(o.spread||0)*k,noteF(d,oct),len,lvl,id,{...o,flash:false}));flash(id,t);return true}
/* ---- instruments ---- */
const toPan=id=>PAN[id]||drumBus;
// a hammered string: a triangle body with a little sawtooth brightness, the felt closing quickly
function piano(t,f,len,lvl,id){
  const g=mkG(0,toPan(id)),lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.setValueAtTime(Math.min(8000,f*9),t);lp.frequency.setTargetAtTime(Math.max(600,f*2.5),t,.15);
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(lvl,t+.004);g.gain.setTargetAtTime(lvl*.35,t+.004,.09);g.gain.setTargetAtTime(0,t+len,.08);
  const o1=AC.createOscillator(),o2=AC.createOscillator();o1.type='triangle';o2.type='sawtooth';o1.frequency.value=f;o2.frequency.value=f*1.0015;
  o1.connect(lp);o2.connect(mkG(.16,lp));lp.connect(g);g.connect(mkG(.3,revSend));
  const end=t+len+.6;o1.start(t);o2.start(t);o1.stop(end);o2.stop(end);
}
function pchord(t,degs,oct,len,lvl,id){degs.forEach((d,k)=>piano(t+k*.004,noteF(d,oct),len,lvl,id));flash(id,t)}
// a plucked nylon string
function nylon(t,f,lvl,dec,id){
  const o=AC.createOscillator();o.type='sawtooth';o.frequency.value=f;const lp=AC.createBiquadFilter();lp.type='lowpass';lp.Q.value=1;
  lp.frequency.setValueAtTime(Math.min(7000,f*7),t);lp.frequency.setTargetAtTime(f*1.3,t,dec*.25);
  const g=mkG(0,toPan(id));env(g,t,lvl,.002,dec);o.connect(lp);lp.connect(g);g.connect(mkG(.25,revSend));o.start(t);o.stop(t+dec*5+.05);
}
function strum(t,degs,oct,lvl,gap,up,id,dec=.35){const d=up?[...degs].reverse():degs;d.forEach((x,k)=>nylon(t+k*gap,noteF(x,oct),lvl*(up?.8:1),dec,id));flash(id,t)}
// the bandoneon: two reeds a few cents apart and a lower reed, through a soft bellows filter
function reed(t,degs,len,lvl,swell){
  degs.forEach(d=>{const f=noteF(d,4),g=mkG(0,PAN.saturn);g.connect(mkG(.3,revSend));
    const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=2300;lp.Q.value=.7;lp.connect(g);
    [-7,7].forEach(c=>{const o=AC.createOscillator();o.type='sawtooth';o.frequency.value=f;o.detune.value=c;o.connect(lp);o.start(t);o.stop(t+len+.15)});
    if(!LOWPOWER){const sq=AC.createOscillator();sq.type='square';sq.frequency.value=f/2;sq.connect(mkG(.3,lp));sq.start(t);sq.stop(t+len+.15)}
    const a=swell?len*.9:.012;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(lvl,t+a);g.gain.setValueAtTime(lvl,t+Math.max(a,len*.85));g.gain.linearRampToValueAtTime(0,t+len+.03)});
  flash('saturn',t);
}
// a plucked double bass
function abass(t,f,len,lvl=.5){
  const o=AC.createOscillator(),o2=AC.createOscillator();o.type='sine';o2.type='triangle';o.frequency.setValueAtTime(f*1.03,t);o.frequency.setTargetAtTime(f,t,.015);o2.frequency.value=f;
  const g=mkG(0,PAN.jupiter);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(lvl,t+.006);g.gain.setTargetAtTime(lvl*.45,t+.006,.12);g.gain.setTargetAtTime(0,t+len,.05);
  o.connect(g);o2.connect(mkG(.35,g));const end=t+len+.4;o.start(t);o2.start(t);o.stop(end);o2.stop(end);flash('jupiter',t);
}
// percussion
function noiseHit(t,dur,type,f,q,lvl,att,dec,id,rev=.15){const n=noise(t,dur),fl=AC.createBiquadFilter();fl.type=type;fl.frequency.value=f;fl.Q.value=q;const g=mkG(0,toPan(id));env(g,t,lvl,att,dec);n.connect(fl);fl.connect(g);if(rev)g.connect(mkG(rev,revSend))}
function toneHit(t,f0,f1,type,lvl,dec,id,glide=.05){const o=AC.createOscillator();o.type=type;o.frequency.setValueAtTime(f0,t);if(f1!==f0)o.frequency.exponentialRampToValueAtTime(f1,t+glide);const g=mkG(0,toPan(id));env(g,t,lvl,.001,dec);o.connect(g);o.start(t);o.stop(t+dec*6+.05)}
function shaker(t,v){noiseHit(t,.12,'highpass',5200,.7,.13*v,.006,.022,'mercury',.05);flash('mercury',t)}
function castanet(t,v){[0,.013].forEach(d=>noiseHit(t+d,.03,'bandpass',3200,5,.32*v,.0005,.005,'mercury',.1));flash('mercury',t)}
function claves(t,v){toneHit(t,2500,2500,'sine',.2*v,.03,'earth');flash('earth',t)}
function tamborim(t,v){toneHit(t,900,820,'sine',.2*v,.04,'earth');noiseHit(t,.03,'bandpass',4000,2,.14*v,.0005,.006,'earth',0);flash('earth',t)}
function brush(t,v,long){noiseHit(t,long?.3:.15,'bandpass',3600,.6,.16*v,long?.03:.008,long?.09:.035,'earth',.2);flash('earth',t)}
function agogo(t,hi,v){const f=hi?905:678;[[1,.15,.09],[2.74,.05,.03]].forEach(([r,a,d])=>{const o=AC.createOscillator();o.type='sine';o.frequency.value=f*r;const g=mkG(0,PAN.mars);env(g,t,a*v,.001,d);o.connect(g);o.start(t);o.stop(t+.6)});flash('mars',t)}
function conga(t,kind,v){
  if(kind==='slap'){noiseHit(t,.06,'bandpass',1900,1.4,.32*v,.0008,.018,'mars',.1);toneHit(t,420,380,'sine',.14*v,.03,'mars')}
  else toneHit(t,kind==='open'?330:250,kind==='open'?300:230,'sine',(kind==='mute'?.12:.32)*v,kind==='mute'?.03:.13,'mars');
  flash('mars',t);
}
function surdo(t,open,v){toneHit(t,95,58,'sine',(open?.75:.38)*v,open?.28:.07,'sun',.08);noiseHit(t,.03,'lowpass',600,.7,.14*v,.001,.01,'sun',0);flash('sun',t);if(open)duckIt(t)}
function cajon(t,low,v){
  if(low){toneHit(t,120,70,'sine',.7*v,.12,'sun',.04);noiseHit(t,.08,'lowpass',500,.7,.25*v,.001,.03,'sun',.05);flash('sun',t);duckIt(t)}
  else{noiseHit(t,.1,'bandpass',2300,1,.4*v,.0008,.03,'mars',.15);toneHit(t,240,200,'triangle',.12*v,.03,'mars');flash('mars',t)}
}
function ride(t,v){
  noiseHit(t,.5,'highpass',7000,.7,.07*v,.001,.12,'mercury',.15);
  if(!LOWPOWER)[523,797].forEach(f=>{const o=AC.createOscillator();o.type='square';o.frequency.value=f*2.3;const hp=AC.createBiquadFilter();hp.type='highpass';hp.frequency.value=4000;const g=mkG(0,PAN.mercury);env(g,t,.018*v,.001,.15);o.connect(hp);hp.connect(g);o.start(t);o.stop(t+.9)});
  flash('mercury',t);
}
function chick(t,v){noiseHit(t,.05,'highpass',8000,.7,.09*v,.001,.01,'mercury',0)}
function timp(t,f,v){toneHit(t,f*1.03,f,'sine',.42*v,.45,'mars',.06);toneHit(t,f*2.01,f*2,'sine',.09*v,.2,'mars',.06);flash('mars',t)}
function guiro(t,long,v){
  const n=noise(t,long?.2:.08),bp=AC.createBiquadFilter();bp.type='bandpass';bp.Q.value=3;bp.frequency.setValueAtTime(2600,t);bp.frequency.linearRampToValueAtTime(3600,t+(long?.16:.06));
  const am=AC.createGain();am.gain.value=.5;const lfo=AC.createOscillator();lfo.type='square';lfo.frequency.value=46;lfo.connect(mkG(.5,am.gain));
  const g=mkG(0,PAN.mercury);env(g,t,.2*v,.005,long?.07:.025);n.connect(bp);bp.connect(am);am.connect(g);lfo.start(t);lfo.stop(t+(long?.25:.12));flash('mercury',t);
}

/* ---- a few more synthesised sounds for the bands ---- */
function triangleBell(t,v){[[5400,.06,.6],[7930,.03,.4],[11800,.015,.3]].forEach(([f,a,d])=>toneHit(t,f,f,'sine',a*v,d,'mercury'));flash('mercury',t)}
function timbale(t,v){toneHit(t,380,350,'sine',.22*v,.12,'sun');noiseHit(t,.08,'bandpass',3000,1.2,.2*v,.0008,.03,'sun',.15);flash('sun',t)}
function golpe(t,v){toneHit(t,85,60,'sine',.4*v,.06,'sun',.03);noiseHit(t,.05,'lowpass',900,.7,.12*v,.001,.02,'sun',.05);flash('sun',t)}
function chicharra(t,v){
  const n=noise(t,.12),bp=AC.createBiquadFilter();bp.type='bandpass';bp.frequency.value=1500;bp.Q.value=2.5;
  const am=AC.createGain();am.gain.value=.5;const lfo=AC.createOscillator();lfo.type='sawtooth';lfo.frequency.value=72;lfo.connect(mkG(.5,am.gain));
  const g=mkG(0,PAN.mercury);env(g,t,.16*v,.004,.04);n.connect(bp);bp.connect(am);am.connect(g);lfo.start(t);lfo.stop(t+.15);flash('mercury',t);
}
function cymbalSwell(t,dur,v){
  const n=AC.createBufferSource();n.buffer=noiseBuf;n.loop=true;const hp=AC.createBiquadFilter();hp.type='highpass';hp.frequency.value=5500;
  const g=mkG(0,PAN.uranus);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.001,t+dur*.3);g.gain.exponentialRampToValueAtTime(.16*v,t+dur);g.gain.setTargetAtTime(0,t+dur,.25);
  n.connect(hp);hp.connect(g);g.connect(mkG(.4,revSend));n.start(t);n.stop(t+dur+1.2);flash('uranus',t);
}
// the trumpets and trombones together, for shouts at the drop
function brassShout(t,deg,len){
  const ok=sChord('trumpet',t,chordTones(deg),4,len,.42,'uranus',{att:.012,rel:.15});
  sChord('trombone',t,[deg,deg+4],3,len,.42,'uranus',{att:.015,rel:.15});return ok;
}
// Ouranos' build: each band swells in its own way
function ballRiser(t,dur){
  const deg=D.prog[0], k=D.style;
  const rs=STY().rise;
  if(rs){if(rs==='strings')sChord('string_ensemble_1',t,chordTones(deg),4,dur,.3,'uranus',{att:dur*.9,rel:.2});
    else if(rs==='cymbal')cymbalSwell(t,dur,.7);
    else if(rs==='voices')sChord('choir_aahs',t,chordTones(deg),4,dur,.22,'uranus',{att:dur*.9,rel:.3});
    else if(rs==='organ'){if(!sChord('church_organ',t,[deg-7,deg,deg+2,deg+4],3,dur,.26,'uranus',{att:dur*.9,rel:.15}))cymbalSwell(t,dur,.4)}
    if(rs!=='none')flash('uranus',t);return}
  if(k==='waltz'){cymbalSwell(t,dur,1);sChord('string_ensemble_1',t,chordTones(deg),4,dur,.3,'uranus',{att:dur*.9,rel:.2})}
  else if(k==='tango'){if(!sChord('tango_accordion',t,chordTones(deg),4,dur,.4,'uranus',{att:dur*.9,rel:.1}))reed(t,chordTones(deg),dur,.06,true)}
  else if(k==='swing'||k==='jive'){cymbalSwell(t,dur,.8);sChord('trombone',t,[deg,deg+2,deg+4],3,dur,.38,'uranus',{att:dur*.85,rel:.12})}
  else if(k==='jungle')riser(t,dur);
  else if(k==='baroque'){if(!sChord('church_organ',t,[deg-7,deg,deg+2,deg+4],3,dur,.3,'uranus',{att:dur*.9,rel:.15}))cymbalSwell(t,dur,.4)}
  else cymbalSwell(t,dur,k==='fandango'?.6:1);
  flash('uranus',t);
}

// the jungle bass: two detuned saws through a slowly moving filter, with a sine sub beneath
function reese(t,f,len){
  const g=mkG(0,PAN.jupiter),lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=420;lp.Q.value=3;lp.connect(g);
  const lfo=AC.createOscillator();lfo.frequency.value=.6;lfo.connect(mkG(240,lp.frequency));lfo.start(t);lfo.stop(t+len+.2);
  [-16,16].forEach(c=>{const o=AC.createOscillator();o.type='sawtooth';o.frequency.value=f*2;o.detune.value=c;o.connect(lp);o.start(t);o.stop(t+len+.15)});
  const sub=AC.createOscillator();sub.type='sine';sub.frequency.value=f;sub.connect(mkG(1.2,g));sub.start(t);sub.stop(t+len+.15);
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.32,t+.015);g.gain.setValueAtTime(.32,t+len*.9);g.gain.linearRampToValueAtTime(0,t+len+.1);
  flash('jupiter',t);
}
// a two-bar fugue subject the sky composes from Aphrodite's sign: chord tones on the beats, stepwise motion between,
// in a mix of quavers and semiquavers, ending on a long note
function bachSubject(){
  const key=signOf('venus');if(D.subjKey===key)return D.subj;D.subjKey=key;
  const r=rng(key*41+11),RH=[[1,0,1,0],[1,1,1,1],[1,0,1,1],[1,1,1,0],[1,0,0,0]],CT=[-3,0,2,4,7,9],S=new Array(32).fill(null);
  let cur=[0,2,4][Math.floor(r()*3)],last=null;
  for(let b=0;b<8;b++){const p=b===7?[1,0,0,0]:b===0?[1,0,1,0]:RH[Math.floor(r()*4)];
    for(let i=0;i<4;i++){if(!p[i])continue;
      if(i===0){const near=CT.filter(c=>Math.abs(c-cur)<=2&&c!==cur);cur=b===7?(Math.abs(cur)<Math.abs(cur-7)?0:7):near.length?near[Math.floor(r()*near.length)]:0}
      else cur+=(r()<.55?1:-1)*(r()<.85?1:2);
      cur=Math.max(-3,Math.min(8,cur));if(cur===last&&b<7)cur+=cur<3?1:-1;S[b*4+i]=last=cur}}
  return D.subj=S;
}
function bachVoice(S,idx,t,deg,oct,inst,lvl,id,stepT,inv){
  const v=S[idx];if(v===null)return;let n=1;while(n<8&&S[(idx+n)%32]===null)n++;
  const f=noteF(deg+(inv?4-v:v),oct),hp=inst==='harpsichord';
  samp(inst,t,f,stepT*n*(hp?1.2:.95),lvl,id,{att:hp?.002:.03,rel:hp?.25:.08})||pluck(t,f,lvl*.15,'triangle',stepT*n,id);
}

/* ---- the patterns: the same planets, a different band ---- */
function ballStep(s,pos,bar,t,st,L,deg,stepT,m,into,spb){
  if(st.own){COMPOSE[D.style](s,pos,bar,t,st,L,stepT,m,into);return}
  const nxt=D.prog[(bar+1)%4], sec=D.section, sw=!!st.swing8, drop=sec==='drop', bd=barDur();
  const dropStart=drop&&into===0&&pos===0;
  switch(D.style){
  case 'waltz':case 'slowwaltz':
    // a Viennese orchestra: basses on the one, horns and pizzicato on two and three, strings singing over all
    if(L.kick&&m('sun')&&pos===0){kick(t);if(dropStart||(drop&&bar%4===0))noiseHit(t,1.6,'highpass',5000,.7,.14,.002,.5,'sun',.3)}
    if(L.bass&&m('jupiter')&&pos===0){const f=noteF(bar%2?deg-3:deg,2);samp('contrabass',t,f,stepT*3.6,.7,'jupiter',{att:.012,rel:.18})||abass(t,f,stepT*3.8)}
    if(L.pads&&m('saturn')){
      if(pos===4||pos===8)sChord('french_horn',t,chordTones(deg),3,stepT*2.4,pos===4?.28:.22,'saturn',{att:.02,rel:.12})||pchord(t,chordTones(deg),4,stepT*2.2,pos===4?.085:.07,'saturn');
      if(pos===0)sChord('string_ensemble_1',t,[deg-7,deg,deg+2,deg+4],4,bd*1.02,.2*L.pads,'saturn',{att:.12,rel:.35,flash:false})}
    if(L.clap&&m('earth')&&(pos===4||pos===8))sChord('pizzicato_strings',t,chordTones(deg),4,stepT*2,.3*L.clap,'earth',{rel:.08})||brush(t,.7*L.clap,false);
    if(L.hats&&m('mercury')&&pos===0&&bar%2===0&&sec!=='intro')triangleBell(t,L.hats);
    if(L.toms&&m('mars')&&pos===0&&bar%4===0){const f=noteF(deg,2);samp('timpani',t,f,bd,.6,'mars',{rel:.3})||timp(t,f,.9)}
    break;
  case 'tango':{
    // an orquesta típica: bandoneons in marcato, the bass on the 3-3-2, piano chords and a solo violin
    if(L.kick&&m('sun')&&(pos===0||pos===8))golpe(t,pos===0?1:.7);
    if(L.bass&&m('jupiter')){const h={0:[0,5],6:[0,5],12:[4,3],14:drop?[nxt-deg-1,2]:null}[pos];if(h){const f=noteF(deg+h[0],2);samp('contrabass',t,f,stepT*h[1]*.8,1,'jupiter',{att:.008,rel:.1})||abass(t,f,stepT*h[1]*.9)}}
    const drag=bar%2===1&&sec!=='intro';
    if(L.pads&&m('saturn')){
      if(pos%4===0&&!(drag&&pos===12)){const len=stepT*(pos%8===0?1.6:1.1),lv=pos%8===0?.4:.3;sChord('tango_accordion',t,chordTones(deg),4,len,lv,'saturn',{att:.008,rel:.06})||reed(t,chordTones(deg),len,lv*.16,false)}
      if(drag&&pos===12)sChord('tango_accordion',t,chordTones(nxt),4,stepT*3.8,.4,'saturn',{att:stepT*3.4,rel:.05})||reed(t,chordTones(nxt),stepT*3.6,.065,true);
      if(pos===0)sChord('string_ensemble_1',t,chordTones(deg),4,bd*1.02,.14*L.pads,'saturn',{att:.15,rel:.3,flash:false})}
    if(L.clap&&m('earth')&&(pos===4||pos===12))sChord('acoustic_grand_piano',t,chordTones(deg),4,stepT*1.2,.32*L.clap,'earth',{rel:.1})||brush(t,.6*L.clap,false);
    if(L.hats&&m('mercury')&&(drop||sec==='groove')&&pos%4===2&&bar%2===0)chicharra(t,L.hats);
    if(L.toms&&m('mars')){const tp=D.tomPat[pos];if(tp!==null&&bar%2){const f=noteF(deg+tp,2);if(samp('acoustic_grand_piano',t,f,stepT*1.4,.6,'mars',{rel:.1}))samp('acoustic_grand_piano',t,f*2,stepT*1.4,.45,'mars',{rel:.1,flash:false});else{piano(t,f,stepT*1.5,.16,'mars');flash('mars',t)}}}
    break;}
  case 'samba':
    // a roda de samba: surdo, ganzá, tamborim and agogô, with seven-string guitar and cavaquinho
    if(L.kick&&m('sun')&&pos%4===0)surdo(t,pos===4||pos===12,1);
    if(L.hats&&m('mercury'))shaker(t,[.55,.25,.35,.85][pos%4]*L.hats*2.5);
    if(L.clap&&m('earth')&&[0,3,6,10,12].includes(pos))tamborim(t,L.clap*(pos===0?2.5:1.9));
    if(L.toms&&m('mars')){const hi=[0,3,6,10].includes(pos),lo=[8,12,14].includes(pos);if(hi||lo){if(!samp('agogo',t,hi?905:678,.3,.8,'mars',{rel:.05,rev:.15}))agogo(t,hi,.8)}}
    if(L.bass&&m('jupiter')){const h={0:[0,.8],3:[0,.6],4:[4,1.8],8:[0,.8],11:[0,.6],12:[-3,1.8]}[pos];if(h){const f=noteF(deg+h[0],2);samp('acoustic_guitar_nylon',t,f,stepT*h[1]*2,.35,'jupiter',{rel:.08})||abass(t,f,stepT*h[1]*2)}}
    if(L.pads&&m('saturn')&&[0,3,6,10,13].includes(pos)){const up=pos%2===1,V=chordTones(deg).concat([deg+7]);
      if(smpReady('acoustic_guitar_steel')){(up?[...V].reverse():V).forEach((d,k)=>samp('acoustic_guitar_steel',t+k*.008,noteF(d,4),stepT*1.6,up?.16:.2,'saturn',{rel:.06,flash:false}));flash('saturn',t)}
      else strum(t,V,4,.055,.008,up,'saturn',.18)}
    break;
  case 'chacha':
    // a charanga: flute and violins over piano montuno, tumbao bass, güiro, claves, congas and timbales
    if(L.kick&&m('sun')&&(pos===0||pos===14||(drop&&pos===6)))timbale(t,pos===0?1:.75);
    if(L.bass&&m('jupiter')){const f=pos===6?noteF(deg,2):pos===12?noteF(nxt,2):0;if(f)samp('acoustic_bass',t,f,stepT*(pos===6?5.5:4),.6,'jupiter',{rel:.1})||abass(t,f,stepT*(pos===6?5.5:4))}
    if(L.pads&&m('saturn')){
      if([0,3,6,8,11,14].includes(pos))sChord('acoustic_grand_piano',t,chordTones(deg),4,stepT*1.3,.28,'saturn',{rel:.08})||pchord(t,chordTones(deg),4,stepT*1.3,.07,'saturn');
      if((sec==='groove'||drop)&&(pos===0||pos===8))sChord('string_ensemble_1',t,chordTones(deg),5,stepT*2.5,.16,'saturn',{att:.02,rel:.12,flash:false})}
    if(L.hats&&m('mercury')){if(pos===0||pos===4||pos===8)guiro(t,true,L.hats);else if(pos===12||pos===14)guiro(t,false,L.hats)}
    if(L.clap&&m('earth')&&(bar%2===0?[4,8]:[0,6,12]).includes(pos))claves(t,L.clap);
    if(L.toms&&m('mars')){if(pos===4)conga(t,'slap',1);else if(pos===12||pos===14)conga(t,'open',1);else if(pos===0||pos===8)conga(t,'mute',1)}
    break;
  case 'swing':case 'jive':{
    // a big band (swing) and a jump-blues band (jive): swung eighths, walking bass, saxes, brass and drums
    if(pos%2)break;
    const jive=D.style==='jive';
    if(L.kick&&m('sun')&&pos%4===0)kick(t);
    if(L.hats&&m('mercury')){if([0,4,6,8,12,14].includes(pos))ride(t,L.hats*(pos===6||pos===14?.6:1));if(pos===4||pos===12)chick(t,.8)}
    if(L.clap&&m('earth')&&(pos===4||pos===12)){if(jive)snare(t,.85*L.clap);else brush(t,2.6*L.clap,true)}
    if(L.bass&&m('jupiter')&&pos%4===0){const wl=[deg,deg+2,deg+4,nxt+((bar+signOf('jupiter'))%2?1:-1)],f=noteF(wl[pos/4],2);samp('acoustic_bass',t,f,stepT*3.4,.5,'jupiter',{rel:.08})||abass(t,f,stepT*3.6,.48)}
    if(L.pads&&m('saturn')){
      if(!jive&&(pos===0||pos===6)){const len=stepT*(pos===0?3:5);const a=sChord('tenor_sax',t,[deg,deg+2],3,len,.28,'saturn',{att:.02,rel:.1});sChord('alto_sax',t,[deg+4,deg+6],3,len,.26,'saturn',{att:.02,rel:.1,flash:false});if(!a)pchord(t,chordTones(deg),4,stepT*2.5,.07,'saturn')}
      if(!jive&&pos===14&&bar%2)sChord('acoustic_grand_piano',t,chordTones(deg),5,stepT*1.2,.22,'saturn',{rel:.08,flash:false});
      if(jive&&[4,12,14].includes(pos))sChord('acoustic_grand_piano',t,chordTones(deg),4,stepT*1.4,.3,'saturn',{rel:.08})||pchord(t,chordTones(deg),4,stepT*1.4,.07,'saturn');
      if(jive&&drop&&(pos===0||pos===6)){sChord('tenor_sax',t,[deg,deg+4],3,stepT*(pos===0?2:1.6),.22,'saturn',{att:.01,rel:.08,flash:false});sChord('alto_sax',t,[deg+2],4,stepT*(pos===0?2:1.6),.2,'saturn',{att:.01,rel:.08,flash:false})}}
    if(dropStart&&m('uranus'))brassShout(t,deg,stepT*5);
    if(drop&&m('uranus')&&bar%4===3&&pos===12)brassShout(t,nxt,stepT*3);
    if(L.toms&&m('mars')&&bar%4===3&&pos>=8&&sec!=='intro')tom(t,noteF(deg+(14-pos)/2,3),.8);
    break;}
  case 'fandango':{
    // flamenco: cajón, castanets, palmas and the guitar, with the cante over it
    if(L.kick&&m('sun')&&(pos===0||(pos===8&&drop)))cajon(t,true,1);
    if(L.toms&&m('mars')&&(pos===4||pos===8||(pos===10&&bar%2)))cajon(t,false,pos===10?.6:1);
    if(L.clap&&m('earth')&&(sec==='groove'||drop)){if(pos%4===0)clap(t,pos===0?.9:.65);else if(pos%4===2&&drop)clap(t,.3)}
    if(L.hats&&m('mercury')){if(pos%2===0)castanet(t,L.hats*(pos%4===0?1:.6));if(pos===10){castanet(t+stepT*.66,.5*L.hats);castanet(t+stepT*1.33,.6*L.hats)}}
    if(L.bass&&m('jupiter')&&(pos===0||pos===8)){const f=noteF(pos===0?deg:deg-3,2);if(!samp('acoustic_guitar_nylon',t,f,stepT*4,.4,'jupiter',{rel:.1})){nylon(t,f,.32,.5,'jupiter');flash('jupiter',t)}}
    if(L.pads&&m('saturn')){const V=[deg-7,deg-3,deg,deg+2,deg+4,deg+7],g=smpReady('acoustic_guitar_nylon');
      const st2=(tt,vs,lv,gap,up,len)=>{if(g){(up?[...vs].reverse():vs).forEach((d,k)=>samp('acoustic_guitar_nylon',tt+k*gap,noteF(d,3),len,lv,'saturn',{rel:.06,flash:false}));flash('saturn',tt)}else strum(tt,vs,3,lv*.12,gap,up,'saturn',len*.4)};
      if(pos===0){st2(t,V,.3,.018,false,stepT*4);if(drop){st2(t+.045,V.slice(2),.25,.009,false,stepT*2);st2(t+.09,V.slice(2),.3,.009,false,stepT*3)}}
      else if(pos===4||pos===6)st2(t,V.slice(2),.24,.01,pos===6,stepT*2);
      else if(pos===8)st2(t,V,.27,.014,false,stepT*3)}
    break;}
  case 'jungle':{
    // a chopped breakbeat at 166: kick and snares from the break, Ares stuttering it from his sign, a Reese bass rolling underneath
    const edit=sec!=='intro'&&bar%2===1&&D.tomPat[pos]!==null;
    if(L.kick&&m('sun')&&(pos===0||pos===10||(pos===2&&bar%4===1)))kick(t);
    if(L.clap&&m('earth')){if(pos===4||pos===12)snare(t,1);else if([7,9,15].includes(pos))snare(t,.28)}
    if(L.hats&&m('mercury')&&pos%2===0)hat(t,pos%8===6,.55*L.hats);
    if(L.toms&&m('mars')&&edit){[0,.33,.66].forEach(d=>snare(t+stepT*d,.35));flash('mars',t)}
    if(L.bass&&m('jupiter')&&(pos===0||(pos===8&&bar%2===1)))reese(t,noteF(pos===0?deg:deg-3,1),stepT*(pos===0&&bar%2===0?15.5:7.5));
    break;}
  case 'baroque':{
    // counterpoint: the sky's subject, its answer, an inverted countersubject and a walking continuo
    const S=bachSubject(),org=drop,ex=sec==='intro',idx=(bar%2)*16+pos;
    const lag=sec==='build'?8:16;   // stretto: in the build the answer crowds in after half a bar
    if(m('venus'))bachVoice(S,idx,t,deg,5,org?'church_organ':'violin',org?.3:.45,'venus',stepT);
    if(m('mars')&&!(ex&&into<2)&&sec!=='break')bachVoice(S,(idx-lag+32)%32,t,deg,4,org?'church_organ':'oboe',org?.26:.42,'mars',stepT);
    if(m('mercury')&&!(ex&&into<4))bachVoice(S,(idx+8)%32,t,deg,4,org?'church_organ':'harpsichord',org?.24:.4,'mercury',stepT,true);
    if(m('jupiter')&&!(ex&&into<4)&&pos%2===0){const BL=[0,2,4,2,-3,-1,1];const k=pos/2,d=k===7?nxt-1:deg+BL[k],f=noteF(d,2);samp('cello',t,f,stepT*1.8,.5,'jupiter',{att:.02,rel:.06})||abass(t,f,stepT*1.8,.4)}
    if(m('saturn')&&!(ex&&into<4)){if(org){if(pos===0)sChord('church_organ',t,chordTones(deg),4,bd,.2,'saturn',{att:.04,rel:.15})}else if(pos===0||pos===8)sChord('harpsichord',t,[deg-7,deg,deg+2,deg+4],3,stepT*7,.26,'saturn',{spread:.025})}
    if(org&&m('neptune')&&pos===0)samp('church_organ',t,noteF(deg,1),bd,.4,'neptune',{att:.05,rel:.2});
    if(org&&m('earth')&&(pos===0||pos===8))samp('trumpet',t,noteF(deg+4,4),stepT*6,.3,'earth',{att:.02,rel:.15});
    if(org&&m('sun')&&(pos===0||pos===8||(pos===14&&bar%2)))samp('timpani',t,noteF(pos===8?deg-3:deg,2),stepT*4,.5,'sun',{rel:.25});
    break;}
  }
  // the build: a timpani roll from Ares that quickens toward the drop (jungle rolls its snare; Bach builds by stretto instead)
  if(D.style==='jungle'){if(sec==='build'&&m('earth')){const prog=(into+pos/spb)/D.secLen,every=prog<.5?4:prog<.75?2:1;if(pos%every===0)snare(t,.3+.7*prog)}}
  else if(D.style==='baroque'){}
  else {
    if(sec==='build'&&m('mars')&&!(sw&&pos%2)){const prog=(into+pos/spb)/D.secLen,every=prog<.5?4:prog<.75?2:1;if(pos%every===0){const f=noteF(0,2),v=.2+.55*prog;samp('timpani',t,f,stepT*every*1.5,v*.7,'mars',{rel:.15})||timp(t,f,v)}}
  }
  // Jupiter's moons, still in their 1:2:4 resonance, counted across the bar lines
  if(L.arp&&m('jupiter-moons')&&!(sw&&pos%2)){const lv=L.arp*st.arp,tones=chordTones(deg).concat([deg+7]),up=moonWaxing(),k=s>>1;
    if(s%2===0)moonNote(t,noteF(tones[up?k%4:3-k%4],5),.06*lv,stepT*3,'io',st.arpV);
    if(s%4===0)moonNote(t,noteF(tones[((s>>2)+1)%3],4),.07*lv,stepT*5,'europa',st.arpV);
    if(s%8===0)moonNote(t,noteF(tones[(s>>3)%3],6),.045*lv,stepT*7,'ganymede',st.arpV);}
  // Aphrodite's line, played by the band's solo instrument
  if(L.lead*st.lead>.2&&D.style!=='baroque'&&m('venus')&&!(sw&&pos%2)){const mm=D.motif[(bar%2)*16+pos];if(mm&&(L.lead>=.3||pos%8===0)){
    const f=noteF(deg+mm.deg,5),len=bd*mm.len*(st.leadLen||1),li=LEADS[D.style];
    if(!(li&&samp(li[0],t,f*(li[2]||1),len,li[1],'venus',{att:li[3]||.03,rel:.18,rev:.35})))chop(t,f,len,mm.vow);
    if((D.style==='waltz'||D.style==='slowwaltz')&&drop)samp('flute',t,f*2,len,.22,'venus',{att:.03,rel:.15,flash:false})}}
}
// each band's solo instrument: [sample, level, octave shift, attack]
const LEADS={waltz:['violin',.5,1,.05],slowwaltz:['violin',.5,1,.08],tango:['violin',.5,1,.04],samba:['flute',.5,1,.02],chacha:['flute',.55,1,.02],swing:['muted_trumpet',.4,.5,.02],jive:['tenor_sax',.45,.5,.02]};
const MOONSMP={harpsi:'harpsichord',harp:'orchestral_harp',piano:'acoustic_grand_piano',guitar:'acoustic_guitar_nylon',pizz:'pizzicato_strings',vibes:'vibraphone',eguitar:'electric_guitar_clean'};
function moonNote(t,f,lvl,dec,id,v){
  const n=MOONSMP[v];if(n&&samp(n,t,f,dec*1.6,lvl*5.5,'jupiter',{rel:.12,flash:false})){flash(id,t);return}
  if(v==='guitar'){nylon(t,f,lvl*1.6,dec,'jupiter');flash(id,t)}
  else if(v==='piano'){piano(t,f,dec,lvl*1.3,'jupiter');flash(id,t)}
  else pluck(t,f,lvl,v==='vibes'?'sine':'triangle',dec,id);
}

/* ================= COMPOSERS: each one's own method, the planets still the band ================= */
Object.assign(BALL_INST,{
  mozart:{sun:'Horns (in the climax)',mercury:'Flute: trills at the cadences',earth:'Oboe, in thirds',mars:'Timpani at the cadences',jupiter:'Alberti bass (piano)','jupiter-moons':'Second violins, 1 : 2 : 4',saturn:'Inner strings',venus:'Melody (violin)',uranus:'String crescendo',neptune:'Cellos and basses'},
  satie:{sun:'—',mercury:'—',earth:'Harp (in the climax)',mars:'—',jupiter:'Bass note on the one (piano)','jupiter-moons':'—',saturn:'Floating seventh chords (piano)',venus:'Melody (piano, then flute)',uranus:'—',neptune:'Strings (in the climax)'},
  debussy:{sun:'Antique cymbals',mercury:'Celesta',earth:'Oboe, echoing',mars:'Timpani roll',jupiter:'Deep piano pedal','jupiter-moons':'Harp, 1 : 2 : 4',saturn:'Strings, parallel ninth chords',venus:'Flute arabesque',uranus:'String swell',neptune:'—'},
  part:{sun:'Bells',mercury:'—',earth:'Choir (in the climax)',mars:'—',jupiter:'Mirror voice (cello)','jupiter-moons':'—',saturn:'Tintinnabuli voice (piano)',venus:'Melodic voice (violin)',uranus:'—',neptune:'—'},
  reich:{sun:'—',mercury:'Clapping',earth:'Marimba 1, the pattern',mars:'Marimba 3, phased by Mars',jupiter:'Bass swells','jupiter-moons':'Vibraphone, 1 : 2 : 4',saturn:'Pulsing voices',venus:'Marimba 2, phased by Venus',uranus:'Voices swell',neptune:'—'},
  glass:{sun:'—',mercury:'Flute, doubling',earth:'Choir',mars:'—',jupiter:'Organ left hand, in twos','jupiter-moons':'—',saturn:'Organ arpeggios, in threes',venus:'Soprano (in the climax)',uranus:'Organ swell',neptune:'Organ pedal'}
});
Object.assign(BALL_SAMPLES,{
  mozart:['acoustic_grand_piano','violin','string_ensemble_1','contrabass','flute','oboe','french_horn','timpani','pizzicato_strings'],
  satie:['acoustic_grand_piano','orchestral_harp','flute','string_ensemble_1'],
  debussy:['string_ensemble_1','orchestral_harp','flute','oboe','celesta','acoustic_grand_piano','timpani'],
  part:['violin','acoustic_grand_piano','cello','tubular_bells','choir_aahs'],
  reich:['marimba','choir_aahs','vibraphone','contrabass'],
  glass:['drawbar_organ','choir_aahs','flute','church_organ']
});
Object.assign(STYLES,{
  mozart:{gain:3.0,name:'Mozart',fam:'ball',own:true,beats:4,bpm:126,mode:'C',swing:0,kickF:[90,48,.4],kickLvl:0,duck:1,pads:'none',buildBars:4,noSub:true,rise:'strings'},
  satie:{gain:4.2,name:'Satie',fam:'ball',own:true,beats:3,bpm:66,mode:'F',swing:0,kickF:[90,48,.4],kickLvl:0,duck:1,pads:'none',buildBars:4,noSub:true,rise:'none'},
  debussy:{gain:3.6,name:'Debussy',fam:'ball',own:true,beats:4,bpm:60,mode:'C',swing:0,kickF:[90,48,.4],kickLvl:0,duck:1,pads:'none',buildBars:4,noSub:true,rise:'strings'},
  part:{gain:3.6,name:'Pärt',fam:'ball',own:true,beats:4,bpm:60,mode:'A',swing:0,kickF:[90,48,.4],kickLvl:0,duck:1,pads:'none',buildBars:4,noSub:true,rise:'none'},
  reich:{gain:1.8,name:'Reich',fam:'ball',own:true,beats:4,bpm:132,mode:'D',swing:0,kickF:[90,48,.4],kickLvl:0,duck:1,pads:'none',buildBars:8,noSub:true,rise:'voices'},
  glass:{gain:3.4,name:'Glass',fam:'ball',own:true,beats:4,sub:6,bpm:96,mode:'A',swing:0,kickF:[90,48,.4],kickLvl:0,duck:1,pads:'none',buildBars:4,noSub:true,rise:'organ'}
});
['mozart','satie','debussy','part','reich','glass'].forEach(k=>{STYLES[k].inst=BALL_INST[k];STYLES[k].samples=BALL_SAMPLES[k]});
// a recorded note, or a soft piano-like stand-in while recordings load
const SP=(n,t,f,len,lvl,id,o)=>samp(n,t,f,len,lvl,id,o)||(piano(t,f,len,lvl*.28,id),true);
const tri=deg=>[deg,deg+2,deg+4];
const sev=deg=>[deg,deg+2,deg+4,deg+6];
const ET=(semis,oct)=>noteF(0,oct)*Math.pow(2,semis/12);
// a melody that the sky composes from Aphrodite's sign: rhythms per beat and chord-tone targets, stepwise between
function skyLine(key,bars,beatsPer,seed,opts={}){
  const k=key+'|'+bars+'|'+beatsPer;if(D.lines&&D.lines[k])return D.lines[k];D.lines=D.lines||{};
  const r=rng(seed),RH=opts.rh||[[1,0,0,0],[1,0,1,0],[1,0,1,0],[1,1,1,0],[1,0,0,0]],out=[];let cur=opts.start||4;
  for(let b=0;b<bars*beatsPer;b++){const p=RH[Math.floor(r()*RH.length)];
    for(let i=0;i<4;i++){if(!p[i]){out.push(null);continue}
      if(i===0){const tg=[0,2,4,7][Math.floor(r()*4)];cur=Math.abs(tg-cur)<=4?tg:cur+(tg>cur?2:-2)}else cur+=(r()<.55?-1:1);
      cur=Math.max(opts.lo??-1,Math.min(opts.hi??9,cur));out.push(cur)}}
  return D.lines[k]=out;
}
function lenAt(line,i){let n=1;while(n<16&&line[(i+n)%line.length]===null)n++;return n}

const COMPOSE={
  // Mozart: an eight-bar period, a question ending on V and an answer coming home to I
  mozart(s,pos,bar,t,st,L,stepT,m,into){
    const pb=bar%8,z=D.prog[1],pdRaw=D.prog[2],pd=[1,3,5].includes(pdRaw)?pdRaw:3;
    const CH=[0,z===4?5:z,pd,4,0,z===4?5:z,4,0],deg=CH[pb],sec=D.section,drop=sec==='drop',bd=barDur();
    // Alberti bass: root, fifth, third, fifth in quavers
    if(L.bass&&m('jupiter')&&pos%2===0){const a=[0,4,2,4][(pos/2)%4];SP('acoustic_grand_piano',t,noteF(deg+a,3),stepT*2.2,.3,'jupiter',{rel:.1})}
    // cellos and basses on the strong beats
    if(m('neptune')&&(pos===0||pos===8)&&sec!=='intro')samp('contrabass',t,noteF(deg,2),stepT*7,.2,'neptune',{att:.02,rel:.15});
    // inner strings repeating the harmony in quavers
    if(L.pads&&m('saturn')&&pos%2===0)sChord('string_ensemble_1',t,[deg+2,deg+4],4,stepT*1.8,drop?.16:.1,'saturn',{att:.01,rel:.06});
    // the melody: a two-bar idea, repeated on the new harmony, then the cadence
    const line=skyLine('moz'+signOf('venus'),2,4,signOf('venus')*29+3,{start:4,lo:-1,hi:9});
    let mel=null,ml=1;
    if(pb===3||pb===7){const cad=pb===3?{0:[2,4],4:[1,8]}:{0:[2,4],4:[1,4],8:[0,8]};const c=cad[pos];if(c){mel=c[0]-deg;ml=c[1]}}
    else{const i=((pb%4)%2)*16+pos,v=line[i];if(v!==null){mel=v;ml=lenAt(line,i)}}
    if(mel!==null&&L.lead>.2&&m('venus')){const f=noteF(deg+mel,5);SP('violin',t,f,stepT*ml*.95,.5,'venus',{att:.03,rel:.12});
      if(m('earth')&&(sec==='groove'||drop))samp('oboe',t,noteF(deg+mel-2,5),stepT*ml*.9,.3,'earth',{att:.03,rel:.1});
      if(drop&&m('mercury'))samp('flute',t,f*2,stepT*ml*.9,.24,'mercury',{att:.03,rel:.1})}
    // a flute trill at each cadence
    if((pb===3||pb===7)&&pos>=8&&pos<12&&m('mercury')&&sec!=='intro'){const top=pb===3?1:0;samp('flute',t,noteF(pos%2?top+1:top,6),stepT*.9,.22,'mercury',{rel:.04})}
    // horns and timpani in the climax
    if(drop&&m('sun')&&pos===0)sChord('french_horn',t,[0,4],3,bd*.95,.24,'sun',{att:.04,rel:.2});
    if((drop||sec==='groove')&&m('mars')&&(pb===3||pb===7)&&(pos===0||pos===8))samp('timpani',t,noteF(pos===0?4:0,2),stepT*6,.5,'mars',{rel:.25});
    if(drop&&L.arp&&m('jupiter-moons')){const tn=tri(deg);if(s%2===0)samp('pizzicato_strings',t,noteF(tn[(s>>1)%3],5),stepT*2,.2,'jupiter-moons',{rel:.05})}
    if(sec==='build'&&m('mars')&&pos%2===0)samp('timpani',t,noteF(4,2),stepT*2,.2+.4*(into+pos/16)/D.secLen,'mars',{rel:.1});
  },
  // Satie: a slow three, a bass note on the one and a floating seventh chord after it, two chords swaying
  satie(s,pos,bar,t,st,L,stepT,m){
    let a=D.prog[1],b=D.prog[2];if(a===b)b=(a+3)%7;const deg=bar%2?b:a,sec=D.section,drop=sec==='drop',bd=barDur();
    if(m('jupiter')&&pos===0)SP('acoustic_grand_piano',t,noteF(deg,2),bd*1.05,.4,'jupiter',{rel:.4});
    if(m('saturn')&&pos===4){const ch=sev(deg).slice(1);ch.forEach((d,k)=>SP('acoustic_grand_piano',t+k*.012,noteF(d,3),stepT*8,.2,'saturn',{rel:.3}));flash('saturn',t)}
    if(drop&&m('neptune')&&pos===0)sChord('string_ensemble_1',t,sev(deg).slice(1),3,bd*1.02,.1,'neptune',{att:.4,rel:.6});
    if(drop&&m('earth')&&pos===4)sChord('orchestral_harp',t,sev(deg).slice(1),4,stepT*8,.3,'earth',{spread:.06,rel:.4});
    // a sparse, slowly falling melody, as in the Gymnopédies
    const line=skyLine('sat'+signOf('venus'),8,3,signOf('venus')*17+5,{rh:[[1,0,0,0],[1,0,0,0],[0,0,0,0]],start:7,lo:2,hi:11});
    const i=(bar%8)*12+pos;
    if(pos%4===0&&L.lead>.2&&m('venus')){const v=line[i];if(v!==null&&v!==undefined){const n=Math.min(lenAt(line,i),12),f=noteF(v,5);
      SP('acoustic_grand_piano',t,f,stepT*n,.42,'venus',{rel:.4});if(drop)samp('flute',t,f,stepT*n*.95,.24,'venus',{att:.05,rel:.2,flash:false})}}
  },
  // Debussy: parallel ninth chords gliding by whole tones, harp washes, a flute arabesque on the whole-tone or pentatonic scale
  debussy(s,pos,bar,t,st,L,stepT,m,into){
    const sec=D.section,drop=sec==='drop',bd=barDur(),pat=[[0,2,4,2],[0,-2,-4,-2],[0,2,-2,0],[0,4,2,6]][signOf('saturn')%4],root=pat[bar%4];
    const CH=[0,4,7,11,14].map(x=>x+root),wt=moonWaxing(),SC=wt?[0,2,4,6,8,10]:[0,2,4,7,9];
    if(m('saturn')&&pos===0&&L.pads)CH.slice(1).forEach((x,k)=>samp('string_ensemble_1',t,ET(x,3),bd*1.05,drop?.16:.11,'saturn',{att:.5,rel:.6,flash:k===0}));
    if(m('jupiter')&&pos===0&&bar%2===0)SP('acoustic_grand_piano',t,ET(root,1),bd*2,.38,'jupiter',{rel:.8});
    // the harp washes up through the chord, Jupiter's moons in their 1:2:4 resonance
    if(L.arp&&m('jupiter-moons')){if(s%2===0&&(pos<8||drop)){const k=(s>>1)%8;samp('orchestral_harp',t,ET(CH[k%5]+12*Math.floor(k/5),4),stepT*4,.22,'jupiter-moons',{rel:.3})}}
    // the flute: a sinuous line inside a tritone, in quavers and dotted rhythms
    const line=skyLine('deb'+signOf('venus')+(wt?'w':'p'),2,4,signOf('venus')*13+(wt?1:2),{rh:[[1,0,0,1],[0,0,1,0],[1,1,0,0],[1,0,0,0]],start:3,lo:0,hi:8});
    const i=(bar%2)*16+pos,v=line[i];
    if(v!==null&&L.lead>.2&&m('venus')){const deg=SC[((v%SC.length)+SC.length)%SC.length]+12*Math.floor(v/SC.length);const f=ET(deg+root*0,5);SP('flute',t,f,stepT*lenAt(line,i)*.95,.42,'venus',{att:.05,rel:.2});
      if(m('earth')&&(sec==='groove'||drop))samp('oboe',t+bd,f/2,stepT*lenAt(line,i)*.9,.26,'earth',{att:.05,rel:.15})}
    if(m('mercury')&&(pos===6||pos===14)&&((bar*7+pos)%3===0))samp('celesta',t,ET(CH[(bar+pos)%5],6),stepT*4,.24,'mercury',{rel:.3});
    if(drop&&m('sun')&&pos===0)samp('celesta',t,ET(CH[4]+12,6),bd,.18,'sun',{rel:.6});
    if(sec==='build'&&m('mars')&&pos%2===0)samp('timpani',t,ET(root,2),stepT*2,.12+.35*(into+pos/16)/D.secLen,'mars',{rel:.1});
  },
  // Pärt: tintinnabuli. The melodic voice grows towards a centre note, mirrored below; the piano rings the home triad
  part(s,pos,bar,t,st,L,stepT,m){
    const sec=D.section,drop=sec==='drop',C=7,TRI=[0,2,4];
    // phrases of growing length: 1, 2, 3 … notes, approaching the centre alternately from above and below
    const halfs=Math.floor(s/(SPB()/2)),onset=pos%8===0;D.part=D.part||{h:-1,ph:1,i:0,above:moonWaxing(),note:C};
    if(onset&&halfs!==D.part.h){D.part.h=halfs;const P=D.part;
      if(P.i>=P.ph+1){P.i=0;P.ph=P.ph>=7?1:P.ph+1;P.above=!P.above}
      const k=P.i;P.note=k<P.ph?(P.above?C+(P.ph-1-k):C-(P.ph-1-k)):null;P.i++;
      if(P.note!==null){const mn=P.note,f=noteF(mn,4);
        if(m('venus'))SP('violin',t,f,stepT*7.6,.55,'venus',{att:.08,rel:.25});
        // the T-voice: the nearest note of the home triad above the melody
        let tv=mn+1;while(!TRI.includes(((tv%7)+7)%7))tv++;if(m('saturn'))SP('acoustic_grand_piano',t,noteF(tv,4),stepT*8,.42,'saturn',{rel:.5});
        // the mirror: the same steps inverted, two octaves down
        if(m('jupiter')&&sec!=='intro')samp('cello',t,noteF(C-(mn-C),2),stepT*7.6,.24,'jupiter',{att:.1,rel:.3});}
    }
    if(m('saturn')&&pos%2===1&&sec!=='intro'){const k=(s>>1)%6,tv=TRI[k%3]+7*Math.floor(k/3);SP('acoustic_grand_piano',t,noteF(tv,5),stepT*3,.12,'saturn',{rel:.3,flash:false})}
    if(m('sun')&&pos===0&&bar%4===0)samp('tubular_bells',t,noteF(0,4),barDur()*3,.32,'sun',{rel:1});
    if(drop&&m('earth')&&pos===0)sChord('choir_aahs',t,[0,2,4],4,barDur()*1.02,.18,'earth',{att:.4,rel:.6});
  },
  // Reich: phasing. Marimbas play one pattern; the angle between Venus (and Mars) and the Earth sets how far apart they are
  reich(s,pos,bar,t,st,L,stepT,m,into){
    const sec=D.section,drop=sec==='drop',deg=D.prog[Math.floor(bar/4)%4];
    if(!D.rpat||D.rkey!==signOf('earth')){D.rkey=signOf('earth');const r=rng(D.rkey*7+31),SET=[0,1,4,5,7];D.rpat=[];let last=-1;for(let k=0;k<12;k++){let v;do{v=SET[Math.floor(r()*5)]}while(v===last);D.rpat.push(v);last=v}}
    const PT=D.rpat,ang=w=>{const a=((Math.atan2(P_(w).y,P_(w).x)-Math.atan2(P_('earth').y,P_('earth').x))/DEG+720)%360;return Math.floor(a/30)%12};
    const offV=ang('venus'),offM=ang('mars');D.rphase=[offV,offM];
    {const i=s%12;
      if(m('earth')&&L.pads!==0)samp('marimba',t,noteF(PT[i],4),stepT*2,.36,'earth',{rel:.08});
      if(m('venus')&&sec!=='intro')samp('marimba',t,noteF(PT[(i+offV)%12],5),stepT*2,.3,'venus',{rel:.08});
      if(m('mars')&&(drop||sec==='build'))samp('marimba',t,noteF(PT[(i+offM)%12],4)*1.0,stepT*2,.24,'mars',{rel:.08});}
    // pulsing voices: each chord breathes in quavers, swelling and fading through the bar
    if(m('saturn')&&pos%2===0&&sec!=='intro'){const sw=Math.sin(Math.PI*(pos+1)/16);sChord('choir_aahs',t,tri(deg),4,stepT*1.7,.07+.12*sw*(drop?1.4:1),'saturn',{att:.02,rel:.05})}
    if(m('jupiter')&&pos===0&&bar%2===0)samp('contrabass',t,noteF(deg,2),barDur()*1.9,.4,'jupiter',{att:.5,rel:.4});
    // clapping: one pattern, a second clapper phased by the Moon's angle from the Sun
    const CL=[1,1,1,0,1,1,0,1,0,1,1,0];const mo=byId.earth.moons[0],el=((TAU*((S.jd-J2000)/mo.P+mo.ph0)-Math.atan2(-P.earth.y,-P.earth.x))/TAU%1+1)%1,moonOff=Math.floor(el*12)%12;
    if(m('mercury')&&(drop||sec==='groove')){if(CL[s%12])clap(t,.35);if(drop&&CL[(s+moonOff)%12])clap(t+.004,.25)}
    if(drop&&m('jupiter-moons')){const tn=tri(deg);if(s%4===0)samp('vibraphone',t,noteF(tn[(s>>2)%3],5),stepT*4,.22,'jupiter-moons',{rel:.2})}
  },
  // Glass: organ arpeggios in threes over a left hand in twos, the figure growing by a note each bar
  glass(s,pos,bar,t,st,L,stepT,m){
    const sec=D.section,drop=sec==='drop',deg=D.prog[Math.floor(bar/2)%4],spb=SPB(),bd=barDur();
    const len=3+(bar%4),UP=[0,2,4,7,9,11,14],fig=[];for(let k=0;k<len;k++)fig.push(UP[k]);for(let k=len-2;k>0;k--)fig.push(UP[k]);
    if(m('saturn')&&pos%2===0&&L.pads){const k=(pos/2)%fig.length;samp('drawbar_organ',t,noteF(deg+fig[k],4),stepT*1.9,.22,'saturn',{att:.005,rel:.03})||piano(t,noteF(deg+fig[k],4),stepT*2,.06,'saturn')}
    if(m('jupiter')&&pos%3===0&&L.bass){const k=(pos/3)%2;samp('drawbar_organ',t,noteF(deg+(k?4:0),3),stepT*2.8,.2,'jupiter',{att:.005,rel:.03})||piano(t,noteF(deg+(k?4:0),3),stepT*3,.06,'jupiter')}
    if(m('neptune')&&pos===0)samp('church_organ',t,noteF(deg,1),bd*1.02,.22,'neptune',{att:.05,rel:.15});
    if(m('earth')&&pos===0&&(sec==='groove'||drop))sChord('choir_aahs',t,tri(deg),4,bd*1.02,.14,'earth',{att:.2,rel:.3});
    if(drop&&m('mercury')&&pos%2===0){const k=(pos/2)%fig.length;samp('flute',t,noteF(deg+fig[k],5),stepT*1.9,.16,'mercury',{rel:.03})}
    if(drop&&m('venus')&&pos===0&&bar%2===0){const v=[4,2,0,1][Math.floor(bar/2)%4];samp('choir_aahs',t,noteF(deg+v,5),bd*1.95,.3,'venus',{att:.15,rel:.3})}
  }
};
const P_=w=>P[w];

/* ---- the dance floor: the orrery seen from above ---- */
const BAND=[
  {id:'sun',god:'Apollo',inst:'Kick',color:'#ffd98a'},
  {id:'mercury',god:'Hermes',inst:'Hi-hats'},
  {id:'earth',god:'Gaia',inst:'Claps and snares'},
  {id:'mars',god:'Ares',inst:'Toms'},
  {id:'jupiter',god:'Zeus',inst:'Bass'},
  {id:'jupiter-moons',god:'Io · Europa · Ganymede',inst:'Arpeggio, 1 : 2 : 4',color:'#efe6cf'},
  {id:'saturn',god:'Kronos',inst:'Pads and chords'},
  {id:'venus',god:'Aphrodite',inst:'Vocal chops'},
  {id:'uranus',god:'Ouranos',inst:'Risers'},
  {id:'neptune',god:'Poseidon',inst:'Sub and atmosphere'}];
BAND.forEach(x=>{if(!x.color)x.color=byId[x.id].color});
function renderMixer(){
  $('mix').innerHTML=BAND.map(x=>`<div class="mrow${D.mute.has(x.id)?' off':''}" data-id="${x.id}"><span class="sw" id="sw_${x.id}" style="background:${x.color};color:${x.color}"></span><span class="nm">${x.god} <span>${(STY().inst&&STY().inst[x.id])||x.inst}</span></span><button class="mb" aria-pressed="${D.mute.has(x.id)}" title="Mute ${x.god}">M</button></div>`).join('');
}
$('mix').onclick=e=>{const r=e.target.closest('.mrow');if(!r||!e.target.closest('.mb'))return;const id=r.dataset.id;D.mute.has(id)?D.mute.delete(id):D.mute.add(id);renderMixer()};
const cv=$('dial'),g=cv.getContext('2d');let W=0,H=0,DPR=1,CX=0,CY=0,RR=0;
function resize(){DPR=Math.min(2,devicePixelRatio||1);const r=cv.getBoundingClientRect();W=r.width;H=r.height;cv.width=Math.round(W*DPR);cv.height=Math.round(H*DPR);CX=W/2;CY=H/2;RR=Math.min(W,H)/2*.8}
new ResizeObserver(resize).observe(cv);
const RMAX=34,R0=.45;
const sr=r=>RR*Math.log(1+r/R0)/Math.log(1+RMAX/R0);
function pr(x,y){const r=Math.hypot(x,y),s=r>0?sr(r)/r:0;return {x:CX+x*s,y:CY-y*s}}
const hexA=(h,a)=>{const n=parseInt(h.slice(1),16);return `rgba(${n>>16&255},${n>>8&255},${n&255},${a})`};
let starSeed=3;const srnd=()=>{starSeed=(starSeed*16807)%2147483647;return (starSeed-1)/2147483646};
const DSTARS=Array.from({length:380},()=>({x:srnd(),y:srnd(),m:srnd()}));
function draw(){
  g.setTransform(DPR,0,0,DPR,0,0);g.clearRect(0,0,W,H);
  DSTARS.forEach(s=>{g.fillStyle=`rgba(233,225,204,${.1+s.m*.3})`;g.fillRect(s.x*W,s.y*H,1,1)});
  // zodiac ring, with the Sun's current sign lit
  const Rz=RR*1.07, sun=sunSign();
  for(let k=0;k<12;k++){const a0=k*30*DEG,a1=(k+1)*30*DEG;g.strokeStyle=k===sun?'rgba(201,152,79,.9)':'rgba(201,152,79,.28)';g.lineWidth=k===sun?3:1;g.beginPath();g.arc(CX,CY,Rz,-a1,-a0);g.stroke();
    const am=(k*30+15)*DEG;g.fillStyle=k===sun?'rgba(201,152,79,1)':'rgba(201,152,79,.55)';g.font=`${Math.max(10,RR*.033)}px "GFS Didot",Georgia,serif`;g.textAlign='center';g.textBaseline='middle';g.fillText(SIGNS[k][0],CX+Math.cos(am)*Rz*1.075,CY-Math.sin(am)*Rz*1.075)}
  // orbits
  BODIES.filter(b=>b.kind==='planet').forEach(b=>{g.strokeStyle=hexA(b.color,.18);g.lineWidth=1;g.beginPath();b.orbit.forEach((o,k)=>{const q=pr(o.x,o.y);k?g.lineTo(q.x,q.y):g.moveTo(q.x,q.y)});g.stroke()});
  // aspect lines
  ASPNOW.slice(0,3).forEach(a=>{const p=pr(P[a.a.id].x,P[a.a.id].y),q=pr(P[a.b.id].x,P[a.b.id].y);g.strokeStyle=`rgba(201,152,79,${.15+.6*a.str})`;g.lineWidth=1+a.str*2;g.beginPath();g.moveTo(p.x,p.y);g.lineTo(q.x,q.y);g.stroke()});
  // the Sun pulses with the kick
  const sp=pr(0,0),k=FL.sun||0,sr2=16+k*14;const sg=g.createRadialGradient(sp.x,sp.y,0,sp.x,sp.y,sr2*1.7);sg.addColorStop(0,'rgba(255,236,190,1)');sg.addColorStop(.3,`rgba(232,180,95,${.7+.3*k})`);sg.addColorStop(1,'rgba(201,152,79,0)');g.fillStyle=sg;g.beginPath();g.arc(sp.x,sp.y,sr2*1.7,0,TAU);g.fill();
  // comets near the Sun
  BODIES.filter(b=>b.kind==='comet'&&P[b.id].r<3).forEach(b=>{const q=pr(P[b.id].x,P[b.id].y);g.fillStyle='rgba(200,230,255,.8)';g.beginPath();g.arc(q.x,q.y,2,0,TAU);g.fill()});
  // planets, flaring as they play
  BODIES.filter(b=>b.kind==='planet').forEach(b=>{
    const q=pr(P[b.id].x,P[b.id].y),f=FL[b.id]||0,r=Math.max(3,Math.min(9,1.4+2.1*Math.log10(b.R/120)));
    if(f>.02){g.strokeStyle=hexA(b.color,.5*f);g.lineWidth=2;g.beginPath();g.arc(q.x,q.y,r+4+(1-f)*16,0,TAU);g.stroke();const gl=g.createRadialGradient(q.x,q.y,0,q.x,q.y,r*3.5);gl.addColorStop(0,hexA(b.color,.6*f));gl.addColorStop(1,hexA(b.color,0));g.fillStyle=gl;g.beginPath();g.arc(q.x,q.y,r*3.5,0,TAU);g.fill()}
    g.fillStyle=b.color;g.beginPath();g.arc(q.x,q.y,r*(1+.35*f),0,TAU);g.fill();
    if(b.id==='saturn'){g.strokeStyle=hexA(b.color,.7);g.lineWidth=1.2;g.beginPath();g.ellipse(q.x,q.y,r*2.1,r*.8,-.35,0,TAU);g.stroke()}
    if(b.id==='jupiter'){['io','europa','ganymede'].forEach((id,k)=>{const m=b.moons[k+1],th=TAU*((S.jd-J2000)/m.P+m.ph0),rad=r+6+k*5,mf=FL[id]||0;g.fillStyle=`rgba(239,230,207,${.5+.5*mf})`;g.beginPath();g.arc(q.x+rad*Math.cos(th),q.y-rad*Math.sin(th),1.4+mf*2.6,0,TAU);g.fill()})}
    g.font='13px "GFS Didot",Georgia,serif';g.textAlign='left';g.textBaseline='middle';g.fillStyle=`rgba(233,225,204,${.75+.25*f})`;g.fillText(b.god,q.x+r+7,q.y-1);
  });
  Object.keys(FL).forEach(id=>{FL[id]*=.86;const sw=$('sw_'+(['io','europa','ganymede'].includes(id)?'jupiter-moons':id));if(sw)sw.style.boxShadow=FL[id]>.05?`0 0 ${4+10*FL[id]}px ${2*FL[id]}px currentColor`:'none'});
}
// mixer swatches glow in their own colour
function tintSwatches(){BAND.forEach(x=>{const el=$('sw_'+x.id);if(el)el.style.color=x.color})}

/* ---- readouts ---- */
function toast(t){const el=$('toast');el.textContent=t;el.style.opacity=1;clearTimeout(toast.h);toast.h=setTimeout(()=>el.style.opacity=0,3500)}
function renderSection(){const el=$('secTxt');el.textContent=D.section;el.className='sec '+D.section}
const MODENAME={trance:'Hypodorian (minor)',house:'Phrygian (modern Dorian)',techno:'Dorian (modern Phrygian)',waltz:'Lydian (the modern major)',tango:'Hypodorian (minor)',samba:'Hypophrygian (modern Mixolydian)',chacha:'Phrygian (modern Dorian)',swing:'Hypophrygian (modern Mixolydian)',jive:'Hypophrygian (modern Mixolydian)',fandango:'Dorian (modern Phrygian), Andalusian cadence'};
Object.assign(MODENAME,{jungle:'Hypodorian (minor)',slowwaltz:'Lydian (the modern major)',baroque:'Hypodorian (minor), in counterpoint'});
Object.assign(MODENAME,{mozart:'Lydian (the modern major)',satie:'Hypolydian (modern Lydian)',debussy:'whole-tone and pentatonic',part:'Hypodorian (minor), on the home triad',reich:'Phrygian (modern Dorian)',glass:'Hypodorian (minor)'});
const PROGNOTE={sky:'Home, then the chords that Zeus, Kronos and Poseidon stand on in the zodiac, seen from Earth.',cadence:'The Andalusian cadence: Zeus and Kronos choose the first two chords from where they stand in the zodiac, then the Phrygian second leads home.'};
function renderProg(){
  if(!D.progInfo.length)return;
  $('progNote').textContent=STY().cadence?PROGNOTE.cadence:PROGNOTE.sky;
  const cur=Math.floor(D.step/SPB())%4;
  $('prog').innerHTML=D.progInfo.map((c,k)=>`<div class="chord${D.playing&&k===cur?' on':''}"><div class="r">${ROMAN[c.deg]}</div><div class="w">${c.who}${c.sign!==null?' · '+SIGNS[c.sign][0]:''}</div></div>`).join('');
}
function fmtDays(d){return d<1?(d*24).toFixed(0)+' hours / bar':d<60?d.toFixed(d<10?1:0)+' days / bar':(d/30.44).toFixed(1)+' months / bar'}
function dateStr(jd){const d=new Date((jd-2440587.5)*86400000);const M=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];return `${d.getUTCDate()} ${M[d.getUTCMonth()]} ${d.getUTCFullYear()}`}
function readouts(){
  if(!DEG7)DEG7=modeDeg();
  const i=sunSign(),tonic=noteF(0,3),m=69+12*Math.log2(tonic/440),nm=['C','C♯','D','E♭','E','F','F♯','G','G♯','A','B♭','B'][((Math.round(m)%12)+12)%12];
  $('keyTxt').innerHTML=`Key of <b>${nm}</b>, ${MODENAME[D.style]} · Sun in <b>${SIGNS[i][0]}</b> (${SIGNS[i][1]})`;
  $('aspTxt').innerHTML=ASPNOW.length?ASPNOW.slice(0,2).map(a=>`${a.a.god} ${a.asp.sym}︎ ${a.b.god} <span style="opacity:.7">${a.asp.name}, ${Math.round(a.str*100)}%</span>`).join('<br>'):'No aspects at the moment: the band grooves.';
  $('energy').style.width=Math.round(D.energy*100)+'%';
  $('barTxt').textContent=D.playing?`bar ${Math.floor(D.step/SPB())+1}`:'stopped';
  $('dateTxt').textContent=dateStr(S.jd);
  renderProg();
}

/* ---- controls ---- */
window.recName=()=>RECBASE+D.style;
function syncPlay(){$('play').setAttribute('aria-pressed',String(D.playing));$('play').textContent=D.playing?'Stop':'Play'}
$('play').onclick=()=>D.playing?stopDance():startDance();
document.querySelectorAll('#style button').forEach(b=>b.onclick=()=>setStyle(b.dataset.v));
$('bpm').oninput=e=>{D.bpm=+e.target.value;$('bpmOut').textContent=D.bpm+' BPM';if(window.MOTS&&MOTS.midi.transport)MOTS.midi.transport(D.playing,D.bpm)};
if(window.MOTS&&MOTS.defaultOut)MOTS.defaultOut('stereo');
$('dpb').oninput=e=>{D.dpb=Math.pow(10,-.6+e.target.value/1000*2.4);$('dpbOut').textContent=fmtDays(D.dpb)};$('dpb').oninput({target:$('dpb')});
try{const v=localStorage.getItem('mots.vol.dance');if(v!==null)$('vol').value=v}catch(e){}
$('vol').oninput=e=>{D.vol=e.target.value/100;$('volOut').textContent=e.target.value+'%';if(AC&&D.playing)master.gain.setTargetAtTime(outGain(),AC.currentTime,.05);try{localStorage.setItem('mots.vol.dance',e.target.value)}catch(e){}};$('vol').oninput({target:$('vol')});
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&AC&&D.playing&&AC.state!=='running')AC.resume()});

/* ---- main loop ---- */
S.mode=STYLES[D.style].mode;
computePositions();computeAspectsD();updateProgression();renderMixer();tintSwatches();renderSection();
let last=performance.now(),lastUI=0;
function frame(t){
  const dt=Math.min(.1,(t-last)/1000);last=t;
  // the sky moves a set number of days per bar while playing, and drifts slowly when stopped
  S.jd+=dt*(D.playing?1/barDur():.5)*D.dpb;
  computePositions();pumpFlashes();
  if(!D.playing&&t-lastUI>240){computeAspectsD();updateProgression()}
  draw();
  if(t-lastUI>240){lastUI=t;readouts()}
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

})();
