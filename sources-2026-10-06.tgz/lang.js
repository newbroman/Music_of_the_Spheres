/* ---------- one language menu instead of a row of language links ---------- */
(()=>{
"use strict";
const B='https://newbroman.github.io/Music_of_the_Spheres/';
const ALL=[['en','English'],['pl','Polski'],['cy','Cymraeg'],['de','Deutsch'],['es','Español'],['fr','Français'],['it','Italiano'],['zh','中文'],['ja','日本語']];
const AVAIL=/*LANGS*/['en','pl','cy']/*LANGS-END*/;
const LANGS=ALL.filter(([c])=>AVAIL.includes(c));
const LS={get:k=>{try{return localStorage.getItem(k)}catch(e){return null}},set:(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}}};
const cur=(document.documentElement.lang||'en').slice(0,2);
// the page within the app, whichever language folder it is in
function page(){const m=location.pathname.match(/(?:^|\/)(?:(pl|cy|de|es|fr|it|zh|ja)\/)?([a-z]+\.html)?$/);const p=(m&&m[2])||'';return p==='index.html'?'':p}
const href=c=>B+(c==='en'?'':c+'/')+page()+location.hash;
const GLOBE='<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" style="vertical-align:-3px;margin-right:6px"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M3 12h18M12 3c2.6 2.6 3.9 5.6 3.9 9s-1.3 6.4-3.9 9c-2.6-2.6-3.9-5.6-3.9-9S9.4 5.6 12 3z" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>';
function build(){
  const links=[...document.querySelectorAll('body a[hreflang]')].filter(a=>!a.closest('#langMenu'));if(!links.length)return;
  const first=links[0],compact=links.every(a=>a.textContent.trim().length<=3),name=(LANGS.find(l=>l[0]===cur)||ALL[0])[1];
  const d=document.createElement('details');d.id='langMenu';d.className='langmenu';
  const s=document.createElement('summary');s.className=first.className;
  // the button keeps the look of the link it replaces
  {const cs=getComputedStyle(first);['border','borderRadius','padding','font','color','background','letterSpacing','textTransform','minHeight','lineHeight','boxShadow'].forEach(k=>s.style[k]=cs[k]);s.style.display='inline-flex';s.style.alignItems='center'}
s.innerHTML=GLOBE+(compact?cur.toUpperCase():name)+' ▾';s.setAttribute('aria-label','Language · '+name);
  const m=document.createElement('div');m.className='lmenu';m.setAttribute('role','menu');
  LANGS.forEach(([c,n])=>{const a=document.createElement('a');a.href=href(c);a.lang=c;a.hreflang=c;a.textContent=n;a.setAttribute('role','menuitem');if(c===cur){a.setAttribute('aria-current','true')}a.onclick=e=>{LS.set('mots.lang',c);if(c!==cur){e.preventDefault();location.href=href(c)}else{e.preventDefault();d.open=false}};m.appendChild(a)});
  // keep the list on screen next to an edge
  d.addEventListener('toggle',()=>{if(!d.open||innerWidth<=760)return;m.style.cssText='';const r=m.getBoundingClientRect();if(r.right>innerWidth-8)m.style.cssText='left:auto;right:0;transform:none';else if(r.left<8)m.style.cssText='left:0;transform:none'});
  d.append(s,m);first.replaceWith(d);links.slice(1).forEach(a=>a.remove());
  document.addEventListener('click',e=>{if(d.open&&!d.contains(e.target))d.open=false});
  document.addEventListener('keydown',e=>{if(e.key==='Escape')d.open=false});
}
const css=document.createElement('style');
css.textContent=`.langmenu{position:relative;display:inline-block}.langmenu summary{list-style:none;cursor:pointer;white-space:nowrap}.langmenu summary::-webkit-details-marker{display:none}
.langmenu .lmenu{position:absolute;left:50%;transform:translateX(-50%);top:calc(100% + 6px);z-index:40;min-width:180px;display:flex;flex-direction:column;padding:6px;background:#13162a;border:1px solid #2b3050;border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.45)}
.langmenu .lmenu a{display:block!important;margin:0!important;border:0!important;background:none!important;box-shadow:none!important;padding:9px 12px!important;border-radius:6px!important;color:#e9e1cc!important;text-decoration:none!important;font:16px/1.3 "Alegreya Sans",system-ui,sans-serif!important;text-transform:none!important;letter-spacing:0!important;min-height:0!important}
.langmenu .lmenu a:hover{background:#1d2140!important;color:#e9d093!important}.langmenu .lmenu a[aria-current="true"]{color:#e9d093!important}.langmenu .lmenu a[aria-current="true"]::after{content:" ✓"}
@media (max-width:760px){.langmenu .lmenu{position:fixed;top:auto;width:min(300px,calc(100vw - 32px))}}
#langHint{position:fixed;left:50%;bottom:16px;transform:translateX(-50%);z-index:70;display:flex;gap:10px;align-items:center;background:#13162a;border:1px solid #c9984f;border-radius:999px;padding:6px 8px 6px 14px;color:#e9e1cc;font:15px/1.3 "Alegreya Sans",system-ui,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.5)}
#langHint a{color:#e9d093;text-decoration:none;font-weight:600}#langHint button{appearance:none;border:0;background:transparent;color:#a39c89;font-size:18px;cursor:pointer;padding:4px 8px}`;
document.head.appendChild(css);
// on a first visit to the English pages, offer the visitor's own language if the app has it
function hint(){
  if(cur!=='en'||LS.get('mots.lang'))return;
  const want=(navigator.languages||[navigator.language||'']).map(x=>String(x).slice(0,2).toLowerCase()).find(c=>c!=='en'&&AVAIL.includes(c));if(!want)return;
  const n=LANGS.find(l=>l[0]===want)[1],h=document.createElement('div');h.id='langHint';
  h.innerHTML=GLOBE+`<a href="${href(want)}" lang="${want}">${n} →</a><button type="button" aria-label="×">×</button>`;
  h.querySelector('a').onclick=()=>LS.set('mots.lang',want);h.querySelector('button').onclick=()=>{LS.set('mots.lang','en');h.remove()};
  document.body.appendChild(h);
}
// copyright and credits, at the foot of every page except the 3D flight (which fills the screen)
const CR={en:['All rights reserved.','Instruments','3D','Orbits'],pl:['Wszelkie prawa zastrzeżone.','Instrumenty','3D','Orbity'],cy:['Cedwir pob hawl.','Offerynnau','3D','Orbitau'],
 de:['Alle Rechte vorbehalten.','Instrumente','3D','Bahnen'],es:['Todos los derechos reservados.','Instrumentos','3D','Órbitas'],fr:['Tous droits réservés.','Instruments','3D','Orbites'],
 it:['Tutti i diritti riservati.','Strumenti','3D','Orbite'],zh:['保留所有权利。','乐器','3D','轨道'],ja:['無断転載を禁じます。','楽器','3D','軌道']};
function footer(){
  if(document.getElementById('motsCopy')||page()==='flight.html')return;
  const c=CR[cur]||CR.en,f=document.createElement('footer');f.id='motsCopy';
  f.style.cssText='margin:40px auto 24px;padding:0 16px;max-width:1080px;text-align:center;font-size:12px;line-height:1.6;opacity:.6';
  f.innerHTML=`© 2026 Martin Hollingham. ${c[0]}<br>${c[1]}: FluidR3 GM SoundFont, Frank Wen (CC BY 3.0) · ${c[2]}: three.js (MIT) · ${c[3]}: NASA JPL`;
  document.body.appendChild(f);
}
const go=()=>{build();hint();footer()};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',go);else go();
})();
