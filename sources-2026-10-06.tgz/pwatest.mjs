import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});const ctx=await b.newContext();const p=await ctx.newPage();
const errs=[];p.on('pageerror',e=>errs.push(String(e)));
await p.goto('http://localhost:8123/index.html');
const st=await p.evaluate(async()=>{const r=await navigator.serviceWorker.ready;await new Promise(r=>setTimeout(r,8000));const ks=await caches.keys();let n=0;for(const k of ks)n+=(await (await caches.open(k)).keys()).length;return [r.active&&r.active.state,ks,n]});
console.log('sw',JSON.stringify(st));
await ctx.setOffline(true);
for(const u of ['index.html','dance.html','pl/index.html','pl/dance.html','flight.html','help.html']){await p.goto('http://localhost:8123/'+u);await p.waitForTimeout(500);console.log('offline',u,await p.title())}
await p.goto('http://localhost:8123/dance.html');await p.click('#style button[data-v="mozart"]');await p.click('#play');await p.waitForTimeout(4000);console.log('toast',await p.textContent('#toast'));
console.log('errors',errs.slice(0,3));await b.close();
