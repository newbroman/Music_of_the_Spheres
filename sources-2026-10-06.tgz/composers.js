
/* ================= COMPOSERS: each one's own method, the planets still the band ================= */
Object.assign(BALL_INST,{
  mozart:{sun:'Horns (in the climax)',mercury:'Flute: trills at the cadences',earth:'Oboe, in thirds',mars:'Timpani at the cadences',jupiter:'Alberti bass (piano)','jupiter-moons':'Second violins, 1 : 2 : 4',saturn:'Inner strings',venus:'Melody (violin)',uranus:'String crescendo',neptune:'Cellos and basses'},
  satie:{sun:'—',mercury:'—',earth:'Harp (in the climax)',mars:'—',jupiter:'Bass note on the one (piano)','jupiter-moons':'—',saturn:'Floating seventh chords (piano)',venus:'Melody (piano, then flute)',uranus:'—',neptune:'Strings (in the climax)'},
  debussy:{sun:'Antique cymbals',mercury:'Celesta',earth:'Oboe, echoing',mars:'Timpani roll',jupiter:'Deep piano pedal','jupiter-moons':'Harp, 1 : 2 : 4',saturn:'Strings, parallel ninth chords',venus:'Flute arabesque',uranus:'String swell',neptune:'—'},
  part:{sun:'Bells',mercury:'—',earth:'Choir (in the climax)',mars:'—',jupiter:'Mirror voice (cello)','jupiter-moons':'—',saturn:'Tintinnabuli voice (piano)',venus:'Melodic voice (violin)',uranus:'—',neptune:'—'},
  reich:{sun:'—',mercury:'Clapping',earth:'Marimba 1, the pattern',mars:'Marimba 3, phased by Mars',jupiter:'Bass swells','jupiter-moons':'Vibraphone, 1 : 2 : 4',saturn:'Pulsing voices',venus:'Marimba 2, phased by Venus',uranus:'Voices swell',neptune:'—'},
  glass:{sun:'—',mercury:'Flute, doubling',earth:'Choir',mars:'—',jupiter:'Organ left hand, in twos','jupiter-moons':'—',saturn:'Organ arpeggios, in threes',venus:'Soprano (in the climax)',uranus:'Organ swell',neptune:'Organ pedal'}
});
Object.assign(BALL_SAMPLES,{
  mozart:['acoustic_grand_piano','violin','string_ensemble_1','contrabass','flute','oboe','french_horn','timpani','pizzicato_strings'],
  satie:['acoustic_grand_piano','orchestral_harp','flute','string_ensemble_1'],
  debussy:['string_ensemble_1','orchestral_harp','flute','oboe','celesta','acoustic_grand_piano','timpani'],
  part:['violin','acoustic_grand_piano','cello','tubular_bells','choir_aahs'],
  reich:['marimba','choir_aahs','vibraphone','contrabass'],
  glass:['drawbar_organ','choir_aahs','flute','church_organ']
});
Object.assign(STYLES,{
  mozart:{gain:3.0,name:'Mozart',fam:'ball',own:true,beats:4,bpm:126,mode:'C',swing:0,kickF:[90,48,.4],kickLvl:0,duck:1,pads:'none',buildBars:4,noSub:true,rise:'strings'},
  satie:{gain:4.2,name:'Satie',fam:'ball',own:true,beats:3,bpm:66,mode:'F',swing:0,kickF:[90,48,.4],kickLvl:0,duck:1,pads:'none',buildBars:4,noSub:true,rise:'none'},
  debussy:{gain:3.6,name:'Debussy',fam:'ball',own:true,beats:4,bpm:60,mode:'C',swing:0,kickF:[90,48,.4],kickLvl:0,duck:1,pads:'none',buildBars:4,noSub:true,rise:'strings'},
  part:{gain:3.6,name:'Pärt',fam:'ball',own:true,beats:4,bpm:60,mode:'A',swing:0,kickF:[90,48,.4],kickLvl:0,duck:1,pads:'none',buildBars:4,noSub:true,rise:'none'},
  reich:{gain:1.8,name:'Reich',fam:'ball',own:true,beats:4,bpm:132,mode:'D',swing:0,kickF:[90,48,.4],kickLvl:0,duck:1,pads:'none',buildBars:8,noSub:true,rise:'voices'},
  glass:{gain:3.4,name:'Glass',fam:'ball',own:true,beats:4,sub:6,bpm:96,mode:'A',swing:0,kickF:[90,48,.4],kickLvl:0,duck:1,pads:'none',buildBars:4,noSub:true,rise:'organ'}
});
['mozart','satie','debussy','part','reich','glass'].forEach(k=>{STYLES[k].inst=BALL_INST[k];STYLES[k].samples=BALL_SAMPLES[k]});
// a recorded note, or a soft piano-like stand-in while recordings load
const SP=(n,t,f,len,lvl,id,o)=>samp(n,t,f,len,lvl,id,o)||(piano(t,f,len,lvl*.28,id),true);
const tri=deg=>[deg,deg+2,deg+4];
const sev=deg=>[deg,deg+2,deg+4,deg+6];
const ET=(semis,oct)=>noteF(0,oct)*Math.pow(2,semis/12);
// a melody that the sky composes from Aphrodite's sign: rhythms per beat and chord-tone targets, stepwise between
function skyLine(key,bars,beatsPer,seed,opts={}){
  const k=key+'|'+bars+'|'+beatsPer;if(D.lines&&D.lines[k])return D.lines[k];D.lines=D.lines||{};
  const r=rng(seed),RH=opts.rh||[[1,0,0,0],[1,0,1,0],[1,0,1,0],[1,1,1,0],[1,0,0,0]],out=[];let cur=opts.start||4;
  for(let b=0;b<bars*beatsPer;b++){const p=RH[Math.floor(r()*RH.length)];
    for(let i=0;i<4;i++){if(!p[i]){out.push(null);continue}
      if(i===0){const tg=[0,2,4,7][Math.floor(r()*4)];cur=Math.abs(tg-cur)<=4?tg:cur+(tg>cur?2:-2)}else cur+=(r()<.55?-1:1);
      cur=Math.max(opts.lo??-1,Math.min(opts.hi??9,cur));out.push(cur)}}
  return D.lines[k]=out;
}
function lenAt(line,i){let n=1;while(n<16&&line[(i+n)%line.length]===null)n++;return n}

const COMPOSE={
  // Mozart: an eight-bar period, a question ending on V and an answer coming home to I
  mozart(s,pos,bar,t,st,L,stepT,m,into){
    const pb=bar%8,z=D.prog[1],pdRaw=D.prog[2],pd=[1,3,5].includes(pdRaw)?pdRaw:3;
    const CH=[0,z===4?5:z,pd,4,0,z===4?5:z,4,0],deg=CH[pb],sec=D.section,drop=sec==='drop',bd=barDur();
    // Alberti bass: root, fifth, third, fifth in quavers
    if(L.bass&&m('jupiter')&&pos%2===0){const a=[0,4,2,4][(pos/2)%4];SP('acoustic_grand_piano',t,noteF(deg+a,3),stepT*2.2,.3,'jupiter',{rel:.1})}
    // cellos and basses on the strong beats
    if(m('neptune')&&(pos===0||pos===8)&&sec!=='intro')samp('contrabass',t,noteF(deg,2),stepT*7,.2,'neptune',{att:.02,rel:.15});
    // inner strings repeating the harmony in quavers
    if(L.pads&&m('saturn')&&pos%2===0)sChord('string_ensemble_1',t,[deg+2,deg+4],4,stepT*1.8,drop?.16:.1,'saturn',{att:.01,rel:.06});
    // the melody: a two-bar idea, repeated on the new harmony, then the cadence
    const line=skyLine('moz'+signOf('venus'),2,4,signOf('venus')*29+3,{start:4,lo:-1,hi:9});
    let mel=null,ml=1;
    if(pb===3||pb===7){const cad=pb===3?{0:[2,4],4:[1,8]}:{0:[2,4],4:[1,4],8:[0,8]};const c=cad[pos];if(c){mel=c[0]-deg;ml=c[1]}}
    else{const i=((pb%4)%2)*16+pos,v=line[i];if(v!==null){mel=v;ml=lenAt(line,i)}}
    if(mel!==null&&L.lead>.2&&m('venus')){const f=noteF(deg+mel,5);SP('violin',t,f,stepT*ml*.95,.5,'venus',{att:.03,rel:.12});
      if(m('earth')&&(sec==='groove'||drop))samp('oboe',t,noteF(deg+mel-2,5),stepT*ml*.9,.3,'earth',{att:.03,rel:.1});
      if(drop&&m('mercury'))samp('flute',t,f*2,stepT*ml*.9,.24,'mercury',{att:.03,rel:.1})}
    // a flute trill at each cadence
    if((pb===3||pb===7)&&pos>=8&&pos<12&&m('mercury')&&sec!=='intro'){const top=pb===3?1:0;samp('flute',t,noteF(pos%2?top+1:top,6),stepT*.9,.22,'mercury',{rel:.04})}
    // horns and timpani in the climax
    if(drop&&m('sun')&&pos===0)sChord('french_horn',t,[0,4],3,bd*.95,.24,'sun',{att:.04,rel:.2});
    if((drop||sec==='groove')&&m('mars')&&(pb===3||pb===7)&&(pos===0||pos===8))samp('timpani',t,noteF(pos===0?4:0,2),stepT*6,.5,'mars',{rel:.25});
    if(drop&&L.arp&&m('jupiter-moons')){const tn=tri(deg);if(s%2===0)samp('pizzicato_strings',t,noteF(tn[(s>>1)%3],5),stepT*2,.2,'jupiter-moons',{rel:.05})}
    if(sec==='build'&&m('mars')&&pos%2===0)samp('timpani',t,noteF(4,2),stepT*2,.2+.4*(into+pos/16)/D.secLen,'mars',{rel:.1});
  },
  // Satie: a slow three, a bass note on the one and a floating seventh chord after it, two chords swaying
  satie(s,pos,bar,t,st,L,stepT,m){
    let a=D.prog[1],b=D.prog[2];if(a===b)b=(a+3)%7;const deg=bar%2?b:a,sec=D.section,drop=sec==='drop',bd=barDur();
    if(m('jupiter')&&pos===0)SP('acoustic_grand_piano',t,noteF(deg,2),bd*1.05,.4,'jupiter',{rel:.4});
    if(m('saturn')&&pos===4){const ch=sev(deg).slice(1);ch.forEach((d,k)=>SP('acoustic_grand_piano',t+k*.012,noteF(d,3),stepT*8,.2,'saturn',{rel:.3}));flash('saturn',t)}
    if(drop&&m('neptune')&&pos===0)sChord('string_ensemble_1',t,sev(deg).slice(1),3,bd*1.02,.1,'neptune',{att:.4,rel:.6});
    if(drop&&m('earth')&&pos===4)sChord('orchestral_harp',t,sev(deg).slice(1),4,stepT*8,.3,'earth',{spread:.06,rel:.4});
    // a sparse, slowly falling melody, as in the Gymnopédies
    const line=skyLine('sat'+signOf('venus'),8,3,signOf('venus')*17+5,{rh:[[1,0,0,0],[1,0,0,0],[0,0,0,0]],start:7,lo:2,hi:11});
    const i=(bar%8)*12+pos;
    if(pos%4===0&&L.lead>.2&&m('venus')){const v=line[i];if(v!==null&&v!==undefined){const n=Math.min(lenAt(line,i),12),f=noteF(v,5);
      SP('acoustic_grand_piano',t,f,stepT*n,.42,'venus',{rel:.4});if(drop)samp('flute',t,f,stepT*n*.95,.24,'venus',{att:.05,rel:.2,flash:false})}}
  },
  // Debussy: parallel ninth chords gliding by whole tones, harp washes, a flute arabesque on the whole-tone or pentatonic scale
  debussy(s,pos,bar,t,st,L,stepT,m,into){
    const sec=D.section,drop=sec==='drop',bd=barDur(),pat=[[0,2,4,2],[0,-2,-4,-2],[0,2,-2,0],[0,4,2,6]][signOf('saturn')%4],root=pat[bar%4];
    const CH=[0,4,7,11,14].map(x=>x+root),wt=moonWaxing(),SC=wt?[0,2,4,6,8,10]:[0,2,4,7,9];
    if(m('saturn')&&pos===0&&L.pads)CH.slice(1).forEach((x,k)=>samp('string_ensemble_1',t,ET(x,3),bd*1.05,drop?.16:.11,'saturn',{att:.5,rel:.6,flash:k===0}));
    if(m('jupiter')&&pos===0&&bar%2===0)SP('acoustic_grand_piano',t,ET(root,1),bd*2,.38,'jupiter',{rel:.8});
    // the harp washes up through the chord, Jupiter's moons in their 1:2:4 resonance
    if(L.arp&&m('jupiter-moons')){if(s%2===0&&(pos<8||drop)){const k=(s>>1)%8;samp('orchestral_harp',t,ET(CH[k%5]+12*Math.floor(k/5),4),stepT*4,.22,'jupiter-moons',{rel:.3})}}
    // the flute: a sinuous line inside a tritone, in quavers and dotted rhythms
    const line=skyLine('deb'+signOf('venus')+(wt?'w':'p'),2,4,signOf('venus')*13+(wt?1:2),{rh:[[1,0,0,1],[0,0,1,0],[1,1,0,0],[1,0,0,0]],start:3,lo:0,hi:8});
    const i=(bar%2)*16+pos,v=line[i];
    if(v!==null&&L.lead>.2&&m('venus')){const deg=SC[((v%SC.length)+SC.length)%SC.length]+12*Math.floor(v/SC.length);const f=ET(deg+root*0,5);SP('flute',t,f,stepT*lenAt(line,i)*.95,.42,'venus',{att:.05,rel:.2});
      if(m('earth')&&(sec==='groove'||drop))samp('oboe',t+bd,f/2,stepT*lenAt(line,i)*.9,.26,'earth',{att:.05,rel:.15})}
    if(m('mercury')&&(pos===6||pos===14)&&((bar*7+pos)%3===0))samp('celesta',t,ET(CH[(bar+pos)%5],6),stepT*4,.24,'mercury',{rel:.3});
    if(drop&&m('sun')&&pos===0)samp('celesta',t,ET(CH[4]+12,6),bd,.18,'sun',{rel:.6});
    if(sec==='build'&&m('mars')&&pos%2===0)samp('timpani',t,ET(root,2),stepT*2,.12+.35*(into+pos/16)/D.secLen,'mars',{rel:.1});
  },
  // Pärt: tintinnabuli. The melodic voice grows towards a centre note, mirrored below; the piano rings the home triad
  part(s,pos,bar,t,st,L,stepT,m){
    const sec=D.section,drop=sec==='drop',C=7,TRI=[0,2,4];
    // phrases of growing length: 1, 2, 3 … notes, approaching the centre alternately from above and below
    const halfs=Math.floor(s/(SPB()/2)),onset=pos%8===0;D.part=D.part||{h:-1,ph:1,i:0,above:moonWaxing(),note:C};
    if(onset&&halfs!==D.part.h){D.part.h=halfs;const P=D.part;
      if(P.i>=P.ph+1){P.i=0;P.ph=P.ph>=7?1:P.ph+1;P.above=!P.above}
      const k=P.i;P.note=k<P.ph?(P.above?C+(P.ph-1-k):C-(P.ph-1-k)):null;P.i++;
      if(P.note!==null){const mn=P.note,f=noteF(mn,4);
        if(m('venus'))SP('violin',t,f,stepT*7.6,.55,'venus',{att:.08,rel:.25});
        // the T-voice: the nearest note of the home triad above the melody
        let tv=mn+1;while(!TRI.includes(((tv%7)+7)%7))tv++;if(m('saturn'))SP('acoustic_grand_piano',t,noteF(tv,4),stepT*8,.42,'saturn',{rel:.5});
        // the mirror: the same steps inverted, two octaves down
        if(m('jupiter')&&sec!=='intro')samp('cello',t,noteF(C-(mn-C),2),stepT*7.6,.24,'jupiter',{att:.1,rel:.3});}
    }
    if(m('saturn')&&pos%2===1&&sec!=='intro'){const k=(s>>1)%6,tv=TRI[k%3]+7*Math.floor(k/3);SP('acoustic_grand_piano',t,noteF(tv,5),stepT*3,.12,'saturn',{rel:.3,flash:false})}
    if(m('sun')&&pos===0&&bar%4===0)samp('tubular_bells',t,noteF(0,4),barDur()*3,.32,'sun',{rel:1});
    if(drop&&m('earth')&&pos===0)sChord('choir_aahs',t,[0,2,4],4,barDur()*1.02,.18,'earth',{att:.4,rel:.6});
  },
  // Reich: phasing. Marimbas play one pattern; the angle between Venus (and Mars) and the Earth sets how far apart they are
  reich(s,pos,bar,t,st,L,stepT,m,into){
    const sec=D.section,drop=sec==='drop',deg=D.prog[Math.floor(bar/4)%4];
    if(!D.rpat||D.rkey!==signOf('earth')){D.rkey=signOf('earth');const r=rng(D.rkey*7+31),SET=[0,1,4,5,7];D.rpat=[];let last=-1;for(let k=0;k<12;k++){let v;do{v=SET[Math.floor(r()*5)]}while(v===last);D.rpat.push(v);last=v}}
    const PT=D.rpat,ang=w=>{const a=((Math.atan2(P_(w).y,P_(w).x)-Math.atan2(P_('earth').y,P_('earth').x))/DEG+720)%360;return Math.floor(a/30)%12};
    const offV=ang('venus'),offM=ang('mars');D.rphase=[offV,offM];
    {const i=s%12;
      if(m('earth')&&L.pads!==0)samp('marimba',t,noteF(PT[i],4),stepT*2,.36,'earth',{rel:.08});
      if(m('venus')&&sec!=='intro')samp('marimba',t,noteF(PT[(i+offV)%12],5),stepT*2,.3,'venus',{rel:.08});
      if(m('mars')&&(drop||sec==='build'))samp('marimba',t,noteF(PT[(i+offM)%12],4)*1.0,stepT*2,.24,'mars',{rel:.08});}
    // pulsing voices: each chord breathes in quavers, swelling and fading through the bar
    if(m('saturn')&&pos%2===0&&sec!=='intro'){const sw=Math.sin(Math.PI*(pos+1)/16);sChord('choir_aahs',t,tri(deg),4,stepT*1.7,.07+.12*sw*(drop?1.4:1),'saturn',{att:.02,rel:.05})}
    if(m('jupiter')&&pos===0&&bar%2===0)samp('contrabass',t,noteF(deg,2),barDur()*1.9,.4,'jupiter',{att:.5,rel:.4});
    // clapping: one pattern, a second clapper phased by the Moon's angle from the Sun
    const CL=[1,1,1,0,1,1,0,1,0,1,1,0];const mo=byId.earth.moons[0],el=((TAU*((S.jd-J2000)/mo.P+mo.ph0)-Math.atan2(-P.earth.y,-P.earth.x))/TAU%1+1)%1,moonOff=Math.floor(el*12)%12;
    if(m('mercury')&&(drop||sec==='groove')){if(CL[s%12])clap(t,.35);if(drop&&CL[(s+moonOff)%12])clap(t+.004,.25)}
    if(drop&&m('jupiter-moons')){const tn=tri(deg);if(s%4===0)samp('vibraphone',t,noteF(tn[(s>>2)%3],5),stepT*4,.22,'jupiter-moons',{rel:.2})}
  },
  // Glass: organ arpeggios in threes over a left hand in twos, the figure growing by a note each bar
  glass(s,pos,bar,t,st,L,stepT,m){
    const sec=D.section,drop=sec==='drop',deg=D.prog[Math.floor(bar/2)%4],spb=SPB(),bd=barDur();
    const len=3+(bar%4),UP=[0,2,4,7,9,11,14],fig=[];for(let k=0;k<len;k++)fig.push(UP[k]);for(let k=len-2;k>0;k--)fig.push(UP[k]);
    if(m('saturn')&&pos%2===0&&L.pads){const k=(pos/2)%fig.length;samp('drawbar_organ',t,noteF(deg+fig[k],4),stepT*1.9,.22,'saturn',{att:.005,rel:.03})||piano(t,noteF(deg+fig[k],4),stepT*2,.06,'saturn')}
    if(m('jupiter')&&pos%3===0&&L.bass){const k=(pos/3)%2;samp('drawbar_organ',t,noteF(deg+(k?4:0),3),stepT*2.8,.2,'jupiter',{att:.005,rel:.03})||piano(t,noteF(deg+(k?4:0),3),stepT*3,.06,'jupiter')}
    if(m('neptune')&&pos===0)samp('church_organ',t,noteF(deg,1),bd*1.02,.22,'neptune',{att:.05,rel:.15});
    if(m('earth')&&pos===0&&(sec==='groove'||drop))sChord('choir_aahs',t,tri(deg),4,bd*1.02,.14,'earth',{att:.2,rel:.3});
    if(drop&&m('mercury')&&pos%2===0){const k=(pos/2)%fig.length;samp('flute',t,noteF(deg+fig[k],5),stepT*1.9,.16,'mercury',{rel:.03})}
    if(drop&&m('venus')&&pos===0&&bar%2===0){const v=[4,2,0,1][Math.floor(bar/2)%4];samp('choir_aahs',t,noteF(deg+v,5),bd*1.95,.3,'venus',{att:.15,rel:.3})}
  }
};
const P_=w=>P[w];
