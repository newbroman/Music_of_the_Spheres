import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});const p=await b.newPage();
await p.goto('http://localhost:8123/dance.html');
console.log(await p.evaluate(()=>{const c=new AudioContext();const m=c.destination.maxChannelCount;let ok='';try{c.destination.channelCount=6;ok='set6 ok'}catch(e){ok=String(e)}return [m,ok]}));
await b.close();
