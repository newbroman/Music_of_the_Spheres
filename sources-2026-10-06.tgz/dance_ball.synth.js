
/* ================= BALLROOM & LATIN: acoustic-style instruments, the same sky ================= */
const CADENCE='cadence';
const BALL_INST={
  waltz:{sun:'Bass drum on the one',mercury:'Shaker',earth:'Brushes',mars:'Timpani',jupiter:'Double bass','jupiter-moons':'Harp, 1 : 2 : 4',saturn:'Piano and strings',venus:'Violin voice',uranus:'Swells',neptune:'Cellos'},
  tango:{sun:'Marcato beat',mercury:'Brushed hats',earth:'Brushes',mars:'Piano left hand',jupiter:'Double bass, 3-3-2','jupiter-moons':'Piano arpeggio, 1 : 2 : 4',saturn:'Bandoneon and strings',venus:'Violin voice',uranus:'Swells',neptune:'Cellos'},
  samba:{sun:'Surdo',mercury:'Ganzá shaker',earth:'Tamborim',mars:'Agogô bells',jupiter:'Bass','jupiter-moons':'Guitar, 1 : 2 : 4',saturn:'Cavaquinho',venus:'Vocal chops',uranus:'Risers',neptune:'Sub'},
  chacha:{sun:'Kick',mercury:'Güiro',earth:'Claves, son clave',mars:'Congas',jupiter:'Tumbao bass','jupiter-moons':'Piano arpeggio, 1 : 2 : 4',saturn:'Piano montuno',venus:'Vocal chops',uranus:'Risers',neptune:'Sub'},
  swing:{sun:'Feathered bass drum',mercury:'Ride cymbal',earth:'Brushes',mars:'Tom fills',jupiter:'Walking bass','jupiter-moons':'Vibes, 1 : 2 : 4',saturn:'Piano comping',venus:'Horn voice',uranus:'Risers',neptune:'Sub'},
  jive:{sun:'Bass drum',mercury:'Ride cymbal',earth:'Snare backbeat',mars:'Tom fills',jupiter:'Walking bass','jupiter-moons':'Vibes, 1 : 2 : 4',saturn:'Piano offbeats',venus:'Horn voice',uranus:'Risers',neptune:'Sub'},
  fandango:{sun:'Cajón bass',mercury:'Castanets',earth:'Palmas (hand claps)',mars:'Cajón slaps',jupiter:'Guitar thumb','jupiter-moons':'Guitar picado, 1 : 2 : 4',saturn:'Rasgueado guitar',venus:'Cante (voice)',uranus:'Risers',neptune:'Sub'}
};
Object.assign(STYLES,{
  waltz:{gain:1.9,name:'Waltz',fam:'ball',beats:3,bpm:174,mode:'C',swing:0,kickF:[95,48,.45],kickLvl:.55,duck:.85,arp:.55,arpV:'harp',lead:.9,leadLen:1.6,pads:'strings',buildBars:8},
  tango:{gain:2.0,name:'Tango',fam:'ball',beats:4,bpm:118,mode:'A',swing:0,kickF:[110,50,.4],kickLvl:.5,duck:.85,arp:.45,arpV:'piano',lead:.9,leadLen:1.3,pads:'strings',buildBars:4},
  samba:{gain:1.65,name:'Samba',fam:'ball',beats:4,bpm:104,mode:'G',swing:.08,kickF:[95,55,.3],kickLvl:.6,duck:.85,arp:.5,arpV:'guitar',lead:.8,pads:'none',buildBars:4},
  chacha:{gain:2.0,name:'Cha-cha',fam:'ball',beats:4,bpm:120,mode:'D',swing:0,kickF:[120,52,.35],kickLvl:.55,duck:.8,arp:.45,arpV:'piano',lead:.8,pads:'none',buildBars:4},
  swing:{gain:1.6,name:'Swing',fam:'ball',beats:4,bpm:140,mode:'G',swing:0,swing8:.667,kickF:[90,50,.35],kickLvl:.35,duck:.95,arp:.45,arpV:'vibes',lead:.85,leadLen:1.2,pads:'none',buildBars:4},
  jive:{gain:1.3,name:'Jive',fam:'ball',beats:4,bpm:172,mode:'G',swing:0,swing8:.667,kickF:[100,50,.35],kickLvl:.5,duck:.9,arp:.45,arpV:'vibes',lead:.85,pads:'none',buildBars:8},
  fandango:{gain:2.0,name:'Fandango',fam:'ball',beats:3,bpm:168,mode:'E',swing:0,kickF:[100,50,.3],kickLvl:.6,duck:.85,arp:.5,arpV:'guitar',lead:.9,leadLen:1.8,pads:'none',buildBars:8,cadence:true}
});
Object.keys(BALL_INST).forEach(k=>STYLES[k].inst=BALL_INST[k]);

/* ---- instruments ---- */
const toPan=id=>PAN[id]||drumBus;
// a hammered string: a triangle body with a little sawtooth brightness, the felt closing quickly
function piano(t,f,len,lvl,id){
  const g=mkG(0,toPan(id)),lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.setValueAtTime(Math.min(8000,f*9),t);lp.frequency.setTargetAtTime(Math.max(600,f*2.5),t,.15);
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(lvl,t+.004);g.gain.setTargetAtTime(lvl*.35,t+.004,.09);g.gain.setTargetAtTime(0,t+len,.08);
  const o1=AC.createOscillator(),o2=AC.createOscillator();o1.type='triangle';o2.type='sawtooth';o1.frequency.value=f;o2.frequency.value=f*1.0015;
  o1.connect(lp);o2.connect(mkG(.16,lp));lp.connect(g);g.connect(mkG(.3,revSend));
  const end=t+len+.6;o1.start(t);o2.start(t);o1.stop(end);o2.stop(end);
}
function pchord(t,degs,oct,len,lvl,id){degs.forEach((d,k)=>piano(t+k*.004,noteF(d,oct),len,lvl,id));flash(id,t)}
// a plucked nylon string
function nylon(t,f,lvl,dec,id){
  const o=AC.createOscillator();o.type='sawtooth';o.frequency.value=f;const lp=AC.createBiquadFilter();lp.type='lowpass';lp.Q.value=1;
  lp.frequency.setValueAtTime(Math.min(7000,f*7),t);lp.frequency.setTargetAtTime(f*1.3,t,dec*.25);
  const g=mkG(0,toPan(id));env(g,t,lvl,.002,dec);o.connect(lp);lp.connect(g);g.connect(mkG(.25,revSend));o.start(t);o.stop(t+dec*5+.05);
}
function strum(t,degs,oct,lvl,gap,up,id,dec=.35){const d=up?[...degs].reverse():degs;d.forEach((x,k)=>nylon(t+k*gap,noteF(x,oct),lvl*(up?.8:1),dec,id));flash(id,t)}
// the bandoneon: two reeds a few cents apart and a lower reed, through a soft bellows filter
function reed(t,degs,len,lvl,swell){
  degs.forEach(d=>{const f=noteF(d,4),g=mkG(0,PAN.saturn);g.connect(mkG(.3,revSend));
    const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=2300;lp.Q.value=.7;lp.connect(g);
    [-7,7].forEach(c=>{const o=AC.createOscillator();o.type='sawtooth';o.frequency.value=f;o.detune.value=c;o.connect(lp);o.start(t);o.stop(t+len+.15)});
    if(!LOWPOWER){const sq=AC.createOscillator();sq.type='square';sq.frequency.value=f/2;sq.connect(mkG(.3,lp));sq.start(t);sq.stop(t+len+.15)}
    const a=swell?len*.9:.012;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(lvl,t+a);g.gain.setValueAtTime(lvl,t+Math.max(a,len*.85));g.gain.linearRampToValueAtTime(0,t+len+.03)});
  flash('saturn',t);
}
// a plucked double bass
function abass(t,f,len,lvl=.5){
  const o=AC.createOscillator(),o2=AC.createOscillator();o.type='sine';o2.type='triangle';o.frequency.setValueAtTime(f*1.03,t);o.frequency.setTargetAtTime(f,t,.015);o2.frequency.value=f;
  const g=mkG(0,PAN.jupiter);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(lvl,t+.006);g.gain.setTargetAtTime(lvl*.45,t+.006,.12);g.gain.setTargetAtTime(0,t+len,.05);
  o.connect(g);o2.connect(mkG(.35,g));const end=t+len+.4;o.start(t);o2.start(t);o.stop(end);o2.stop(end);flash('jupiter',t);
}
// percussion
function noiseHit(t,dur,type,f,q,lvl,att,dec,id,rev=.15){const n=noise(t,dur),fl=AC.createBiquadFilter();fl.type=type;fl.frequency.value=f;fl.Q.value=q;const g=mkG(0,toPan(id));env(g,t,lvl,att,dec);n.connect(fl);fl.connect(g);if(rev)g.connect(mkG(rev,revSend))}
function toneHit(t,f0,f1,type,lvl,dec,id,glide=.05){const o=AC.createOscillator();o.type=type;o.frequency.setValueAtTime(f0,t);if(f1!==f0)o.frequency.exponentialRampToValueAtTime(f1,t+glide);const g=mkG(0,toPan(id));env(g,t,lvl,.001,dec);o.connect(g);o.start(t);o.stop(t+dec*6+.05)}
function shaker(t,v){noiseHit(t,.12,'highpass',5200,.7,.13*v,.006,.022,'mercury',.05);flash('mercury',t)}
function castanet(t,v){[0,.013].forEach(d=>noiseHit(t+d,.03,'bandpass',3200,5,.32*v,.0005,.005,'mercury',.1));flash('mercury',t)}
function claves(t,v){toneHit(t,2500,2500,'sine',.2*v,.03,'earth');flash('earth',t)}
function tamborim(t,v){toneHit(t,900,820,'sine',.2*v,.04,'earth');noiseHit(t,.03,'bandpass',4000,2,.14*v,.0005,.006,'earth',0);flash('earth',t)}
function brush(t,v,long){noiseHit(t,long?.3:.15,'bandpass',3600,.6,.16*v,long?.03:.008,long?.09:.035,'earth',.2);flash('earth',t)}
function agogo(t,hi,v){const f=hi?905:678;[[1,.15,.09],[2.74,.05,.03]].forEach(([r,a,d])=>{const o=AC.createOscillator();o.type='sine';o.frequency.value=f*r;const g=mkG(0,PAN.mars);env(g,t,a*v,.001,d);o.connect(g);o.start(t);o.stop(t+.6)});flash('mars',t)}
function conga(t,kind,v){
  if(kind==='slap'){noiseHit(t,.06,'bandpass',1900,1.4,.32*v,.0008,.018,'mars',.1);toneHit(t,420,380,'sine',.14*v,.03,'mars')}
  else toneHit(t,kind==='open'?330:250,kind==='open'?300:230,'sine',(kind==='mute'?.12:.32)*v,kind==='mute'?.03:.13,'mars');
  flash('mars',t);
}
function surdo(t,open,v){toneHit(t,95,58,'sine',(open?.75:.38)*v,open?.28:.07,'sun',.08);noiseHit(t,.03,'lowpass',600,.7,.14*v,.001,.01,'sun',0);flash('sun',t);if(open)duckIt(t)}
function cajon(t,low,v){
  if(low){toneHit(t,120,70,'sine',.7*v,.12,'sun',.04);noiseHit(t,.08,'lowpass',500,.7,.25*v,.001,.03,'sun',.05);flash('sun',t);duckIt(t)}
  else{noiseHit(t,.1,'bandpass',2300,1,.4*v,.0008,.03,'mars',.15);toneHit(t,240,200,'triangle',.12*v,.03,'mars');flash('mars',t)}
}
function ride(t,v){
  noiseHit(t,.5,'highpass',7000,.7,.07*v,.001,.12,'mercury',.15);
  if(!LOWPOWER)[523,797].forEach(f=>{const o=AC.createOscillator();o.type='square';o.frequency.value=f*2.3;const hp=AC.createBiquadFilter();hp.type='highpass';hp.frequency.value=4000;const g=mkG(0,PAN.mercury);env(g,t,.018*v,.001,.15);o.connect(hp);hp.connect(g);o.start(t);o.stop(t+.9)});
  flash('mercury',t);
}
function chick(t,v){noiseHit(t,.05,'highpass',8000,.7,.09*v,.001,.01,'mercury',0)}
function timp(t,f,v){toneHit(t,f*1.03,f,'sine',.42*v,.45,'mars',.06);toneHit(t,f*2.01,f*2,'sine',.09*v,.2,'mars',.06);flash('mars',t)}
function guiro(t,long,v){
  const n=noise(t,long?.2:.08),bp=AC.createBiquadFilter();bp.type='bandpass';bp.Q.value=3;bp.frequency.setValueAtTime(2600,t);bp.frequency.linearRampToValueAtTime(3600,t+(long?.16:.06));
  const am=AC.createGain();am.gain.value=.5;const lfo=AC.createOscillator();lfo.type='square';lfo.frequency.value=46;lfo.connect(mkG(.5,am.gain));
  const g=mkG(0,PAN.mercury);env(g,t,.2*v,.005,long?.07:.025);n.connect(bp);bp.connect(am);am.connect(g);lfo.start(t);lfo.stop(t+(long?.25:.12));flash('mercury',t);
}
// the moons' arpeggio in each style's own instrument
function moonNote(t,f,lvl,dec,id,v){
  if(v==='guitar'){nylon(t,f,lvl*1.6,dec,'jupiter');flash(id,t)}
  else if(v==='piano'){piano(t,f,dec,lvl*1.3,'jupiter');flash(id,t)}
  else pluck(t,f,lvl,v==='vibes'?'sine':'triangle',dec,id);
}

/* ---- the patterns: the same planets, a different dance ---- */
function ballStep(s,pos,bar,t,st,L,deg,stepT,m,into,spb){
  const nxt=D.prog[(bar+1)%4], sec=D.section, sw=!!st.swing8;
  switch(D.style){
  case 'waltz':
    // oom-pah-pah: Apollo and Zeus on the one, Kronos on two and three
    if(L.kick&&m('sun')&&pos===0)kick(t);
    if(L.bass&&m('jupiter')&&pos===0)abass(t,noteF(bar%2?deg-3:deg,2),stepT*3.8);
    if(L.pads&&m('saturn')&&(pos===4||pos===8))pchord(t,chordTones(deg),4,stepT*2.2,pos===4?.085:.07,'saturn');
    if(L.hats&&m('mercury')&&(pos===4||pos===8||(pos===10&&sec==='drop')))shaker(t,L.hats*(pos===10?.5:.8));
    if(L.clap&&m('earth')&&(pos===4||pos===8))brush(t,.7*L.clap,false);
    if(L.toms&&m('mars')&&pos===0&&bar%4===0)timp(t,noteF(deg,2),.9);
    break;
  case 'tango':{
    // marcato in four, the bass on the 3-3-2 of the habanera, and the bandoneon dragging into the next bar
    if(L.kick&&m('sun')&&(pos===0||pos===8))kick(t);
    if(L.bass&&m('jupiter')){const h={0:[0,5],6:[0,5],12:[4,3],14:sec==='drop'?[nxt-deg-1,2]:null}[pos];if(h)abass(t,noteF(deg+h[0],2),stepT*h[1]*.9)}
    const drag=bar%2===1&&sec!=='intro';
    if(L.pads&&m('saturn')){if(pos%4===0&&!(drag&&pos===12))reed(t,chordTones(deg),stepT*(pos%8===0?1.6:1.1),pos%8===0?.065:.045,false);
      if(drag&&pos===12)reed(t,chordTones(nxt),stepT*3.6,.065,true)}
    if(L.clap&&m('earth')&&(pos===4||pos===12))brush(t,.6*L.clap,false);
    if(L.hats&&m('mercury')&&pos%2===0)chick(t,(pos%4===0?.6:.35)*L.hats);
    if(L.toms&&m('mars')){const tp=D.tomPat[pos];if(tp!==null&&bar%2){piano(t,noteF(deg+tp,2),stepT*1.5,.16,'mars');flash('mars',t)}}
    break;}
  case 'samba':
    // the surdo answers itself on two and four; ganzá, tamborim and agogô ride on top
    if(L.kick&&m('sun')&&pos%4===0)surdo(t,pos===4||pos===12,1);
    if(L.hats&&m('mercury'))shaker(t,[.55,.25,.35,.85][pos%4]*L.hats);
    if(L.clap&&m('earth')&&[0,3,6,10,12].includes(pos))tamborim(t,L.clap*(pos===0?1:.75));
    if(L.toms&&m('mars')){if([0,3,6,10].includes(pos))agogo(t,true,.8);else if([8,12,14].includes(pos))agogo(t,false,.8)}
    if(L.bass&&m('jupiter')){const h={0:[0,.8],3:[0,.6],4:[4,1.8],8:[0,.8],11:[0,.6],12:[-3,1.8]}[pos];if(h)abass(t,noteF(deg+h[0],2),stepT*h[1]*2)}
    if(L.pads&&m('saturn')&&[0,3,6,10,13].includes(pos))strum(t,chordTones(deg).concat([deg+7]),4,.055,.008,pos%2===1,'saturn',.18);
    break;
  case 'chacha':
    // one, two, three, cha-cha: the güiro and congas mark the cha-cha on four-and
    if(L.kick&&m('sun')&&(pos===0||pos===8))kick(t);
    if(L.bass&&m('jupiter')){if(pos===6)abass(t,noteF(deg,2),stepT*5.5);if(pos===12)abass(t,noteF(nxt,2),stepT*4)}
    if(L.pads&&m('saturn')&&[0,3,6,8,11,14].includes(pos))pchord(t,chordTones(deg),4,stepT*1.3,.07,'saturn');
    if(L.hats&&m('mercury')){if(pos===0||pos===4||pos===8)guiro(t,true,L.hats);else if(pos===12||pos===14)guiro(t,false,L.hats)}
    if(L.clap&&m('earth')&&(bar%2===0?[4,8]:[0,6,12]).includes(pos))claves(t,L.clap);
    if(L.toms&&m('mars')){if(pos===4)conga(t,'slap',1);else if(pos===12||pos===14)conga(t,'open',1);else if(pos===0||pos===8)conga(t,'mute',1)}
    break;
  case 'swing':case 'jive':{
    // swung eighths only: the off-beat eighth is pushed to the last third of the beat
    if(pos%2)break;
    const jive=D.style==='jive';
    if(L.kick&&m('sun')&&pos%4===0)kick(t);
    if(L.hats&&m('mercury')){if([0,4,6,8,12,14].includes(pos))ride(t,L.hats*(pos===6||pos===14?.6:1));if(pos===4||pos===12)chick(t,.8)}
    if(L.clap&&m('earth')&&(pos===4||pos===12)){if(jive)snare(t,.85*L.clap);else brush(t,.9*L.clap,true)}
    if(L.bass&&m('jupiter')&&pos%4===0){const wl=[deg,deg+2,deg+4,nxt+((bar+signOf('jupiter'))%2?1:-1)];abass(t,noteF(wl[pos/4],2),stepT*3.6,.48)}
    if(L.pads&&m('saturn')&&(jive?[4,12,14]:[0,6]).includes(pos))pchord(t,chordTones(deg),4,stepT*(jive?1.4:2.5),.07,'saturn');
    if(L.toms&&m('mars')&&bar%4===3&&pos>=8&&sec!=='intro')tom(t,noteF(deg+(14-pos)/2,3),.8);
    break;}
  case 'fandango':{
    // three-time with the Andalusian cadence: cajón, castanets, palmas and a rasgueado guitar
    if(L.kick&&m('sun')&&(pos===0||(pos===8&&sec==='drop')))cajon(t,true,1);
    if(L.toms&&m('mars')&&(pos===4||pos===8||(pos===10&&bar%2)))cajon(t,false,pos===10?.6:1);
    if(L.clap&&m('earth')&&(sec==='groove'||sec==='drop')){if(pos%4===0)clap(t,pos===0?.9:.65);else if(pos%4===2&&sec==='drop')clap(t,.3)}
    if(L.hats&&m('mercury')){if(pos%2===0)castanet(t,L.hats*(pos%4===0?1:.6));if(pos===10){castanet(t+stepT*.66,.5*L.hats);castanet(t+stepT*1.33,.6*L.hats)}}
    if(L.bass&&m('jupiter')&&(pos===0||pos===8)){nylon(t,noteF(pos===0?deg:deg-3,2),.32,.5,'jupiter');flash('jupiter',t)}
    if(L.pads&&m('saturn')){const V=[deg-7,deg-3,deg,deg+2,deg+4,deg+7];
      if(pos===0){strum(t,V,3,.06,.018,false,'saturn',.5);if(sec==='drop'&&!LOWPOWER){strum(t+.04,V.slice(2),3,.04,.01,false,'saturn',.2);strum(t+.08,V.slice(2),3,.04,.01,false,'saturn',.25)}}
      else if(pos===4||pos===6)strum(t,V.slice(2),3,.05,.01,pos===6,'saturn',.25);
      else if(pos===8)strum(t,V,3,.055,.014,false,'saturn',.4)}
    break;}
  }
  // the build: a timpani roll from Ares that quickens toward the drop
  if(sec==='build'&&m('mars')&&!(sw&&pos%2)){const prog=(into+pos/spb)/D.secLen,every=prog<.5?4:prog<.75?2:1;if(pos%every===0)timp(t,noteF(0,2),.2+.55*prog)}
  // Jupiter's moons, still in their 1:2:4 resonance, counted across the bar lines
  if(L.arp&&m('jupiter-moons')&&!(sw&&pos%2)){const lv=L.arp*st.arp,tones=chordTones(deg).concat([deg+7]),up=moonWaxing(),k=s>>1;
    if(s%2===0)moonNote(t,noteF(tones[up?k%4:3-k%4],5),.06*lv,stepT*3,'io',st.arpV);
    if(s%4===0)moonNote(t,noteF(tones[((s>>2)+1)%3],4),.07*lv,stepT*5,'europa',st.arpV);
    if(s%8===0)pluck(t,noteF(tones[(s>>3)%3],6),.045*lv,'sine',stepT*7,'ganymede');}
  // Aphrodite's line: a violin-like voice in the ballroom, the cante in the fandango
  if(L.lead*st.lead>.2&&m('venus')&&!(sw&&pos%2)){const mm=D.motif[(bar%2)*16+pos];if(mm&&(L.lead>=.9||pos%8===0))chop(t,noteF(deg+mm.deg,5),barDur()*mm.len*(st.leadLen||1),mm.vow)}
}
