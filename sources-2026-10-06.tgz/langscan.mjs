import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const EN=/\b(the|and|of|with|from|this|that|your|you|is|are|tap|hear|listen|moons?|sound|voice|singing|days|years|hours|stopped|play|pause|back|speed|volume)\b/i;
for(const l of process.argv[2].split(',')){
 const acts=[['index.html?notour',[p=>p.click('#begin')]],['index.html?notour#plato',[p=>p.click('#begin')]],['index.html?notour#today',[p=>p.click('#begin')]],['dance.html',[p=>p.click('#play'),p=>p.waitForTimeout(2500)]],['flight.html',[p=>p.click('#begin'),p=>p.waitForTimeout(1500)]],['index.html',[]]];
 const found=new Set();
 for(const [u,a] of acts){const p=await b.newPage({viewport:{width:1300,height:1000}});await p.goto(`http://localhost:8123/${l}/${u}`);await p.waitForTimeout(800);for(const f of a){await f(p);await p.waitForTimeout(600)}
  if(u.includes('#today')){await p.click('#stageBtn');await p.waitForTimeout(200)}
  const t=await p.evaluate(()=>document.body.innerText);t.split('\n').map(x=>x.trim()).filter(x=>x&&EN.test(x)).forEach(x=>found.add(x.slice(0,110)));
  if(u==='index.html'){await p.screenshot({path:`/tmp/claude-0/ls_${l}_tour.png`})}
  if(u.includes('#plato')){await p.screenshot({path:`/tmp/claude-0/ls_${l}_plato.png`})}
  if(u==='dance.html'){await p.screenshot({path:`/tmp/claude-0/ls_${l}_dance.png`})}
  await p.close()}
 console.log('==',l,found.size);[...found].slice(0,25).forEach(x=>console.log('   ',x));
}
await b.close();
