import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch();const errs=[];
for(const [u,sup] of [['index.html?notour',0],['de/index.html?notour&playapp=1',0],['de/dance.html?notour&playapp=1',0],['ja/flight.html?notour&playapp=1',0],['index.html?notour&playapp=1',1]]){
  const p=await b.newPage({viewport:{width:1280,height:800}});p.on('pageerror',e=>errs.push(u+': '+e.message));
  if(sup)await p.addInitScript(()=>localStorage.setItem('mots.supporter','1'));
  await p.goto('http://localhost:8123/'+u);await p.waitForTimeout(1200);
  await p.click('#stageBtn');await p.waitForTimeout(400);
  const t=await p.evaluate(()=>{const s=document.getElementById('stPanel');return s?s.querySelector('h2').textContent+' | '+[...s.querySelectorAll('#stTiers button')].map(b=>b.textContent).join(' / '):'none'});
  console.log(u,sup?'(supporter)':'','→',t);
  if(u.startsWith('de/index'))await p.screenshot({path:'/tmp/claude-0/-home-claude-music-of-the-spheres/808fb75a-4c88-5877-9823-ab514d31a639/scratchpad/sup_de.png'});
  await p.close()}
console.log('errors',errs);await b.close();
