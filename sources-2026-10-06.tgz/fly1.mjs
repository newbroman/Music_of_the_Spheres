import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
const page = await browser.newPage({viewport:{width:1200,height:760}});
const errs=[];page.on('pageerror',e=>errs.push(String(e)));page.on('console',m=>{if(m.type()==='error'||m.type()==='warning')errs.push(m.type()+': '+m.text())});
await page.addInitScript(()=>{
  const Orig=window.AudioContext;
  window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();this.__an.fftSize=4096;}};
  const oc=AudioNode.prototype.connect;
  AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return res};
});
await page.goto('file:///home/claude/flight.html');await page.waitForTimeout(3000);
await page.screenshot({path:'f_start.png'});
console.log('readout:',await page.textContent('#nearTxt'),'|',await page.textContent('#speedTxt'));
async function rms(secs){return page.evaluate(async(secs)=>{const an=window.__ac.__an,b=new Float32Array(an.fftSize),o=[];for(let k=0;k<secs*4;k++){await new Promise(r=>setTimeout(r,250));an.getFloatTimeDomainData(b);let s=0;for(const x of b)s+=x*x;o.push(Math.sqrt(s/b.length))}return {min:Math.min(...o).toFixed(4),mean:(o.reduce((a,c)=>a+c)/o.length).toFixed(4)}},secs)}
await page.click('#begin');await page.waitForTimeout(1500);
console.log('near Earth audio',JSON.stringify(await rms(4)));
await page.click('#navBtn');await page.click('#dest button[data-id="saturn"]');
for(let k=0;k<8;k++){await page.waitForTimeout(2000);console.log(' t',2*(k+1),'s:',await page.textContent('#nearTxt'),'|',await page.textContent('#speedTxt'))}
await page.screenshot({path:'f_saturn.png'});
console.log('chips:',await page.textContent('#moonChips'));
console.log('at Saturn audio',JSON.stringify(await rms(5)));
console.log('errors',errs.slice(0,10));
await browser.close();
