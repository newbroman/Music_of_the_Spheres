import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--use-angle=swiftshader','--enable-unsafe-swiftshader']});
for(const [u,f] of [['http://localhost:8123/pl/flight.html','ph_fly_pl.png'],['http://localhost:8123/index.html','ph_2d.png']]){const p=await b.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});await p.goto(u);await p.waitForTimeout(2500);await p.screenshot({path:f});await p.close()}
await b.close();
