import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
for(const url of ['dance.html','index.html?notour']){const p=await b.newPage({viewport:{width:1280,height:720}});await p.goto('http://localhost:8123/'+url);await p.waitForTimeout(800);
 if(url.startsWith('index')){await p.click('#showBtn');await p.waitForTimeout(1500);for(let k=0;k<34;k++){await p.keyboard.press('ArrowRight');await p.waitForTimeout(150)}await p.waitForTimeout(6000)}
 else{await p.click('#play');await p.waitForTimeout(4000)}
 // main-thread lateness: how late 25 ms timers fire, as the dance scheduler uses them
 const w=url.startsWith('index')?await (await p.$('#motsShow iframe')).contentFrame():p.mainFrame();
 const late=await w.evaluate(()=>new Promise(r=>{const L=[];let t0=performance.now();const id=setInterval(()=>{const n=performance.now();L.push(n-t0-25);t0=n},25);setTimeout(()=>{clearInterval(id);L.sort((a,b)=>a-b);r([L[L.length>>1],L[Math.floor(L.length*.95)],L[L.length-1]].map(x=>x.toFixed(1)))},5000)}));
 console.log(url,'timer lateness ms median/p95/max',late.join(' / '));await p.close()}
await b.close();
