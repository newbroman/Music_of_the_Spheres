/* Music of the Spheres: works offline once installed. Pages are fetched fresh when there is a network and from the cache when there is not;
   the recorded instruments, icons, fonts and 3D library are kept in the cache. The version changes whenever any file does. */
const VER='mots-__VER__',CORE=__CORE__,SAMPLES=__SAMPLES__;
// install quickly with just the front page and icons, so the app is ready at once; everything else is fetched afterwards
const SHELL=CORE.filter(u=>u==='./'||u==='index.html'||u==='manifest.webmanifest'||u.startsWith('icons/'));
self.addEventListener('install',e=>{e.waitUntil(caches.open(VER).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()))});
// the rest of the pages and the instruments, one by one, so a single failure never stops the rest (files already kept are reused)
let warming=null;
function warm(){return warming||(warming=(async()=>{const c=await caches.open(VER);
  for(const list of [CORE,SAMPLES])await Promise.allSettled(list.map(async u=>{if(await c.match(u))return;const hit=await caches.match(u);return hit?c.put(u,hit.clone()):c.add(u)}));
  warming=null})())}
self.addEventListener('message',e=>{if(e.data==='warm')e.waitUntil(warm())});
self.addEventListener('activate',e=>{e.waitUntil((async()=>{await self.clients.claim();
  // old versions are cleared only once the new one holds everything, so the app keeps working offline throughout
  warm().then(async()=>{for(const k of await caches.keys())if(k!==VER&&k!=='mots-ext'&&k.startsWith('mots-'))await caches.delete(k)})})())});
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET')return;const u=new URL(r.url);
  if(u.origin===location.origin&&!u.pathname.startsWith(new URL('./',location).pathname))return;
  const page=r.mode==='navigate'||(u.origin===location.origin&&/\.html$|\/$/.test(u.pathname));
  if(page){e.respondWith((async()=>{try{const n=await fetch(r);if(n.ok){const c=await caches.open(VER);c.put(r,n.clone())}return n}
    catch(err){return (await caches.match(r,{ignoreSearch:true}))||(await caches.match(new URL('index.html',(m=>m?new URL(m[1]+'/',location):location)(u.pathname.match(/\/(pl|cy|de|es|fr|it|zh|ja)\//))).href))||Response.error()}})());return}
  if(u.origin===location.origin){e.respondWith(caches.match(r,{ignoreSearch:true}).then(hit=>hit||fetch(r).then(n=>{if(n.ok){const cl=n.clone();caches.open(VER).then(c=>c.put(r,cl))}return n})));return}
  if(/cdnjs\.cloudflare\.com|fonts\.(googleapis|gstatic)\.com/.test(u.hostname)){e.respondWith((async()=>{const c=await caches.open('mots-ext'),hit=await c.match(r);
    const net=fetch(r).then(n=>{if(n.ok||n.type==='opaque')c.put(r,n.clone());return n}).catch(()=>null);return hit||(await net)||Response.error()})())}
});
