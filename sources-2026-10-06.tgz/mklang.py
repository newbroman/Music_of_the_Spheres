import re,json
av=open('/tmp/claude-0/langs.txt').read().split()
s=open('/tmp/claude-0/lang.js').read()
out=re.sub(r"/\*LANGS\*/.*?/\*LANGS-END\*/","/*LANGS*/"+json.dumps(av)+"/*LANGS-END*/",s)
assert json.dumps(av) in out
open('/tmp/claude-0/lang_built.js','w').write(out)
