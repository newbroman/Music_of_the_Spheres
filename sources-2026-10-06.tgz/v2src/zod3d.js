
/* ---- the zodiac in the sky: the twelve constellations along the ecliptic ---- */
// main stars as [right ascension h, declination deg, magnitude], and the lines that join them
const ZODIAC=[
 ['Κριός','Aries',[[2.1195,23.462,2.0],[1.9106,20.808,2.6],[1.8921,19.294,3.9],[2.8330,27.261,3.6]],[[3,0],[0,1],[1,2]]],
 ['Ταῦρος','Taurus',[[4.5987,16.509,.9],[5.4382,28.608,1.7],[5.6274,21.143,3.0],[4.4769,19.180,3.5],[4.3299,15.628,3.7],[4.3822,17.543,3.8],[4.0109,12.490,3.4],[3.7914,24.105,2.9]],[[1,3],[3,5],[5,4],[4,0],[0,2],[4,6]]],
 ['Δίδυμοι','Gemini',[[7.5767,31.888,1.6],[7.7553,28.026,1.1],[6.6285,16.399,1.9],[6.3827,22.514,2.9],[6.7322,25.131,3.0],[7.3354,21.982,3.5],[7.0686,20.570,3.9],[6.2479,22.507,3.3]],[[0,4],[4,3],[3,7],[1,5],[5,6],[6,2],[0,1]]],
 ['Καρκίνος','Cancer',[[8.9748,11.858,4.3],[8.7448,18.154,3.9],[8.7215,21.469,4.7],[8.2753,9.186,3.5],[8.7779,28.760,4.0]],[[4,2],[2,1],[1,0],[1,3]]],
 ['Λέων','Leo',[[10.1395,11.967,1.4],[11.8177,14.572,2.1],[10.3329,19.842,2.0],[11.2351,20.524,2.6],[11.2373,15.430,3.3],[10.1222,16.763,3.5],[10.2782,23.417,3.4],[9.8794,26.007,3.9],[9.7642,23.774,3.0]],[[0,5],[5,2],[2,6],[6,7],[7,8],[2,3],[3,1],[1,4],[4,0],[3,4]]],
 ['Παρθένος','Virgo',[[13.4199,-11.161,1.0],[12.6943,-1.449,2.7],[13.0363,10.959,2.8],[12.9268,3.397,3.4],[13.5783,-.596,3.4],[11.8448,1.765,3.6],[12.3318,-.667,3.9]],[[5,6],[6,1],[1,0],[1,3],[3,2],[3,4],[4,0]]],
 ['Ζυγός','Libra',[[14.8480,-16.042,2.8],[15.2835,-9.383,2.6],[15.0679,-25.282,3.3],[15.5921,-14.789,3.9]],[[2,0],[0,1],[1,3],[3,0]]],
 ['Σκορπίος','Scorpius',[[16.4901,-26.432,1.0],[16.0056,-22.622,2.3],[16.0906,-19.806,2.6],[15.9809,-26.114,2.9],[16.3531,-25.593,2.9],[16.5980,-28.216,2.8],[16.8361,-34.293,2.3],[16.8645,-38.048,3.0],[16.9097,-42.362,3.6],[17.2026,-43.239,3.3],[17.6220,-42.998,1.9],[17.7930,-40.127,3.0],[17.7081,-39.030,2.4],[17.5601,-37.104,1.6]],[[2,1],[1,3],[1,4],[4,0],[0,5],[5,6],[6,7],[7,8],[8,9],[9,10],[10,11],[11,12],[12,13]]],
 ['Τοξότης','Sagittarius',[[18.4029,-34.385,1.8],[18.3499,-29.828,2.7],[18.4662,-25.422,2.8],[18.9211,-26.297,2.0],[19.0435,-29.880,2.6],[19.1157,-27.671,3.3],[18.7609,-26.991,3.2],[18.0968,-30.424,3.0],[18.2938,-36.761,3.1]],[[7,1],[1,0],[0,4],[4,6],[6,1],[1,2],[2,6],[6,3],[3,5],[5,4],[0,8]]],
 ['Αἰγόκερως','Capricornus',[[20.3007,-12.545,3.6],[20.3502,-14.781,3.1],[20.7684,-25.271,4.1],[20.8636,-26.919,4.1],[21.4441,-22.411,3.7],[21.7840,-16.127,2.8],[21.6682,-16.662,3.7],[21.0990,-17.233,4.1]],[[0,1],[1,2],[2,3],[3,4],[4,5],[5,6],[6,7],[7,1]]],
 ['Ὑδροχόος','Aquarius',[[21.5260,-5.571,2.9],[22.0964,-.320,2.9],[22.9108,-15.821,3.3],[22.4807,-.020,3.6],[22.3609,-1.387,3.8],[22.5893,-.117,4.0],[22.8769,-7.580,3.7],[20.7946,-9.496,3.8]],[[7,0],[0,1],[1,4],[4,3],[3,5],[4,6],[6,2]]],
 ['Ἰχθύες','Pisces',[[2.0340,2.764,3.8],[1.5247,15.346,3.6],[1.7565,9.158,4.3],[23.2861,3.282,3.7],[23.4489,1.256,4.9],[23.7002,1.780,4.5],[23.6658,5.626,4.1],[23.4661,6.379,4.3],[23.9886,6.863,4.0],[.8114,7.585,4.4],[1.0491,7.890,4.3]],[[3,4],[4,5],[5,6],[6,7],[7,3],[6,8],[8,9],[9,10],[10,0],[0,2],[2,1]]]
];
const ZR=8000, OBLQ=23.4393*DEG;
// equatorial (RA, Dec) to ecliptic, then into the scene's axes
function skyPos(ra,dec,r){
  const a=ra*15*DEG,d=dec*DEG,xq=Math.cos(d)*Math.cos(a),yq=Math.cos(d)*Math.sin(a),zq=Math.sin(d);
  return toV({x:xq,y:yq*Math.cos(OBLQ)+zq*Math.sin(OBLQ),z:-yq*Math.sin(OBLQ)+zq*Math.cos(OBLQ)}).multiplyScalar(r);
}
const ZOD3=new THREE.Group();scene.add(ZOD3);
{
  const bright=[],faint=[],seg=[];
  ZODIAC.forEach(([gr,la,stars,lines],i)=>{
    const P3=stars.map(([ra,dec])=>skyPos(ra,dec,ZR));
    stars.forEach((s,k)=>(s[2]<2.6?bright:faint).push(P3[k]));
    lines.forEach(([a,b])=>seg.push(P3[a],P3[b]));
    const c=P3.reduce((acc,v)=>acc.add(v),new THREE.Vector3()).multiplyScalar(1/P3.length);
    ZODIAC[i].centre=c;
  });
  const pts=(arr,size,op)=>new THREE.Points(new THREE.BufferGeometry().setFromPoints(arr),new THREE.PointsMaterial({size,sizeAttenuation:false,color:0xf3e6c4,transparent:true,opacity:op,depthWrite:false}));
  ZOD3.add(pts(bright,4.2,1),pts(faint,2.8,.85));
  ZOD3.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(seg),new THREE.LineBasicMaterial({color:0xc9984f,transparent:true,opacity:.42,depthWrite:false})));
  // the ecliptic itself, with a tick at each sign's boundary
  const ring=[];for(let k=0;k<=360;k+=2)ring.push(toV({x:Math.cos(k*DEG),y:Math.sin(k*DEG),z:0}).multiplyScalar(ZR*1.02));
  ZOD3.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(ring),new THREE.LineBasicMaterial({color:0xc9984f,transparent:true,opacity:.18,depthWrite:false})));
  const ticks=[];for(let k=0;k<12;k++){const a=k*30*DEG;ticks.push(toV({x:Math.cos(a),y:Math.sin(a),z:-.035}).multiplyScalar(ZR*1.02),toV({x:Math.cos(a),y:Math.sin(a),z:.035}).multiplyScalar(ZR*1.02))}
  ZOD3.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(ticks),new THREE.LineBasicMaterial({color:0xc9984f,transparent:true,opacity:.35,depthWrite:false})));
}
ZODIAC.forEach(([gr,la],i)=>{const d=lbl('zod:'+i,`${gr} <small>${la}</small>`,'zod');d.onclick=null;d.style.pointerEvents='none'});
// aspect lines between planets, drawn in space
const ASPLINES=[0,1,2,3].map(()=>{const l=new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(),new THREE.Vector3()]),new THREE.LineBasicMaterial({color:0xc9984f,transparent:true,opacity:0,depthWrite:false}));scene.add(l);return l});
function updateAspectLines(){
  ASPLINES.forEach((l,k)=>{const a=S.aspects&&ASPNOW[k];
    if(!a){l.visible=false;return}
    l.visible=true;const pa=l.geometry.attributes.position;const A=OBJ[a.a.id].pos,B=OBJ[a.b.id].pos;
    pa.setXYZ(0,A.x,A.y,A.z);pa.setXYZ(1,B.x,B.y,B.z);pa.needsUpdate=true;l.geometry.computeBoundingSphere();l.material.opacity=.12+.5*a.str;});
}
