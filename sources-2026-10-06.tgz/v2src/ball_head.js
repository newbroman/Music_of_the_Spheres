
/* ================= BALLROOM & LATIN: each dance played by its own band ================= */
// Recorded instruments come from the Fluid R3 General MIDI SoundFont (Frank Wen, CC BY 3.0), loaded per style.
// Until they arrive, or if they cannot be fetched, the synthesised instruments below stand in.
const CADENCE='cadence';
const BALL_INST={
  waltz:{sun:'Bass drum and cymbals',mercury:'Triangle',earth:'Pizzicato strings',mars:'Timpani',jupiter:'Double basses','jupiter-moons':'Harp, 1 : 2 : 4',saturn:'Horns and strings',venus:'Solo violin and flute',uranus:'Cymbal roll and string swell',neptune:'Cellos'},
  tango:{sun:'Golpe on the bass',mercury:'Violin chicharra',earth:'Piano chords',mars:'Piano left hand',jupiter:'Double bass, 3-3-2','jupiter-moons':'Piano arpeggio, 1 : 2 : 4',saturn:'Bandoneons and strings',venus:'Solo violin',uranus:'Bandoneon swell',neptune:'Cellos'},
  samba:{sun:'Surdo',mercury:'Ganzá shaker',earth:'Tamborim',mars:'Agogô bells',jupiter:'Seven-string guitar','jupiter-moons':'Guitar, 1 : 2 : 4',saturn:'Cavaquinho',venus:'Flute',uranus:'Cymbal swell',neptune:'Sub'},
  chacha:{sun:'Timbales',mercury:'Güiro',earth:'Claves, son clave',mars:'Congas',jupiter:'Tumbao bass','jupiter-moons':'Pizzicato violins, 1 : 2 : 4',saturn:'Piano montuno and violins',venus:'Charanga flute',uranus:'Cymbal swell',neptune:'Sub'},
  swing:{sun:'Feathered bass drum',mercury:'Ride cymbal',earth:'Brushes',mars:'Tom fills',jupiter:'Walking bass','jupiter-moons':'Vibraphone, 1 : 2 : 4',saturn:'Saxophone section and piano',venus:'Muted trumpet',uranus:'Trombones and brass shouts',neptune:'Sub'},
  jive:{sun:'Bass drum',mercury:'Ride cymbal',earth:'Snare backbeat',mars:'Tom fills',jupiter:'Walking bass','jupiter-moons':'Electric guitar, 1 : 2 : 4',saturn:'Piano and saxophones',venus:'Tenor saxophone',uranus:'Trombones and brass shouts',neptune:'Sub'},
  fandango:{sun:'Cajón bass',mercury:'Castanets',earth:'Palmas (hand claps)',mars:'Cajón slaps',jupiter:'Guitar thumb','jupiter-moons':'Guitar picado, 1 : 2 : 4',saturn:'Rasgueado guitar',venus:'Cante (voice)',uranus:'Cymbal swell',neptune:'Sub'}
};
const BALL_SAMPLES={
  waltz:['string_ensemble_1','violin','contrabass','french_horn','pizzicato_strings','orchestral_harp','timpani','flute'],
  tango:['tango_accordion','violin','contrabass','acoustic_grand_piano','string_ensemble_1'],
  samba:['acoustic_guitar_nylon','acoustic_guitar_steel','agogo','flute'],
  chacha:['acoustic_grand_piano','acoustic_bass','flute','string_ensemble_1','pizzicato_strings'],
  swing:['acoustic_bass','acoustic_grand_piano','alto_sax','tenor_sax','muted_trumpet','trombone','trumpet','vibraphone'],
  jive:['acoustic_bass','acoustic_grand_piano','alto_sax','tenor_sax','trumpet','trombone','electric_guitar_clean'],
  fandango:['acoustic_guitar_nylon']
};
Object.assign(STYLES,{
  waltz:{gain:2.3,name:'Waltz',fam:'ball',beats:3,bpm:174,mode:'C',swing:0,kickF:[95,48,.45],kickLvl:.25,duck:.92,arp:.55,arpV:'harp',lead:.9,leadLen:1.6,pads:'strings',buildBars:8},
  tango:{gain:2.8,name:'Tango',fam:'ball',beats:4,bpm:118,mode:'A',swing:0,kickF:[110,50,.4],kickLvl:.5,duck:.9,arp:.45,arpV:'piano',lead:.9,leadLen:1.3,pads:'strings',buildBars:4},
  samba:{gain:1.65,name:'Samba',fam:'ball',beats:4,bpm:104,mode:'G',swing:.08,kickF:[95,55,.3],kickLvl:.6,duck:.85,arp:.5,arpV:'guitar',lead:.8,pads:'none',buildBars:4},
  chacha:{gain:2.6,name:'Cha-cha',fam:'ball',beats:4,bpm:120,mode:'D',swing:0,kickF:[120,52,.35],kickLvl:.55,duck:.85,arp:.45,arpV:'pizz',lead:1,pads:'none',buildBars:4},
  swing:{gain:1.9,name:'Swing',fam:'ball',beats:4,bpm:140,mode:'G',swing:0,swing8:.667,kickF:[90,50,.35],kickLvl:.18,duck:.97,arp:.45,arpV:'vibes',lead:.85,leadLen:1.2,pads:'none',buildBars:4},
  jive:{gain:1.5,name:'Jive',fam:'ball',beats:4,bpm:172,mode:'G',swing:0,swing8:.667,kickF:[100,50,.35],kickLvl:.5,duck:.9,arp:.45,arpV:'eguitar',lead:.85,pads:'none',buildBars:8},
  fandango:{gain:1.45,name:'Fandango',fam:'ball',beats:3,bpm:168,mode:'E',swing:0,kickF:[100,50,.3],kickLvl:.6,duck:.85,arp:.5,arpV:'guitar',lead:.9,leadLen:1.8,pads:'none',buildBars:8,cadence:true}
});
// jungle (with the club styles), the slow waltz, and Bach-style counterpoint
Object.assign(BALL_INST,{
  jungle:{sun:'Breakbeat kick',mercury:'Break hats',earth:'Break snares',mars:'Break edits',jupiter:'Reese bass','jupiter-moons':'Arpeggio, 1 : 2 : 4',saturn:'Pads',venus:'Ragga chops',uranus:'Risers',neptune:'Sub'},
  slowwaltz:BALL_INST.waltz,
  baroque:{sun:'Timpani (in the climax)',mercury:'Countersubject (harpsichord)',earth:'Trumpet (in the climax)',mars:'The answer (oboe)',jupiter:'Continuo bass (cello)','jupiter-moons':'Harpsichord, 1 : 2 : 4',saturn:'Continuo harpsichord, then organ',venus:'The subject (violin)',uranus:'Organ swell',neptune:'Organ pedal'}
});
Object.assign(BALL_SAMPLES,{jungle:[],slowwaltz:BALL_SAMPLES.waltz,baroque:['harpsichord','church_organ','cello','violin','oboe','trumpet','timpani']});
Object.assign(STYLES,{
  jungle:{gain:1,name:'Jungle',fam:'ball',beats:4,bpm:166,mode:'A',swing:0,kickF:[160,48,.22],kickLvl:.9,duck:.45,arp:.35,arpV:'synth',lead:.6,pads:'saw',buildBars:8},
  slowwaltz:{gain:2.8,name:'Slow waltz',fam:'ball',beats:3,bpm:90,mode:'C',swing:0,kickF:[90,48,.45],kickLvl:.2,duck:.95,arp:.5,arpV:'harp',lead:.9,leadLen:1.3,pads:'strings',buildBars:4},
  baroque:{gain:3.2,name:'Bach',fam:'ball',beats:4,bpm:80,mode:'A',swing:0,kickF:[90,48,.4],kickLvl:.3,duck:.95,arp:.25,arpV:'harpsi',lead:0,pads:'none',buildBars:4,noSub:true}
});
Object.keys(BALL_INST).forEach(k=>{STYLES[k].inst=BALL_INST[k];STYLES[k].samples=BALL_SAMPLES[k]});

/* ---- the sampler ---- */
const SMP={man:null,base:null,buf:{},ready:{},loading:{},tried:false};
const SMP_ABS='https://newbroman.github.io/Music_of_the_Spheres/samples/';
const smpReady=n=>!!SMP.ready[n];
async function smpManifest(){
  if(SMP.man)return true;if(SMP.tried)return false;SMP.tried=true;
  const rel=(location.pathname.includes('/pl/')?'../':'')+'samples/';
  for(const b of location.protocol==='file:'?[SMP_ABS]:[rel,SMP_ABS]){try{const u=new URL(b,location.href).href,r=await fetch(u+'manifest.json');if(r.ok){SMP.man=await r.json();SMP.base=u;return true}}catch(e){}}
  return false;
}
function smpLoad(n){
  if(SMP.loading[n])return SMP.loading[n];const info=SMP.man&&SMP.man[n];if(!info)return Promise.resolve(false);
  const list=[];
  return SMP.loading[n]=Promise.all(info.notes.map(m=>fetch(`${SMP.base}${n}/${m}.mp3`).then(r=>{if(!r.ok)throw 0;return r.arrayBuffer()}).then(ab=>new Promise((ok,no)=>AC.decodeAudioData(ab,ok,no))).then(buf=>list.push({m,buf}))))
    .then(()=>{list.sort((a,c)=>a.m-c.m);SMP.buf[n]=list;SMP.ready[n]=true;return true}).catch(()=>{delete SMP.loading[n];return false});
}
let smpMsg='';
async function loadStyleSamples(){
  const st=STY(),names=st.samples;if(!AC||!names)return;
  if(names.every(smpReady))return;
  const k=D.style;smpMsg=k;toast(SMPTXT.tuning);
  if(!(await smpManifest())){if(smpMsg===k)toast(SMPTXT.synth);return}
  const ok=await Promise.all(names.map(smpLoad));
  if(smpMsg===k&&D.style===k)toast(ok.every(Boolean)?SMPTXT.ready:SMPTXT.synth);
}
const SMPTXT={tuning:'The band is tuning up…',ready:'The band is ready',synth:'Recorded instruments unavailable: playing synthesised ones'};
// play one recorded note at any frequency: the nearest sample, re-pitched
function samp(n,t,f,len,lvl,id,o={}){
  if(!SMP.ready[n])return false;
  const L=SMP.buf[n],midi=69+12*Math.log2(f/440);let best=L[0];for(const x of L)if(Math.abs(x.m-midi)<Math.abs(best.m-midi))best=x;
  const src=AC.createBufferSource();src.buffer=best.buf;const rate=Math.pow(2,(midi-best.m)/12);src.playbackRate.value=rate;
  const g=AC.createGain(),pk=lvl*SMP.man[n].gain,att=o.att||.004,rel=o.rel||.12;
  const end=Math.max(t+att,Math.min(t+len,t+best.buf.duration/rate-rel));
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(pk,t+att);g.gain.setValueAtTime(pk,end);g.gain.linearRampToValueAtTime(0,end+rel);
  src.connect(g);g.connect(toPan(id));const rv=o.rev===undefined?.25:o.rev;if(rv)g.connect(mkG(rv,revSend));
  src.start(t);src.stop(end+rel+.05);if(o.flash!==false)flash(id,t);return true;
}
function sChord(n,t,degs,oct,len,lvl,id,o={}){if(!SMP.ready[n])return false;degs.forEach((d,k)=>samp(n,t+(o.spread||0)*k,noteF(d,oct),len,lvl,id,{...o,flash:false}));flash(id,t);return true}
