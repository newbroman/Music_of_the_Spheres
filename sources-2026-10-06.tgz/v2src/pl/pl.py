# Generate the Polish pages from the built English ones.
# The English pages stay the master copy. HTML bodies are replaced by hand-translated Polish bodies
# (guarded by a hash of the English body, so a change to the English layout stops the build),
# and the script's visible strings are swapped by exact, asserted pairs.
import hashlib, sys, os
H='/tmp/claude-0/pl/'
B='https://newbroman.github.io/Music_of_the_Spheres/'

# ---------- engine, part A: elements, state, pitch, zodiac (in all three pages) ----------
A=[
 # bodies: Polish names, epithets and voice descriptions
 ("name:'Mercury',god:'Hermes'","name:'Merkury',god:'Hermes'"),
 ("name:'Venus',god:'Aphrodite'","name:'Wenus',god:'Afrodyta'"),
 ("name:'Earth',god:'Gaia'","name:'Ziemia',god:'Gaja'"),
 ("name:'Jupiter',god:'Zeus'","name:'Jowisz',god:'Zeus'"),
 ("name:'Uranus',god:'Ouranos'","name:'Uran',god:'Uranos'"),
 ("name:'Neptune',god:'Poseidon'","name:'Neptun',god:'Posejdon'"),
 ("name:'Pluto',god:'Hades'","name:'Pluton',god:'Hades'"),
 ("name:'Vesta',god:'Hestia'","name:'Westa',god:'Hestia'"),
 ("name:'Pallas',god:'Athena'","name:'Pallas',god:'Atena'"),
 ("name:'Juno',god:'Hera'","name:'Junona',god:'Hera'"),
 ("name:'Hygiea',god:'Hygieia'","name:'Higiea',god:'Hygieja'"),
 ("name:'67P/Churyumov–Gerasimenko'","name:'67P/Czuriumow–Gierasimienko'"),
 ("ancient:'Stilbōn, the Gleaming'","ancient:'Stilbon, Migocący'"),
 ("ancient:'Phōsphoros at dawn, Hesperos at dusk'","ancient:'Fosforos o świcie, Hesperos o zmierzchu'"),
 ("ancient:'the hearth of the cosmos'","ancient:'ognisko kosmosu'"),
 ("ancient:'Pyroeis, the Fiery'","ancient:'Pyroeis, Ognisty'"),
 ("ancient:'Phaethōn, the Shining'","ancient:'Faethon, Świecący'"),
 ("ancient:'Phainōn, the Bright'","ancient:'Fainon, Jasny'"),
 ("ancient:'the sky itself'","ancient:'samo niebo'"),
 ("ancient:'lord of the deep'","ancient:'pan głębin'"),
 ("ancient:'the unseen one'","ancient:'niewidzialny'"),
 ("ancient:'goddess of the harvest'","ancient:'bogini urodzajów'"),
 ("ancient:'keeper of the hearth'","ancient:'strażniczka ogniska'"),
 ("ancient:'Pallas, the grey-eyed'","ancient:'Pallas o sowich oczach'"),
 ("ancient:'queen of Olympus'","ancient:'królowa Olimpu'"),
 ("ancient:'goddess of health'","ancient:'bogini zdrowia'"),
 ("ancient:'the near-Earth wanderer'","ancient:'wędrowiec bliski Ziemi'"),
 ("ancient:'goddess of strife'","ancient:'bogini niezgody'"),
 ("greek:'Hawaiian goddess'","greek:'bogini hawajska'"),
 ("ancient:'named outside the Greek pantheon'","ancient:'imię spoza panteonu greckiego'"),
 ("greek:'Rapa Nui creator'","greek:'stwórca z Rapa Nui'"),
 ("greek:'Inuit sea goddess'","greek:'inuicka bogini morza'"),
 ("ancient:'the long-haired star'","ancient:'gwiazda o długich włosach'"),
 ("ancient:'parent of the Perseids'","ancient:'rodzic Perseidów'"),
 ("ancient:'parent of the Leonids'","ancient:'rodzic Leonidów'"),
 ("ancient:'the great comet of 1997'","ancient:'wielka kometa 1997 roku'"),
 ("'Hermes, the messenger: a bright, quick “ee”, darting with his eccentric orbit.'","'Hermes, posłaniec: jasne, szybkie „i”, śmigające po ekscentrycznej orbicie.'"),
 ("'Aphrodite: an open, sustained “ah”, its slow pulse reversed by her backward spin.'","'Afrodyta: otwarte, długie „a”, którego powolny puls odwraca jej wsteczny obrót.'"),
 ("'Gaia: a round, warm “oh”, with Selene singing above her.'","'Gaja: okrągłe, ciepłe „o”, a nad nią śpiewa Selene.'"),
 ("'Ares: a hard, forward “eh”, his sons Phobos and Deimos rattling around him.'","'Ares: twarde, natarczywe „e”, a wokół niego grzechoczą jego synowie, Fobos i Dejmos.'"),
 ("'Zeus: a broad bass “aw”, the widest chorus in the sky.'","'Zeus: szerokie, basowe „a”, najszerszy chór na niebie.'"),
 ("'Kronos, father of time: a dark, hollow “oo”, ringed by eight moons.'","'Kronos, ojciec czasu: ciemne, głuche „u”, otoczone ośmioma księżycami.'"),
 ("'Ouranos: a deep, muffled “uh” that pulses backward, as the planet rolls on its side.'","'Uranos: głębokie, stłumione „y”, pulsujące wstecz, bo planeta toczy się na boku.'"),
 ("'Poseidon: the lowest “oh” of the planets, with Triton circling against the current.'","'Posejdon: najniższe „o” wśród planet, a Tryton krąży pod prąd.'"),
 ("'Hades: a low “oo” that climbs as Pluto nears the Sun and sinks again, Charon beside him.'","'Hades: niskie „u”, które wznosi się, gdy Pluton zbliża się do Słońca, i znów opada, a obok niego Charon.'"),
 ("'Demeter: a soft “ah” from the heart of the asteroid belt.'","'Demeter: miękkie „a” z serca pasa planetoid.'"),
 ("'Hestia: a small, steady “eh”, pulsing with Vesta’s five-hour day.'","'Hestia: małe, równe „e”, pulsujące pięciogodzinną dobą Westy.'"),
 ("'Athena: a keen “ee” that soars high above the ecliptic on Pallas’s steep orbit.'","'Atena: przenikliwe „i”, wzlatujące wysoko nad ekliptykę po stromej orbicie Pallas.'"),
 ("'Hera: a proud, light “ah”.'","'Hera: dumne, lekkie „a”.'"),
 ("'Hygieia: a calm, small “ee”.'","'Hygieja: spokojne, drobne „i”.'"),
 ("'Eros: a slender thread of “ae” that swings in close to Gaia.'","'Eros: cienka nić „e”, która przechodzi blisko Gai.'"),
 ("'Eris: a distant, discordant “eh” from beyond Hades.'","'Eris: odległe, fałszywe „e” zza Hadesa.'"),
 ("'A guest voice from the Hawaiian pantheon: the fastest pulse in the choir, from a four-hour day.'","'Głos gościnny z panteonu hawajskiego: najszybszy puls w chórze, z czterogodzinnej doby.'"),
 ("'A guest voice from Rapa Nui: a low, remote “oh”.'","'Głos gościnny z Rapa Nui: niskie, odległe „o”.'"),
 ("'A guest voice from the Inuit sea: the slowest wanderer here, folded up into hearing.'","'Głos gościnny z morza Inuitów: najwolniejszy tu wędrowiec, przeniesiony w zakres słyszalny.'"),
 ("'A breath of wind that roars past the Sun every 76 years, travelling against the planets.'","'Podmuch wiatru, który co 76 lat z hukiem mija Słońce, pędząc pod prąd planet.'"),
 ("'The quickest comet: a whisper that returns every 3.3 years.'","'Najszybsza kometa: szept, który wraca co 3,3 roku.'"),
 ("'Rosetta’s comet: a faint breath every six and a half years.'","'Kometa Rosetty: słaby oddech co sześć i pół roku.'"),
 ("'Mother of the Perseid meteors, steeply tilted; next close pass in 2126.'","'Matka meteorów Perseidów, stromo nachylona; następne bliskie przejście w 2126 roku.'"),
 ("'Mother of the Leonids, orbiting backward every 33 years.'","'Matka Leonidów, krążąca wstecz co 33 lata.'"),
 ("'A huge, slow comet whose breath last swelled in 1997 and returns in about 2,500 years.'","'Ogromna, powolna kometa, której oddech ostatnio wezbrał w 1997 roku i wróci za około 2500 lat.'"),
 # moons
 ("{name:'Selene (Moon)',","{name:'Selene (Księżyc)',"),
 ("{name:'Phobos',","{name:'Fobos',"),("{name:'Deimos',","{name:'Dejmos',"),
 ("{name:'Amalthea',","{name:'Amaltea',"),("{name:'Ganymede',","{name:'Ganimedes',"),("{name:'Callisto',","{name:'Kallisto',"),
 ("{name:'Tethys',","{name:'Tetyda',"),("{name:'Rhea',","{name:'Rea',"),("{name:'Titan',","{name:'Tytan',"),("{name:'Iapetus',","{name:'Japet',"),
 ("{name:'Titania',","{name:'Tytania',"),
 ("{name:'Proteus',","{name:'Proteusz',"),("{name:'Triton',","{name:'Tryton',"),("{name:'Nereid',","{name:'Nereida',"),
 # spoken introductions
 ('"I am Hermes the messenger of the gods, Stilbon the Gleaming. I run my circuit of the Sun in eighty-eight days and no wanderer is swifter."','"Jestem Hermes, posłaniec bogów, Stilbon Migocący. Okrążam Słońce w osiemdziesiąt osiem dni i żaden wędrowiec nie jest ode mnie szybszy."'),
 ('"I am Aphrodite the morning and the evening star. My day is longer than my year and I turn backward against all the others."','"Jestem Afrodyta, gwiazda poranna i wieczorna. Mój dzień jest dłuższy niż mój rok, a obracam się wstecz, wbrew wszystkim innym."'),
 ('"I am Gaia the mother of all things. You are standing upon me, and Selene my Moon keeps me company each month."','"Jestem Gaja, matka wszystkiego. Stoisz na mnie, a Selene, mój Księżyc, co miesiąc dotrzymuje mi towarzystwa."'),
 ('"I am Ares the Fiery, and Fear and Dread run at my side."','"Jestem Ares Ognisty, a Strach i Trwoga biegną u mego boku."'),
 ('"I am Zeus the Shining king of Olympus. Twelve years I take to walk the zodiac and my moons are many."','"Jestem Zeus, świecący król Olimpu. Dwanaście lat wędruję przez zodiak, a moich księżyców jest wiele."'),
 ('"I am Kronos the father of time. I walk slowly in my rings, twenty-nine years to a circuit."','"Jestem Kronos, ojciec czasu. Kroczę powoli w swoich pierścieniach, dwadzieścia dziewięć lat na jedno okrążenie."'),
 ('"I am Ouranos the sky itself and the first of all the fathers. I roll upon my side, eighty-four years to a turn."','"Jestem Uranos, samo niebo, pierwszy ze wszystkich ojców. Toczę się na boku, osiemdziesiąt cztery lata na jedno okrążenie."'),
 ('"I am Poseidon the lord of the deep. One hundred and sixty-five years I take to circle the Sun."','"Jestem Posejdon, pan głębin. Sto sześćdziesiąt pięć lat okrążam Słońce."'),
 ('"I am little Hades the unseen one. I keep to the cold edge and Charon keeps me company."','"Jestem mały Hades, niewidzialny. Trzymam się zimnego skraju, a Charon dotrzymuje mi towarzystwa."'),
 ('"I am Demeter the harvest child and the biggest of the stones between Ares and Zeus."','"Jestem Demeter, dziecko żniw, największa spośród kamieni między Aresem a Zeusem."'),
 ('"I am Hestia the keeper of the hearth. I tend the fire out in the belt of stones."','"Jestem Hestia, strażniczka ogniska. Pilnuję ognia daleko w pasie kamieni."'),
 ('"I am Pallas Athena the grey-eyed. My path climbs steeply above all the others."','"Jestem Pallas Atena o sowich oczach. Moja droga wspina się stromo ponad wszystkie inne."'),
 ('"I am Hera the little queen. I walk the belt of stones in four and a half years."','"Jestem Hera, mała królowa. Obchodzę pas kamieni w cztery i pół roku."'),
 ('"I am Hygieia the healing child. I keep quietly to the outer edge of the belt."','"Jestem Hygieja, dziecko, które leczy. Trzymam się cicho zewnętrznego skraju pasa."'),
 ('"I am little Eros and I swing close to Gaia, where every heart notices."','"Jestem mały Eros i przelatuję blisko Gai, a każde serce to czuje."'),
 ('"I am Eris the troublemaker. When they found me Hades lost his place among the planets."','"Jestem Eris, mącicielka. Gdy mnie odkryto, Hades stracił miejsce wśród planet."'),
 ('"I am Haumea the guest from the Hawaiian islands. I spin all the way round every four hours."','"Jestem Haumea, gość z wysp hawajskich. Obracam się dookoła co cztery godziny."'),
 ('"I am Makemake the guest from Rapa Nui, playing far out in the Kuiper belt."','"Jestem Makemake, gość z Rapa Nui. Bawię się daleko w pasie Kuipera."'),
 ('"I am Sedna from the Inuit sea. One of my years is longer than eleven thousand of yours."','"Jestem Sedna z morza Inuitów. Jeden mój rok trwa dłużej niż jedenaście tysięcy waszych."'),
 ('"I am Halley\'s comet the long-haired star. I come back every seventy-six years travelling against the planets."','"Jestem kometa Halleya, gwiazda o długich włosach. Wracam co siedemdziesiąt sześć lat, pędząc pod prąd planet."'),
 ('"I am Encke\'s comet the quickest of all. I return every three years and a little more."','"Jestem kometa Enckego, najszybsza ze wszystkich. Wracam co trzy lata z małym okładem."'),
 ('"I am comet sixty-seven P and a spacecraft called Rosetta once came to live beside me."','"Jestem kometa sześćdziesiąt siedem P. Sonda Rosetta przyleciała kiedyś, by zamieszkać obok mnie."'),
 ('"I am Swift-Tuttle the mother of the Perseid meteors. I will pass close again in twenty-one twenty-six."','"Jestem Swift-Tuttle, matka meteorów Perseidów. Znów przelecę blisko w roku dwa tysiące sto dwudziestym szóstym."'),
 ('"I am Tempel-Tuttle the mother of the Leonid meteors. I circle backward every thirty-three years."','"Jestem Tempel-Tuttle, matka meteorów Leonidów. Krążę wstecz co trzydzieści trzy lata."'),
 ('"I am Hale-Bopp the great comet of nineteen ninety-seven. I will not return for two and a half thousand years."','"Jestem Hale-Bopp, wielka kometa roku tysiąc dziewięćset dziewięćdziesiątego siódmego. Nie wrócę przez dwa i pół tysiąca lat."'),
 # group labels
 ("label:'Planets'}","label:'Planety'}"),("label:'Dwarfs & asteroids'}","label:'Karłowate i planetoidy'}"),("label:'Comets'}","label:'Komety'}"),
 ("label:'Moons'}","label:'Księżyce'}"),("label:'Belt bells'}","label:'Dzwonki pasa'}"),
 # Polish note names: B is B flat, H is B natural
 ("const NOTE=['C','C♯','D','E♭','E','F','F♯','G','G♯','A','B♭','B'];","const NOTE=['C','Cis','D','Es','E','F','Fis','G','Gis','A','B','H'];"),
 # zodiac
 ("'Aries','♈'","'Baran','♈'"),("'Taurus','♉'","'Byk','♉'"),("'Gemini','♊'","'Bliźnięta','♊'"),("'Cancer','♋'","'Rak','♋'"),
 ("'Leo','♌'","'Lew','♌'"),("'Virgo','♍'","'Panna','♍'"),("'Libra','♎'","'Waga','♎'"),("'Scorpio','♏'","'Skorpion','♏'"),
 ("'Sagittarius','♐'","'Strzelec','♐'"),("'Capricorn','♑'","'Koziorożec','♑'"),("'Aquarius','♒'","'Wodnik','♒'"),("'Pisces','♓'","'Ryby','♓'"),
 ("`Sun in <b>${SIGNS[i][0]}</b> (${SIGNS[i][1]})`+(S.zodiacKey?` · key of ${keyName()}`:'')","`Słońce w znaku <b>${SIGNS[i][0]}</b> (${SIGNS[i][1]})`+(S.zodiacKey?` · tonacja ${keyName()}`:'')"),
]

# ---------- engine, part B: audio, voices, aspects, moon systems (2D and flight) ----------
Bp=[
 ("const VOICE_LABEL={bass:'bass',tenor:'tenor',ct:'countertenor',alto:'alto',soprano:'soprano',child:'child'};","const VOICE_LABEL={bass:'bas',tenor:'tenor',ct:'kontratenor',alto:'alt',soprano:'sopran',child:'głos dziecięcy'};"),
 ("name:'conjunction',sym:'☌',orb:7,iv:'a unison'","name:'koniunkcja',sym:'☌',orb:7,iv:'pryma'"),
 ("name:'sextile',sym:'⚹',orb:4,iv:'a major sixth'","name:'sekstyl',sym:'⚹',orb:4,iv:'seksta wielka'"),
 ("name:'square',sym:'□',orb:6,iv:'a fourth'","name:'kwadratura',sym:'□',orb:6,iv:'kwarta'"),
 ("name:'trine',sym:'△',orb:6,iv:'a fifth'","name:'trygon',sym:'△',orb:6,iv:'kwinta'"),
 ("name:'opposition',sym:'☍',orb:7,iv:'an octave'","name:'opozycja',sym:'☍',orb:7,iv:'oktawa'"),
 ("+' dB':'faint'","+' dB':'cicho'"),
 ("g.fillText('toward the Sun',","g.fillText('ku Słońcu',"),
 ("+' h':fmt(Math.abs(sm.m.P),1)+' d';","+' godz.':fmt(Math.abs(sm.m.P),1)+' d';"),
 ("${sm.m.P<0?' · retrograde':''}","${sm.m.P<0?' · wstecznie':''}"),
 ('title="Listen from ${sm.m.name}"','title="Słuchaj z: ${sm.m.name}"'),
 ("<h3>The system of ${b.god}</h3>","<h3>Układ: ${b.god}</h3>"),
 ("${b.name} and ${b.moons.length===1?'its moon':'its '+b.moons.length+' moons'}, as a small solar system","${b.name} ${b.moons.length===1?'z księżycem':'z księżycami ('+b.moons.length+')'} jako mały układ słoneczny"),
 ("Each moon sings, pitched by its orbital speed and as loud as it looks from where you listen. ${b.god} hums at the centre. Time is slowed so the quickest moon circles in about four seconds.","Każdy księżyc śpiewa tak wysoko, jak szybko krąży, i tak głośno, jak duży wydaje się z miejsca, w którym słuchasz. ${b.god} nuci w środku. Czas jest zwolniony, tak by najszybszy księżyc okrążał w około cztery sekundy."),
 ("'Listening from '+b.god:'Listen from '+b.god","'Słuchasz z: '+b.god:'Słuchaj z: '+b.god"),
 (">Back to the solar system</button>",">Wróć do Układu Słonecznego</button>"),
]

# ---------- speech (2D and flight) ----------
SP=[
 ("const FEMALE=/female|","const FEMALE=/female|paulina|zofia|zosia|ewa|maja|agnieszka|marysia|google polski|"),
 ("const MALE=/(^|\\W)male|","const MALE=/(^|\\W)male|marek|krzysztof|jacek|jan|adam|piotr|"),
 ("filter(v=>/^en/i.test(v.lang))","filter(v=>/^pl/i.test(v.lang))"),
 ("filter(v=>/en[-_]GB/i.test(v.lang))","filter(v=>/pl[-_]PL/i.test(v.lang))"),
 ("else u.lang='en-GB';","else u.lang='pl-PL';"),
]

FS=[ # fmtSpeed, in 2D and flight
 ("function fmtSpeed(d){","function fmtSpeed(d){return fmtSpeedEn(d).replace('.',',')}\nfunction fmtSpeedEn(d){"),
 ("+' hours / s';","+' godz./s';"),("+' days / s';","+' dni/s';"),("+' months / s';","+' mies./s';"),("+' years / s';","+' lat/s';"),
 ("const M=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];","const M=['sty','lut','mar','kwi','maj','cze','lip','sie','wrz','paź','lis','gru'];"),
]

# ---------- the 2D dial ----------
D2=[
 ("const T={rec:'Record',stop:'Stop',save:'Save recording',close:'Close',none:'Recording is not supported in this browser.',start:'Start the sound first, then record.',done:'Your recording'};","const T={rec:'Nagraj',stop:'Stop',save:'Zapisz nagranie',close:'Zamknij',none:'Ta przeglądarka nie obsługuje nagrywania.',start:'Najpierw włącz dźwięk, potem nagrywaj.',done:'Twoje nagranie'};"),
 ("g.fillText('R',","g.fillText('P',"),
 ("const KIND_LABEL={planet:'The wanderers · πλανῆται',minor:'Dwarf planets & asteroids',comet:'Comets · κομῆται'};","const KIND_LABEL={planet:'Wędrowcy · πλανῆται',minor:'Planety karłowate i planetoidy',comet:'Komety · κομῆται'};"),
 ("'<option value=\"sun\">The Sun · Helios (heliocentric)</option>'","'<option value=\"sun\">Słońce · Helios (heliocentrycznie)</option>'"),
 ("' (Ptolemaic)'","' (geocentrycznie)'"),
 ("'<option value=\"vernal\">The vernal point ♈︎ (fixed)</option><option value=\"sun\">The Sun</option>'","'<option value=\"vernal\">Punkt Barana ♈︎ (stały)</option><option value=\"sun\">Słońce</option>'"),
 ("(S.turn===0?' ahead':Math.abs(S.turn)===180?' behind':S.turn>0?' left':' right')","(S.turn===0?' przód':Math.abs(S.turn)===180?' tył':S.turn>0?' w lewo':' w prawo')"),
 ("S.playing?'Pause':'Play'","S.playing?'Pauza':'Start'"),
 ("S.dir>0?'◀ Backward':'Forward ▶'","S.dir>0?'◀ Wstecz':'Naprzód ▶'"),
 ('aria-label="${g.label} volume"','aria-label="Głośność: ${g.label}"'),
 ('title="Mute ${b.god}"','title="Wycisz: ${b.god}"'),
 ('title="Solo ${b.god}"','title="Solo: ${b.god}"'),
 ("SYS.id?'tap a moon to listen from it · drag to turn':'tap a body to hear it alone · drag to turn · scroll to zoom'","SYS.id?'dotknij księżyca, aby z niego słuchać · przeciągnij, aby obrócić':'dotknij ciała, aby usłyszeć je osobno · przeciągnij, aby obrócić · przewiń, aby przybliżyć'"),
 ("`Inside the system of ${byId[SYS.id].god}`","`Wewnątrz układu: ${byId[SYS.id].god}`"),
 ("$('audBack').textContent='Solar system'","$('audBack').textContent='Układ Słoneczny'"),
 ("$('audBack').textContent='Full choir'","$('audBack').textContent='Cały chór'"),
 ("`Hearing ${b.kind==='comet'?b.name:b.god}${n?` and ${n===1?b.moons[0].name.split(' ')[0]:n+' moons'}`:''} alone`","`Słuchasz osobno: ${b.kind==='comet'?b.name:b.god}${n?` i ${n===1?b.moons[0].name.split(' ')[0]:'księżyce ('+n+')'}`:''}`"),
 ("x.toLocaleString('en-GB',","x.toLocaleString('pl-PL',"),
 ("fmt(b.Pyears*365.25,0)+' days':fmt(b.Pyears,b.Pyears<20?2:0)+' years'","fmt(b.Pyears*365.25,0)+' dni':fmt(b.Pyears,b.Pyears<20?2:0)+' lat'"),
 ("fmt(Math.abs(b.rot),1)+' h':fmt(Math.abs(b.rot)/24,1)+' days'","fmt(Math.abs(b.rot),1)+' godz.':fmt(Math.abs(b.rot)/24,1)+' dni'"),
 ("'none shown'","'brak'"),
 ("?'Comet':b.name","?'Kometa':b.name"),
 ("'Back to full choir':'Hear alone'+(b.moons.length?' with moons':'')","'Wróć do całego chóru':'Słuchaj osobno'+(b.moons.length?' z księżycami':'')"),
 ('id="sayBtn">Speak</button>','id="sayBtn">Przemów</button>'),
 (">Enter the system of '",">Wejdź do układu: '"),
 ("'Listening from here':'Listen from here'","'Słuchasz stąd':'Słuchaj stąd'"),
 ('id="faceBtn">Face toward</button>','id="faceBtn">Zwróć się ku</button>'),
 ("<dt>Singing now</dt>","<dt>Śpiewa teraz</dt>"),("<dt>In the mix</dt>","<dt>W miksie</dt>"),("<dt>Frequency</dt>","<dt>Częstotliwość</dt>"),
 ("<dt>From the Sun</dt>","<dt>Od Słońca</dt>"),("<dt>From your post</dt>","<dt>Od twojego punktu</dt>"),("<dt>Orbital period</dt>","<dt>Okres obiegu</dt>"),
 ("<dt>Eccentricity</dt>","<dt>Mimośród</dt>"),("<dt>Inclination</dt>","<dt>Nachylenie orbity</dt>"),("<dt>Day length</dt>","<dt>Długość doby</dt>"),
 ("<dt>Radius</dt>","<dt>Promień</dt>"),("<dt>Height above ecliptic</dt>","<dt>Wysokość nad ekliptyką</dt>"),("<dt>Moons</dt>","<dt>Księżyce</dt>"),
 ("S.vp===b.id?'here':","S.vp===b.id?'tutaj':"),
 ("+' AU'","+' j.a.'"),
 ("b.el.i>90?' (retrograde)':''","b.el.i>90?' (wsteczna)':''"),
 ("b.rot<0?' · retrograde':''","b.rot<0?' · obrót wsteczny':''"),
 # the human-voice description, rewritten for Polish grammar
 ("""  if(b.kind==='comet')return `A whispering ${VOICE_LABEL[h.type]}, breathing “kometes”, the long-haired star, louder near the Sun.`;
  const who=h.type==='child'?'A child’s voice':`A ${VOICE_LABEL[h.type]}`;
  const moons=b.moons.length?` ${b.moons.length===1?'Its moon is':'Its moons are'} children who sing their names to a melody that follows their phase.`:'';
  return `${who} sings “${sung}”.${moons}`;""",
  """  if(b.kind==='comet')return `Szepcze ${VOICE_LABEL[h.type]}: „kometes”, gwiazda o długich włosach, głośniej blisko Słońca.`;
  const who=h.type==='child'?'Głos dziecięcy':VOICE_LABEL[h.type][0].toUpperCase()+VOICE_LABEL[h.type].slice(1);
  const moons=b.moons.length?` ${b.moons.length===1?'Księżyc to dziecko, które śpiewa swoje imię':'Księżyce to dzieci, które śpiewają swoje imiona'} na melodię podążającą za fazą.`:'';
  return `${who} śpiewa „${sung}”.${moons}`;"""),
 ("long:'sound is off'","long:'dźwięk wyłączony'"),
 ("long:`wobbling ${t.god}'s voice by up to ${Math.round(b.wobDepth)} cents`","long:`kołysze głosem: ${t.god}, do ${Math.round(b.wobDepth)} centów`"),
 ("long:'silent'","long:'milczy'"),("long:'muted'","long:'wyciszony'"),
 ("{txt:'faint',quiet:true,long:'too faint to hear from here'}","{txt:'cicho',quiet:true,long:'stąd za cicho, by usłyszeć'}"),
 ("`, wobbled by ${","`, kołysany przez: ${"),
 ("(-y+1)+' BCE'","(-y+1)+' p.n.e.'"),
 ("const VNOTE={instrument:\"Synthesised instruments shaped by each god's vowel.\",human:\"Each god sings their own name in a voice that suits them: Zeus and Kronos are basses, Ares a tenor, Hermes a countertenor, Gaia an alto, Aphrodite a soprano. Dwarf planets, asteroids and moons are children; comets whisper.\"};",
  "const VNOTE={instrument:\"Syntezowane instrumenty, każdy ukształtowany samogłoską swojego boga.\",human:\"Każdy bóg śpiewa własne imię głosem, który do niego pasuje: Zeus i Kronos to basy, Ares tenor, Hermes kontratenor, Gaja alt, Afrodyta sopran. Planety karłowate, planetoidy i księżyce to dzieci; komety szepczą.\"};"),
 ("audioOn?'Silence the spheres':'Begin the harmony'","audioOn?'Ucisz sfery':'Rozpocznij harmonię'"),
 (":'paused';",":'pauza';"),
]

# ---------- 3D flight ----------
FL=[
 ("const T={rec:'Record',stop:'Stop',save:'Save recording',close:'Close',none:'Recording is not supported in this browser.',start:'Start the sound first, then record.',done:'Your recording'};","const T={rec:'Nagraj',stop:'Stop',save:'Zapisz nagranie',close:'Zamknij',none:'Ta przeglądarka nie obsługuje nagrywania.',start:'Najpierw włącz dźwięk, potem nagrywaj.',done:'Twoje nagranie'};"),
 ("if(n.startsWith('titan'))return 'titan';","if(n.startsWith('titan')||n.startsWith('tytan'))return 'titan';"),
 ("return /enceladus|tethys|dione|rhea|mimas|ariel|miranda|titania|oberon|umbriel|triton|charon|ganymede|callisto|iapetus|nereid|proteus|dysnomia/","return /enceladus|tethys|tetyda|dione|rhea|^rea|mimas|ariel|miranda|titania|tytania|oberon|umbriel|triton|tryton|charon|ganymede|ganimedes|callisto|kallisto|iapetus|japet|nereid|proteus|dysnomia/"),
 ("id==='sun'?'Helios, the Sun':","id==='sun'?'Helios, Słońce':"),
 ("toast(`Setting course for ${name}`)","toast(`Kurs na: ${name}`)"),
 ("toast(above?'Above the plane of the planets':`Arrived at ${ship.ap.name}`)","toast(above?'Ponad płaszczyzną planet':`Na miejscu: ${ship.ap.name}`)"),
 ("lbl('sun','Helios <small>Sun</small>','');","lbl('sun','Helios <small>Słońce</small>','');"),
 ("'Aries',[[","'Baran',[["),("'Taurus',[[","'Byk',[["),("'Gemini',[[","'Bliźnięta',[["),("'Cancer',[[","'Rak',[["),("'Leo',[[","'Lew',[["),("'Virgo',[[","'Panna',[["),
 ("'Libra',[[","'Waga',[["),("'Scorpius',[[","'Skorpion',[["),("'Sagittarius',[[","'Strzelec',[["),("'Capricornus',[[","'Koziorożec',[["),("'Aquarius',[[","'Wodnik',[["),("'Pisces',[[","'Ryby',[["),
 ("audioOn?'Silence':'Begin the harmony'","audioOn?'Cisza':'Rozpocznij harmonię'"),
 ("toast(`Among the moons of ${b.god}: time slowed to ${fmtSpeed(S.speed)}`)","toast(`Wśród księżyców · ${b.god}: czas zwolniony do ${fmtSpeed(S.speed)}`)"),
 ("toast('Cruising ahead: drag to steer, ▼ or S to stop')","toast('Lot przed siebie: przeciągnij, by sterować; ▼ lub S, by się zatrzymać')"),
 ("name:'above the planets'","name:'ponad planety'"),
 ("toast('Rising out of the plane of the planets')","toast('Wznosisz się ponad płaszczyznę planet')"),
 ("ship.cruise?'Stop cruising':'Cruise ahead'","ship.cruise?'Zatrzymaj lot':'Leć przed siebie'"),
 ('data-c="above">Rise above</button>','data-c="above">Wznieś się</button>'),
 ('<span class="nm">Helios <span>Sun</span></span>','<span class="nm">Helios <span>Słońce</span></span>'),
 ("grp('Planets',","grp('Planety',"),("grp('Dwarf planets &amp; asteroids',","grp('Planety karłowate i planetoidy',"),("grp('Comets',","grp('Komety',"),
 ("'<em>Rising above the planets</em>':`Travelling to <em>${ship.ap.name}</em>`","'<em>Wznoszenie ponad planety</em>':`W drodze: <em>${ship.ap.name}</em>`"),
 ("'<em>Cruising</em> · drag to steer'","'<em>Lot przed siebie</em> · przeciągnij, by sterować'"),
 ("`In orbit with <em>${anc.god}</em>`:`Nearest: <em>${near}</em>`","`Na orbicie: <em>${anc.god}</em>`:`Najbliżej: <em>${near}</em>`"),
 ("txt+=` · ${byId[SYS.id].moons.length} moon${byId[SYS.id].moons.length>1?'s':''} singing`","txt+=` · śpiewające księżyce: ${byId[SYS.id].moons.length}`"),
 ("+'× light speed':Math.round(v).toLocaleString('en-GB')+' km/s'","+'× prędkość światła':Math.round(v).toLocaleString('pl-PL')+' km/s'"),
 ("AU from the Sun`","j.a. od Słońca`"),
 ("dist.toFixed(dist<2?3:1)","dist.toFixed(dist<2?3:1).replace('.',',')"),
 ("(-y+1)+' BCE'","(-y+1)+' p.n.e.'"),
]

# ---------- dance ----------
DA=[
 ("const T={rec:'Record',stop:'Stop',save:'Save recording',close:'Close',none:'Recording is not supported in this browser.',start:'Start the sound first, then record.',done:'Your recording'};","const T={rec:'Nagraj',stop:'Stop',save:'Zapisz nagranie',close:'Zamknij',none:'Ta przeglądarka nie obsługuje nagrywania.',start:'Najpierw włącz dźwięk, potem nagrywaj.',done:'Twoje nagranie'};"),
 ("const RECBASE='dance-of-the-spheres-';","const RECBASE='taniec-sfer-';"),
 ("const CADENCE='cadence';","const CADENCE='kadencja';"),
 ("waltz:'Lydian (the modern major)',tango:'Hypodorian (minor)',samba:'Hypophrygian (modern Mixolydian)',chacha:'Phrygian (modern Dorian)',swing:'Hypophrygian (modern Mixolydian)',jive:'Hypophrygian (modern Mixolydian)',fandango:'Dorian (modern Phrygian), Andalusian cadence'};","waltz:'lidyjska (współczesny dur)',tango:'hypodorycka (molowa)',samba:'hypofrygijska (współczesna miksolidyjska)',chacha:'frygijska (współczesna dorycka)',swing:'hypofrygijska (współczesna miksolidyjska)',jive:'hypofrygijska (współczesna miksolidyjska)',fandango:'dorycka (współczesna frygijska), kadencja andaluzyjska'};"),
 ("const PROGNOTE={sky:'Home, then the chords that Zeus, Kronos and Poseidon stand on in the zodiac, seen from Earth.',cadence:'The Andalusian cadence: Zeus and Kronos choose the first two chords from where they stand in the zodiac, then the Phrygian second leads home.'};","const PROGNOTE={sky:'Dom, a potem akordy, na których w zodiaku stoją Zeus, Kronos i Posejdon, widziani z Ziemi.',cadence:'Kadencja andaluzyjska: Zeus i Kronos wybierają dwa pierwsze akordy według swoich miejsc w zodiaku, a frygijska sekunda prowadzi do domu.'};"),
 ("nm=['C','C♯','D','E♭','E','F','F♯','G','G♯','A','B♭','B']","nm=['C','Cis','D','Es','E','F','Fis','G','Gis','A','B','H']"),
 ("toast('Drop: '+(ASPNOW[0]?`${ASPNOW[0].a.god} ${ASPNOW[0].asp.sym}︎ ${ASPNOW[0].b.god}`:'the spheres align'))","toast('Drop: '+(ASPNOW[0]?`${ASPNOW[0].a.god} ${ASPNOW[0].asp.sym}︎ ${ASPNOW[0].b.god}`:'sfery w jednej linii'))"),
 ("{ang:0,name:'conjunction',","{ang:0,name:'koniunkcja',"),("{ang:60,name:'sextile',","{ang:60,name:'sekstyl',"),("{ang:90,name:'square',","{ang:90,name:'kwadratura',"),
 ("{ang:120,name:'trine',","{ang:120,name:'trygon',"),("{ang:180,name:'opposition',","{ang:180,name:'opozycja',"),
 ("inst:'Kick'","inst:'Stopa'"),("inst:'Hi-hats'","inst:'Hi-haty'"),("god:'Gaia',inst:'Claps and snares'","god:'Gaja',inst:'Klaśnięcia i werble'"),("inst:'Toms'","inst:'Tomy'"),
 ("inst:'Bass'","inst:'Bas'"),("god:'Io · Europa · Ganymede',inst:'Arpeggio, 1 : 2 : 4'","god:'Io · Europa · Ganimedes',inst:'Arpeggio, 1 : 2 : 4'"),
 ("inst:'Pads and chords'","inst:'Plamy i akordy'"),("god:'Aphrodite',inst:'Vocal chops'","god:'Afrodyta',inst:'Wokalne sample'"),
 ("god:'Ouranos',inst:'Risers'","god:'Uranos',inst:'Narastania'"),("god:'Poseidon',inst:'Sub and atmosphere'","god:'Posejdon',inst:'Sub i atmosfera'"),
 ('title="Mute ${x.god}"','title="Wycisz: ${x.god}"'),
 ("el.textContent=D.section;","el.textContent=({intro:'wstęp',groove:'groove',build:'narastanie',drop:'drop',break:'wyciszenie'})[D.section]||D.section;"),
 ("const MODENAME={trance:'Hypodorian (minor)',house:'Phrygian (modern Dorian)',techno:'Dorian (modern Phrygian)',","const MODENAME={trance:'hypodorycka (molowa)',house:'frygijska (współczesna dorycka)',techno:'dorycka (współczesna frygijska)',"),
 ("function fmtDays(d){return d<1?(d*24).toFixed(0)+' hours / bar':d<60?d.toFixed(d<10?1:0)+' days / bar':(d/30.44).toFixed(1)+' months / bar'}","function fmtDays(d){return (d<1?(d*24).toFixed(0)+' godz./takt':d<60?d.toFixed(d<10?1:0)+' dni/takt':(d/30.44).toFixed(1)+' mies./takt').replace('.',',').replace(',/','./')}"),
 ("const M=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];","const M=['sty','lut','mar','kwi','maj','cze','lip','sie','wrz','paź','lis','gru'];"),
 ("`Key of <b>${nm}</b>, ${MODENAME[D.style]} · Sun in <b>${SIGNS[i][0]}</b> (${SIGNS[i][1]})`","`Tonacja <b>${nm}</b>, skala ${MODENAME[D.style]} · Słońce w znaku <b>${SIGNS[i][0]}</b> (${SIGNS[i][1]})`"),
 ("'No aspects at the moment: the band grooves.'","'Na razie żadnych aspektów: zespół gra groove.'"),
 ("D.playing?`bar ${Math.floor(D.step/SPB())+1}`:'stopped'","D.playing?`takt ${Math.floor(D.step/SPB())+1}`:'zatrzymany'"),
 ("D.playing?'Stop':'Play'","D.playing?'Stop':'Graj'"),
]

# the ballroom band labels, taken from the live English file so they never go stale
BALL_PL={'Breakbeat kick':'Stopa z breakbeatu','Break hats':'Hi-haty z breaku','Break snares':'Werble z breaku','Break edits':'Cięcia breaku','Reese bass':'Bas reese','Arpeggio, 1 : 2 : 4':'Arpeggio, 1 : 2 : 4','Pads':'Plamy','Ragga chops':'Sample ragga','Risers':'Narastania',
 'Timpani (in the climax)':'Kotły (w kulminacji)','Countersubject (harpsichord)':'Kontrapunkt (klawesyn)','Trumpet (in the climax)':'Trąbka (w kulminacji)','The answer (oboe)':'Odpowiedź (obój)','Continuo bass (cello)':'Bas continuo (wiolonczela)','Harpsichord, 1 : 2 : 4':'Klawesyn, 1 : 2 : 4','Continuo harpsichord, then organ':'Klawesyn continuo, potem organy','The subject (violin)':'Temat (skrzypce)','Organ swell':'Crescendo organów','Organ pedal':'Pedał organowy',
 'Bass drum and cymbals':'Bęben basowy i talerze','Triangle':'Trójkąt','Pizzicato strings':'Smyczki pizzicato','Timpani':'Kotły','Double basses':'Kontrabasy','Harp, 1 : 2 : 4':'Harfa, 1 : 2 : 4','Horns and strings':'Waltornie i smyczki','Solo violin and flute':'Skrzypce solo i flet','Cymbal roll and string swell':'Tremolo talerza i crescendo smyczków','Cellos':'Wiolonczele',
 'Golpe on the bass':'Golpe na pudle kontrabasu','Violin chicharra':'Chicharra skrzypiec','Piano chords':'Akordy fortepianu','Piano left hand':'Lewa ręka fortepianu','Double bass, 3-3-2':'Kontrabas, 3-3-2','Piano arpeggio, 1 : 2 : 4':'Arpeggio fortepianu, 1 : 2 : 4','Bandoneons and strings':'Bandoneony i smyczki','Solo violin':'Skrzypce solo','Bandoneon swell':'Crescendo bandoneonu',
 'Ganzá shaker':'Ganzá','Agogô bells':'Dzwonki agogô','Seven-string guitar':'Gitara siedmiostrunowa','Guitar, 1 : 2 : 4':'Gitara, 1 : 2 : 4','Flute':'Flet','Cymbal swell':'Crescendo talerza',
 'Timbales':'Timbalesy','Claves, son clave':'Klawesy, son clave','Congas':'Kongi','Tumbao bass':'Bas tumbao','Pizzicato violins, 1 : 2 : 4':'Skrzypce pizzicato, 1 : 2 : 4','Piano montuno and violins':'Fortepianowe montuno i skrzypce','Charanga flute':'Flet charangi',
 'Feathered bass drum':'Delikatny bęben basowy','Ride cymbal':'Talerz ride','Brushes':'Miotełki','Tom fills':'Przejścia na tomach','Vibraphone, 1 : 2 : 4':'Wibrafon, 1 : 2 : 4','Saxophone section and piano':'Sekcja saksofonów i fortepian','Muted trumpet':'Trąbka z tłumikiem','Trombones and brass shouts':'Puzony i uderzenia blachy',
 'Bass drum':'Bęben basowy','Snare backbeat':'Werbel na dwa i cztery','Electric guitar, 1 : 2 : 4':'Gitara elektryczna, 1 : 2 : 4','Piano and saxophones':'Fortepian i saksofony','Tenor saxophone':'Saksofon tenorowy',
 'Cajón bass':'Bas cajónu','Castanets':'Kastaniety','Palmas (hand claps)':'Palmas (klaskanie)','Cajón slaps':'Uderzenia w cajón','Guitar thumb':'Kciuk gitarzysty','Guitar picado, 1 : 2 : 4':'Gitara picado, 1 : 2 : 4','Rasgueado guitar':'Gitara rasgueado','Cante (voice)':'Cante (śpiew)'}
_b=open('/tmp/claude-0/dance_ball.js').read();_a=_b.index('const BALL_INST={');_z=_b.index('};',_a)+2;_en=_b[_a:_z];_pl=_en
import re as _re
for _k in _re.findall(r":'([^']*)'",_en):
    if _k not in BALL_PL and _k not in ('Surdo','Tamborim','Cavaquinho','Sub','Güiro','Walking bass'):sys.exit('no Polish label for: '+_k)
for _k,_v in BALL_PL.items():_pl=_pl.replace(":'"+_k+"'",":'"+_v+"'")
DA.append((_en,_pl))
DA.append(("Object.assign(MODENAME,{jungle:'Hypodorian (minor)',slowwaltz:'Lydian (the modern major)',baroque:'Hypodorian (minor), in counterpoint'});","Object.assign(MODENAME,{jungle:'hypodorycka (molowa)',slowwaltz:'lidyjska (współczesny dur)',baroque:'hypodorycka (molowa), w kontrapunkcie'});"))
DA.append(("const SMPTXT={tuning:'The band is tuning up…',ready:'The band is ready',synth:'Recorded instruments unavailable: playing synthesised ones'};","const SMPTXT={tuning:'Zespół się stroi…',ready:'Zespół gotowy',synth:'Nagrane instrumenty niedostępne: grają syntezowane'};"))

def body_swap(s,start,end,pl_file,md5):
    i=s.index(start);j=s.index(end,i);eng=s[i:j]
    h=hashlib.md5(eng.encode()).hexdigest()
    if h!=md5:sys.exit(f'English body changed ({pl_file}): update the Polish body, then set md5 to {h}')
    return s[:i]+open(H+pl_file).read()+s[j:]

def apply(s,pairs,page):
    for en,pl in pairs:
        n=s.count(en)
        if n==0:sys.exit(f'[{page}] not found: {en[:90]}')
        s=s.replace(en,pl)
    return s

R='/home/claude/music_of_the_spheres/'
def wrap(s,split,title_en,title_pl,desc,dst,alt):
    s=s.replace(f'<title>{title_en}</title>',f'<title>{title_pl}</title>',1)
    assert f'<title>{title_pl}</title>' in s
    i=s.index(split);head,body=s[:i],s[i:]
    if '[hidden]{display:none!important}' not in head:
        head=head.replace('<style>','<style>\n[hidden]{display:none!important}\nhtml,body{margin:0}\n',1)
    out=('<!doctype html>\n<html lang="pl">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
         f'<meta name="description" content="{desc}">\n<link rel="alternate" hreflang="en" href="{B}{alt}">\n'+head+'</head>\n<body>\n'+body+'\n</body>\n</html>\n')
    os.makedirs(os.path.dirname(dst),exist_ok=True);open(dst,'w').write(out)
    return out

MD5=dict(d2='',fl='',da='')
MD5.update(eval(open(H+'md5.txt').read()) if os.path.exists(H+'md5.txt') else {})

# 2D
s=open('/home/claude/music-of-the-spheres.html').read()
s=body_swap(s,'<div class="wrap">','<script>','body_2d.html',MD5['d2'])
for g,p in ((A,'2d A'),(Bp,'2d B'),(SP,'2d speech'),(FS,'2d fmt'),(D2,'2d')):s=apply(s,g,p)
open(H+'out_2d.html','w').write(s)
wrap(s,'<div class="wrap">','Music of the Spheres','Muzyka sfer','Planetarium, które śpiewa: planety, księżyce, planety karłowate i komety śpiewają głosami greckich bogów, z wysokością dźwięku wyznaczoną przez orbity, wokół wybranego przez ciebie punktu odsłuchu.',R+'pl/index.html','')

# flight
s=open('/home/claude/flight.html').read()
s=body_swap(s,'<canvas id="scene"','<script src=','body_fly.html',MD5['fl'])
for g,p in ((A,'fly A'),(Bp,'fly B'),(SP,'fly speech'),(FS,'fly fmt'),(FL,'fly')):s=apply(s,g,p)
open(H+'out_fly.html','w').write(s)
wrap(s,'<canvas id="scene"','Flight Through the Spheres','Lot przez sfery','Leć statkiem kosmicznym przez Układ Słoneczny w 3D, a planety i księżyce śpiewają wokół ciebie głosami greckich bogów.',R+'pl/flight.html','flight.html')

# dance
s=open('/home/claude/dance.html').read()
s=body_swap(s,'<div class="wrap">','<script>','body_dance.html',MD5['da'])
for g,p in ((A,'dance A'),(DA,'dance')):s=apply(s,g,p)
open(H+'out_dance.html','w').write(s)
wrap(s,'<div class="wrap">','Dance of the Spheres','Taniec sfer','Taniec sfer: Układ Słoneczny gra trance, house i techno. Planety tworzą zespół, zodiak wyznacza tonację i akordy, a aspekty między planetami wywołują narastania i dropy.',R+'pl/dance.html','dance.html')

# help: a hand-written Polish page with the shared stylesheet
hh=open('/tmp/claude-0/help_head.html').read()
s=hh+open(H+'help_body.html').read()
wrap(s,'<div class="wrap">','How the Spheres Sing','Jak śpiewają sfery','Jak śpiewają sfery: Pitagoras, Platon, Ptolemeusz i Kepler oraz to, jak aplikacja Muzyka sfer zamienia prawdziwe ruchy Układu Słonecznego w dźwięk.',R+'pl/help.html','help.html')
print('ok')
