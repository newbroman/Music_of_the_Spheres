import sys
def wrap(src,split,desc,dst,alt=None):
    s=open(src).read();i=s.index(split);head,body=s[:i],s[i:]
    if '[hidden]{display:none!important}' not in head:
        head=head.replace('<style>','<style>\n[hidden]{display:none!important}\nhtml,body{margin:0}\n',1)
    out=('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
         +(f'<link rel="alternate" hreflang="pl" href="https://newbroman.github.io/Music_of_the_Spheres/pl/{alt}">\n' if alt is not None else '')+f'<meta name="description" content="{desc}">\n'+head+'</head>\n<body>\n'+body+'\n</body>\n</html>\n')
    open(dst,'w').write(out)
R='/home/claude/music_of_the_spheres/'
wrap('/home/claude/music-of-the-spheres.html','<div class="wrap">','A live orrery synthesizer: the planets, moons, dwarf planets and comets sing with the voices of the Greek gods, pitched by their orbits and placed in space around a listening post you choose.',R+'index.html','')
wrap('/home/claude/flight.html','<canvas id="scene"','Fly a spaceship through a 3D solar system while the planets and moons sing around you, voiced by the Greek gods and pitched by their orbits.',R+'flight.html','flight.html')
import re
def _d(f):return re.search(r'<meta name="description" content="([^"]*)"',open(R+f).read()).group(1)
_dd,_dh=_d('dance.html'),_d('help.html')
wrap('/home/claude/dance.html','<div class="wrap">',_dd,R+'dance.html','dance.html')
wrap('/home/claude/help.html','<div class="wrap">',_dh,R+'help.html','help.html')
