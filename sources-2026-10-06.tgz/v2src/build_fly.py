src=open('/home/claude/music-of-the-spheres.html').read()
a=src.index("'use strict';")+len("'use strict';"); b=src.index('/* ---------- canvas ---------- */')
kept=src[a:b]
sp_a=src.index('const SYN=window.speechSynthesis'); sp_b=src.index('  SYN.speak(u);\n}',sp_a)+len('  SYN.speak(u);\n}')
speech=src[sp_a:sp_b]
def repl_fn(code,name,new):
    i=code.index('function '+name+'(');j=code.index('{',i);depth=0;k=j
    while True:
        if code[k]=='{':depth+=1
        elif code[k]=='}':
            depth-=1
            if depth==0:break
        k+=1
    return code[:i]+new+code[k+1:]
# the 3D page draws as well as sings, so phones get a tighter voice budget
kept=kept.replace('const MAXVOICES=LOWPOWER?6:10, MAXMOONS=LOWPOWER?6:12;','const MAXVOICES=LOWPOWER?4:10, MAXMOONS=LOWPOWER?4:12;')
assert 'LOWPOWER?4:10' in kept
kept=repl_fn(kept,'listenerPos',"function listenerPos(){return toE(ship.pos)}")
kept=repl_fn(kept,'setListener',"""function setListener(){
  const l=AC.listener,f=new THREE.Vector3(0,0,-1).applyQuaternion(camera.quaternion),u=new THREE.Vector3(0,1,0).applyQuaternion(camera.quaternion);
  if(l.forwardX){const t=AC.currentTime;l.forwardX.setTargetAtTime(f.x,t,.04);l.forwardY.setTargetAtTime(f.y,t,.04);l.forwardZ.setTargetAtTime(f.z,t,.04);l.upX.setTargetAtTime(u.x,t,.04);l.upY.setTargetAtTime(u.y,t,.04);l.upZ.setTargetAtTime(u.z,t,.04)}
  else l.setOrientation(f.x,f.y,f.z,u.x,u.y,u.z);
}""")
kept=repl_fn(kept,'sysListener',"function sysListener(){const e=toE(ship.pos),p=P[SYS.id];return {x:(e.x-p.x)/MAG*AU_KM,y:(e.y-p.y)/MAG*AU_KM,z:(e.z-p.z)/MAG*AU_KM}}")
js="(()=>{\n'use strict';\n"+kept+"\n/* ---------- speech ---------- */\n"+speech+"\n"+open('/tmp/claude-0/fly3d.js').read()+"\n})();\n"
head=open('/tmp/claude-0/fly_head.html').read(); body=open('/tmp/claude-0/fly_body.html').read()
open('/home/claude/flight.html','w').write(head+body+'<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>\n<script>\n'+open('/tmp/claude-0/recorder.js').read()+'</script>\n<script>\n'+js+'</script>\n')
open('/tmp/claude-0/fly_all.js','w').write(js)
