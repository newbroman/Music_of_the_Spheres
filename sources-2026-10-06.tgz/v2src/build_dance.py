src=open('/home/claude/music-of-the-spheres.html').read()
a=src.index("'use strict';")+len("'use strict';"); b=src.index('/* ---------- audio ---------- */')
kept=src[a:b]
js="(()=>{\n'use strict';\n"+kept+open('/tmp/claude-0/dance_engine.js').read()+open('/tmp/claude-0/dance_ball.js').read()+open('/tmp/claude-0/dance_ui.js').read()+"\n})();\n"
open('/tmp/claude-0/dance_all.js','w').write(js)
open('/home/claude/dance.html','w').write(open('/tmp/claude-0/dance_head.html').read()+open('/tmp/claude-0/dance_body.html').read()+'<script>\n'+open('/tmp/claude-0/recorder.js').read()+'</script>\n<script>\n'+js+'</script>\n')
