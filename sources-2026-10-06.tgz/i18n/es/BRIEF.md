# Translation brief: Music of the Spheres → es

The app plays the solar system as music, with the planets sung by the Greek gods. It also lets you hear the "music of the spheres" as ancient and early-modern thinkers imagined it (Pythagoras to Kepler), and it has a dance page with club, ballroom and concert (composer) styles.

Target: Spanish (neutral international), "tú" form.
Write natural, idiomatic, modern prose: the register of a good museum or public-broadcaster website. Keep the English meaning exactly; don't add or drop facts. Keep it concise in buttons and labels, because the layout is tight.

## Fixed names and terms (use these everywhere)
App and pages: **La música de las esferas**; **La danza de las esferas**; **Vuelo por las esferas**; **Cómo cantan las esferas**; 2D dial = **Dial 2D**; 3D flight = **Vuelo 3D**; How it works = **Cómo funciona**; Extras = **Más**; Record = **Grabar**; Stage = **Escenario**.
Sol, Luna, Mercurio, Venus, Tierra, Marte, Júpiter, Saturno, Urano, Neptuno, Plutón; Ceres, Vesta, Palas, Juno, Higía; Eros, Eris, Haumea, Makemake, Sedna. cometa; asteroide; planeta enano; cinturón de asteroides; AU = ua.
Gods: Hermes, Afrodita, Gea, Ares, Zeus, Crono, Urano (god; context distinguishes), Poseidón, Hades, Helios, Selene, Deméter, Hestia, Atenea, Hera, Higía, Eros, Eris.
Thinkers: Pitágoras, Filolao, Platón, Aristóteles, Cicerón, Nicómaco, Ptolomeo, Boecio, Copérnico, Robert Fludd, Kepler, Plinio.
Zodiac: Aries, Tauro, Géminis, Cáncer, Leo, Virgo, Libra, Escorpio, Sagitario, Capricornio, Acuario, Piscis.
Music: key tonalidad, mode modo, chord acorde, bar compás, beat pulso, drone bordón, octave octava, fifth quinta, fourth cuarta, major third tercera mayor, minor third tercera menor, major sixth sexta mayor, unison unísono, semitone semitono. Modes: dórico, frigio, lidio, mixolidio, hipodórico, hipofrigio, hipolidio. Aspects: conjunción, sextil, cuadratura, trígono, oposición. Sections: intro, groove, subida, drop, break. Viennese waltz vals vienés; slow waltz vals lento.
Dates: a. C., d. C.; months short: ene., feb., mar., abr., may., jun., jul., ago., sept., oct., nov., dic. Speed: "h/s", "días/s", "meses/s", "años/s", "min/s", "tiempo real". Decimal comma applied automatically.

Keep genre/dance-floor words such as trance, house, jungle, techno, groove, drop, breakbeat, Reese bass, BPM, MIDI, PA, DMX, HDMI, 5.1 as they are, unless the list above says otherwise. Composer names (Bach, Mozart, Satie, Debussy, Pärt, Reich, Glass) unchanged, in the target script's usual form if it is not Latin (e.g. Chinese 巴赫, 莫扎特, 萨蒂, 德彪西, 佩尔特, 赖希, 格拉斯; Japanese バッハ, モーツァルト, サティ, ドビュッシー, ペルト, ライヒ, グラス).

Speech: the gods' introductions (sentences beginning "I am …") are read aloud by the device's speech synthesiser in this language. Make them natural spoken sentences and write numbers in words as the English does.

## Code rules (very important)

- Translate only text a person sees or hears. Never change HTML tags, attributes (except visible ones: `title`, `aria-label`, `alt`, `placeholder`), ids, classes, URLs, data-* values, JavaScript identifiers, object keys, `${…}` template expressions, or CSS.
- Keep every quote character, backtick, bracket, comma and `\n` that is part of the code. If a JS string is in single quotes, don't put a straight `'` inside it. Use the typographic apostrophe ’ instead (for example `’r`, `i’r`, `a’r`).
- Keep `<b>`, `<em>`, `<a>` and other inline markup around the equivalent words.
- Leave all hrefs and language links (English, Polski, Cymraeg, EN, PL, CY) exactly as they are.
