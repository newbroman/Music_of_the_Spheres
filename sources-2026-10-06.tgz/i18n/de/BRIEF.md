# Translation brief: Music of the Spheres → de

The app plays the solar system as music, with the planets sung by the Greek gods. It also lets you hear the "music of the spheres" as ancient and early-modern thinkers imagined it (Pythagoras to Kepler), and it has a dance page with club, ballroom and concert (composer) styles.

Target: German (Germany). Address the reader with "du" (lower case), as modern German apps for a general audience do; be consistent.
Write natural, idiomatic, modern prose: the register of a good museum or public-broadcaster website. Keep the English meaning exactly; don't add or drop facts. Keep it concise in buttons and labels, because the layout is tight.

## Fixed names and terms (use these everywhere)
App and pages: Music of the Spheres = **Musik der Sphären**; Dance of the Spheres = **Tanz der Sphären**; Flight Through the Spheres = **Flug durch die Sphären**; How the Spheres Sing = **Wie die Sphären klingen**; 2D dial = **2D-Scheibe**; 3D flight = **3D-Flug**; How it works = **So funktioniert es**; Extras = **Extras**; Record = **Aufnehmen**; Stage = **Bühne**.
Sun **Sonne**, Moon **Mond**, Mercury **Merkur**, Venus **Venus**, Earth **Erde**, Mars **Mars**, Jupiter **Jupiter**, Saturn **Saturn**, Uranus **Uranus**, Neptune **Neptun**, Pluto **Pluto**; Ceres, Vesta, Pallas, Juno, Hygiea, Eros, Eris, Haumea, Makemake, Sedna unchanged. comet Komet; asteroid Asteroid; dwarf planet Zwergplanet; asteroid belt Asteroidengürtel; AU = AE.
Gods keep Greek forms in German spelling: Hermes, Aphrodite, Gaia, Ares, Zeus, Kronos, Uranos, Poseidon, Hades, Helios, Selene, Demeter, Hestia, Athene, Hera, Hygieia, Eros, Eris.
Thinkers: Pythagoras, Philolaos, Platon, Aristoteles, Cicero, Nikomachos, Ptolemäus, Boethius, Kopernikus, Robert Fludd, Kepler, Plinius.
Zodiac: Widder, Stier, Zwillinge, Krebs, Löwe, Jungfrau, Waage, Skorpion, Schütze, Steinbock, Wassermann, Fische.
Music: key Tonart, mode Modus (Kirchentonart), chord Akkord, bar Takt, beat Schlag, drone Bordun, octave Oktave, fifth Quinte, fourth Quarte, major third große Terz, minor third kleine Terz, major sixth große Sexte, unison Prime, semitone Halbton. Modes: dorisch, phrygisch, lydisch, mixolydisch, hypodorisch, hypophrygisch, hypolydisch. Aspects: Konjunktion, Sextil, Quadrat, Trigon, Opposition. Dance sections: Intro, Groove, Aufbau, Drop, Break. Viennese waltz Wiener Walzer; slow waltz Langsamer Walzer.
Dates: BC "v. Chr.", AD "n. Chr."; months short: Jan., Feb., März, Apr., Mai, Juni, Juli, Aug., Sept., Okt., Nov., Dez. Speed readouts: "Std./s", "Tage/s", "Monate/s", "Jahre/s", "Min./s", "Echtzeit". Numbers: the app switches the decimal point to a comma automatically for readouts; don't change number literals in code.

Keep genre/dance-floor words such as trance, house, jungle, techno, groove, drop, breakbeat, Reese bass, BPM, MIDI, PA, DMX, HDMI, 5.1 as they are, unless the list above says otherwise. Composer names (Bach, Mozart, Satie, Debussy, Pärt, Reich, Glass) unchanged, in the target script's usual form if it is not Latin (e.g. Chinese 巴赫, 莫扎特, 萨蒂, 德彪西, 佩尔特, 赖希, 格拉斯; Japanese バッハ, モーツァルト, サティ, ドビュッシー, ペルト, ライヒ, グラス).

Speech: the gods' introductions (sentences beginning "I am …") are read aloud by the device's speech synthesiser in this language. Make them natural spoken sentences and write numbers in words as the English does.

## Code rules (very important)

- Translate only text a person sees or hears. Never change HTML tags, attributes (except visible ones: `title`, `aria-label`, `alt`, `placeholder`), ids, classes, URLs, data-* values, JavaScript identifiers, object keys, `${…}` template expressions, or CSS.
- Keep every quote character, backtick, bracket, comma and `\n` that is part of the code. If a JS string is in single quotes, don't put a straight `'` inside it. Use the typographic apostrophe ’ instead (for example `’r`, `i’r`, `a’r`).
- Keep `<b>`, `<em>`, `<a>` and other inline markup around the equivalent words.
- Leave all hrefs and language links (English, Polski, Cymraeg, EN, PL, CY) exactly as they are.
