# Translation brief: Music of the Spheres → zh

The app plays the solar system as music, with the planets sung by the Greek gods. It also lets you hear the "music of the spheres" as ancient and early-modern thinkers imagined it (Pythagoras to Kepler), and it has a dance page with club, ballroom and concert (composer) styles.

Target: Simplified Chinese (mainland), natural and clear; use full-width punctuation in prose（，。：；？！“”）. Keep code punctuation ASCII.
Write natural, idiomatic, modern prose: the register of a good museum or public-broadcaster website. Keep the English meaning exactly; don't add or drop facts. Keep it concise in buttons and labels, because the layout is tight.

## Fixed names and terms (use these everywhere)
App and pages: **天球音乐**; **天球之舞**; **穿越天球**; **天球如何歌唱**; 2D dial = **二维星盘**; 3D flight = **三维飞行**; How it works = **使用说明**; Extras = **更多**; Record = **录音**; Stage = **舞台**.
太阳, 月亮 (the Moon; 月球 in astronomy contexts), 水星, 金星, 地球, 火星, 木星, 土星, 天王星, 海王星, 冥王星; 谷神星 (Ceres), 灶神星 (Vesta), 智神星 (Pallas), 婚神星 (Juno), 健神星 (Hygiea), 爱神星 (Eros), 阋神星 (Eris), 妊神星 (Haumea), 鸟神星 (Makemake), 塞德娜 (Sedna). comet 彗星; asteroid 小行星; dwarf planet 矮行星; asteroid belt 小行星带; AU = 天文单位.
Gods: 赫尔墨斯, 阿佛洛狄忒, 盖亚, 阿瑞斯, 宙斯, 克洛诺斯, 乌拉诺斯, 波塞冬, 哈迪斯, 赫利俄斯, 塞勒涅, 得墨忒耳, 赫斯提亚, 雅典娜, 赫拉, 许革亚, 厄洛斯, 厄里斯. Moons: 福波斯, 得摩斯, 木卫一 (Io), 木卫二 (Europa), 木卫三 (Ganymede), 木卫四 (Callisto), 土卫六 (Titan), 海卫一 (Triton); other moons may keep standard Chinese names (土卫二 etc.) or Latin if obscure.
Thinkers: 毕达哥拉斯, 菲洛劳斯, 柏拉图, 亚里士多德, 西塞罗, 尼各马可, 托勒密, 波爱修斯, 哥白尼, 罗伯特·弗拉德, 开普勒, 老普林尼.
Zodiac: 白羊座, 金牛座, 双子座, 巨蟹座, 狮子座, 处女座, 天秤座, 天蝎座, 射手座, 摩羯座, 水瓶座, 双鱼座.
Music: key 调, mode 调式, chord 和弦, bar 小节, beat 拍, drone 持续音, octave 八度, fifth 五度, fourth 四度, major third 大三度, minor third 小三度, major sixth 大六度, unison 同度, semitone 半音. Modes: 多利亚, 弗里几亚, 利底亚, 混合利底亚, 下多利亚, 下弗里几亚, 下利底亚 (调式). Aspects: 合相, 六分相, 四分相, 三分相, 对分相. Sections: 前奏, 律动, 渐强, 高潮 (drop), 间奏 (break). Viennese waltz 维也纳华尔兹; slow waltz 慢华尔兹; tango 探戈; samba 桑巴; cha-cha 恰恰; swing 摇摆; jive 牛仔舞; fandango 方丹戈.
Dates: 公元前 N 年 / 公元 N 年; months short "1月"…"12月". Speed: "小时/秒", "天/秒", "个月/秒", "年/秒", "分钟/秒", "实时". Note: in code templates that put a number before a unit, Chinese reads naturally as "2.4 小时/秒".

Keep genre/dance-floor words such as trance, house, jungle, techno, groove, drop, breakbeat, Reese bass, BPM, MIDI, PA, DMX, HDMI, 5.1 as they are, unless the list above says otherwise. Composer names (Bach, Mozart, Satie, Debussy, Pärt, Reich, Glass) unchanged, in the target script's usual form if it is not Latin (e.g. Chinese 巴赫, 莫扎特, 萨蒂, 德彪西, 佩尔特, 赖希, 格拉斯; Japanese バッハ, モーツァルト, サティ, ドビュッシー, ペルト, ライヒ, グラス).

Speech: the gods' introductions (sentences beginning "I am …") are read aloud by the device's speech synthesiser in this language. Make them natural spoken sentences and write numbers in words as the English does.

## Code rules (very important)

- Translate only text a person sees or hears. Never change HTML tags, attributes (except visible ones: `title`, `aria-label`, `alt`, `placeholder`), ids, classes, URLs, data-* values, JavaScript identifiers, object keys, `${…}` template expressions, or CSS.
- Keep every quote character, backtick, bracket, comma and `\n` that is part of the code. If a JS string is in single quotes, don't put a straight `'` inside it. Use the typographic apostrophe ’ instead (for example `’r`, `i’r`, `a’r`).
- Keep `<b>`, `<em>`, `<a>` and other inline markup around the equivalent words.
- Leave all hrefs and language links (English, Polski, Cymraeg, EN, PL, CY) exactly as they are.
