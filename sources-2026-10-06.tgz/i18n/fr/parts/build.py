import re
d='/tmp/claude-0/i18n/'
s=''.join(open(d+f'fr/parts/p{i}.html',encoding='utf8').read() for i in (1,2,3))
# NBSP typography in text nodes only (not tags, not <style>)
NB=' '
def fix(t):
    t=re.sub(r'(?<=[^\d\s]) ([:;?!»])',NB+r'\1',t)
    t=re.sub(r'(«) ',r'\1'+NB,t)
    return t
out=[];pos=0
for m in re.finditer(r'<style>.*?</style>|<[^>]+>',s,re.S):
    out.append(fix(s[pos:m.start()]));out.append(m.group(0));pos=m.end()
out.append(fix(s[pos:]))
res=''.join(out)
open(d+'fr/help_body.html','w',encoding='utf8').write(res)
src=open(d+'src/en_help_body.html',encoding='utf8').read()
tg=lambda x:re.findall(r'</?([a-zA-Z0-9]+)',x)
# remove added li
tips=res.index('Les présentations parlées')
a=res.rfind('<li>',0,tips);b=res.index('</li>',tips)+5
res2=res[:a]+res[b:]
print('added:',res[a:b][:60])
print('tagseq equal:',tg(res2)==tg(src),len(tg(src)))
al=lambda x:re.findall(r'<[^>]+>',x)
strip=lambda t:re.sub(r'\s(aria-label|title|alt|placeholder)="[^"]*"','',t)
sa=[strip(t) for t in al(src)];ra=[strip(t) for t in al(res2)]
print('tags+attrs equal (ex visible attrs):',sa==ra)
if sa!=ra:
    for x,y in zip(sa,ra):
        if x!=y: print(x,'|',y);break
# greek preserved
gr=lambda x:re.findall(r'[Ͱ-Ͽἀ-῿]+',x)
print('greek equal:',gr(src)==gr(res))
