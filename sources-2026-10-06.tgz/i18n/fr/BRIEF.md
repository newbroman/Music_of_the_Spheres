# Translation brief: Music of the Spheres → fr

The app plays the solar system as music, with the planets sung by the Greek gods. It also lets you hear the "music of the spheres" as ancient and early-modern thinkers imagined it (Pythagoras to Kepler), and it has a dance page with club, ballroom and concert (composer) styles.

Target: French (France), "vous" form for instructions.
Write natural, idiomatic, modern prose: the register of a good museum or public-broadcaster website. Keep the English meaning exactly; don't add or drop facts. Keep it concise in buttons and labels, because the layout is tight.

## Fixed names and terms (use these everywhere)
App and pages: **La Musique des sphères**; **La Danse des sphères**; **Vol à travers les sphères**; **Comment chantent les sphères**; 2D dial = **Cadran 2D**; 3D flight = **Vol 3D**; How it works = **Comment ça marche**; Extras = **Plus**; Record = **Enregistrer**; Stage = **Scène**.
Soleil, Lune, Mercure, Vénus, Terre, Mars, Jupiter, Saturne, Uranus, Neptune, Pluton; Cérès, Vesta, Pallas, Junon, Hygie; Eros, Éris, Haumea, Makemake, Sedna. comète; astéroïde; planète naine; ceinture d’astéroïdes; AU = ua.
Gods in French form: Hermès, Aphrodite, Gaïa, Arès, Zeus, Cronos, Ouranos, Poséidon, Hadès, Hélios, Séléné, Déméter, Hestia, Athéna, Héra, Hygie, Éros, Éris.
Thinkers: Pythagore, Philolaos, Platon, Aristote, Cicéron, Nicomaque, Ptolémée, Boèce, Copernic, Robert Fludd, Kepler, Pline.
Zodiac: Bélier, Taureau, Gémeaux, Cancer, Lion, Vierge, Balance, Scorpion, Sagittaire, Capricorne, Verseau, Poissons.
Music: key tonalité, mode mode, chord accord, bar mesure, beat temps, drone bourdon, octave octave, fifth quinte, fourth quarte, major third tierce majeure, minor third tierce mineure, major sixth sixte majeure, unison unisson, semitone demi-ton. Modes: dorien, phrygien, lydien, mixolydien, hypodorien, hypophrygien, hypolydien. Aspects: conjonction, sextile, carré, trigone, opposition. Sections: intro, groove, montée, drop, break. Viennese waltz valse viennoise; slow waltz valse lente.
Dates: av. J.-C., apr. J.-C.; months short: janv., févr., mars, avr., mai, juin, juil., août, sept., oct., nov., déc. Speed: "h/s", "jours/s", "mois/s", "ans/s", "min/s", "temps réel". Use French typography: non-breaking space before : ; ? ! is optional; use « » for quotations in prose. Decimal comma is applied automatically.

Keep genre/dance-floor words such as trance, house, jungle, techno, groove, drop, breakbeat, Reese bass, BPM, MIDI, PA, DMX, HDMI, 5.1 as they are, unless the list above says otherwise. Composer names (Bach, Mozart, Satie, Debussy, Pärt, Reich, Glass) unchanged, in the target script's usual form if it is not Latin (e.g. Chinese 巴赫, 莫扎特, 萨蒂, 德彪西, 佩尔特, 赖希, 格拉斯; Japanese バッハ, モーツァルト, サティ, ドビュッシー, ペルト, ライヒ, グラス).

Speech: the gods' introductions (sentences beginning "I am …") are read aloud by the device's speech synthesiser in this language. Make them natural spoken sentences and write numbers in words as the English does.

## Code rules (very important)

- Translate only text a person sees or hears. Never change HTML tags, attributes (except visible ones: `title`, `aria-label`, `alt`, `placeholder`), ids, classes, URLs, data-* values, JavaScript identifiers, object keys, `${…}` template expressions, or CSS.
- Keep every quote character, backtick, bracket, comma and `\n` that is part of the code. If a JS string is in single quotes, don't put a straight `'` inside it. Use the typographic apostrophe ’ instead (for example `’r`, `i’r`, `a’r`).
- Keep `<b>`, `<em>`, `<a>` and other inline markup around the equivalent words.
- Leave all hrefs and language links (English, Polski, Cymraeg, EN, PL, CY) exactly as they are.
