# Translation brief: Music of the Spheres → ja

The app plays the solar system as music, with the planets sung by the Greek gods. It also lets you hear the "music of the spheres" as ancient and early-modern thinkers imagined it (Pythagoras to Kepler), and it has a dance page with club, ballroom and concert (composer) styles.

Target: Japanese, polite です・ます style for sentences; concise noun phrases for buttons and labels. Use Japanese punctuation in prose（、。「」）; keep code punctuation ASCII.
Write natural, idiomatic, modern prose: the register of a good museum or public-broadcaster website. Keep the English meaning exactly; don't add or drop facts. Keep it concise in buttons and labels, because the layout is tight.

## Fixed names and terms (use these everywhere)
App and pages: **天球の音楽**; **天球の舞**; **天球をめぐる飛行**; **天球はどう歌うのか**; 2D dial = **2D 星図**; 3D flight = **3D 飛行**; How it works = **使い方**; Extras = **その他**; Record = **録音**; Stage = **ステージ**.
太陽, 月, 水星, 金星, 地球, 火星, 木星, 土星, 天王星, 海王星, 冥王星; ケレス, ベスタ, パラス, ジュノー, ヒギエア, エロス, エリス, ハウメア, マケマケ, セドナ. comet 彗星; asteroid 小惑星; dwarf planet 準惑星; asteroid belt 小惑星帯; AU = 天文単位 (au).
Gods: ヘルメス, アプロディーテー, ガイア, アレス, ゼウス, クロノス, ウラノス, ポセイドン, ハデス, ヘリオス, セレネ, デメテル, ヘスティア, アテナ, ヘラ, ヒュギエイア, エロス, エリス. Moons in katakana: フォボス, ダイモス, イオ, エウロパ, ガニメデ, カリスト, タイタン, トリトン, etc.
Thinkers: ピタゴラス, フィロラオス, プラトン, アリストテレス, キケロ, ニコマコス, プトレマイオス, ボエティウス, コペルニクス, ロバート・フラッド, ケプラー, プリニウス.
Zodiac: おひつじ座, おうし座, ふたご座, かに座, しし座, おとめ座, てんびん座, さそり座, いて座, やぎ座, みずがめ座, うお座.
Music: key 調, mode 旋法, chord 和音, bar 小節, beat 拍, drone ドローン, octave オクターヴ, fifth 5度, fourth 4度, major third 長3度, minor third 短3度, major sixth 長6度, unison ユニゾン, semitone 半音. Modes: ドリア, フリギア, リディア, ミクソリディア, ヒポドリア, ヒポフリギア, ヒポリディア (旋法). Aspects: コンジャンクション (合), セクスタイル, スクエア, トライン, オポジション. Sections: イントロ, グルーヴ, ビルド, ドロップ, ブレイク. Viennese waltz ウィンナ・ワルツ; slow waltz スロー・ワルツ; tango タンゴ; samba サンバ; cha-cha チャチャ; swing スウィング; jive ジャイヴ; fandango ファンダンゴ.
Dates: 紀元前 N 年 / 紀元 N 年; months short "1月"…"12月". Speed: "時間/秒", "日/秒", "か月/秒", "年/秒", "分/秒", "実時間".

Keep genre/dance-floor words such as trance, house, jungle, techno, groove, drop, breakbeat, Reese bass, BPM, MIDI, PA, DMX, HDMI, 5.1 as they are, unless the list above says otherwise. Composer names (Bach, Mozart, Satie, Debussy, Pärt, Reich, Glass) unchanged, in the target script's usual form if it is not Latin (e.g. Chinese 巴赫, 莫扎特, 萨蒂, 德彪西, 佩尔特, 赖希, 格拉斯; Japanese バッハ, モーツァルト, サティ, ドビュッシー, ペルト, ライヒ, グラス).

Speech: the gods' introductions (sentences beginning "I am …") are read aloud by the device's speech synthesiser in this language. Make them natural spoken sentences and write numbers in words as the English does.

## Code rules (very important)

- Translate only text a person sees or hears. Never change HTML tags, attributes (except visible ones: `title`, `aria-label`, `alt`, `placeholder`), ids, classes, URLs, data-* values, JavaScript identifiers, object keys, `${…}` template expressions, or CSS.
- Keep every quote character, backtick, bracket, comma and `\n` that is part of the code. If a JS string is in single quotes, don't put a straight `'` inside it. Use the typographic apostrophe ’ instead (for example `’r`, `i’r`, `a’r`).
- Keep `<b>`, `<em>`, `<a>` and other inline markup around the equivalent words.
- Leave all hrefs and language links (English, Polski, Cymraeg, EN, PL, CY) exactly as they are.
