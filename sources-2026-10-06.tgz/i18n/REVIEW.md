# Review pass for one language (L)

You are a careful native-level proof-reader for language L. The translations in /tmp/claude-0/i18n/<L>/ were made by three different translators working in parallel, from the English sources in /tmp/claude-0/i18n/src/. Read <L>/BRIEF.md (terms and code rules) first.

Files:
- strings.json (by id; English in src/strings_en.json)
- labels.json
- thinkers_txt.js (English: src/en_thinkers_txt.js)
- body_2d.html, body_fly.html, body_dance.html, help_body.html (English: src/en_*.html)

Fix the following, editing in place:
1. **Consistency across files (most important).** The help page and the dial body refer to buttons and controls by name. Those names must match exactly what the UI uses. The UI is strings.json, the body_* files and the `const T` objects inside strings.json, and the UI wins. Examples: the Begin/Silence button, Record, Stage and its options, "As they wrote it" / "Heard from Athens" (thinkers_txt.js ui.asWritten / ui.athens), Enter the system, Cruise ahead, Test speakers, Connect MIDI, and the dance style names.
   - Thinker names, god names, planet names and section names must also be the same everywhere.
   - The Sun's drone is called Apollo in the English dial. Keep Apollo for the drone and Helios for the Sun god, as the English does.
2. **Grammar, agreement and idiom.** Fix anything a fluent reader would trip on, including word order carried over from English. Keep the register in BRIEF.md.
3. **Mistranslations or omissions against the English.**
4. **Aristotle (thinkers_txt.js):** `ui.athensNote` must end by saying Aristotle’s harmony fades towards his silence but never quite reaches it. Also check that aristotle.hear reads well (it was written separately).
5. **Spoken introductions** (strings.json values that begin with a double quote): these must sound natural when read aloud.

Hard rules:
- Never change code: tags, attributes other than visible title/aria-label, ids, classes, URLs, JS keys, quote delimiters or `${…}` expressions.
- No straight ' inside '-quoted JS strings.
- Keep the JSON valid.

When done, run these checks:
- node evaluates thinkers_txt.js once the /*TXT-START*/ and /*TXT-END*/ markers are stripped.
- Every `const T={…}` fragment in strings.json parses with node.
- Each HTML file's tag sequence still matches its English source. help_body.html has one extra <li> in #tips, which is intended.
- Then run `python3 /tmp/claude-0/i18n/build.py <L>`, which must print "<L> ok".

Report briefly: the number of corrections, the 5–8 most significant (before → after), and the check results.
