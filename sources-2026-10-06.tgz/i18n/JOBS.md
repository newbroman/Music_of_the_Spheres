# Jobs (each translator does one)

All paths are under /tmp/claude-0/i18n/. English sources are in src/. Write output into the language folder <L>/ (e.g. de/). Read <L>/BRIEF.md first and follow it exactly.

## Job A: help page
src/en_help_body.html → <L>/help_body.html
- Translate all visible text, headings, tables, lists, link text and aria-labels. Keep every tag, attribute, id, class and href exactly. Leave the Greek in `<div class="greek">` and in SVG labels written in Greek unchanged.
- Quotations from ancient authors: translate the English rendering faithfully.
- In the "Tips and troubleshooting" section (id="tips"), add one list item, in the same style as its neighbours. It should say that the gods' spoken introductions use the device's speech voices: install a voice for this language in the system's text-to-speech settings if they sound English, and without one they speak English.
- Work section by section. Then verify with a script that the tag-name sequence matches the source exactly, apart from the one added <li>…</li> (with its inline tags).

## Job B: thinkers' texts and the dial page body
1. src/en_thinkers_txt.js → <L>/thinkers_txt.js
   - Keep the /*TXT-START*/ and /*TXT-END*/ markers. Translate every string value, and keep all keys and the structure identical.
   - No straight ' inside '-quoted strings and no straight " inside "-quoted strings.
   - "when" values like 'c. 530 BC' use the brief's date style. In "work" titles, keep Latin or Greek titles and translate descriptive ones in their usual form.
   - Verify that node can evaluate it (strip the markers), and that the key sets at every level match the English.
2. src/en_body_2d.html → <L>/body_2d.html
   - Translate visible text and title/aria-label/placeholder. Keep all tags, ids, classes, data-*, option values and hrefs.
   - Verify the tag sequence matches.

## Job C: UI strings, labels, flight and dance bodies
1. src/strings_en.json: a list of {id, en}. Each "en" is an exact fragment of JS or HTML code containing visible English. Write <L>/strings.json as {id: translated_fragment}, with every id present.
   - Each fragment replaces the English one verbatim in the code, so keep identifiers, keys, quote delimiters, backticks, `${…}` expressions and tags exactly. Translate only the human-visible text.
   - You may reorder words around `${…}` for grammar, but keep every `${…}` expression unchanged.
   - Three fragments are whole `const T={…}` text objects: the Stage panel, the recorder and the welcome tour. Translate every value. In the tour object, keep `img:'tour/en/'` exactly; it is set automatically.
   - The note-name arrays are handled separately, so leave anything that is just note letters unchanged.
   - Validate with a script. For each id: the `${…}` expressions match as multisets; the counts of ` { } ( ) [ ] < > match; there is no straight ' inside a '-quoted JS string (use ’ or the target's quotation marks). Check that each `const T={…}` fragment parses with node (`node -e "const T=…"` style).
2. src/labels_en.json: short instrument and band labels. Write <L>/labels.json as {english: translated}, with every label present. No straight '. Keep "1 : 2 : 4", "3-3-2" and "—".
3. src/en_body_fly.html → <L>/body_fly.html and src/en_body_dance.html → <L>/body_dance.html. Translate visible text and title/aria-label. Keep everything else, including language links (EN, PL, CY, English, Polski, Cymraeg). Verify the tag sequences.

Report briefly: done, check results, and up to 5 uncertain items.
