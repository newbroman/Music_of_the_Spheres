import json,re,collections,subprocess,unicodedata
B='/tmp/claude-0/i18n/'
src=json.load(open(B+'src/strings_en.json'))
txt=open(B+'it/strings_it.txt').read()
parts=re.split(r'^@@(\S+)\n',txt,flags=re.M)
out={}
for i in range(1,len(parts),2):
    c=parts[i+1]
    if c.endswith('\n'): c=c[:-1]
    c=c.replace('{{VS}}','\ufe0e')
    if parts[i] in('D2179','T254','T255','T256'): c=c.replace('\\n','\n')
    out[parts[i]]=c
bad=0
def err(*a):
    global bad;bad+=1;print(*a)
def exprs(s):
    r=[];i=0
    while True:
        i=s.find('${',i)
        if i<0:break
        d=0;j=i+1
        while j<len(s):
            if s[j]=='{':d+=1
            elif s[j]=='}':
                d-=1
                if d==0:break
            j+=1
        r.append(s[i:j+1]);i=j+1
    return r
def mask(e): return re.sub(r"'[^']*'","''",e)
def sym(s): return collections.Counter(ch for ch in s if unicodedata.category(ch)[0] in 'SMC' and ch not in '`<>+=$^|~')
for x in src:
    id,en=x['id'],x['en']
    if id not in out: err('missing',id);continue
    it=out[id]
    if collections.Counter(map(mask,exprs(en)))!=collections.Counter(map(mask,exprs(it))): err('expr',id)
    for ch in '` { } ( ) [ ] < >'.split():
        if en.count(ch)!=it.count(ch): err('count',ch,id,en.count(ch),it.count(ch))
    if (en!=en.strip())!=(it!=it.strip()) or en[:1].isspace()!=it[:1].isspace(): err('ws',id)
    if sym(en)-sym(it) or '\ufe0e' in en and '\ufe0e' not in it: err('sym',id,sym(en)-sym(it))
    # straight ' inside '-quoted JS strings: heuristic via node for objects; for others count of straight quotes
    for q in "'\"":
        if en.count(q)!=it.count(q): err('quote',q,id,en.count(q),it.count(q))
    if en.count('\n')!=it.count('\n'): err('nl',id)
extra=set(out)-{x['id'] for x in src}
if extra: err('extra',extra)
for id in('T254','T255','T256'):
    r=subprocess.run(['node','-e',out[id]+';'+'console.log(Object.keys(T).length)'],capture_output=True,text=True)
    en=[x['en'] for x in src if x['id']==id][0]
    r0=subprocess.run(['node','-e',en+';console.log(Object.keys(T).length, JSON.stringify(T).length>0, '+('T.slides.length' if id=='T256' else '0')+')'],capture_output=True,text=True)
    r1=subprocess.run(['node','-e',out[id]+';console.log(Object.keys(T).length, JSON.stringify(T).length>0, '+('T.slides.length' if id=='T256' else '0')+')'],capture_output=True,text=True)
    print(id,r0.stdout.strip(),r1.stdout.strip(),r1.stderr[:200])
    if r0.stdout!=r1.stdout: err('T mismatch',id)
    if id=='T254':
        code=f"{en};{out[id]}"
    # key equality
    k=lambda s:subprocess.run(['node','-e',s+';const f=(o,p)=>Object.entries(o).flatMap(([k,v])=>typeof v==="object"?f(v,p+k+"."):[p+k]);console.log(JSON.stringify(f(T,"")))'],capture_output=True,text=True).stdout
    if k(en)!=k(out[id]): err('keys',id)
json.dump(out,open(B+'it/strings.json','w'),ensure_ascii=False,indent=1)
# labels
lab=json.load(open(B+'src/labels_en.json'))
L={}
for l in open(B+'it/labels_it.txt').read().split('\n'):
    if l: a,b=l.split('|');L[a]=b
for l in lab:
    if l not in L: err('label missing',l)
    elif "'" in L[l]: err("label '",l)
    elif ('1 : 2 : 4' in l)!=('1 : 2 : 4' in L[l]) or ('3-3-2' in l)!=('3-3-2' in L[l]): err('label nums',l)
if set(L)-set(lab): err('label extra')
json.dump(L,open(B+'it/labels.json','w'),ensure_ascii=False,indent=1)
# html tags
def tags(s): return re.findall(r'</?([a-zA-Z0-9]+)',s)
for a,b in(('en_body_fly.html','body_fly.html'),('en_body_dance.html','body_dance.html')):
    A=open(B+'src/'+a).read();C=open(B+'it/'+b).read()
    if tags(A)!=tags(C): err('tags',b)
    attrs=lambda s:re.findall(r'(?:id|class|href|data-[a-z]+|type|min|max|value|lang|hreflang)="[^"]*"',s)
    if attrs(A)!=attrs(C): err('attrs',b)
print('errors',bad,len(out),len(L))
