# Translation brief: Music of the Spheres → it

The app plays the solar system as music, with the planets sung by the Greek gods. It also lets you hear the "music of the spheres" as ancient and early-modern thinkers imagined it (Pythagoras to Kepler), and it has a dance page with club, ballroom and concert (composer) styles.

Target: Italian, "tu" form.
Write natural, idiomatic, modern prose: the register of a good museum or public-broadcaster website. Keep the English meaning exactly; don't add or drop facts. Keep it concise in buttons and labels, because the layout is tight.

## Fixed names and terms (use these everywhere)
App and pages: **La musica delle sfere**; **La danza delle sfere**; **Volo tra le sfere**; **Come cantano le sfere**; 2D dial = **Quadrante 2D**; 3D flight = **Volo 3D**; How it works = **Come funziona**; Extras = **Altro**; Record = **Registra**; Stage = **Palco**.
Sole, Luna, Mercurio, Venere, Terra, Marte, Giove, Saturno, Urano, Nettuno, Plutone; Cerere, Vesta, Pallade, Giunone, Igea; Eros, Eris, Haumea, Makemake, Sedna. cometa; asteroide; pianeta nano; fascia degli asteroidi; AU = UA.
Gods: Ermes, Afrodite, Gea, Ares, Zeus, Crono, Urano (god), Poseidone, Ade, Elio, Selene, Demetra, Estia, Atena, Era, Igea, Eros, Eris.
Thinkers: Pitagora, Filolao, Platone, Aristotele, Cicerone, Nicomaco, Tolomeo, Boezio, Copernico, Robert Fludd, Keplero, Plinio.
Zodiac: Ariete, Toro, Gemelli, Cancro, Leone, Vergine, Bilancia, Scorpione, Sagittario, Capricorno, Acquario, Pesci.
Music: key tonalità, mode modo, chord accordo, bar battuta, beat movimento, drone bordone, octave ottava, fifth quinta, fourth quarta, major third terza maggiore, minor third terza minore, major sixth sesta maggiore, unison unisono, semitone semitono. Modes: dorico, frigio, lidio, misolidio, ipodorico, ipofrigio, ipolidio. Aspects: congiunzione, sestile, quadratura, trigono, opposizione. Sections: intro, groove, crescendo, drop, break. Viennese waltz valzer viennese; slow waltz valzer lento.
Dates: a.C., d.C.; months short: gen, feb, mar, apr, mag, giu, lug, ago, set, ott, nov, dic. Speed: "h/s", "giorni/s", "mesi/s", "anni/s", "min/s", "tempo reale". Decimal comma applied automatically.

Keep genre/dance-floor words such as trance, house, jungle, techno, groove, drop, breakbeat, Reese bass, BPM, MIDI, PA, DMX, HDMI, 5.1 as they are, unless the list above says otherwise. Composer names (Bach, Mozart, Satie, Debussy, Pärt, Reich, Glass) unchanged, in the target script's usual form if it is not Latin (e.g. Chinese 巴赫, 莫扎特, 萨蒂, 德彪西, 佩尔特, 赖希, 格拉斯; Japanese バッハ, モーツァルト, サティ, ドビュッシー, ペルト, ライヒ, グラス).

Speech: the gods' introductions (sentences beginning "I am …") are read aloud by the device's speech synthesiser in this language. Make them natural spoken sentences and write numbers in words as the English does.

## Code rules (very important)

- Translate only text a person sees or hears. Never change HTML tags, attributes (except visible ones: `title`, `aria-label`, `alt`, `placeholder`), ids, classes, URLs, data-* values, JavaScript identifiers, object keys, `${…}` template expressions, or CSS.
- Keep every quote character, backtick, bracket, comma and `\n` that is part of the code. If a JS string is in single quotes, don't put a straight `'` inside it. Use the typographic apostrophe ’ instead (for example `’r`, `i’r`, `a’r`).
- Keep `<b>`, `<em>`, `<a>` and other inline markup around the equivalent words.
- Leave all hrefs and language links (English, Polski, Cymraeg, EN, PL, CY) exactly as they are.
