# Build one translated language from the built English pages:  python3 build.py de
# Sources (English) are taken live from the English pages; translations are in <lang>/:
#   strings.json (code fragments, by id from src/strings_en.json), labels.json, thinkers_txt.js,
#   body_2d.html, body_fly.html, body_dance.html, help_body.html.
# Language conventions (decimal comma, note names, locale, speech voices, fonts, titles) are in CONF below.
import hashlib, sys, os, re, json
L=sys.argv[1]
I='/tmp/claude-0/i18n/'; H=I+L+'/'; HP='/tmp/claude-0/pl/'
B='https://newbroman.github.io/Music_of_the_Spheres/'
R='/home/claude/music_of_the_spheres/'

SOLF_FR=['Do','Do♯','Ré','Mi♭','Mi','Fa','Fa♯','Sol','Sol♯','La','Si♭','Si']
SOLF=['Do','Do♯','Re','Mi♭','Mi','Fa','Fa♯','Sol','Sol♯','La','Si♭','Si']
GER=['C','Cis','D','Es','E','F','Fis','G','Gis','A','B','H']
CJK_FONTS={'zh':'Noto+Sans+SC:wght@400;500&family=Noto+Serif+SC:wght@400;600','ja':'Noto+Sans+JP:wght@400;500&family=Noto+Serif+JP:wght@400;600'}
CONF={
 'de':dict(locale='de-DE',comma=True,notes=GER,LR=('L','R'),speech='de',region='de[-_]DE',fem='anna|petra|katja|hedda|marlene|vicki|helena|katja|amala|conka|elke|',male='markus|yannick|stefan|hans|conrad|killian|',
   titles=('Musik der Sphären','Flug durch die Sphären','Tanz der Sphären','Wie die Sphären klingen'),
   desc=('Höre die Sphärenmusik, wie jeder Denker sie sich vorstellte, von Pythagoras, Platon und Ptolemäus bis Kepler, gezeichnet nach dem echten Himmel dieses Augenblicks, und das ganze heutige Sonnensystem, gesungen von den griechischen Göttern.',
         'Fliege mit einem Raumschiff in 3D durch das Sonnensystem, während Planeten und Monde mit den Stimmen der griechischen Götter um dich herum singen.',
         'Tanz der Sphären: Das Sonnensystem spielt als Band, vom Club über den Ballsaal bis in den Konzertsaal. Der Tierkreis wählt Tonart und Akkorde, Aspekte zwischen den Planeten lösen Aufbau und Drop aus.',
         'Wie die Sphären klingen: Pythagoras, Platon, Ptolemäus und Kepler, und wie Musik der Sphären die echten Bewegungen des Sonnensystems in Klang verwandelt.')),
 'fr':dict(locale='fr-FR',comma=True,notes=SOLF_FR,LR=('G','D'),speech='fr',region='fr[-_]FR',fem='amelie|amélie|audrey|aurelie|aurélie|julie|denise|marie|virginie|celine|céline|eloise|',male='thomas|nicolas|paul|henri|remy|rémy|daniel|claude|',
   titles=('La Musique des sphères','Vol à travers les sphères','La Danse des sphères','Comment chantent les sphères'),
   desc=('Écoutez la musique des sphères telle que chaque penseur l’imaginait, de Pythagore, Platon et Ptolémée à Kepler, tirée du ciel réel de cet instant, et tout le système solaire d’aujourd’hui chanté par les dieux grecs.',
         'Pilotez un vaisseau à travers le système solaire en 3D, tandis que planètes et lunes chantent autour de vous avec la voix des dieux grecs.',
         'La Danse des sphères : le système solaire joue comme un orchestre, du club à la salle de bal et à la salle de concert. Le zodiaque choisit la tonalité et les accords, et les aspects entre planètes déclenchent montées et drops.',
         'Comment chantent les sphères : Pythagore, Platon, Ptolémée et Kepler, et comment La Musique des sphères transforme les mouvements réels du système solaire en son.')),
 'es':dict(locale='es-ES',comma=True,notes=SOLF,LR=('I','D'),speech='es',region='es[-_]ES',fem='monica|mónica|paulina|helena|laura|elvira|lucia|lucía|marisol|conchita|sabina|',male='jorge|pablo|diego|alvaro|álvaro|juan|enrique|raul|raúl|',
   titles=('La música de las esferas','Vuelo por las esferas','La danza de las esferas','Cómo cantan las esferas'),
   desc=('Escucha la música de las esferas tal como la imaginó cada pensador, de Pitágoras, Platón y Ptolomeo a Kepler, trazada desde el cielo real de este momento, y todo el sistema solar actual cantado por los dioses griegos.',
         'Pilota una nave por el sistema solar en 3D mientras los planetas y las lunas cantan a tu alrededor con las voces de los dioses griegos.',
         'La danza de las esferas: el sistema solar toca como una banda, del club al salón de baile y la sala de conciertos. El zodiaco elige la tonalidad y los acordes, y los aspectos entre planetas desatan subidas y drops.',
         'Cómo cantan las esferas: Pitágoras, Platón, Ptolomeo y Kepler, y cómo La música de las esferas convierte los movimientos reales del sistema solar en sonido.')),
 'it':dict(locale='it-IT',comma=True,notes=SOLF,LR=('S','D'),speech='it',region='it[-_]IT',fem='alice|federica|elsa|isabella|paola|carla|chiara|',male='luca|cosimo|diego|giuseppe|marco|giorgio|',
   titles=('La musica delle sfere','Volo tra le sfere','La danza delle sfere','Come cantano le sfere'),
   desc=('Ascolta la musica delle sfere come la immaginava ogni pensatore, da Pitagora, Platone e Tolomeo a Keplero, tratta dal cielo reale di questo momento, e l’intero sistema solare di oggi cantato dagli dèi greci.',
         'Pilota un’astronave attraverso il sistema solare in 3D mentre pianeti e lune cantano intorno a te con le voci degli dèi greci.',
         'La danza delle sfere: il sistema solare suona come una band, dal club alla sala da ballo e alla sala da concerto. Lo zodiaco sceglie tonalità e accordi, e gli aspetti tra i pianeti fanno scattare crescendo e drop.',
         'Come cantano le sfere: Pitagora, Platone, Tolomeo e Keplero, e come La musica delle sfere trasforma i moti reali del sistema solare in suono.')),
 'zh':dict(locale='zh-CN',comma=False,notes=None,LR=('左','右'),speech='zh',region='zh[-_]CN',fem='ting-ting|tingting|mei-jia|meijia|xiaoxiao|huihui|yaoyao|xiaoyi|lili|sin-ji|',male='kangkang|yunyang|yunxi|yunjian|li-mu|',
   titles=('天球音乐','穿越天球','天球之舞','天球如何歌唱'),
   desc=('按照每一位思想家的想象聆听天球音乐，从毕达哥拉斯、柏拉图、托勒密到开普勒，取自此刻真实的天空；也聆听由希腊众神歌唱的整个当今太阳系。',
         '驾驶飞船在三维太阳系中穿行，行星与卫星以希腊众神的声音在你周围歌唱。',
         '天球之舞：太阳系化身乐队，从俱乐部到舞厅再到音乐厅。黄道选择调与和弦，行星之间的相位触发渐强与高潮。',
         '天球如何歌唱：毕达哥拉斯、柏拉图、托勒密与开普勒，以及“天球音乐”如何把太阳系的真实运动变成声音。')),
 'ja':dict(locale='ja-JP',comma=False,notes=None,LR=('左','右'),speech='ja',region='ja[-_]JP',fem='kyoko|haruka|ayumi|nanami|o-ren|sayaka|mizuki|',male='otoya|ichiro|keita|hattori|daichi|naoki|',
   titles=('天球の音楽','天球をめぐる飛行','天球の舞','天球はどう歌うのか'),
   desc=('ピタゴラス、プラトン、プトレマイオスからケプラーまで、それぞれの思想家が思い描いた天球の音楽を、いまこの瞬間の本物の空から聴く。ギリシアの神々が歌う現在の太陽系全体も。',
         '宇宙船で3Dの太陽系を飛び抜けよう。惑星と衛星がギリシアの神々の声であなたのまわりで歌います。',
         '天球の舞：太陽系がバンドになり、クラブからボールルーム、コンサートホールまで演奏します。黄道十二宮が調と和音を選び、惑星どうしのアスペクトがビルドとドロップを起こします。',
         '天球はどう歌うのか：ピタゴラス、プラトン、プトレマイオス、ケプラー、そして「天球の音楽」が太陽系の本当の動きをどのように音に変えるのか。')),
}
C=CONF[L]

def LANG_JS():
    av=open('/tmp/claude-0/langs.txt').read().split()
    s=open('/tmp/claude-0/lang.js').read()
    return '<script>\n'+re.sub(r"/\*LANGS\*/.*?/\*LANGS-END\*/","/*LANGS*/"+json.dumps(av)+"/*LANGS-END*/",s)+'</script>\n'
def ALTS(alt):
    av=open('/tmp/claude-0/langs.txt').read().split()
    return ''.join(f'<link rel="alternate" hreflang="{c}" href="{B}{"" if c=="en" else c+"/"}{alt}">\n' for c in av if c!=L)

EN=json.load(open(I+'src/strings_en.json'));TR=json.load(open(H+'strings.json'))
miss=[it['id'] for it in EN if it['id'] not in TR]
if miss:sys.exit(f'{L}: missing translations for {miss[:10]}')
GRP={}
for it in EN:
    g=re.match(r'(D2|Bp|FS|FL|DA|A|T)',it['id']).group(1);t=TR[it['id']]
    if g=='T'and t.startswith('const T={img:'):t=re.sub(r"img:'[^']*'",f"img:'../tour/{L}/'",t,1)
    GRP.setdefault(g,[]).append((it['en'],t))
LAB=json.load(open(H+'labels.json'))
# names the Polish build never needed to change: bodies (name/god) and moons, per language
BOD={'fr':{'Mars|Ares':('Mars','Arès'),'Saturn|Kronos':('Saturne','Cronos'),'Ceres|Demeter':('Cérès','Déméter'),'Eris|Eris':('Éris','Éris'),'Eros|Eros':('Éros','Éros')},
 'es':{'Mars|Ares':('Marte','Ares'),'Saturn|Kronos':('Saturno','Crono'),'Ceres|Demeter':('Ceres','Deméter')},
 'it':{'Mars|Ares':('Marte','Ares'),'Saturn|Kronos':('Saturno','Crono'),'Ceres|Demeter':('Cerere','Demetra')},
 'de':{},
 'zh':{'Mars|Ares':('火星','阿瑞斯'),'Saturn|Kronos':('土星','克洛诺斯'),'Ceres|Demeter':('谷神星','得墨忒耳'),'Eris|Eris':('阋神星','厄里斯'),'Eros|Eros':('爱神星','厄洛斯'),'Haumea|Haumea':('妊神星','哈乌美阿'),'Makemake|Makemake':('鸟神星','马奇马奇'),'Sedna|Sedna':('塞德娜','塞德娜'),'1P/Halley|Halley':('1P/哈雷彗星','哈雷')},
 'ja':{'Mars|Ares':('火星','アレス'),'Saturn|Kronos':('土星','クロノス'),'Ceres|Demeter':('ケレス','デメテル'),'Eris|Eris':('エリス','エリス'),'Eros|Eros':('エロス','エロス'),'Haumea|Haumea':('ハウメア','ハウメア'),'Makemake|Makemake':('マケマケ','マケマケ'),'Sedna|Sedna':('セドナ','セドナ'),'1P/Halley|Halley':('1P/ハレー彗星','ハレー')}}
MOON={'de':{'Ganymede':'Ganymed','Callisto':'Kallisto','Iapetus':'Japetus','Nereid':'Nereide'},
 'fr':{'Ganymede':'Ganymède','Enceladus':'Encelade','Tethys':'Téthys','Dione':'Dioné','Rhea':'Rhéa','Hyperion':'Hypérion','Iapetus':'Japet','Oberon':'Obéron','Nereid':'Néréide','Amalthea':'Amalthée'},
 'es':{'Ganymede':'Ganimedes','Callisto':'Calisto','Enceladus':'Encélado','Tethys':'Tetis','Rhea':'Rea','Titan':'Titán','Hyperion':'Hiperión','Iapetus':'Jápeto','Oberon':'Oberón','Triton':'Tritón','Nereid':'Nereida','Proteus':'Proteo','Charon':'Caronte','Amalthea':'Amaltea'},
 'it':{'Ganymede':'Ganimede','Enceladus':'Encelado','Tethys':'Teti','Rhea':'Rea','Titan':'Titano','Hyperion':'Iperione','Iapetus':'Giapeto','Triton':'Tritone','Nereid':'Nereide','Proteus':'Proteo','Charon':'Caronte','Amalthea':'Amaltea'},
 'zh':{'Phobos':'火卫一','Deimos':'火卫二','Amalthea':'木卫五','Io':'木卫一','Europa':'木卫二','Ganymede':'木卫三','Callisto':'木卫四','Mimas':'土卫一','Enceladus':'土卫二','Tethys':'土卫三','Dione':'土卫四','Rhea':'土卫五','Titan':'土卫六','Hyperion':'土卫七','Iapetus':'土卫八','Miranda':'天卫五','Ariel':'天卫一','Umbriel':'天卫二','Titania':'天卫三','Oberon':'天卫四','Proteus':'海卫八','Triton':'海卫一','Nereid':'海卫二','Charon':'冥卫一','Nix':'冥卫二','Hydra':'冥卫三','Dysnomia':'阋卫一'},
 'ja':{'Phobos':'フォボス','Deimos':'ダイモス','Amalthea':'アマルテア','Io':'イオ','Europa':'エウロパ','Ganymede':'ガニメデ','Callisto':'カリスト','Mimas':'ミマス','Enceladus':'エンケラドゥス','Tethys':'テティス','Dione':'ディオネ','Rhea':'レア','Titan':'タイタン','Hyperion':'ヒペリオン','Iapetus':'イアペトゥス','Miranda':'ミランダ','Ariel':'アリエル','Umbriel':'ウンブリエル','Titania':'チタニア','Oberon':'オベロン','Proteus':'プロテウス','Triton':'トリトン','Nereid':'ネレイド','Charon':'カロン','Nix':'ニクス','Hydra':'ヒドラ','Dysnomia':'ディスノミア'}}
NAMES=[(f"name:'{k.split('|')[0]}',god:'{k.split('|')[1]}'",f"name:'{v[0]}',god:'{v[1]}'") for k,v in BOD[L].items()]
NAMES+=[(f"{{name:'{k}',",f"{{name:'{v}',") for k,v in MOON[L].items()]


# speech: a voice for this language if the device has one, otherwise the English line in an English voice
SAY={}
for en,tr in GRP['A']:
    if en.startswith('"I am'):SAY[tr[1:-1].replace("\\'","'").replace('\\"','"')]=en[1:-1].replace("\\'","'")
SP=[
 ("const FEMALE=/female|","const FEMALE=/female|"+C['fem']),
 ("const MALE=/(^|\\W)male|","const MALE=/(^|\\W)male|"+C['male']),
 ("function pickVoice(sex,seed){","let EN_V=false;const SAY_EN="+json.dumps(SAY,ensure_ascii=False)+";\nfunction pickVoice(sex,seed){"),
 ("filter(v=>/^en/i.test(v.lang))","filter(v=>EN_V?/^en/i.test(v.lang):/^"+C['speech']+"/i.test(v.lang))"),
 ("filter(v=>/en[-_]GB/i.test(v.lang))","filter(v=>EN_V?/en[-_]GB/i.test(v.lang):/"+C['region']+"/i.test(v.lang))"),
 ("  const u=new SpeechSynthesisUtterance(line);\n  const v=pickVoice(sex,BODIES.indexOf(b));if(v){u.voice=v;u.lang=v.lang}else u.lang='en-GB';",
  "  let v=pickVoice(sex,BODIES.indexOf(b)),say=line,en=false;if(!v&&SAY_EN[line]){EN_V=true;v=pickVoice(sex,BODIES.indexOf(b));EN_V=false;if(v){say=SAY_EN[line];en=true}}\n  const u=new SpeechSynthesisUtterance(say);if(v){u.voice=v;u.lang=v.lang}else u.lang=en?'en-GB':'"+C['locale']+"';"),
]
NOTE_EN="['C','C♯','D','E♭','E','F','F♯','G','G♯','A','B♭','B']"
def conventions(s,page):
    if C['notes']:
        n=json.dumps(C['notes'],ensure_ascii=False).replace('"',"'").replace(', ',',')
        s=s.replace('const NOTE='+NOTE_EN,'const NOTE='+n).replace('nm='+NOTE_EN,'nm='+n)
    s=s.replace("toLocaleString('en-GB'","toLocaleString('"+C['locale']+"'")
    s=re.sub(r"fillText\('[^']*',lp\.x\+Math\.cos\(la\)",f"fillText('{C['LR'][0]}',lp.x+Math.cos(la)",s)
    s=re.sub(r"fillText\('[^']*',lp\.x\+Math\.cos\(ra\)",f"fillText('{C['LR'][1]}',lp.x+Math.cos(ra)",s)
    if C['comma']:
        for fn in ('fmtSpeed','fmtDays'):
            if f'function {fn}(d){{' in s:
                s=s.replace(f'function {fn}(d){{',f'function {fn}(d){{return {fn}En(d).replace(/(\\d)\\.(\\d)/g,"$1,$2")}}\nfunction {fn}En(d){{',1)
        s=s.replace('dist.toFixed(dist<2?3:1)',"dist.toFixed(dist<2?3:1).replace('.',',')")
    return s

_b=open('/tmp/claude-0/dance_ball.js').read()
def lab_block(a,z):
    en=_b[a:z];tr=en
    for k in re.findall(r":'([^']*)'",en):
        if k not in LAB:sys.exit(f'{L}: no label for: '+k)
    for k,v in sorted(LAB.items(),key=lambda kv:-len(kv[0])):tr=tr.replace(":'"+k+"'",":'"+v+"'")
    return (en,tr)
_a=_b.index('const BALL_INST={');LABS=[lab_block(_a,_b.index('};',_a)+2)]
_a=_b.index('Object.assign(BALL_INST,{',_b.index('/* ================= COMPOSERS'));LABS.append(lab_block(_a,_b.index('});',_a)+3))

def tt_swap(s):
    i=s.index('/*TXT-START*/');j=s.index('/*TXT-END*/')+len('/*TXT-END*/')
    tr=open(H+'thinkers_txt.js').read().strip()
    keys=lambda t:sorted(re.findall(r"(?:^|[{,])\s*(\w+):['\"{]",t,re.M))
    if keys(s[i:j])!=keys(tr):sys.exit(f'{L}: thinkers texts have different keys from the English ones')
    return s[:i]+tr+s[j:]

PAGES=('index.html','flight.html','dance.html','help.html','privacy.html')
def relink(html):
    def app(m):
        tag=m.group(0)
        if ' lang=' in tag or 'hreflang=' in tag:return tag
        return tag.replace(B+m.group(1),B+L+'/'+m.group(1),1)
    return re.sub(r'<a [^>]*href="'+re.escape(B)+r'('+'|'.join(re.escape(p) for p in PAGES if p not in ('privacy.html',))+r'|)(?=["#])[^>]*>',app,html)

def body_swap(s,start,end,f,md5):
    i=s.index(start);j=s.index(end,i);eng=s[i:j]
    h=hashlib.md5(eng.encode()).hexdigest()
    if h!=md5:sys.exit(f'{L}: English body changed ({f}): update the translated bodies, then set md5 to {h}')
    return s[:i]+relink(open(H+f).read())+s[j:]

def apply(s,pairs,page,optional=False):
    for en,tr in pairs:
        if s.count(en)==0:
            if optional:continue
            sys.exit(f'{L} [{page}] not found: {en[:90]}')
        s=s.replace(en,tr)
    return s

PWA='<link rel="manifest" href="manifest.webmanifest">\n<meta name="theme-color" content="#090b18">\n<link rel="icon" type="image/png" href="../icons/favicon-48.png">\n<link rel="apple-touch-icon" href="../icons/apple-touch-icon.png">\n'
_ns={};_src=open(HP+'pl.py').read();exec(_src[:_src.index('\n',_src.index('PWA_HEAD='))],_ns)
PWA+=_ns['PWA_HEAD'].split('\n',4)[4]
FONTS=''
if L in CJK_FONTS:
    fam='SC' if L=='zh' else 'JP'
    FONTS=(f'<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family={CJK_FONTS[L]}&display=swap">\n'
           f'<style>:root{{--f-display:"GFS Didot","Noto Serif {fam}",Georgia,serif;--f-body:"Alegreya Sans","Noto Sans {fam}",system-ui,sans-serif}}'
           f'body{{line-break:strict;word-break:normal;overflow-wrap:anywhere}}</style>\n')
def wrap(s,split,title_en,title,desc,dst,alt):
    s=s.replace(f'<title>{title_en}</title>',f'<title>{title}</title>',1)
    assert f'<title>{title}</title>' in s
    i=s.index(split);head,body=s[:i],s[i:]
    if '[hidden]{display:none!important}' not in head:
        head=head.replace('<style>','<style>\n[hidden]{display:none!important}\nhtml,body{margin:0}\n',1)
    out=(f'<!doctype html>\n<html lang="{L}">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'+PWA+
         f'<meta name="description" content="{desc}">\n'+ALTS(alt)+head+FONTS+'</head>\n<body>\n'+body+'\n</body>\n</html>\n')
    os.makedirs(os.path.dirname(dst),exist_ok=True);open(dst,'w').write(out)

MD5=eval(open(HP+'md5.txt').read())
T,D=C['titles'],C['desc']
G=lambda *ks:[p for k in ks for p in GRP.get(k,[])]

s=open('/home/claude/music-of-the-spheres.html').read()
s=body_swap(s,'<div class="wrap">','<script>','body_2d.html',MD5['d2'])
s=tt_swap(s)
s=apply(s,G('A','Bp'),'2d');s=apply(s,SP,'2d speech');s=apply(s,G('FS','D2'),'2d');s=apply(s,G('T'),'2d',True);s=apply(s,NAMES,'2d',True);s=apply(s,G('A','Bp','FS','D2','FL','DA'),'2d',True)
s=conventions(s,'2d');open(H+'out_2d.html','w').write(s)
wrap(s,'<div class="wrap">','Music of the Spheres',T[0],D[0],R+L+'/index.html','')

s=open('/home/claude/flight.html').read()
s=body_swap(s,'<canvas id="scene"','<script src=','body_fly.html',MD5['fl'])
s=apply(s,G('A','Bp'),'fly');s=apply(s,SP,'fly speech');s=apply(s,G('FS','FL'),'fly');s=apply(s,G('T'),'fly',True);s=apply(s,NAMES,'fly',True);s=apply(s,G('A','Bp','FS','D2','FL','DA'),'fly',True)
s=conventions(s,'fly');open(H+'out_fly.html','w').write(s)
wrap(s,'<canvas id="scene"','Flight Through the Spheres',T[1],D[1],R+L+'/flight.html','flight.html')

s=open('/home/claude/dance.html').read()
s=body_swap(s,'<div class="wrap">','<script>','body_dance.html',MD5['da'])
s=apply(s,G('A','DA'),'dance');s=apply(s,LABS,'dance');s=apply(s,G('T'),'dance',True);s=apply(s,NAMES,'dance',True);s=apply(s,G('A','Bp','FS','D2','FL','DA'),'dance',True)
s=conventions(s,'dance');open(H+'out_dance.html','w').write(s)
wrap(s,'<div class="wrap">','Dance of the Spheres',T[2],D[2],R+L+'/dance.html','dance.html')

hh=open('/tmp/claude-0/help_head.html').read()
wrap(hh+relink(open(H+'help_body.html').read()),'<div class="wrap">','How the Spheres Sing',T[3],D[3],R+L+'/help.html','help.html')
print(L,'ok')
