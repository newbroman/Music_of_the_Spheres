import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const B=process.argv[2]||'http://localhost:8123/';
for(const [pg,pre] of [['index.html',null],['flight.html',null],['dance.html','waltz']]){
  const page=await browser.newPage({viewport:{width:1280,height:900},acceptDownloads:true});const errs=[];page.on('pageerror',e=>errs.push(String(e)));
  await page.goto(B+"pl/"+pg);await page.waitForTimeout(pg==='flight.html'?2500:800);
  if(pre)await page.click(`#style button[data-v="${pre}"]`);
  await page.click('#recBtn');await page.waitForTimeout(8000);
  const lbl=await page.textContent('#recBtn');await page.click('#recBtn');await page.waitForTimeout(800);
  const info=await page.evaluate(async()=>{const a=document.querySelector('#recPanel audio'),l=document.querySelector('#recPanel a[download]');if(!a)return 'no panel';
    const ab=await (await fetch(a.src)).arrayBuffer();const c=new OfflineAudioContext(2,48000,48000);let buf;try{buf=await c.decodeAudioData(ab)}catch(e){return 'decode failed '+e}
    const d=buf.getChannelData(0);let s=0;for(const x of d)s+=x*x;return {file:l.download,bytes:ab.byteLength,secs:buf.duration.toFixed(1),rms:Math.sqrt(s/d.length).toFixed(3)}});
  const dl=page.waitForEvent('download');await page.click('#recPanel a[download]');const d=await dl;
  console.log(pg,'| while recording:',lbl.trim(),'|',JSON.stringify(info),'| download:',d.suggestedFilename(),'| errors',errs.length?errs:'none');
  if(pg==='dance.html')await page.screenshot({path:'rec_dance.png'});
  await page.close();
}
await browser.close();
