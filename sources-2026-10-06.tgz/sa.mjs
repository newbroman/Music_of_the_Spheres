import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch();const p=await b.newPage({viewport:{width:420,height:900}});
const errs=[];p.on('pageerror',e=>errs.push(String(e)));
await p.goto('file:///home/claude/music_of_the_spheres/index.html');await p.waitForTimeout(800);
console.log('banner visible:',await p.isVisible('#aud'),'| hscroll:',await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),'| errors',errs);
await p.screenshot({path:'sa.png'});await b.close();
