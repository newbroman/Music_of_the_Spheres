import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch();const ctx=await b.newContext();const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
const t0=Date.now();await p.goto('http://localhost:8123/index.html?notour');
const st=await p.evaluate(async()=>{const r=await navigator.serviceWorker.ready;return r.active.state});
console.log('active after',Date.now()-t0,'ms',st);
for(let i=0;i<40;i++){const n=await p.evaluate(async()=>{let n=0;for(const k of await caches.keys())n+=(await (await caches.open(k)).keys()).length;return n});if(i%5==0||n>=419)console.log('cached',n);if(n>=419)break;await p.waitForTimeout(1000)}
await ctx.setOffline(true);await p.goto('http://localhost:8123/de/dance.html?notour');console.log('offline title:',await p.title());
await p.goto('http://localhost:8123/flight.html?notour');console.log('offline title:',await p.title());console.log('errors',errs.slice(0,3));await b.close();
