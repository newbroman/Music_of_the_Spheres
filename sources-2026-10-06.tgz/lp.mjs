import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
for(const mobile of [false,true]){
  const page=await browser.newPage(mobile?{viewport:{width:400,height:820},hasTouch:true,isMobile:true,userAgent:'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36'}:{});
  const errs=[];page.on('pageerror',e=>errs.push(String(e)));
  await page.addInitScript(()=>{const Orig=window.AudioContext;window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();this.__an.fftSize=8192;}};const oc=AudioNode.prototype.connect;AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return res};});
  await page.goto('file:///tmp/claude-0/mots_dbg.html');await page.waitForTimeout(1000);
  await page.click('#begin');await page.waitForTimeout(3000);
  const r=await page.evaluate(async()=>{const an=window.__ac.__an,b=new Float32Array(an.fftSize);let worst=0,rr=0,n=0;for(let k=0;k<25;k++){await new Promise(r=>setTimeout(r,200));an.getFloatTimeDomainData(b);let s=0,m=0,mx=0;for(let i=1;i<b.length;i++){const x=Math.abs(b[i]-b[i-1]);m+=x;mx=Math.max(mx,x);s+=b[i]*b[i]}m/=b.length;worst=Math.max(worst,mx/m);rr+=Math.sqrt(s/b.length);n++}return {rms:(rr/n).toFixed(4),worst:worst.toFixed(1)}});
  console.log(mobile?'PHONE':'DESKTOP','2D:',await page.evaluate(()=>__dbg()),JSON.stringify(r),errs);
  await page.close();
}
await browser.close();
