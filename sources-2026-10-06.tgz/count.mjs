import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const url=process.argv[2];
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const page = await browser.newPage();
await page.addInitScript(()=>{
  window.__cnt={osc:0,oscStop:0,bq:0,hrtf:0,pan:0,buf:0};
  const P=OscillatorNode.prototype;const s0=P.start,st=P.stop;
  P.start=function(...a){__cnt.osc++;this.onended=()=>__cnt.oscStop++;return s0.apply(this,a)};
  const C=BaseAudioContext.prototype;
  const cb=C.createBiquadFilter;C.createBiquadFilter=function(){__cnt.bq++;return cb.call(this)};
  const cp=C.createPanner;C.createPanner=function(){__cnt.pan++;const p=cp.call(this);setTimeout(()=>{if(p.panningModel==='HRTF')__cnt.hrtf++},0);return p};
});
await page.goto(url);await page.waitForTimeout(400);
await page.click('#voices button[data-v="human"]');await page.waitForTimeout(3000);
console.log(url.split('/').pop(),JSON.stringify(await page.evaluate(()=>({...__cnt,oscRunning:__cnt.osc-__cnt.oscStop}))));
await browser.close();
