import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch();
for(const [url,w] of [['index.html?notour',1300],['flight.html',1300],['dance.html',390],['cy/help.html',1300],['pl/index.html?notour#kepler',390]]){
  const p=await b.newPage({viewport:{width:w,height:820}});const errs=[];p.on('pageerror',e=>errs.push(String(e)));
  await p.goto('http://localhost:8123/'+url);await p.waitForTimeout(700);
  await p.click('#langMenu summary');await p.waitForTimeout(200);
  const info=await p.evaluate(()=>({sum:document.querySelector('#langMenu summary').textContent,links:[...document.querySelectorAll('#langMenu a')].map(a=>a.textContent+'→'+a.getAttribute('href').replace('https://newbroman.github.io/Music_of_the_Spheres/','/')),left:[...document.querySelectorAll('body a[hreflang]')].filter(a=>!a.closest('#langMenu')).length,box:(r=>[Math.round(r.left),Math.round(r.right)])(document.querySelector('#langMenu .lmenu').getBoundingClientRect())}));
  await p.screenshot({path:'/tmp/claude-0/lang_'+url.replace(/[^a-z]/g,'_')+'.png'});
  console.log(url,w,JSON.stringify(info),errs);await p.close();
}
const ctx=await b.newContext({locale:'pl-PL'});const p=await ctx.newPage();await p.goto('http://localhost:8123/dance.html');await p.waitForTimeout(600);console.log('hint:',await p.evaluate(()=>document.getElementById('langHint')?.textContent));
await b.close();
