import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:1200,height:760}});
const errs=[];page.on('pageerror',e=>errs.push(String(e)));
await page.goto('file:///home/claude/flight.html');await page.waitForTimeout(2000);
await page.click('#begin');await page.waitForTimeout(1500);
console.log('HUD:',(await page.innerText('#zodTxt')).replace(/\n/g,' / '));
await page.click('#navBtn');await page.click('#dest button[data-id="sun"]');await page.waitForTimeout(500);
// rise above for the overview with the zodiac ring around
await page.click('#courseChips [data-c="above"]');await page.waitForTimeout(9000);
await page.screenshot({path:'z_above.png'});
// look along the ecliptic from near Earth
await page.click('#navBtn');await page.click('#dest button[data-id="mars"]');await page.waitForTimeout(9000);
const box=await page.locator('#scene').boundingBox();
await page.mouse.move(box.width/2,box.height/2);await page.mouse.down();await page.mouse.move(box.width/2+520,box.height/2+60,{steps:12});await page.mouse.up();await page.waitForTimeout(800);
await page.screenshot({path:'z_mars.png'});
console.log('HUD now:',(await page.innerText('#zodTxt')).replace(/\n/g,' / '));
console.log('errors',errs);await browser.close();
