import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required','--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});
const ctx=await b.newContext({viewport:{width:360,height:640},deviceScaleFactor:3,isMobile:true,hasTouch:true});
const shot=async(url,fn,name)=>{const p=await ctx.newPage();await p.goto('http://localhost:8123/'+url);await p.waitForTimeout(900);if(fn)await fn(p);await p.screenshot({path:'/home/claude/music_of_the_spheres/store/'+name});await p.close()};
await shot('index.html',async p=>{await p.click('#begin');await p.waitForTimeout(1500);await p.evaluate(()=>document.getElementById('orrery').scrollIntoView({block:'center'}));await p.waitForTimeout(600)},'1-dial.png');
await shot('index.html',async p=>{await p.click('#begin');await p.click('#timeline button:nth-child(3)');await p.waitForTimeout(2000);await p.evaluate(()=>document.getElementById('timeline').scrollIntoView({block:'start'}));await p.waitForTimeout(500)},'2-plato.png');
await shot('dance.html',async p=>{await p.click('#style button[data-v="mozart"]');await p.click('#play');await p.waitForTimeout(2500);await p.evaluate(()=>document.getElementById('dial').scrollIntoView({block:'center'}));await p.waitForTimeout(500)},'3-dance.png');
await shot('flight.html',async p=>{await p.click('#begin').catch(()=>{});await p.waitForTimeout(3500)},'4-flight.png');
await b.close();
