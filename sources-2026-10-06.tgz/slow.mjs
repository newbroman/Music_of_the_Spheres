import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
for(const pre of ['','pl/','cy/']){const p=await b.newPage();const errs=[];p.on('pageerror',e=>errs.push(String(e)));
await p.goto(`http://localhost:8123/${pre}index.html?notour`);await p.waitForTimeout(800);
const a=await p.textContent('#speedOut');await p.click('#realTime');const r=await p.textContent('#speedOut');
await p.evaluate(()=>{const s=document.getElementById('speed');s.value=60;s.dispatchEvent(new Event('input'))});const m=await p.textContent('#speedOut');
await p.click('.tl-chip[data-t="today"]');await p.waitForTimeout(300);const t=await p.textContent('#speedOut');
const f=await b.newPage();await f.goto(`http://localhost:8123/${pre}flight.html`);await f.waitForTimeout(800);await f.evaluate(()=>{const s=document.getElementById('speed');s.value=0;s.dispatchEvent(new Event('input'))});const fl=await f.textContent('#speedOut');
console.log(pre||'en','plato:',a,'| real:',r,await p.textContent('#realTime'),'| slider 60:',m,'| today:',t,'| flight min:',fl,errs);await p.close();await f.close()}
await b.close();
