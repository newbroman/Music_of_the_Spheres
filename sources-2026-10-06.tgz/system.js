
/* ---------- moon systems: each planet and its moons as a small solar system ---------- */
const SYS={id:null,moons:[],voices:[],savedSpeed:null,vp:'centre',sel:null,rmax:1};
// turn a moon's name into singable tokens for the child voices
function g2p(name){
  let w=name.toLowerCase().replace(/\(.*\)/,'').trim().split(/\s/)[0].normalize('NFD').replace(/[̀-ͯ]/g,'');
  w=w.replace(/ph/g,'f').replace(/th/g,'T').replace(/ch/g,'k').replace(/qu/g,'k').replace(/x/g,'ks').replace(/c/g,'k').replace(/y/g,'i').replace(/j/g,'i').replace(/w/g,'u').replace(/v/g,'f').replace(/(.)\1/g,'$1');
  const toks=[];for(const ch of w){if('aeiou'.includes(ch))toks.push(ch);else if(ch==='T')toks.push('th');else if('sztpkdgbmnlrhf'.includes(ch))toks.push(ch)}
  for(let k=toks.length-1;k>=0;k--)if('aeiou'.includes(toks[k])){toks[k]+=':';break}
  return toks.join(' ')||'a:';
}
function sysPitch(P){let f=S.F*1.33*Math.pow(1.77/Math.abs(P),.33);while(f<55)f*=2;while(f>1400)f/=2;return quantize(f)}
// moons orbit in their planet's equatorial plane, tipped by the planet's axial tilt
function moonPos(b,m,jd){
  const th=TAU*((jd-J2000)/m.P+m.ph0), e=(b.obl||0)*DEG;
  return {x:m.a*Math.cos(th),y:m.a*Math.sin(th)*Math.cos(e),z:m.a*Math.sin(th)*Math.sin(e)};
}
function sysListener(){
  if(SYS.vp==='centre')return {x:0,y:0,z:0};
  return SYS.moons[SYS.vp].pos;
}
// facing: toward the Sun as seen from the planet, plus your head turn
function sysFacing(){const pp=P[SYS.id];return Math.atan2(-pp.y,-pp.x)+S.turn*DEG}
function enterSystem(id){
  const b=byId[id];if(!b.moons.length)return;
  if(S.audition)endAudition();
  SYS.id=id;SYS.vp='centre';SYS.sel=null;
  SYS.moons=b.moons.map((m,k)=>({m,k,id:'moon:'+id+':'+k,pos:moonPos(b,m,S.jd)}));
  SYS.rmax=Math.max(...b.moons.map(m=>m.a))*1.15;
  // slow time so the quickest moon takes about four seconds per orbit
  SYS.savedSpeed=S.speed;
  const minP=Math.min(...b.moons.map(m=>Math.abs(m.P)));
  setSpeed(Math.max(.02,minP/4));
  if(!audioOn)startAudio();
  buildSystemVoices();
  renderInfo();renderAud();
}
function leaveSystem(){
  if(!SYS.id)return;
  killSystemVoices();
  SYS.id=null;SYS.moons=[];
  if(SYS.savedSpeed)setSpeed(SYS.savedSpeed);
  renderInfo();renderAud();
}
function moonBody(b,sm){
  const m=sm.m, v0=(m.name.toLowerCase().match(/[aeiou]/)||['a'])[0];
  return {id:sm.id,name:m.name,god:m.name.split(' ')[0],kind:'moonv',R:m.R,sizeN:Math.max(0,m.sizeN),
    vowel:v0==='a'?'ah':v0,
    // nearly every major moon is tidally locked, so its day equals its orbit; Hyperion tumbles chaotically
    rot:m.name==='Hyperion'?13*24:Math.abs(m.P)*24,
    hv:{type:'child',tilt:1.1,vib:[5.6,.02],breath:.08,jit:m.name==='Hyperion'?.02:.004,syl:.5,rest:2.2,ens:0,words:g2p(m.name)}};
}
function buildSystemVoices(){
  if(!AC||!SYS.id)return;
  killSystemVoices();
  const b=byId[SYS.id];
  SYS.voices=SYS.moons.map(sm=>{
    const mb=moonBody(b,sm);P[mb.id]={f:sysPitch(sm.m.P)};
    const v={pan:mkPanner(true),body:mb,part:null};v.vol=mkGain(0,v.pan);
    v.rate=Math.min(7,6*Math.pow(3.9/Math.abs(mb.rot),.45));
    if(sm.m.name==='Hyperion')v.rate=1.7;
    return v;
  });
  SYS.mode=S.voices;
}
function killSystemVoices(){
  SYS.voices.forEach(v=>{killPart(v.part);tgt(v.vol.gain,0,.08);const pan=v.pan;setTimeout(()=>{try{pan.disconnect()}catch(e){}const i=PANNERS.findIndex(x=>x.p===pan);if(i>=0)PANNERS.splice(i,1)},700)});
  SYS.voices=[];
}
function updateSystemAudio(){
  const now=AC.currentTime, b=byId[SYS.id], pp=P[SYS.id], ang=sysFacing();
  setListener(ang);
  if(SYS.mode!==S.voices)buildSystemVoices();
  const L=sysListener(), law=.25+.85*S.dist;
  // every other body falls silent while you are inside a system
  BODIES.forEach(x=>{
    const v=V[x.id];
    if(x.id!==SYS.id){tgt(v.vol.gain,0,.1);tgt(v.moonVol.gain,0,.1);(x.moons||[]).forEach(m=>tgt(m.hg.gain,0,.1));
      if(v.part&&now-(v.born||0)>1){killPart(v.part);v.part=null;v.mode=null}return}
    // the planet hums at the centre of its system
    if(!v.part)buildPart(x,v);
    const a=audioDir({x:0,y:0,z:0},L);setPos(v.pan,a.x,a.y,a.z);
    const g=a.self?.5:Math.min(.8,Math.pow((x.R/a.d)/.002,law)*.5);
    tgt(v.vol.gain,.07*g,.15);tgt(v.moonVol.gain,0,.1);(x.moons||[]).forEach(m=>tgt(m.hg.gain,0,.1));
    const I=v.mode==='instrument'?v.part:null;
    if(I){tgt(I.o1.frequency,pp.f,.07);tgt(I.o2.frequency,pp.f,.07);if(I.o3)tgt(I.o3.frequency,pp.f,.07)}
    if(v.mode==='human')humanTick(v.part.h,pp.f,1,now);
  });
  // reference loudness: the moon that looks biggest from the planet's centre sings at full voice
  const ref=Math.max(...SYS.moons.map(sm=>sm.m.R/sm.m.a));
  SYS.moons.forEach((sm,k)=>{
    const v=SYS.voices[k], mb=v.body, f=P[mb.id].f=sysPitch(sm.m.P);
    const isMe=SYS.vp===k;
    const a=audioDir(sm.pos,L);setPos(v.pan,a.x,a.y,a.z,.06);
    const g=v.gRel=isMe?.55:Math.min(1.6,Math.pow((sm.m.R/Math.max(a.d,1))/ref,law));
    const want=!S.muted.has(mb.id)&&g>(v.part?.025:.035);
    if(want&&!v.part){v.part=S.voices==='human'?buildHumanPart(mb,v):buildInst(mb,v,true);v.mode=S.voices;v.born=now}
    else if(!want&&v.part&&now-v.born>2.5){killPart(v.part);v.part=null}
    if(!v.part){tgt(v.vol.gain,0,.1);return}
    const I=v.mode==='instrument'?v.part:null;
    if(I){tgt(I.o1.frequency,f,.07);tgt(I.o2.frequency,f,.07);if(I.o3)tgt(I.o3.frequency,f,.07);tgt(I.vd.gain,f*.004,.2)}
    else humanTick(v.part.h,f,1,now);
    tgt(v.vol.gain,.075*g*S.groups.moons.vol/(.8),.12);
  });
  // Apollo, the Sun, stays where the Sun is
  const sd={x:-pp.x,y:-pp.y,z:-pp.z}, sl=Math.hypot(sd.x,sd.y,sd.z)||1;
  setPos(sunV.pan,sd.x/sl,sd.z/sl,-sd.y/sl);
  const [d1,d2,d3]=droneFreqs(), sp=sunV.part;
  if(sunV.mode==='instrument'){tgt(sp.d1.frequency,d1,.3);tgt(sp.d2.frequency,d2,.3);tgt(sp.d3.frequency,d3,.3)}
  else if(sp&&S.drone){humanTick(sp.hums[0],d3,1,now);humanTick(sp.hums[1],d2,1,now)}
  tgt(sunV.vol.gain,S.drone?.03:0,.3);
  POOL.forEach(s=>tgt(s.g.gain,0,.1));
}
function sysProj(x,y,z){
  const r=Math.hypot(x,y,z), r0=byId[SYS.id].R*3, s=r>0?RR*.92*Math.log(1+r/r0)/Math.log(1+SYS.rmax/r0)/r:0;
  const X=x*s,Y=y*s,Z=z*s,c=Math.cos(S.az),sn=Math.sin(S.az),X2=X*c-Y*sn,Y2=X*sn+Y*c,st=Math.sin(S.tilt),ct=Math.cos(S.tilt);
  return {x:CX+X2,y:CY-(Y2*st+Z*ct),d:Y2*ct-Z*st};
}
function drawSystem(g,t){
  const b=byId[SYS.id], pp=P[SYS.id];
  SYS.moons.forEach(sm=>sm.pos=moonPos(b,sm.m,S.jd));
  screen={};
  // orbits
  SYS.moons.forEach(sm=>{
    const m=sm.m;g.strokeStyle=SYS.sel===sm.k?'rgba(201,152,79,.7)':'rgba(233,225,204,.16)';g.lineWidth=1;g.beginPath();
    for(let k=0;k<=96;k++){const th=TAU*k/96, e=(b.obl||0)*DEG;const q=sysProj(m.a*Math.cos(th),m.a*Math.sin(th)*Math.cos(e),m.a*Math.sin(th)*Math.sin(e));k?g.lineTo(q.x,q.y):g.moveTo(q.x,q.y)}
    g.stroke();
  });
  // the planet at the centre
  const c=sysProj(0,0,0), pr=Math.max(10,Math.min(34,RR*.06*Math.pow(b.R/20000,.35)));
  const gr=g.createRadialGradient(c.x-pr*.3,c.y-pr*.3,pr*.1,c.x,c.y,pr);gr.addColorStop(0,b.color);gr.addColorStop(1,hexA(b.color,.55));
  if(b.id==='saturn'){g.strokeStyle=hexA(b.color,.75);g.lineWidth=2;g.beginPath();g.ellipse(c.x,c.y,pr*2.2,pr*2.2*Math.max(.15,Math.sin(S.tilt)*.4),-.35,0,TAU);g.stroke()}
  g.fillStyle=gr;g.beginPath();g.arc(c.x,c.y,pr,0,TAU);g.fill();
  screen[SYS.id]=c;
  g.font='15px "GFS Didot",Georgia,serif';g.fillStyle='rgba(233,225,204,.9)';g.textAlign='center';g.textBaseline='top';g.fillText(b.god,c.x,c.y+pr+6);
  // the direction of the Sun
  const sa=Math.atan2(-pp.y,-pp.x)+S.az, sx=CX+Math.cos(sa)*RR*1.0, sy=CY-Math.sin(sa)*RR*Math.sin(S.tilt);
  const sg=g.createRadialGradient(sx,sy,0,sx,sy,14);sg.addColorStop(0,'rgba(255,236,190,1)');sg.addColorStop(1,'rgba(201,152,79,0)');g.fillStyle=sg;g.beginPath();g.arc(sx,sy,14,0,TAU);g.fill();
  g.font='11px "Alegreya Sans",sans-serif';g.fillStyle='rgba(233,225,204,.7)';g.fillText('toward the Sun',sx,sy+14);
  // moons, nearest last
  SYS.moons.map(sm=>({sm,s:sysProj(sm.pos.x,sm.pos.y,sm.pos.z)})).sort((p,q)=>q.s.d-p.s.d).forEach(({sm,s})=>{
    const v=SYS.voices[sm.k], r=Math.max(2.5,Math.min(9,1.5+2.2*Math.log10(Math.max(sm.m.R,5)/20)));
    screen['moon:'+sm.k]=s;
    if(v&&v.part){const ph=(t/1000*(v.rate||1))%1,w=Math.sin(ph*TAU)*.5+.5;g.strokeStyle=`rgba(233,225,204,${.15+.3*w})`;g.lineWidth=1;g.beginPath();g.arc(s.x,s.y,r+4+w*5,0,TAU);g.stroke()}
    g.fillStyle=v&&v.part?'#ece4d0':'rgba(233,225,204,.45)';g.beginPath();g.arc(s.x,s.y,r,0,TAU);g.fill();
    if(SYS.vp===sm.k){g.strokeStyle='#62a597';g.lineWidth=1.5;g.beginPath();g.arc(s.x,s.y,r+9,0,TAU);g.stroke()}
    g.font='12px "Alegreya Sans",sans-serif';g.textAlign='left';g.textBaseline='middle';g.fillStyle='rgba(233,225,204,.8)';
    g.fillText(sm.m.name.split(' ')[0],s.x+r+6,s.y);
  });
  // listener
  const L=sysListener(), lp=sysProj(L.x,L.y,L.z);drawListener(g,lp,sysFacing()+S.az);
}
function setSpeed(d){
  const v=Math.max(0,Math.min(1000,Math.round((Math.log10(d)+1)/5*1000)));
  $('speed').value=v;S.speed=Math.pow(10,-1+v/1000*5);if(d<.1)S.speed=d;$('speedOut').textContent=fmtSpeed(S.speed);
}
function sysInfoHTML(){
  const b=byId[SYS.id];
  const rows=SYS.moons.map(sm=>{const v=SYS.voices[sm.k];const st=!AC?'':(v&&v.part?noteName(P[v.body.id].f)+' · '+((x=>(x>=0?'+':'')+x)(Math.round(20*Math.log10(Math.max(1e-4,v.gRel)))))+' dB':'faint');
    const per=Math.abs(sm.m.P)<2?fmt(Math.abs(sm.m.P)*24,1)+' h':fmt(Math.abs(sm.m.P),1)+' d';
    return `<div class="vrow${SYS.vp===sm.k?' sel':''}" data-moon="${sm.k}" style="grid-template-columns:minmax(0,1fr) auto auto auto"><span class="nm">${sm.m.name} <span>${per}${sm.m.P<0?' · retrograde':''} · ${fmt(sm.m.R,0)} km</span></span><span class="nt" id="sm_${sm.k}">${st}</span><button class="ms" data-act="here" title="Listen from ${sm.m.name}" aria-pressed="${SYS.vp===sm.k}">◎</button><span></span></div>`}).join('');
  return `<div>
      <div class="greek">${b.greek}</div>
      <h3>The system of ${b.god}</h3>
      <div class="sub">${b.name} and ${b.moons.length===1?'its moon':'its '+b.moons.length+' moons'}, as a small solar system</div>
      <div class="voice">Each moon sings, pitched by its orbital speed and as loud as it looks from where you listen. ${b.god} hums at the centre. Time is slowed so the quickest moon circles in about four seconds.</div>
      <div class="acts"><button class="btn" id="sysCentre">${SYS.vp==='centre'?'Listening from '+b.god:'Listen from '+b.god}</button><button class="btn" id="sysLeave" style="border-color:var(--bronze);color:var(--bronze)">Back to the solar system</button></div>
    </div>
    <div class="roster" id="sysRoster" style="max-height:none">${rows}</div>`;
}
function wireSysInfo(){
  $('sysLeave').onclick=leaveSystem;
  $('sysCentre').onclick=()=>{SYS.vp='centre';renderInfo()};
  $('sysRoster').onclick=e=>{const row=e.target.closest('.vrow');if(!row)return;const k=+row.dataset.moon;SYS.vp=SYS.vp===k?'centre':k;renderInfo()};
}
function tickSysInfo(){
  SYS.moons.forEach(sm=>{const el=$('sm_'+sm.k),v=SYS.voices[sm.k];if(!el||!v)return;el.textContent=v.part?noteName(P[v.body.id].f)+' · '+((x=>(x>=0?'+':'')+x)(Math.round(20*Math.log10(Math.max(1e-4,v.gRel)))))+' dB':'faint'});
}
