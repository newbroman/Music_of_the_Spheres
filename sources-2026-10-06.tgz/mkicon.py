from PIL import Image, ImageDraw, ImageFilter
import math
S=1024
def art(scale):
    im=Image.new('RGBA',(S,S),(9,11,24,255));d=ImageDraw.Draw(im)
    c=S/2
    # glow
    g=Image.new('RGBA',(S,S),(0,0,0,0));gd=ImageDraw.Draw(g)
    for r,a in [(150,40),(110,70),(80,110)]:gd.ellipse([c-r*scale,c-r*scale,c+r*scale,c+r*scale],fill=(233,190,110,a))
    g=g.filter(ImageFilter.GaussianBlur(40*scale));im.alpha_composite(g)
    radii=[120,175,235,300,370,440]
    planets=[(-40,(200,200,210)),(35,(233,208,147)),(150,(110,160,220)),(250,(214,110,80)),(300,(222,170,120)),(200,(230,210,160))]
    for R,(ang,col) in zip(radii,planets):
        R*=scale;d.ellipse([c-R,c-R,c+R,c+R],outline=(201,152,79,200),width=int(6*scale))
    for R,(ang,col) in zip(radii,planets):
        R*=scale;x=c+R*math.cos(math.radians(ang));y=c-R*math.sin(math.radians(ang));r=(16+R/40)*1
        d.ellipse([x-r-6*scale,y-r-6*scale,x+r+6*scale,y+r+6*scale],fill=(9,11,24,255));d.ellipse([x-r,y-r,x+r,y+r],fill=col)
    r=58*scale;d.ellipse([c-r,c-r,c+r,c+r],fill=(246,214,140,255))
    return im
any_=art(1.0)
mask=Image.new('L',(S,S),0);ImageDraw.Draw(mask).rounded_rectangle([0,0,S-1,S-1],radius=200,fill=255)
a=any_.copy();a.putalpha(mask)
m=art(0.78)  # maskable: everything inside the safe circle
out='/home/claude/music_of_the_spheres/icons/'
for n in (192,512):
    a.resize((n,n),Image.LANCZOS).save(out+f'icon-{n}.png')
    m.resize((n,n),Image.LANCZOS).save(out+f'icon-{n}-maskable.png')
m.convert('RGB').resize((180,180),Image.LANCZOS).save(out+'apple-touch-icon.png')
a.resize((48,48),Image.LANCZOS).save(out+'favicon-48.png')
