import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const page=await browser.newPage({viewport:{width:1300,height:950}});
const errs=[];page.on('pageerror',e=>errs.push(String(e)));page.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
await page.addInitScript(()=>{const Orig=window.AudioContext;window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();this.__an.fftSize=4096;}};const oc=AudioNode.prototype.connect;AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return res};});
await page.goto('file:///home/claude/dance.html');await page.waitForTimeout(800);
const lv=()=>page.evaluate(()=>{const an=__ac.__an,b=new Float32Array(an.fftSize);an.getFloatTimeDomainData(b);let s=0,pk=0;for(const x of b){s+=x*x;pk=Math.max(pk,Math.abs(x))}return Math.sqrt(s/b.length).toFixed(3)+'/'+pk.toFixed(2)});
for(const style of ['trance','house','techno']){
  await page.click(`#style button[data-v="${style}"]`);
  await page.click('#play');const t0=Date.now();const rows=[];
  for(let k=0;k<(style==='trance'?40:20);k++){await page.waitForTimeout(1000);rows.push(`${await page.textContent('#secTxt')}@${(await page.textContent('#barTxt')).replace('bar ','')} ${await lv()}`)}
  const bars=+(await page.textContent('#barTxt')).replace('bar ','');const secs=(Date.now()-t0)/1000;
  console.log(`\n${style.toUpperCase()}: ${bars} bars in ${secs.toFixed(1)}s (expected ~${(secs/(240/({trance:138,house:124,techno:130}[style]))).toFixed(1)})`);
  console.log(rows.join(' | '));
  if(style==='trance')await page.screenshot({path:'d_trance.png'});
  await page.click('#play');await page.waitForTimeout(400);
}
console.log('\nprog:',await page.innerText('#prog'));console.log('key:',await page.innerText('#keyTxt'));
console.log('errors',errs);await browser.close();
