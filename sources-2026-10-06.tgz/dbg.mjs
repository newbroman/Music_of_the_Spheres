import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const page=await browser.newPage({viewport:{width:1300,height:950}});
const errs=[];page.on('pageerror',e=>errs.push(String(e)));page.on('console',m=>errs.push(m.type()+': '+m.text()));
await page.goto('file:///home/claude/dance.html');await page.waitForTimeout(1500);
await page.click('#play');await page.waitForTimeout(1500);
console.log(await page.textContent('#play'),await page.textContent('#barTxt'));console.log(errs.slice(0,8));await browser.close();
