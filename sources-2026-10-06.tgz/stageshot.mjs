import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const p=await b.newPage({viewport:{width:390,height:844}});await p.goto('http://localhost:8123/dance.html');await p.waitForTimeout(600);
await p.click('#stageBtn');await p.waitForTimeout(300);await p.screenshot({path:'stage_phone.png'});
await p.close();await b.close();
