def LANG_JS():
    import re as _r,json as _j
    av=open('/tmp/claude-0/langs.txt').read().split()
    s=open('/tmp/claude-0/lang.js').read()
    return '<script>\n'+_r.sub(r"/\*LANGS\*/.*?/\*LANGS-END\*/","/*LANGS*/"+_j.dumps(av)+"/*LANGS-END*/",s)+'</script>\n'
# Generate the Welsh pages from the built English ones, in the same way as pl/pl.py builds the Polish ones.
# The English source strings come from the Polish build's own pair lists (so both stay in step with the English pages);
# the Welsh replacements are in strings_cy.json, labels_cy.json, stage_T_cy.js and the hand-translated bodies here.
import hashlib, sys, os, re, json
H='/tmp/claude-0/cy/'; HP='/tmp/claude-0/pl/'
B='https://newbroman.github.io/Music_of_the_Spheres/'
R='/home/claude/music_of_the_spheres/'

src=open(HP+'pl.py').read()
ns={};exec(src[:src.index("# the ballroom band labels")].replace("H='/tmp/claude-0/pl/'","H='"+HP+"'"),ns)
EN_ITEMS=json.load(open(H+'strings_en.json'));CY=json.load(open(H+'strings_cy.json'))
BY_EN={it['en']:CY[it['id']] for it in EN_ITEMS}
LAB=json.load(open(H+'labels_cy.json'))
_st=open(H+'stage_T_cy.js').read();_i=_st.index('\nconst T={rec:')
STAGE_CY=_st[:_i].strip();REC_CY=_st[_i:].strip()
_s=open('/tmp/claude-0/stage.js').read();_a=_s.index('const T={');STAGE_EN=_s[_a:_s.index("close:'Close'};",_a)+len("close:'Close'};")]
_r=open('/tmp/claude-0/recorder.js').read();_a=_r.index('const T={');REC_EN=_r[_a:_r.index('};',_a)+2]

def welsh(group):
    out=[]
    for en,_pl in ns[group]:
        if en in BY_EN:out.append((en,BY_EN[en]))
    return out

A=welsh('A');Bp=welsh('Bp');FS=welsh('FS');FS=[("return 'real time';","return 'amser go iawn';"),("+'× real time';","+'× amser go iawn';"),("+' min / s';","+' mun / e';")]+FS;D2=welsh('D2');FL=welsh('FL');DA=welsh('DA')
COMMON_T=[(REC_EN,REC_CY),(STAGE_EN,STAGE_CY)]
D2+=COMMON_T+[("rt.textContent='Real time'","rt.textContent='Amser go iawn'"),tuple(open(H+'tour_T.txt').read().split('\n@@\n')),("g.fillText('L',","g.fillText('C',"),("x.toLocaleString('en-GB',","x.toLocaleString('cy-GB',")]
FL+=COMMON_T+[("+'× light speed':Math.round(v).toLocaleString('en-GB')+' km/s'","+'× cyflymder golau':Math.round(v).toLocaleString('cy-GB')+' km/s'")]
DA+=COMMON_T

# speech: a Welsh voice if the device has one, otherwise the god speaks the English line in an English voice
SAY={}
for en,cy in A:
    if en.startswith('"I am'):SAY[cy[1:-1].replace("\\'","'")]=en[1:-1].replace("\\'","'")
SP=[
 ("const FEMALE=/female|","const FEMALE=/female|nia|"),
 ("const MALE=/(^|\\W)male|","const MALE=/(^|\\W)male|aled|gwynfor|"),
 ("function pickVoice(sex,seed){","let EN_V=false;const SAY_EN="+json.dumps(SAY,ensure_ascii=False)+";\nfunction pickVoice(sex,seed){"),
 ("filter(v=>/^en/i.test(v.lang))","filter(v=>EN_V?/^en/i.test(v.lang):/^cy/i.test(v.lang))"),
 ("filter(v=>/en[-_]GB/i.test(v.lang))","filter(v=>EN_V?/en[-_]GB/i.test(v.lang):true)"),
 ("  const u=new SpeechSynthesisUtterance(line);\n  const v=pickVoice(sex,BODIES.indexOf(b));if(v){u.voice=v;u.lang=v.lang}else u.lang='en-GB';",
  "  let v=pickVoice(sex,BODIES.indexOf(b)),say=line,en=false;if(!v&&SAY_EN[line]){EN_V=true;v=pickVoice(sex,BODIES.indexOf(b));EN_V=false;if(v){say=SAY_EN[line];en=true}}\n  const u=new SpeechSynthesisUtterance(say);if(v){u.voice=v;u.lang=v.lang}else u.lang=en?'en-GB':'cy-GB';"),
]

# dance band labels (both the ballroom block and the composers' block), from the live English file
_b=open('/tmp/claude-0/dance_ball.js').read()
def lab_block(a,z):
    en=_b[a:z];cy=en
    for k in re.findall(r":'([^']*)'",en):
        if k not in LAB:sys.exit('no Welsh label for: '+k)
    for k,v in sorted(LAB.items(),key=lambda kv:-len(kv[0])):cy=cy.replace(":'"+k+"'",":'"+v+"'")
    return (en,cy)
_a=_b.index('const BALL_INST={');DA.append(lab_block(_a,_b.index('};',_a)+2))
_a=_b.index('Object.assign(BALL_INST,{',_b.index('/* ================= COMPOSERS'));DA.append(lab_block(_a,_b.index('});',_a)+3))
DA.append(("Object.assign(MODENAME,{mozart:'Lydian (the modern major)',satie:'Hypolydian (modern Lydian)',debussy:'whole-tone and pentatonic',part:'Hypodorian (minor), on the home triad',reich:'Phrygian (modern Dorian)',glass:'Hypodorian (minor)'});",
 "Object.assign(MODENAME,{mozart:'Lydiaidd (y mwyaf modern)',satie:'Hypolydiaidd (Lydiaidd modern)',debussy:'graddfa tonau cyfan a phentatonig',part:'Hypodoriaidd (lleiaf), ar driad y cartref',reich:'Phrygaidd (Doriaidd modern)',glass:'Hypodoriaidd (lleiaf)'});"))
DA.append(("Object.assign(MODENAME,{jungle:'Hypodorian (minor)',slowwaltz:'Lydian (the modern major)',baroque:'Hypodorian (minor), in counterpoint'});",
 "Object.assign(MODENAME,{jungle:'Hypodoriaidd (lleiaf)',slowwaltz:'Lydiaidd (y mwyaf modern)',baroque:'Hypodoriaidd (lleiaf), mewn gwrthbwynt'});"))
DA.append(("const SMPTXT={tuning:'The band is tuning up…',ready:'The band is ready',synth:'Recorded instruments unavailable: playing synthesised ones'};",
 "const SMPTXT={tuning:'Mae’r band yn tiwnio…',ready:'Mae’r band yn barod',synth:'Dydy’r offerynnau wedi’u recordio ddim ar gael: offerynnau syntheseiddiedig sy’n chwarae'};"))

def tt_swap(s):
    i=s.index('/*TXT-START*/');j=s.index('/*TXT-END*/')+len('/*TXT-END*/')
    cy=open(H+'thinkers_txt_cy.js').read().strip()
    keys=lambda t:sorted(re.findall(r"(?:^|[{,])\s*(\w+):['\"{]",t,re.M))
    if keys(s[i:j])!=keys(cy):sys.exit('thinkers: Welsh texts have different keys from the English ones; update cy/thinkers_txt_cy.js')
    return s[:i]+cy+s[j:]

PAGES=('','index.html','flight.html','dance.html','help.html','privacy.html')
def relink(html):
    # the self-link (Cymraeg) becomes the English link; app links point at the Welsh pages; Polish links stay
    def lang_cy(m):
        tag=m.group(0);href=m.group(1)
        tag=tag.replace(href,B+href[len(B)+3:]).replace('lang="cy"','lang="en"').replace('hreflang="cy"','hreflang="en"')
        return tag.replace('>Cymraeg<','>English<').replace('>CY<','>EN<')
    html=re.sub(r'<a [^>]*href="('+re.escape(B)+r'cy/[^"]*)"[^>]*>(?:Cymraeg|CY)</a>',lang_cy,html)
    def app(m):
        p=m.group(1)
        return m.group(0) if 'lang="en"' in m.group(0) else m.group(0).replace(B+p,B+'cy/'+p)
    return re.sub(r'<a [^>]*href="'+re.escape(B)+r'('+'|'.join(re.escape(p) for p in PAGES if p)+r'|)(?=["#])[^>]*>',app,html)

def body_swap(s,start,end,cy_file,md5):
    i=s.index(start);j=s.index(end,i);eng=s[i:j]
    h=hashlib.md5(eng.encode()).hexdigest()
    if h!=md5:sys.exit(f'English body changed ({cy_file}): update the Welsh body (and the Polish one), then set md5 to {h}')
    return s[:i]+relink(open(H+cy_file).read())+s[j:]

def apply(s,pairs,page):
    for en,cy in pairs:
        if s.count(en)==0:sys.exit(f'[{page}] not found: {en[:90]}')
        s=s.replace(en,cy)
    return s

PWA_HEAD='<link rel="manifest" href="manifest.webmanifest">\n<meta name="theme-color" content="#090b18">\n<link rel="icon" type="image/png" href="../icons/favicon-48.png">\n<link rel="apple-touch-icon" href="../icons/apple-touch-icon.png">\n'+ns['PWA_HEAD'].split('\n',4)[4]
def wrap(s,split,title_en,title_cy,desc,dst,alt):
    s=s.replace(f'<title>{title_en}</title>',f'<title>{title_cy}</title>',1)
    assert f'<title>{title_cy}</title>' in s
    i=s.index(split);head,body=s[:i],s[i:]
    if '[hidden]{display:none!important}' not in head:
        head=head.replace('<style>','<style>\n[hidden]{display:none!important}\nhtml,body{margin:0}\n',1)
    out=('<!doctype html>\n<html lang="cy">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'+PWA_HEAD+
         f'<meta name="description" content="{desc}">\n<link rel="alternate" hreflang="en" href="{B}{alt}">\n<link rel="alternate" hreflang="pl" href="{B}pl/{alt}">\n'+head+'</head>\n<body>\n'+body+'\n</body>\n</html>\n')
    os.makedirs(os.path.dirname(dst),exist_ok=True);open(dst,'w').write(out)

MD5=eval(open(HP+'md5.txt').read())

s=open('/home/claude/music-of-the-spheres.html').read()
s=body_swap(s,'<div class="wrap">','<script>','body_2d.html',MD5['d2'])
s=tt_swap(s)
for g,p in ((A,'2d A'),(Bp,'2d B'),(SP,'2d speech'),(FS,'2d fmt'),(D2,'2d')):s=apply(s,g,p)
open(H+'out_2d.html','w').write(s)
wrap(s,'<div class="wrap">','Music of the Spheres','Cerddoriaeth y Sfferau','Clywch gerddoriaeth y sfferau fel y dychmygodd pob meddyliwr hi, o Pythagoras, Platon a Ptolemi i Kepler, wedi’i thynnu o awyr go iawn y funud hon, a’r holl gysawd heddiw yn cael ei chanu gan y duwiau Groegaidd.',R+'cy/index.html','')

s=open('/home/claude/flight.html').read()
s=body_swap(s,'<canvas id="scene"','<script src=','body_fly.html',MD5['fl'])
for g,p in ((A,'fly A'),(Bp,'fly B'),(SP,'fly speech'),(FS,'fly fmt'),(FL,'fly')):s=apply(s,g,p)
open(H+'out_fly.html','w').write(s)
wrap(s,'<canvas id="scene"','Flight Through the Spheres','Hedfan drwy’r Sfferau','Hedfanwch long ofod drwy gysawd yr haul mewn 3D tra bo’r planedau a’r lleuadau’n canu o’ch cwmpas â lleisiau’r duwiau Groegaidd.',R+'cy/flight.html','flight.html')

s=open('/home/claude/dance.html').read()
s=body_swap(s,'<div class="wrap">','<script>','body_dance.html',MD5['da'])
for g,p in ((A,'dance A'),(DA,'dance')):s=apply(s,g,p)
open(H+'out_dance.html','w').write(s)
wrap(s,'<div class="wrap">','Dance of the Spheres','Dawns y Sfferau','Dawns y Sfferau: cysawd yr haul yn chwarae fel band, o’r clwb i’r neuadd ddawns a’r neuadd gyngerdd. Mae’r Sidydd yn dewis y cywair a’r cordiau, ac mae agweddau rhwng y planedau’n sbarduno’r cronni a’r drop.',R+'cy/dance.html','dance.html')

hh=open('/tmp/claude-0/help_head.html').read()
wrap(hh+relink(open(H+'help_body.html').read()),'<div class="wrap">','How the Spheres Sing','Sut mae’r Sfferau’n Canu','Sut mae’r sfferau’n canu: Pythagoras, Platon, Ptolemi a Kepler, a sut mae Cerddoriaeth y Sfferau yn troi symudiadau go iawn cysawd yr haul yn sain.',R+'cy/help.html','help.html')
print('ok')
