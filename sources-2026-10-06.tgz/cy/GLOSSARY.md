# Welsh translation brief: Music of the Spheres

The app plays the solar system as music, with the planets sung by the Greek gods. It also lets you hear the "music of the spheres" as ancient and early-modern thinkers imagined it, and it has a dance page.

Write natural, modern standard Welsh, the kind a good Welsh-medium museum, BBC Cymru or S4C would use. Keep it clear and warm, not stiff. Address the reader with **chi**: imperatives such as *Gwrandewch*, *Dewiswch*, *Pwyswch*, *Tapiwch*. Use correct mutations. Keep the English meaning exactly; don't add or drop facts. Keep typographic quotes as Welsh normally does: ‘…’ or “…”.

## Fixed names (use these everywhere)

**App and pages**
- Music of the Spheres: **Cerddoriaeth y Sfferau**
- Dance of the Spheres: **Dawns y Sfferau**
- Flight Through the Spheres: **Hedfan drwy’r Sfferau**
- How the Spheres Sing: **Sut mae’r Sfferau’n Canu**
- 2D dial: **Deial 2D**
- 3D flight: **Hedfan 3D**
- How it works: **Sut mae’n gweithio**
- Extras: **Rhagor**
- Record: **Recordio**
- Stage: **Llwyfan**
- Polish (language link): **Polski**, left as it is
- English (language link): **English**, left as it is

**Planets and bodies**
- Sun: **yr Haul**
- Moon: **y Lleuad**
- Mercury: **Mercher**
- Venus: **Gwener**
- Earth: **y Ddaear**
- Mars: **Mawrth**
- Jupiter: **Iau**
- Saturn: **Sadwrn**
- Uranus: **Wranws**
- Neptune: **Neifion**
- Pluto: **Plwton**
- Ceres: **Ceres**
- Vesta: **Vesta**
- Pallas: **Pallas**
- Juno: **Juno**
- Hygiea: **Hygiea**
- Eros, Eris, Haumea, Makemake, Sedna: unchanged
- comet: **comed**, plural **comedau**
- asteroid: **asteroid**, plural **asteroidau**
- dwarf planet: **planed gorrach**, plural **planedau corrach**
- moon (satellite): **lleuad**, plural **lleuadau**
- the asteroid belt: **y gwregys asteroidau**
- Kuiper belt: **gwregys Kuiper**
- ecliptic: **ecliptig**
- orbit: **orbit**
- AU: **UA** (uned seryddol)

**Moons:** keep the international names (Phobos, Deimos, Io, Europa, Ganymede, Callisto, Titan, Triton and so on), except Selene (Moon), which becomes **Selene (y Lleuad)**.

**Gods:** keep the Greek forms. These are Hermes, Aphrodite, Gaia, Ares, Zeus, Kronos, Ouranos, Poseidon, Hades, Helios, Selene, Demeter, Hestia, Athena, Hera, Hygieia, Eros and Eris.

**Thinkers**
- Pythagoras
- Philolaus
- Plato: **Platon**
- Aristotle: **Aristoteles**
- Cicero
- Nicomachus
- Ptolemy: **Ptolemi**
- Boethius
- Copernicus
- Robert Fludd
- Kepler
- Pliny: **Plinius**

**Zodiac**
- Aries: **yr Hwrdd**
- Taurus: **y Tarw**
- Gemini: **yr Efeilliaid**
- Cancer: **y Cranc**
- Leo: **y Llew**
- Virgo: **y Forwyn**
- Libra: **y Fantol**
- Scorpio or Scorpius: **y Sgorpion**
- Sagittarius: **y Saethydd**
- Capricorn or Capricornus: **yr Afr**
- Aquarius: **y Cariwr Dŵr**
- Pisces: **y Pysgod**

In a code list like `'Aries','♈'`, give just the name without the article, so `'Hwrdd'`, `'Tarw'` and so on. Use the article only where the text reads as a sentence.

**Music**
- key: **cywair**
- mode: **modd**
- chord: **cord**
- bar: **bar**
- beat: **curiad**
- tempo: **tempo**
- melody: **alaw**
- harmony: **harmoni**
- drone: **bwrdwn**
- octave: **wythfed**
- fifth: **pumed**
- fourth: **pedwerydd**
- major third: **trydydd mwyaf**
- minor third: **trydydd lleiaf**
- major sixth: **chweched mwyaf**
- unison: **unsain**
- semitone: **hanner tôn**
- tone: **tôn**
- scale: **graddfa**
- counterpoint: **gwrthbwynt**
- voice: **llais**
- choir: **côr**
- bass: **bas**
- tenor: **tenor**
- countertenor: **gwrthdenor**
- alto: **alto**
- soprano: **soprano**
- child: **plentyn**

Modes keep their Greek names in Welsh form: Doriaidd, Phrygaidd, Lydiaidd, Mixolydiaidd, Hypodoriaidd, Hypophrygaidd, Hypolydiaidd. So "Hypodorian (minor)" becomes **Hypodoriaidd (lleiaf)**, and "Lydian (the modern major)" becomes **Lydiaidd (y mwyaf modern)**.

**Instruments**
- violin: **ffidil**
- strings: **llinynnau**
- flute: **ffliwt**
- oboe: **obo**
- horn or horns: **corn** or **cyrn**
- timpani: **timpani**
- harp: **telyn**
- piano: **piano**
- organ: **organ**
- harpsichord: **harpsicord**
- cello: **soddgrwth**
- double bass: **bas dwbl**
- trumpet: **trwmped**
- trombone: **trombôn**
- saxophone: **sacsoffon**
- guitar: **gitâr**
- bells: **clychau**
- cymbal: **symbal**
- celesta: **celesta**
- marimba: **marimba**
- vibraphone: **fibraffon**
- choir: **côr**
- clapping: **clapio**

Keep genre and dance-floor words in their usual form: trance, house, jungle, techno, groove, drop, breakbeat, Reese bass, riser, BPM.

**Dance sections**
- intro: **cyflwyniad**
- groove: **groove**
- build: **cronni**
- drop: **drop**
- break: **egwyl**

**Dances**
- Viennese waltz: **walts Fiennaidd**
- slow waltz: **walts araf**
- tango, samba, cha-cha, swing, jive, fandango: unchanged

**Aspects**
- conjunction: **cydiad**
- sextile: **secstil**
- square: **sgwâr**
- trine: **trein**
- opposition: **gwrthwynebiad**

**Dates and units**
- BCE / BC: **CC**
- AD: **OC**
- hours: **awr**
- days: **diwrnod**
- months: **mis**
- years: **blwyddyn**

In compact UI readouts like "2.4 hours / s", write `awr / e`, `diwrnod / e`, `mis / e`, `blwyddyn / e`. Use "e" for eiliad.

**Months** (short form): Ion, Chwef, Maw, Ebr, Mai, Meh, Gorff, Awst, Medi, Hyd, Tach, Rhag.

The number format is unchanged: a decimal point, as in English.

**Speech.** The gods introduce themselves aloud through the device's speech synthesiser. Welsh voices are rare. If the device has no Welsh voice, the app will speak the English line instead. Just translate the lines naturally, as spoken Welsh.

## Code rules (very important)

- Translate only text a person sees or hears. Never change HTML tags, attributes (except visible ones: `title`, `aria-label`, `alt`, `placeholder`), ids, classes, URLs, data-* values, JavaScript identifiers, object keys, `${…}` template expressions, or CSS.
- Keep every quote character, backtick, bracket, comma and `\n` that is part of the code. If a JS string is in single quotes, don't put a straight `'` inside it. Use the typographic apostrophe ’ instead (for example `’r`, `i’r`, `a’r`).
- Keep `<b>`, `<em>`, `<a>` and other inline markup around the equivalent words.
- In the language links, translate nothing that names a language. Change only links that point to the current Welsh page, as the task says.
