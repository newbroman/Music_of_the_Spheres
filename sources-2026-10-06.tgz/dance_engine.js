
/* ================= DANCE: the sky plays the band ================= */
const $=id=>document.getElementById(id);
const LOWPOWER=matchMedia('(hover:none)').matches||/Android|iPhone|iPad/i.test(navigator.userAgent);
const STYLES={
  trance:{name:'Trance',bpm:138,mode:'A',swing:0,kickF:[165,46,.30],arp:1,lead:1,pads:'saw',bass:'rolling',hats:'trance',toms:.25,buildBars:8,clap:'clap'},
  house:{name:'House',bpm:124,mode:'D',swing:.17,kickF:[130,50,.36],arp:.45,lead:.9,pads:'stab',bass:'house',hats:'house',toms:.55,buildBars:4,clap:'clap'},
  techno:{name:'Techno',bpm:130,mode:'E',swing:0,kickF:[175,42,.52],arp:.3,lead:.25,pads:'drone',bass:'acid',hats:'techno',toms:1,buildBars:8,clap:'rim'}
};
const D={style:'trance',bpm:138,dpb:3,vol:.7,playing:false,step:0,section:'intro',secBar:0,secLen:8,energy:.4,lastDrop:-99,prevMax:0,
  mute:new Set(),prog:[0,5,3,4],progInfo:[],motif:null,motifKey:'',tomPat:null,tomKey:'',acid:null,acidKey:''};
const STY=()=>STYLES[D.style];
const RECBASE='dance-of-the-spheres-';
// each style's output level, so the acoustic styles sit as loud as the club ones
const outGain=()=>D.vol*.42*(STY().gain||1);
// steps per bar: four sixteenths per beat, three beats for the waltz and fandango
const SPB=()=>(STY().beats||4)*(STY().sub||4);

/* ---- scale and harmony, in Pythagorean tuning, transposed by the Sun's sign ---- */
function modeDeg(){const t=Math.log2(PY[S.mode]);return Object.values(PY).map(r=>((Math.log2(r)-t)%1+1)%1).sort((a,c)=>a-c)}
let DEG7=null;
function noteF(deg,oct){const d=DEG7,t=Math.log2(PY[S.mode])+keyShift();const o=Math.floor(deg/7),i=((deg%7)+7)%7;const f=C_BASE*Math.pow(2,t+oct+o+d[i]);return D.raise3&&i===2?f*2187/2048:f}
// geocentric zodiac sign of a body: the sign it stands in, seen from Earth
function signOf(id){const p=P[id],e=P.earth;return Math.floor(((Math.atan2(p.y-e.y,p.x-e.x)/DEG)%360+360)%360/30)%12}
const DEGFOR=[0,5,3,4,2,6,0,5,3,4,2,6];
const ROMAN=['i','ii','iii','iv','v','vi','vii'];
// four-bar progression: home, then the chords Zeus, Kronos and Poseidon stand on
function updateProgression(){
  const who=['jupiter','saturn','neptune'];
  const prog=[0];const info=[{deg:0,who:'Apollo',sign:null}];
  who.forEach(id=>{let d=DEGFOR[signOf(id)];if(d===prog[prog.length-1])d=(d+3)%7;prog.push(d);info.push({deg:d,who:byId[id].god,sign:signOf(id)})});
  if(STY().cadence){
    // the Andalusian cadence: the sky picks the first two chords, then the Phrygian second and home
    let dz=info[1].deg,dk=info[2].deg;if(dz<=1)dz=3;if(dk<=1||dk===dz)dk=dz===2?3:2;
    D.prog=[dz,dk,1,0];D.progInfo=[{deg:dz,who:info[1].who,sign:info[1].sign},{deg:dk,who:info[2].who,sign:info[2].sign},{deg:1,who:CADENCE,sign:null},{deg:0,who:'Apollo',sign:null}];return}
  D.prog=prog;D.progInfo=info;
}
const chordTones=(deg)=>[deg,deg+2,deg+4];

/* ---- aspects, heliocentric: they drive builds and drops ---- */
const ASPS=[{ang:0,name:'conjunction',sym:'☌',orb:7},{ang:60,name:'sextile',sym:'⚹',orb:4},{ang:90,name:'square',sym:'□',orb:6},{ang:120,name:'trine',sym:'△',orb:6},{ang:180,name:'opposition',sym:'☍',orb:7}];
let ASPNOW=[];
function computeAspectsD(){
  ASPNOW=[];const pl=BODIES.filter(b=>b.kind==='planet').map(b=>({b,lon:Math.atan2(P[b.id].y,P[b.id].x)/DEG}));
  for(let i=0;i<pl.length;i++)for(let j=i+1;j<pl.length;j++){let s=Math.abs(pl[i].lon-pl[j].lon)%360;if(s>180)s=360-s;
    for(const a of ASPS){const dv=Math.abs(s-a.ang);if(dv<a.orb){ASPNOW.push({a:pl[i].b,b:pl[j].b,asp:a,str:Math.pow(1-dv/a.orb,2)});break}}}
  ASPNOW.sort((x,y)=>y.str-x.str);
}

/* ---- seeded patterns that follow the planets' signs ---- */
function rng(seed){let s=seed*9301+49297;return ()=>{s=(s*16807)%2147483647;return (s-1)/2147483646}}
function ensurePatterns(){
  const vk=signOf('venus')+'/'+D.style;
  if(D.motifKey!==vk){D.motifKey=vk;const r=rng(signOf('venus')*31+7);const m=[];
    for(let k=0;k<32;k++){const hit=(k%4===0&&r()<.75)||(k%4===2&&r()<.45)||(k%2===1&&r()<.12);m.push(hit?{deg:[0,2,4,7,4,2,1,5][Math.floor(r()*8)],len:k%4===0?.38:.2,vow:r()<.5?'a':'o'}:null)}D.motif=m}
  const tk=signOf('mars')+'/'+D.style;
  if(D.tomKey!==tk){D.tomKey=tk;const r=rng(signOf('mars')*17+3);D.tomPat=Array.from({length:16},(_,k)=>k%4!==0&&r()<.16?(r()<.5?0:2):null)}
  const ak=signOf('jupiter')+'/'+D.style;
  if(D.acidKey!==ak){D.acidKey=ak;const r=rng(signOf('jupiter')*13+5);D.acid=Array.from({length:16},(_,k)=>({deg:[0,0,0,7,3,0,5,-2][Math.floor(r()*8)],acc:r()<.3,on:k%4===0||r()<.7}))}
}

/* ---- audio graph ---- */
let AC=null,master,lim,musicBus,duck,musicLP,drumBus,revSend,dlySend,noiseBuf,PAN={},padV=[],subV=null,audioOn=false;
const mkG=(v,to)=>{const g=AC.createGain();g.gain.value=v;if(to)g.connect(to);return g};
function makeTemple(input,output){
  const pre=mkG(.5);input.connect(pre);
  [[.0437,-.8],[.0531,.8],[.0617,-.35],[.0719,.35]].forEach(([dt,pan])=>{
    const d=AC.createDelay(.2);d.delayTime.value=dt*1.9;
    const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=2600;lp.Q.value=-3;
    const fb=mkG(.78),out=AC.createStereoPanner();out.pan.value=pan;
    pre.connect(d);d.connect(lp);lp.connect(fb);fb.connect(d);lp.connect(out);out.connect(output);
  });
}
function initDanceAudio(){
  const C=window.AudioContext||window.webkitAudioContext;try{AC=new C({latencyHint:'playback'})}catch(e){AC=new C()}
  master=mkG(0);
  lim=AC.createDynamicsCompressor();lim.threshold.value=-6;lim.knee.value=0;lim.ratio.value=20;lim.attack.value=.002;lim.release.value=.15;
  const glue=AC.createDynamicsCompressor();glue.threshold.value=-16;glue.ratio.value=3;glue.attack.value=.01;glue.release.value=.2;
  glue.connect(master);master.connect(lim);lim.connect(AC.destination);
  drumBus=mkG(.9,glue);
  musicLP=AC.createBiquadFilter();musicLP.type='lowpass';musicLP.frequency.value=3000;musicLP.Q.value=.3;
  duck=mkG(1,musicLP);musicBus=duck;musicLP.connect(glue);
  // shared space: a light reverb and a dotted-eighth echo
  const wet=mkG(.55,glue);revSend=mkG(1);makeTemple(revSend,wet);
  const dl=AC.createDelay(1.5);const dfb=mkG(.33);const dlp=AC.createBiquadFilter();dlp.type='lowpass';dlp.frequency.value=3200;dlp.Q.value=-3;
  dlySend=mkG(1);dlySend.connect(dl);dl.connect(dlp);dlp.connect(dfb);dfb.connect(dl);dlp.connect(mkG(.45,glue));D.delayNode=dl;
  noiseBuf=AC.createBuffer(1,AC.sampleRate*2,AC.sampleRate);const nd=noiseBuf.getChannelData(0);for(let i=0;i<nd.length;i++)nd[i]=Math.random()*2-1;
  // one stereo position per planet, from where it stands around the Sun
  BODIES.filter(b=>b.kind==='planet').concat([{id:'sun'}]).forEach(b=>{const p=AC.createStereoPanner();PAN[b.id]=p});
  ['sun','mercury','earth','mars'].forEach(id=>PAN[id].connect(drumBus));
  ['jupiter','saturn','venus','uranus','neptune'].forEach(id=>PAN[id].connect(musicBus));
  // 5.1: the band's gods circle the room with their planets (the vernal point ahead); drums and bass stay at the front
  if(window.MOTS&&MOTS.surround){['jupiter','saturn','venus','uranus','neptune'].forEach(id=>MOTS.surround.add(PAN[id],{az:()=>P[id]?Math.atan2(P[id].y,P[id].x)*180/Math.PI:null}));
    MOTS.surround.attach({ctx:AC,master,lim,entry:duck,bypass:[[musicLP,glue,master]]})}
  buildPads();buildSub();
}
function noise(t,dur){const s=AC.createBufferSource();s.buffer=noiseBuf;s.start(t,Math.random()*1.5,dur+.05);return s}
const env=(g,t,peak,att,dec)=>{g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(peak,t+att);g.gain.setTargetAtTime(0,t+att,dec)};

/* drums */
function kick(t){
  const [f0,f1,dec]=STY().kickF, o=AC.createOscillator(), g=mkG(0,PAN.sun);
  o.frequency.setValueAtTime(f0,t);o.frequency.exponentialRampToValueAtTime(f1,t+.11);
  env(g,t,1.1*(STY().kickLvl||1),.002,dec*.42);o.connect(g);o.start(t);o.stop(t+dec*3);
  const c=noise(t,.02),hp=AC.createBiquadFilter();hp.type='highpass';hp.frequency.value=2500;const cg=mkG(0,PAN.sun);env(cg,t,.25,.001,.006);c.connect(hp);hp.connect(cg);
  if(D.style==='techno'){const rg=mkG(0);env(rg,t+.05,.5,.01,.18);const rl=AC.createBiquadFilter();rl.type='lowpass';rl.frequency.value=160;o.connect(rg);rg.connect(rl);rl.connect(revSend)}
  // sidechain: the music breathes with the kick
  duckIt(t);
  flash('sun',t);
}
function duckIt(t){const d=STY().duck||.32;duck.gain.cancelScheduledValues(t);duck.gain.setTargetAtTime(d,t,.004);duck.gain.setTargetAtTime(1,t+.06,.09)}
function clap(t,v=1){
  const n=noise(t,.25),bp=AC.createBiquadFilter();bp.type='bandpass';bp.frequency.value=STY().clap==='rim'?2600:1300;bp.Q.value=STY().clap==='rim'?6:1.2;
  const g=mkG(0,PAN.earth);n.connect(bp);bp.connect(g);
  if(STY().clap==='rim'){env(g,t,.5*v,.001,.018)}else{[0,.011,.022].forEach(d=>{g.gain.setValueAtTime(.55*v,t+d);g.gain.setTargetAtTime(.05,t+d+.002,.004)});g.gain.setValueAtTime(.45*v,t+.03);g.gain.setTargetAtTime(0,t+.03,.06)}
  bp.connect(mkG(.2,revSend));flash('earth',t);
}
function snare(t,v){
  const n=noise(t,.2),bp=AC.createBiquadFilter();bp.type='bandpass';bp.frequency.value=1900;bp.Q.value=.9;const g=mkG(0,PAN.earth);env(g,t,.42*v,.001,.045);n.connect(bp);bp.connect(g);
  const o=AC.createOscillator();o.type='triangle';o.frequency.setValueAtTime(200,t);o.frequency.exponentialRampToValueAtTime(150,t+.08);const og=mkG(0,PAN.earth);env(og,t,.25*v,.001,.03);o.connect(og);o.start(t);o.stop(t+.25);
  bp.connect(mkG(.25,revSend));flash('earth',t);
}
function hat(t,open,v){
  const n=noise(t,open?.35:.08),hp=AC.createBiquadFilter();hp.type='highpass';hp.frequency.value=open?6500:7800;
  const g=mkG(0,PAN.mercury);env(g,t,(open?.2:.16)*v,.001,open?.07:.014);n.connect(hp);hp.connect(g);flash('mercury',t);
}
function tom(t,f,v=1){const o=AC.createOscillator();o.frequency.setValueAtTime(f,t);o.frequency.exponentialRampToValueAtTime(f*.55,t+.22);const g=mkG(0,PAN.mars);env(g,t,.42*v,.002,.09);o.connect(g);o.start(t);o.stop(t+.5);o.connect(mkG(.12,revSend));flash('mars',t)}
// the composers and Bach have no noise effects: no cymbal crash at the climax, no comet whoosh
const classical=()=>!!(STY().own||D.style==='baroque');
function crash(t){const n=noise(t,1.8),hp=AC.createBiquadFilter();hp.type='highpass';hp.frequency.value=4200;const g=mkG(0,drumBus);env(g,t,.22,.002,.55);n.connect(hp);hp.connect(g);hp.connect(mkG(.3,revSend))}

/* bass: Zeus */
function bass(t,f,len,opt={}){
  const o=AC.createOscillator();o.type='sawtooth';o.frequency.setValueAtTime(f,t);
  const o2=D.style==='house'?AC.createOscillator():null;if(o2){o2.type='square';o2.frequency.setValueAtTime(f/2,t)}
  const lp=AC.createBiquadFilter();lp.type='lowpass';
  const acid=D.style==='techno';lp.Q.value=acid?14:(D.style==='trance'?2:4);
  const base=acid?260:(D.style==='trance'?380:300),top=acid?(opt.acc?2600:1200):(D.style==='trance'?1400:900);
  lp.frequency.setValueAtTime(top,t);lp.frequency.setTargetAtTime(base,t+.005,acid?.07:.05);
  const g=mkG(0,PAN.jupiter);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(acid?(opt.acc?.42:.3):.42,t+.004);g.gain.setValueAtTime(acid?(opt.acc?.42:.3):.42,t+len*.85);g.gain.linearRampToValueAtTime(0,t+len);
  o.connect(lp);if(o2){const g2=mkG(.5,lp);o2.connect(g2);o2.start(t);o2.stop(t+len+.05)}lp.connect(g);o.start(t);o.stop(t+len+.05);
  flash('jupiter',t);
}
/* pads: Kronos */
let padVib=null;
function buildPads(){
  const n=LOWPOWER?2:3;const lfo=AC.createOscillator();lfo.frequency.value=5.3;padVib=mkG(0);lfo.connect(padVib);lfo.start();
  padV=[0,1,2].map(()=>{const g=mkG(0),lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=1800;lp.Q.value=.5;g.connect(lp);lp.connect(PAN.saturn);lp.connect(mkG(.35,revSend));
    const os=Array.from({length:n},(_,k)=>{const o=AC.createOscillator();o.type='sawtooth';o.detune.value=(k-(n-1)/2)*14;padVib.connect(o.detune);o.connect(g);o.start();return o});return {g,lp,os}});
}
function setPads(t,degs,level,cut){
  padV.forEach((v,k)=>{const f=noteF(degs[k],4);v.os.forEach(o=>o.frequency.setTargetAtTime(f,t,.03));v.g.gain.setTargetAtTime(level*.1,t,.25);v.lp.frequency.setTargetAtTime(cut,t,.3)});
}
function stab(t,degs,len){
  degs.forEach(d=>{const f=noteF(d,4);const o=AC.createOscillator();o.type='sawtooth';o.frequency.value=f;const o2=AC.createOscillator();o2.type='square';o2.frequency.value=f*1.004;
    const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.setValueAtTime(3200,t);lp.frequency.setTargetAtTime(700,t,.06);
    const g=mkG(0,PAN.saturn);env(g,t,.085,.003,len*.4);o.connect(lp);o2.connect(lp);lp.connect(g);g.connect(mkG(.4,revSend));o.start(t);o2.start(t);o.stop(t+len*2.5);o2.stop(t+len*2.5)});
  flash('saturn',t);
}
/* arpeggio: Jupiter's moons in their 1:2:4 resonance */
function pluck(t,f,lvl,type,dec,id){
  const o=AC.createOscillator();o.type=type;o.frequency.value=f;const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.setValueAtTime(Math.min(9000,f*6),t);lp.frequency.setTargetAtTime(f*1.5,t,dec*.6);
  const g=mkG(0,PAN.jupiter);env(g,t,lvl,.002,dec);o.connect(lp);lp.connect(g);g.connect(mkG(.35,dlySend));g.connect(mkG(.25,revSend));o.start(t);o.stop(t+dec*6);if(id)flash(id,t);
}
/* lead: Aphrodite's vocal chops */
const VOW={a:[[800,1],[1150,.5],[2900,.2]],o:[[450,1],[800,.4],[2830,.12]]};
function chop(t,f,len,vow){
  const o=AC.createOscillator();o.type='sawtooth';o.frequency.setValueAtTime(f*.985,t);o.frequency.setTargetAtTime(f,t,.02);
  const vib=AC.createOscillator();vib.frequency.value=5.5;const vd=mkG(0);vd.gain.setValueAtTime(0,t);vd.gain.linearRampToValueAtTime(f*.012,t+len);vib.connect(vd);vd.connect(o.frequency);
  const g=mkG(0,PAN.venus);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.32,t+.012);g.gain.setValueAtTime(.32,t+len*.8);g.gain.linearRampToValueAtTime(0,t+len);
  VOW[vow].forEach(([F,a])=>{const bp=AC.createBiquadFilter();bp.type='bandpass';bp.frequency.value=F;bp.Q.value=F/90;o.connect(bp);bp.connect(mkG(a*1.6,g))});
  g.connect(mkG(.4,dlySend));g.connect(mkG(.4,revSend));o.start(t);vib.start(t);o.stop(t+len+.05);vib.stop(t+len+.05);flash('venus',t);
}
/* Ouranos' riser and Poseidon's sub */
function riser(t,dur){
  const n=AC.createBufferSource();n.buffer=noiseBuf;n.loop=true;const bp=AC.createBiquadFilter();bp.type='bandpass';bp.Q.value=2.5;bp.frequency.setValueAtTime(250,t);bp.frequency.exponentialRampToValueAtTime(7000,t+dur);
  const g=mkG(0,PAN.uranus);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.22,t+dur);g.gain.setValueAtTime(0,t+dur+.01);
  n.connect(bp);bp.connect(g);g.connect(mkG(.4,revSend));n.start(t);n.stop(t+dur+.05);
  const o=AC.createOscillator();o.type='sine';o.frequency.setValueAtTime(110,t);o.frequency.exponentialRampToValueAtTime(880,t+dur);const og=mkG(0,PAN.uranus);og.gain.setValueAtTime(0,t);og.gain.linearRampToValueAtTime(.06,t+dur);og.gain.setValueAtTime(0,t+dur+.01);o.connect(og);o.start(t);o.stop(t+dur+.05);
  flash('uranus',t);
}
function buildSub(){const o=AC.createOscillator();o.type='sine';const g=mkG(0,PAN.neptune);o.connect(g);o.start();subV={o,g}}
function whoosh(t){const n=noise(t,3.2),bp=AC.createBiquadFilter();bp.type='bandpass';bp.Q.value=1.4;bp.frequency.setValueAtTime(5000,t);bp.frequency.exponentialRampToValueAtTime(300,t+3);const g=mkG(0,drumBus);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.12,t+.6);g.gain.linearRampToValueAtTime(0,t+3);n.connect(bp);bp.connect(g);g.connect(mkG(.5,revSend))}

/* ---- arrangement: the sky decides when to build, drop and break ---- */
// which instruments play in each section
const LAYERS={
  intro:{kick:1,clap:0,hats:.6,bass:0,pads:.6,arp:.5,lead:0,toms:0,sub:.4},
  groove:{kick:1,clap:1,hats:1,bass:1,pads:.8,arp:.7,lead:.35,toms:1,sub:0},
  build:{kick:0,clap:0,hats:.8,bass:0,pads:1,arp:1,lead:0,toms:0,sub:0},
  drop:{kick:1,clap:1,hats:1,bass:1,pads:1,arp:1,lead:1,toms:1,sub:0},
  break:{kick:0,clap:0,hats:.3,bass:0,pads:1,arp:.8,lead:.5,toms:0,sub:1}
};
function setSection(name,len,bar){D.section=name;D.secLen=len;D.secBar=bar;renderSection();if(window.MOTS&&MOTS.midi.on)MOTS.midi.section(name,nextT)}
function atBar(bar,t){
  computeAspectsD();updateProgression();ensurePatterns();
  const max=ASPNOW.length?ASPNOW[0].str:0, rising=max>D.prevMax+.01;D.prevMax=max;
  D.energy+=((.35+Math.min(.65,ASPNOW.reduce((a,x)=>a+x.str,0)*.35))-D.energy)*.35;
  const into=bar-D.secBar, st=STY();
  if(D.section==='intro'&&into>=D.secLen)setSection('groove',16,bar);
  else if(D.section==='groove'&&into>=8&&bar%4===0&&((max>.55&&rising)||into>=32)&&bar-D.lastDrop>20){setSection('build',st.buildBars,bar);if(st.fam==='ball')ballRiser(t,st.buildBars*barDur());else riser(t,st.buildBars*barDur())}
  else if(D.section==='build'&&into>=D.secLen){setSection('drop',16,bar);D.lastDrop=bar;if(!classical())crash(t);toast('Drop: '+(ASPNOW[0]?`${ASPNOW[0].a.god} ${ASPNOW[0].asp.sym}︎ ${ASPNOW[0].b.god}`:'the spheres align'))}
  else if(D.section==='drop'&&into>=D.secLen)setSection('break',8,bar);
  else if(D.section==='break'&&into>=D.secLen)setSection('groove',16,bar);
  // the music filter opens and closes with the section
  const cut={intro:1400,groove:4200,build:900,drop:14000,break:1600}[D.section];
  if(D.section==='build'&&bar===D.secBar){musicLP.frequency.cancelScheduledValues(t);musicLP.frequency.setValueAtTime(700,t);musicLP.frequency.exponentialRampToValueAtTime(9000,t+D.secLen*barDur())}
  else if(D.section!=='build'&&bar===D.secBar){musicLP.frequency.cancelScheduledValues(t);musicLP.frequency.setTargetAtTime(cut,t,.4)}
  // stereo: each planet sits where it stands around the Sun
  Object.keys(PAN).forEach(id=>{if(id==='sun')return;const p=P[id];PAN[id].pan.setTargetAtTime(Math.sin(Math.atan2(p.y,p.x))*.75,t,.5)});
  // pads change chord each bar
  const deg=D.prog[bar%4], L=LAYERS[D.section], pm=STY().pads==='strings'&&smpReady('string_ensemble_1')?'none':STY().pads;
  D.raise3=!!STY().cadence&&((deg%7)+7)%7===0;
  const padsOn=!D.mute.has('saturn')&&pm!=='stab'&&pm!=='none';
  padVib.gain.setTargetAtTime(pm==='strings'?9:0,t,.2);
  setPads(t,pm==='drone'?[deg-7,deg-3,deg]:chordTones(deg),padsOn?L.pads*(pm==='drone'?.6:pm==='strings'?.5:1):0,pm==='strings'?(D.section==='drop'?2600:1500):D.section==='drop'?5000:D.section==='break'?1500:2600);
  if(padsOn)flash('saturn',t);
  subV.o.frequency.setTargetAtTime(noteF(deg,1),t,.1);subV.g.gain.setTargetAtTime(D.mute.has('neptune')||STY().noSub?0:L.sub*.22,t,.6);if(L.sub)flash('neptune',t);
  // a comet near the Sun sweeps through every eight bars
  if(bar%8===0&&!classical()&&BODIES.some(b=>b.kind==='comet'&&P[b.id].r<1.6))whoosh(t);
  D.delayNode.delayTime.setValueAtTime(45/D.bpm,t);
  renderProg();
}
const barDur=()=>(STY().beats||4)*60/D.bpm;
function playStep(s,t){
  const st=STY(), spb=SPB(), pos=s%spb, bar=Math.floor(s/spb), L=LAYERS[D.section], into=bar-D.secBar, m=id=>!D.mute.has(id);
  if(pos===0)atBar(bar,t);
  const deg=D.prog[bar%4], stepT=barDur()/spb;
  if(st.fam==='ball'){ballStep(s,pos,bar,t,st,L,deg,stepT,m,into,spb);return}
  // Apollo's kick, four to the floor
  if(L.kick&&m('sun')&&pos%4===0){if(!(D.style==='house'&&D.section==='build'&&into===D.secLen-1))kick(t)}
  if(D.style==='techno'&&D.section==='build'&&m('sun')&&pos%4===0)kick(t);
  // Gaia's claps and the build's snare roll
  if(L.clap&&m('earth')&&(pos===4||pos===12))clap(t,1);
  if(D.style==='techno'&&L.clap&&m('earth')&&pos===14&&bar%2)clap(t,.6);
  if(D.section==='build'&&m('earth')){const prog=(into+pos/16)/D.secLen, every=prog<.5?4:prog<.75?2:1;if(pos%every===0)snare(t,.3+.7*prog)}
  // Hermes' hats: busier when Mercury runs fast near perihelion
  if(L.hats&&m('mercury')){const fast=P.mercury.om/(TAU/87.97)>1.12, slow=P.mercury.om/(TAU/87.97)<.88;
    if(st.hats==='trance'){if(pos%4===2)hat(t,true,L.hats);else if(!slow&&(fast||pos%2===0))hat(t,false,.45*L.hats)}
    else if(st.hats==='house'){if(pos%4===2)hat(t,bar%2===0,L.hats);else if(!slow||pos%2===0)hat(t,false,.5*L.hats)}
    else{if(!slow||pos%2===0)hat(t,pos%4===2&&fast,(pos%4===2?.9:.5)*L.hats)}}
  // Zeus' bass
  if(L.bass&&m('jupiter')){
    if(st.bass==='rolling'){if(pos%4!==0)bass(t,noteF(deg,2),stepT*.85)}
    else if(st.bass==='house'){const hits={2:[0,1.6],3:null,6:[7,.9],10:[0,1.6],13:[0,.9],14:[4,.9]};const h=hits[pos];if(h)bass(t,noteF(deg+h[0],2),stepT*h[1])}
    else{const a=D.acid[pos];if(a.on)bass(t,noteF(deg+a.deg,2),stepT*(a.acc?.95:.7),{acc:a.acc})}}
  // Kronos' house stabs
  if(st.pads==='stab'&&L.pads&&m('saturn')&&[2,6,11,14].includes(pos)&&(pos!==11||bar%2))stab(t,chordTones(deg),stepT*1.6);
  // Jupiter's moons: Io, Europa and Ganymede in their 1:2:4 resonance
  if(L.arp&&m('jupiter-moons')){const lv=L.arp*st.arp, tones=chordTones(deg), up=moonWaxing();
    const io=tones[(up?pos:15-pos)%3], eu=tones[(up?pos/2:7-pos/2)%3|0];
    pluck(t,noteF(io,5),.085*lv,'square',stepT*.6,'io');
    if(pos%2===0)pluck(t,noteF(eu,4),.1*lv,'triangle',stepT*1.4,'europa');
    if(pos%4===0)pluck(t,noteF(tones[(pos/4|0)%3],6),.06*lv,'sine',stepT*4,'ganymede');}
  // Aphrodite's vocal chops
  if(L.lead*st.lead>.2&&m('venus')){const mm=D.motif[(bar%2)*16+pos];if(mm&&(L.lead>=.9||pos%8===0))chop(t,noteF(deg+mm.deg,5),barDur()*mm.len,mm.vow)}
  // Ares' toms
  if(L.toms*st.toms>.2&&m('mars')){const tp=D.tomPat[pos];if(tp!==null&&(st.toms>.5||bar%2))tom(t,noteF(deg+tp,3))}
}
function moonWaxing(){const e=P.earth,m=byId.earth.moons[0];const th=TAU*((S.jd-J2000)/m.P+m.ph0),sun=Math.atan2(-e.y,-e.x);return (((th-sun)/TAU)%1+1)%1<.5}

/* ---- the scheduler: a short look-ahead keeps timing tight ---- */
let nextT=0,schedTimer=null;
function scheduler(){
  const ahead=LOWPOWER?.2:.12;
  while(nextT<AC.currentTime+ahead){
    const st=STY(), pos=D.step%SPB(), sd=barDur()/SPB(), sw=st.swing8?(pos%4===2?st.swing8*sd:0):(pos%2===1)?st.swing*sd:0;
    playStep(D.step,nextT+sw);D.step++;nextT+=sd;
  }
}
function startDance(){
  if(!AC)initDanceAudio();
  AC.resume();DEG7=modeDeg();loadStyleSamples();
  D.playing=true;D.step=0;nextT=AC.currentTime+.1;if(window.MOTS&&MOTS.midi.transport)MOTS.midi.transport(true,D.bpm);setSection('intro',8,0);D.lastDrop=-99;
  master.gain.setTargetAtTime(outGain(),AC.currentTime,.05);
  clearInterval(schedTimer);schedTimer=setInterval(scheduler,25);scheduler();syncPlay();
}
function stopDance(){D.playing=false;if(window.MOTS&&MOTS.midi.transport)MOTS.midi.transport(false);clearInterval(schedTimer);if(AC){master.gain.setTargetAtTime(0,AC.currentTime,.05);padV.forEach(v=>v.g.gain.setTargetAtTime(0,AC.currentTime,.1));subV.g.gain.setTargetAtTime(0,AC.currentTime,.1)}syncPlay()}
function setStyle(k){const old=SPB();D.style=k;loadStyleSamples();if(D.playing)D.step=(Math.floor(D.step/old)+1)*SPB();S.mode=STYLES[k].mode;DEG7=AC?modeDeg():null;D.bpm=STYLES[k].bpm;if(window.MOTS&&MOTS.midi.transport)MOTS.midi.transport(D.playing,D.bpm);$('bpm').value=D.bpm;$('bpmOut').textContent=D.bpm+' BPM';
  document.querySelectorAll('#style button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.v===k)));renderMixer();renderProg();if(AC&&D.playing)master.gain.setTargetAtTime(outGain(),AC.currentTime,.1)}

/* ---- visuals: flashes when a planet's instrument sounds ---- */
const FL={},FQ=[];
function flash(id,t){FQ.push([id,t]);if(window.MOTS&&MOTS.midi.on)MOTS.midi.hit(id,t,0,.6,.15)}
function pumpFlashes(){if(!AC)return;const now=AC.currentTime;while(FQ.length&&FQ[0][1]<=now){FL[FQ.shift()[0]]=1}if(FQ.length>400)FQ.splice(0,FQ.length-400)}
