import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const mobile=process.argv[2]==='phone';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage(mobile?{viewport:{width:400,height:820},hasTouch:true,isMobile:true,userAgent:'Mozilla/5.0 (Linux; Android 14) Mobile'}:{viewport:{width:1100,height:760}});
const errs=[];page.on('pageerror',e=>errs.push(String(e)));
await page.addInitScript(()=>{const Orig=window.AudioContext;window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();this.__an.fftSize=4096;}};const oc=AudioNode.prototype.connect;AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return res};});
await page.goto('file:///home/claude/flight.html');await page.waitForTimeout(1200);
await page.click('#begin');await page.waitForTimeout(800);
await page.click('#navBtn');await page.click('#dest button[data-id="venus"]');
const row=[];
for(let k=0;k<45;k++){await page.waitForTimeout(1000);
  row.push(await page.evaluate(()=>{const an=__ac.__an,b=new Float32Array(an.fftSize),f=new Float32Array(an.frequencyBinCount);an.getFloatTimeDomainData(b);an.getFloatFrequencyData(f);let s=0;for(const x of b)s+=x*x;let mi=0;for(let i=1;i<f.length;i++)if(f[i]>f[mi])mi=i;return Math.sqrt(s/b.length).toFixed(3)+'@'+Math.round(mi*__ac.sampleRate/an.fftSize)+'Hz'}));}
console.log(mobile?'PHONE':'DESKTOP','level@peak per second:\n',row.join(' '));
console.log('errors',errs);await browser.close();
