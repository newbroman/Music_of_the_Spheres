/* ---------- the thinkers: each one's cosmos, drawn and sung their way ---------- */
const AU_KM=149597870.7, TONE=9/8, LIM=256/243, APO=2187/2048, MIN3=32/27;
// fixed-note cosmoses: [who, ratio to the base note, note name in the thinker's own system]
const THINK={
  pythagoras:{model:'siren',listen:'earth',base:220,voices:(()=>{let r=1;return [['moon',TONE],['mercury',LIM],['venus',APO],['sun',MIN3],['mars',TONE],['jupiter',LIM],['saturn',APO],['stars',LIM]].map(([w,s])=>[w,r*=s,''])})(),
    steps:{moon:1,mercury:.5,venus:.5,sun:1.5,mars:1,jupiter:.5,saturn:.5,stars:.5}},
  philolaus:{model:'siren',listen:'fire',base:164.81,voices:[['fire',.5,''],['counter',1,''],['moon',LIM,''],['sun',MIN3,''],['mercury',4/3,''],['venus',3/2,''],['mars',128/81,''],['jupiter',16/9,''],['saturn',2,''],['stars',2*MIN3,'']]},
  plato:{model:'siren',listen:'earth',base:73.42,voices:[['moon',1,'1'],['sun',2,'2'],['venus',3,'3'],['mercury',4,'4'],['mars',9,'9'],['jupiter',8,'8'],['saturn',27,'27'],['stars',6,'6']],
    fates:[['lachesis',2],['clotho',3],['atropos',4]]},
  aristotle:{model:'silence',listen:'earth',voices:[]},
  cicero:{model:'siren',listen:'earth',base:220,roar:true,voices:[['moon',1,'A'],['mercury',MIN3,'C'],['venus',MIN3,'C'],['sun',4/3,'D'],['mars',3/2,'E'],['jupiter',128/81,'F'],['saturn',16/9,'G'],['stars',2,'a']]},
  nicomachus:{model:'lyre',listen:'earth',base:164.81,voices:[['saturn',1,'hypate'],['jupiter',LIM,'parhypate'],['mars',MIN3,'lichanos'],['sun',4/3,'mese'],['venus',1024/729,'trite'],['mercury',128/81,'paranete'],['moon',16/9,'nete']]},
  ptolemy:{model:'siren',listen:'earth',base:13.75,aspects:true,voices:[['earthwater',8,'proslambanomenos'],['elements',9,'hypate hypaton'],['moon',12,'hypate meson'],['mercury',16,'mese'],['venus',16,'mese'],['sun',18,'paramese'],['mars',64/3,'nete synemmenon'],['jupiter',24,'nete diezeugmenon'],['saturn',32,'nete hyperbolaion']]},
  boethius:{model:'siren',listen:'earth',base:220,orders:{
    cicero:[['moon',1,'proslambanomenos'],['mercury',9/8,'hypate hypaton'],['venus',MIN3,'parhypate hypaton'],['sun',4/3,'lichanos hypaton'],['mars',3/2,'hypate meson'],['jupiter',128/81,'parhypate meson'],['saturn',16/9,'lichanos meson'],['heaven',2,'mese']],
    nicomachus:[['saturn',3/2,'hypate meson'],['jupiter',128/81,'parhypate meson'],['mars',16/9,'lichanos meson'],['sun',2,'mese'],['venus',2*LIM,'trite synemmenon'],['mercury',2*MIN3,'paranete synemmenon'],['moon',8/3,'nete synemmenon']]}},
  copernicus:{model:'bodies',listen:'sun',voices:[]},
  fludd:{model:'monochord',listen:'earth',base:98,voices:[['earth',1,'Γ'],['water',9/8,'A'],['air',81/64,'B'],['efire',4/3,'C'],['moon',3/2,'D'],['mercury',27/16,'E'],['venus',16/9,'F'],['sun',2,'G'],['mars',9/4,'a'],['jupiter',81/32,'b'],['saturn',8/3,'c'],['stars',3,'d'],['emp1',27/8,'e'],['emp2',32/9,'f'],['emp3',4,'g']]},
  kepler:{model:'bodies',listen:'sun',voices:[]},
  today:{model:'today',voices:[]}
};
const THINK_ORDER=['pythagoras','philolaus','plato','aristotle','cicero','nicomachus','ptolemy','boethius','copernicus','fludd','kepler','today'];
const KEP6=new Set(['mercury','venus','earth','mars','jupiter','saturn']);
// Kepler's voices: Saturn and Jupiter bass, Mars tenor, Earth and Venus alto, Mercury soprano; each planet keeps its true interval
const KEP_CENTRE={saturn:98,jupiter:131,mars:220,earth:330,venus:392,mercury:660};
const KEP_IV={saturn:'major third (4:5)',jupiter:'minor third (5:6)',mars:'fifth (2:3)',earth:'semitone, mi-fa (15:16)',venus:'diesis (24:25)',mercury:'octave and minor third (5:12)'};
const OM_N=b=>b.el.n*DEG;
function kepShift(b){return Math.round(Math.log2(KEP_CENTRE[b.id]/(330*OM_N(b)/OM_EARTH)))}
function kepF(b,om){return 330*(om/OM_EARTH)*Math.pow(2,kepShift(b))}
function kepEnds(b){const e=b.el.e,n=OM_N(b),k=Math.pow(1-e*e,1.5);return [kepF(b,n*(1-e)*(1-e)/k),kepF(b,n*(1+e)*(1+e)/k)]}
// Copernicus: perfect circles, so each planet holds the note of its mean speed, on the Pythagorean diatonic scale
function copF(b){const f=rawPitch(OM_N(b));const set=['C','D','E','F','G','A','B'].map(n=>Math.log2(PY[n]));set.push(1);const l=Math.log2(f/C_BASE),o=Math.floor(l),fr=l-o;let best=0,bd=9;for(const s of set){const d=Math.abs(s-fr);if(d<bd){bd=d;best=s}}return C_BASE*Math.pow(2,o+best)}
const isBodyModel=()=>THINK[S.thinker].model==='bodies';
const thinkerOn=()=>S.thinker!=='today';
const nn=f=>noteName(f).replace(/ [+−]\d+¢$/,'');

/* where each voice is: positions in the same frame as the planets (AU, ecliptic) */
function geo(who){
  const E=P.earth;
  if(who==='sun')return {x:-E.x,y:-E.y,z:-E.z};
  if(who==='moon'){const m=moonPos(byId.earth,byId.earth.moons[0],S.jd);return {x:m.x/AU_KM,y:m.y/AU_KM,z:m.z/AU_KM}}
  if(P[who])return {x:P[who].x-E.x,y:P[who].y-E.y,z:P[who].z-E.z};
  return null;
}
function voicePos(who){
  const E=P.earth,g=geo(who);
  if(g)return {x:E.x+g.x,y:E.y+g.y,z:E.z+g.z};
  if(['stars','heaven','emp1','emp2','emp3'].includes(who))return {x:E.x,y:E.y,z:E.z+3};
  if(who==='fire'||who==='counter')return {x:E.x,y:E.y,z:E.z-3};
  return {x:E.x,y:E.y,z:E.z}; // the elements, and the Earth itself: all around you
}
const lonOf=v=>Math.atan2(v.y,v.x);

/* ---- the Siren choir ---- */
const SIR={v:{},solo:null,boe:'cicero',roar:null,fl:{},plk:{},sweep:0,nextSweep:0,asp:[]};
const VOW_OF={moon:'u',sun:'a',mercury:'i',venus:'ah',mars:'e',jupiter:'a',saturn:'u',stars:'i',heaven:'i',earth:'o',earthwater:'o',elements:'ae',fire:'o',lachesis:'a',clotho:'o',atropos:'u'};
function thinkerVoices(){const th=THINK[S.thinker];if(S.thinker==='boethius')return th.orders[SIR.boe];return th.voices||[]}
function voiceF(w,r){return THINK[S.thinker].base*r}
function buildSiren(v,f,vowel){
  const I={srcs:[]};I.g=mkGain(0,v.vol);I.g.gain.setTargetAtTime(1,AC.currentTime,.3);
  I.o1=AC.createOscillator();I.o1.type='sawtooth';I.o1.frequency.value=f;I.o2=AC.createOscillator();I.o2.type='triangle';I.o2.frequency.value=f;I.o2.detune.value=7;
  const src=mkGain(.3);I.o1.connect(src);I.o2.connect(mkGain(.9,src));const form=mkGain(1);
  (VOWELS[vowel]||VOWELS.a).slice(0,2).forEach(([F,g],k)=>{const bp=AC.createBiquadFilter();bp.type='bandpass';bp.frequency.value=F;bp.Q.value=[6,9][k];src.connect(bp);bp.connect(mkGain(g*2,form))});
  src.connect(mkGain(.18,form));const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=2800;form.connect(lp);lp.connect(I.g);
  I.vib=AC.createOscillator();I.vib.frequency.value=4.5+Math.random()*1.2;I.vd=mkGain(f*.005);I.vib.connect(I.vd);I.vd.connect(I.o1.frequency);I.vd.connect(I.o2.frequency);
  I.srcs.push(I.o1,I.o2,I.vib);I.srcs.forEach(o=>o.start());return I;
}
function sirenBody(who,f){
  const fate=['lachesis','clotho','atropos'].includes(who);
  const words=fate?{lachesis:'l a k e s i: s',clotho:'k l o: t o:',atropos:'a t r o p o: s'}[who]:(VOW_OF[who]==='u'?'u:':VOW_OF[who]==='i'?'i:':VOW_OF[who]==='o'?'o:':'a:');
  return {id:'siren:'+who,kind:'minor',tiltWob:0,hv:{type:fate?'alto':f<300?'alto':'soprano',tilt:1.15,vib:[5.2,.025],breath:.09,jit:.004,syl:fate?.8:1.8,rest:fate?2.2:1.0,ens:.15,words}};
}
// a plucked string, for the lyre and the monochord
function strPluck(v,f,lvl,dec){
  const t=AC.currentTime+.03,o=AC.createOscillator(),o2=AC.createOscillator();o.type='sawtooth';o2.type='triangle';o.frequency.value=f;o2.frequency.value=f*2.003;
  const lp=AC.createBiquadFilter();lp.type='lowpass';lp.Q.value=.8;lp.frequency.setValueAtTime(Math.min(9000,f*10),t);lp.frequency.setTargetAtTime(f*1.6,t,dec*.3);
  const g=mkGain(0);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(lvl,t+.004);g.gain.setTargetAtTime(0,t+.004,dec);
  o.connect(lp);o2.connect(mkGain(.25,lp));lp.connect(g);g.connect(v.vol);o.start(t);o2.start(t);o.stop(t+dec*6);o2.stop(t+dec*6);
}
function sirenVoice(who){
  let v=SIR.v[who];if(v)return v;
  v=SIR.v[who]={pan:mkPanner(!LOWPOWER),part:null,mode:null};v.vol=mkGain(0,v.pan);return v;
}
function killSirens(){Object.values(SIR.v).forEach(v=>{if(v.part){killPart(v.part);v.part=null}tgt(v.vol.gain,0,.1)});if(SIR.roar){const r=SIR.roar;tgt(r.g.gain,0,.3);setTimeout(()=>{try{r.src.stop()}catch(e){}},900);SIR.roar=null}}
function hushWorld(){
  if(!AC)return;
  BODIES.forEach(b=>{const v=V[b.id];if(!v)return;if(v.part){killPart(v.part);v.part=null;v.mode=null}tgt(v.vol.gain,0,.1);tgt(v.moonVol.gain,0,.1);
    (b.moons||[]).forEach(m=>{if(m.sv&&m.sv.part){killPart(m.sv.part);m.sv.part=null}})});
  tgt(sunV.vol.gain,0,.2);ASP.forEach(s=>tgt(s.g.gain,0,.2));POOL.forEach(s=>tgt(s.g.gain,0,.1));
}
function ptolemyAspects(){
  const ids=['moon','mercury','venus','sun','mars','jupiter','saturn'],L=ids.map(w=>[w,lonOf(geo(w))/DEG]),out=[];
  const AS=[[180,7,'☍',2],[120,6,'△',1.5],[90,6,'□',4/3]];
  for(let i=0;i<L.length;i++)for(let j=i+1;j<L.length;j++){let s=Math.abs(L[i][1]-L[j][1])%360;if(s>180)s=360-s;
    for(const [a,o,sym,r] of AS){const d=Math.abs(s-a);if(d<o){out.push({a:L[i][0],b:L[j][0],sym,r,str:Math.pow(1-d/o,2)});break}}}
  return out.sort((x,y)=>y.str-x.str).slice(0,3);
}
function thinkerAudio(){
  const th=THINK[S.thinker],now=AC.currentTime,E=P.earth;
  const ang=Math.atan2(-E.y,-E.x)+S.turn*DEG;setListener(ang);
  const list=thinkerVoices().slice();if(th.fates&&!LOWPOWER)th.fates.forEach(([w,r])=>list.push([w,r,'']));
  const want=new Set(list.map(x=>x[0]));
  Object.keys(SIR.v).forEach(w=>{if(!want.has(w)){const v=SIR.v[w];if(v.part){killPart(v.part);v.part=null}tgt(v.vol.gain,0,.15)}});
  SIR.asp=th.aspects?ptolemyAspects():[];
  const swell={};SIR.asp.forEach(a=>{swell[a.a]=Math.max(swell[a.a]||0,a.str);swell[a.b]=Math.max(swell[a.b]||0,a.str)});
  // Cicero: the roar that deafens us, like the cataracts of the Nile
  if(th.roar&&!SIR.roar){const src=AC.createBufferSource();src.buffer=noiseBuf;src.loop=true;const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=260;const bp=AC.createBiquadFilter();bp.type='bandpass';bp.frequency.value=90;bp.Q.value=.7;const g=mkGain(0,bus);src.connect(lp);lp.connect(g);src.connect(bp);bp.connect(mkGain(1.4,g));src.start();SIR.roar={src,g}}
  if(SIR.roar)tgt(SIR.roar.g.gain,SIR.solo?0:.16,.6);
  let built=0;const humanCap=LOWPOWER?6:99;let humans=0;
  list.forEach(([w,r])=>{
    const v=sirenVoice(w),f=voiceF(w,r),silent=w==='counter';
    const pos=voicePos(w),a=audioDir(pos,E);setPos(v.pan,a.x,a.y,a.z,.15);
    const fate=['lachesis','clotho','atropos'].includes(w);
    let lvl=silent?0:(SIR.solo?(SIR.solo===w?.11:0):fate?.03*(.6+.4*Math.sin(now*.25+r*2)):.07);
    lvl*=1+.7*(swell[w]||0);
    if(th.model==='lyre'||th.model==='monochord'){tgt(v.vol.gain,silent?0:(SIR.solo&&SIR.solo!==w?0:1),.1);v.f=f;return}
    const mode=S.voices==='human'&&humans<humanCap?'human':'instrument';if(mode==='human')humans++;
    if(v.part&&v.mode!==mode){killPart(v.part);v.part=null}
    if(!v.part&&!silent&&built<3){v.part=mode==='human'?buildHumanPart(sirenBody(w,f),v):buildSiren(v,f,VOW_OF[w]);v.mode=mode;built++}
    if(v.part){if(v.mode==='instrument'){tgt(v.part.o1.frequency,f,.2);tgt(v.part.o2.frequency,f,.2)}else humanTick(v.part.h,f,1,now)}
    v.f=f;tgt(v.vol.gain,lvl*(v.mode==='human'?.9:1),.25);
  });
  // Nicomachus: each planet plucks its lyre string, quicker the quicker its own orbit
  if(th.model==='lyre'){list.forEach(([w,r])=>{const v=SIR.v[w];const per=w==='moon'?27.32:w==='sun'?365.25:byId[w].Pyears*365.25;
    const gap=.55*Math.pow(per/27.32,.22);if(!v.next||now>v.next+2)v.next=now+Math.random()*gap;
    if(now>=v.next){v.next+=gap*(.9+Math.random()*.2);strPluck(v,v.f,.042,1.4);SIR.plk[w]=performance.now()}})}
  // Fludd: the hand of God plucks the monochord, fret by fret, up two octaves and down again
  if(th.model==='monochord'){const n=list.length;if(now>=SIR.nextSweep){const k=SIR.sweep%(2*n-2),i=k<n?k:2*n-2-k;const [w]=list[i],v=SIR.v[w];
    if(!SIR.solo||SIR.solo===w)strPluck(v,v.f,['moon','mercury','venus','sun','mars','jupiter','saturn'].includes(w)?.07:.05,1.8);SIR.plk[w]=performance.now();SIR.sweep++;SIR.nextSweep=Math.max(now,SIR.nextSweep)+(i===7?.9:.45)}}
}

/* ---- switching thinker ---- */
let SAVED=null;
function setThinker(id){
  if(!THINK[id]||S.thinker===id)return;
  if(S.thinker==='today')SAVED={vp:S.vp,face:S.face};
  if(SYS.id)leaveSystem();
  S.audition=null;SIR.solo=null;
  S.thinker=id;
  if(AC){killSirens();hushWorld();stopSpeech()}
  if(id==='today'){if(SAVED){S.vp=SAVED.vp;S.face=SAVED.face}}
  else if(isBodyModel()){S.vp='sun';S.face='vernal'}
  else S.vp='earth';
  $('vp').value=S.vp;$('face').value=S.face;
  document.body.classList.toggle('thinking',id!=='today');
  try{history.replaceState(null,'',id==='today'?location.pathname:'#'+id)}catch(e){}
  renderTimeline();renderRoster();renderInfo();renderAud();
  if(audioOn&&AC)updateAudio();
}
function thinkerTap(best){
  if(isBodyModel()){if(best&&KEP6.has(best)){if(S.audition===best)endAudition();else audition(best)}else if(S.audition)endAudition();return}
  const ws=thinkerVoices().map(x=>x[0]);if(best&&ws.includes(best)&&best!=='counter'){SIR.solo=SIR.solo===best?null:best}else SIR.solo=null;
  if(!audioOn)startAudio();renderInfo();renderAud();
}

/* ---- the timeline and the reading ---- */
function renderTimeline(){
  $('timeline').innerHTML=`<span class="tl-lab">${TT.ui.timeline}</span><div class="tl-row">`+THINK_ORDER.map(id=>{const t=TT[id];return `<button class="tl-chip${S.thinker===id?' on':''}" data-t="${id}" aria-pressed="${S.thinker===id}"><b>${t.name}</b><span>${t.when}</span></button>`}).join('')+'</div>';
  const on=$('timeline').querySelector('.on');if(on&&on.scrollIntoView)try{on.scrollIntoView({block:'nearest',inline:'center'})}catch(e){}
}
function bodyName(w){return TT.bodies[w]||(byId[w]?byId[w].name:w)}
function thinkerInfoHTML(){
  const id=S.thinker,t=TT[id],th=THINK[id];
  const listen=th.listen==='sun'?TT.ui.sun:th.listen==='fire'?TT.ui.fire:TT.ui.earth;
  let side='';
  if(th.model==='bodies'&&id==='kepler'){
    side=`<h4>${TT.ui.kepTitle}</h4><div class="vlist">`+[...KEP6].map(k=>{const b=byId[k],[lo,hi]=kepEnds(b);return `<button class="vrow2${S.audition===k?' on':''}" data-w="${k}"><span class="sw" style="background:${b.color}"></span><span class="nm">${b.god} <i>${b.name}</i><br><small>${KEP_IV[k]} · ${nn(lo)} – ${nn(hi)}</small></span><span class="nt" id="tv_${k}">${nn(P[k].f)}</span></button>`}).join('')+'</div>';
  }else if(th.model==='bodies'){
    side=`<h4>${TT.ui.voices}</h4><div class="vlist">`+[...KEP6].map(k=>{const b=byId[k];return `<button class="vrow2${S.audition===k?' on':''}" data-w="${k}"><span class="sw" style="background:${b.color}"></span><span class="nm">${b.god} <i>${b.name}</i></span><span class="nt">${nn(P[k].f)}</span></button>`}).join('')+'</div>';
  }else if(th.model!=='silence'){
    const list=thinkerVoices();
    side=`<h4>${TT.ui.voices} <small>${TT.ui.tapSolo}</small></h4><div class="vlist">`+list.map(([w,r,nm])=>{const silent=w==='counter';return `<button class="vrow2${SIR.solo===w?' on':''}${silent?' mute':''}" data-w="${w}"><span class="sw" style="background:${colorOf(w)}"></span><span class="nm">${bodyName(w)}${nm?` <i>${nm}</i>`:''}${silent?`<br><small>${TT.ui.hidden}</small>`:''}</span><span class="nt" id="tv_${w}">${silent?'—':nn(voiceF(w,r))}</span></button>`}).join('')+'</div>'+
      (th.fates?`<p class="small">${TT.bodies.fates}: ${th.fates.map(([w,r])=>bodyName(w)+' '+nn(th.base*r)).join(' · ')}</p>`:'')+
      (th.aspects?`<p class="small" id="tAsp"></p>`:'');
  }
  const acts=(id==='boethius'?`<div class="seg" id="boeSeg"><button data-o="cicero" aria-pressed="${SIR.boe==='cicero'}">${TT.ui.orderCicero}</button><button data-o="nicomachus" aria-pressed="${SIR.boe==='nicomachus'}">${TT.ui.orderNico}</button></div>`:'')+
    (id==='aristotle'?`<button class="btn" id="replyBtn" style="border-color:var(--bronze);color:var(--bronze)">${TT.ui.reply}</button>`:'');
  return `<div class="reading">
      <div class="greek">${t.when} · ${t.work}</div>
      <h3>${t.name}</h3>
      <div class="sub">${TT.ui.from} ${listen}</div>
      <p class="idea">${t.idea}</p>
      <div class="sh"><div><h4>${TT.ui.see}</h4><p>${t.see}</p></div><div><h4>${TT.ui.hear}</h4><p>${t.hear}</p></div></div>
      ${t.quote?`<blockquote>“${t.quote}”<cite>${t.cite}</cite></blockquote>`:''}
      ${t.doubt?`<p class="doubt"><b>${TT.ui.doubt}:</b> ${t.doubt}</p>`:''}
      ${acts?`<div class="acts">${acts}</div>`:''}
    </div><div class="voices2">${side}</div>`;
}
function colorOf(w){return byId[w]?byId[w].color:{moon:'#cfd6e0',sun:'#ffd98a',stars:'#e9e1cc',heaven:'#e9e1cc',earth:'#74abdc',earthwater:'#5f8fb8',elements:'#e08a4a',fire:'#ff9a3c',counter:'#555a70',water:'#5b8fd6',air:'#cfe3f0',efire:'#e8743b',emp1:'#f3e6c4',emp2:'#f7edd2',emp3:'#fff6e0',lachesis:'#c9984f',clotho:'#c9984f',atropos:'#c9984f'}[w]||'#c9984f'}
function wireThinkerInfo(){
  $('info').querySelectorAll('.vrow2').forEach(b=>b.onclick=()=>thinkerTap(b.dataset.w));
  const bs=$('boeSeg');if(bs)bs.querySelectorAll('button').forEach(b=>b.onclick=()=>{SIR.boe=b.dataset.o;killSirens();SIR.solo=null;renderInfo();if(!audioOn)startAudio()});
  const rp=$('replyBtn');if(rp)rp.onclick=()=>{setThinker('pythagoras');if(!audioOn)startAudio()};
}
function tickThinkerInfo(){
  if(S.thinker==='kepler')[...KEP6].forEach(k=>{const el=$('tv_'+k);if(el)el.textContent=nn(P[k].f)});
  const ta=$('tAsp');if(ta)ta.textContent=SIR.asp.length?SIR.asp.map(a=>`${bodyName(a.a)} ${a.sym}︎ ${bodyName(a.b)}`).join(' · ')+' — '+TT.ui.aspect:'';
}

/* ---- drawing each cosmos ---- */
const SCR={};
function dot(g,x,y,r,c,glow){if(glow){const gr=g.createRadialGradient(x,y,0,x,y,r*3.2);gr.addColorStop(0,hexA(c,.55*glow));gr.addColorStop(1,hexA(c,0));g.fillStyle=gr;g.beginPath();g.arc(x,y,r*3.2,0,TAU);g.fill()}g.fillStyle=c;g.beginPath();g.arc(x,y,r,0,TAU);g.fill()}
function ring(g,r,c,w,dash){g.strokeStyle=c;g.lineWidth=w||1;g.setLineDash(dash||[]);g.beginPath();g.arc(CX,CY,r,0,TAU);g.stroke();g.setLineDash([])}
function label(g,txt,x,y,c,size,align,font){g.fillStyle=c||'rgba(233,225,204,.85)';g.font=`${size||12}px ${font||'"Alegreya Sans",sans-serif'}`;g.textAlign=align||'left';g.textBaseline='middle';g.fillText(txt,x,y)}
const scrPt=(lon,r)=>({x:CX+r*Math.cos(lon+S.az),y:CY-r*Math.sin(lon+S.az)});
function pulse(w,t){if(SIR.solo&&SIR.solo!==w)return .15;const p=SIR.plk[w];if(p)return Math.max(.25,1-(t-p)/900);return .55+.45*Math.sin(t/700+w.length)}
function placeBody(g,w,lon,r,t,size){const p=scrPt(lon,r);SCR[w]=p;dot(g,p.x,p.y,size||4.5,colorOf(w),pulse(w,t));return p}
function noteTag(g,w,p,txt){label(g,txt,p.x+9,p.y-1,'rgba(233,225,204,.88)',12)}
function geoNoteRings(g,t,radii,order,withNames){
  // a body on each ring at its true direction from the Earth
  order.forEach(w=>{const r=radii[w];if(r===undefined)return;const v=geo(w);const lon=v?lonOf(v):(t/40000)%TAU;
    const p=placeBody(g,w,lon,r,t,w==='sun'?7:w==='stars'||w==='heaven'?3:4.5);
    const vv=thinkerVoices().find(x=>x[0]===w);if(withNames!==false)noteTag(g,w,p,bodyName(w)+(vv&&w!=='counter'?' · '+nn(voiceF(w,vv[1])):''))});
}
function drawStarsBg(g,a){STARS.forEach(s=>{g.fillStyle=`rgba(233,225,204,${(a||1)*(.1+s.m*.3)})`;g.fillRect(s.x*W,s.y*H,1,1)})}
function earthAt(g,x,y,r){dot(g,x,y,r||6,'#74abdc',.4);SCR.earth=SCR.earth||{x,y}}

const D_THINK={
  pythagoras(g,t){
    drawStarsBg(g,.7);const th=THINK.pythagoras,tot=6,R=RR*1.02;let cum=0;const radii={};
    ['moon','mercury','venus','sun','mars','jupiter','saturn','stars'].forEach(w=>{cum+=th.steps[w];radii[w]=R*(.1+.9*cum/tot)});
    // the string: the cosmos as a monochord stretched from the Earth to the stars
    const ax=CX,ay=CY;g.strokeStyle='rgba(201,152,79,.5)';g.lineWidth=1.4;g.beginPath();g.moveTo(ax,ay);g.lineTo(ax+radii.stars,ay);g.stroke();
    let prev=0;Object.entries(radii).forEach(([w,r])=>{ring(g,r,hexA(colorOf(w),.28),1);g.strokeStyle='rgba(201,152,79,.8)';g.beginPath();g.moveTo(ax+r,ay-5);g.lineTo(ax+r,ay+5);g.stroke();
      const st=th.steps[w];label(g,st===1?TT.ui.tone||'tone':st===.5?'½':'1½',ax+(prev+r)/2,ay+11,'rgba(201,152,79,.85)',10,'center');prev=r});
    earthAt(g,CX,CY,6);geoNoteRings(g,t,radii,Object.keys(radii));
  },
  philolaus(g,t){
    drawStarsBg(g,.7);const R=RR*1.02,rr={moon:.3,sun:.42,mercury:.52,venus:.61,mars:.7,jupiter:.79,saturn:.88,stars:.98};
    const fg=g.createRadialGradient(CX,CY,0,CX,CY,RR*.12);fg.addColorStop(0,'rgba(255,240,200,1)');fg.addColorStop(.35,'rgba(255,150,60,.9)');fg.addColorStop(1,'rgba(255,120,40,0)');g.fillStyle=fg;g.beginPath();g.arc(CX,CY,RR*.12,0,TAU);g.fill();SCR.fire={x:CX,y:CY};
    label(g,bodyName('fire'),CX,CY+RR*.09,'rgba(255,214,160,.95)',12,'center');
    // the Earth and the Counter-earth circle the fire once a day, always on opposite sides
    const day=((S.jd%1)+1)%1*TAU, re=RR*.17;ring(g,re,'rgba(116,171,220,.35)',1,[2,4]);
    const ep=scrPt(day,re),cp=scrPt(day+Math.PI,re);dot(g,ep.x,ep.y,5,'#74abdc',.5);SCR.earth=ep;label(g,bodyName('earth'),ep.x+8,ep.y,'rgba(233,225,204,.85)',11);
    dot(g,cp.x,cp.y,4.5,'#555a70');SCR.counter=cp;label(g,bodyName('counter'),cp.x+8,cp.y,'rgba(163,156,137,.8)',11);
    const radii={};Object.entries(rr).forEach(([w,f])=>{radii[w]=R*f;ring(g,R*f,hexA(colorOf(w),.25),1)});geoNoteRings(g,t,radii,Object.keys(radii));
  },
  plato(g,t){
    drawStarsBg(g,.5);
    // the whorls of the Spindle, outside in, with Plato's widths (rank 1 widest) and colours
    const W8=[['stars',1,'#2b3260'],['saturn',8,'#d6c27a'],['jupiter',7,'#f4f1e8'],['mars',3,'#c8553d'],['mercury',6,'#d6c27a'],['venus',2,'#ece6d6'],['sun',5,'#ffd98a'],['moon',4,'#c3cbd8']];
    const units=W8.reduce((a,x)=>a+(9-x[1]),0),R=RR*1.02,inner=RR*.1;let r=R;const radii={};
    W8.forEach(([w,rank,c])=>{const wd=(R-inner)*(9-rank)/units;const mid=r-wd/2;g.strokeStyle=hexA(c,w==='stars'?.45:.26);g.lineWidth=Math.max(2,wd*.7);g.beginPath();g.arc(CX,CY,mid,0,TAU);g.stroke();radii[w]=mid;r-=wd});
    // the starry whorl spangled, turning with the day
    const spin=((S.jd%1)+1)%1*TAU;for(let k=0;k<90;k++){const a=k*2.399+spin,rad=radii.stars+(((k*37)%11)/11-.5)*(R-radii.stars)*1.4;const p={x:CX+rad*Math.cos(a),y:CY-rad*Math.sin(a)};g.fillStyle='rgba(233,225,204,.75)';g.fillRect(p.x,p.y,1.3,1.3)}
    // the shaft of Necessity's spindle
    g.strokeStyle='rgba(201,152,79,.75)';g.lineWidth=2;g.beginPath();g.moveTo(CX,CY-RR*1.12);g.lineTo(CX,CY+RR*1.12);g.stroke();dot(g,CX,CY,4,'#c9984f');
    geoNoteRings(g,t,radii,Object.keys(radii));
    // the Fates at the rim
    THINK.plato.fates.forEach(([w],k)=>{const a=-Math.PI/2+(k-1)*.55;const p={x:CX+RR*1.1*Math.cos(a),y:CY-RR*1.1*Math.sin(a)};label(g,bodyName(w),p.x,p.y,'rgba(201,152,79,.9)',12,'center','"GFS Didot",Georgia,serif')});
  },
  aristotle(g,t){
    drawStarsBg(g,.4);const R=RR*1.0;
    [['efire','#e8743b',.17],['air','#cfe3f0',.14],['water','#5b8fd6',.11],['earth','#8a6a45',.08]].forEach(([w,c,f])=>{g.fillStyle=hexA(c,.22);g.beginPath();g.arc(CX,CY,RR*f,0,TAU);g.fill()});
    const radii={},order=['moon','mercury','venus','sun','mars','jupiter','saturn','stars'];
    order.forEach((w,k)=>{const r=R*(.24+.095*k);radii[w]=r;const gr=g.createRadialGradient(CX,CY,r-6,CX,CY,r+2);gr.addColorStop(0,'rgba(180,210,255,0)');gr.addColorStop(1,'rgba(180,210,255,.16)');g.fillStyle=gr;g.beginPath();g.arc(CX,CY,r+2,0,TAU);g.fill();ring(g,r,'rgba(200,220,255,.35)',1)});
    ring(g,R*1.03,'rgba(201,152,79,.6)',2);label(g,TT.ui.prime+' · τὸ πρῶτον κινοῦν',CX,CY-R*1.07,'rgba(201,152,79,.9)',12,'center','"GFS Didot",Georgia,serif');
    earthAt(g,CX,CY,5);geoNoteRings(g,t,radii,order,false);order.forEach(w=>{const p=SCR[w];if(p)label(g,bodyName(w),p.x+8,p.y,'rgba(233,225,204,.75)',11)});
    label(g,'σιγή',CX,CY+RR*.55,'rgba(233,225,204,.12)',Math.max(28,RR*.2),'center','"GFS Didot",Georgia,serif');
  },
  cicero(g,t){
    drawStarsBg(g,.9);
    // the Milky Way, where Scipio stands
    const mw=g.createLinearGradient(0,CY-RR*1.2,0,CY-RR*.6);mw.addColorStop(0,'rgba(233,225,204,0)');mw.addColorStop(.5,'rgba(233,225,204,.12)');mw.addColorStop(1,'rgba(233,225,204,0)');g.fillStyle=mw;g.save();g.translate(CX,CY);g.rotate(-.35);g.fillRect(-W,-RR*1.15,W*2,RR*.45);g.restore();
    const order=['moon','mercury','venus','sun','mars','jupiter','saturn','stars'],radii={};order.forEach((w,k)=>{radii[w]=RR*(.2+.11*k);ring(g,radii[w],hexA(colorOf(w),.3),1)});
    // ripples of the overwhelming sound
    for(let k=0;k<4;k++){const f=((t/2600+k/4)%1);g.strokeStyle=`rgba(201,152,79,${.18*(1-f)})`;g.lineWidth=1;g.beginPath();g.arc(CX,CY,RR*.06+f*RR*.9,0,TAU);g.stroke()}
    earthAt(g,CX,CY,3);label(g,bodyName('earth')+' · '+TT.ui.silent,CX,CY+12,'rgba(163,156,137,.85)',11,'center');
    geoNoteRings(g,t,radii,order);
  },
  nicomachus(g,t){
    drawStarsBg(g,.5);const list=THINK.nicomachus.voices,n=list.length,w=Math.min(W*.7,RR*1.6),top=CY-RR*.78,bot=CY+RR*.55,x0=CX-w/2;
    // the lyre: tortoise-shell sound box, two horns, the yoke
    g.fillStyle='rgba(127,98,54,.35)';g.strokeStyle='rgba(201,152,79,.8)';g.lineWidth=2;g.beginPath();g.ellipse(CX,bot+RR*.12,w*.62,RR*.2,0,0,TAU);g.fill();g.stroke();
    g.beginPath();g.moveTo(x0-w*.08,bot);g.bezierCurveTo(x0-w*.32,CY,x0-w*.02,top+RR*.1,x0-w*.14,top-RR*.12);g.moveTo(x0+w*1.08,bot);g.bezierCurveTo(x0+w*1.32,CY,x0+w*1.02,top+RR*.1,x0+w*1.14,top-RR*.12);g.stroke();
    g.lineWidth=5;g.beginPath();g.moveTo(x0-w*.14,top);g.lineTo(x0+w*1.14,top);g.stroke();
    list.forEach(([wh,r,nm],k)=>{const x=x0+w*(k+.5)/n,age=(t-(SIR.plk[wh]||-9999))/1000,amp=age<2?7*Math.exp(-age*2.2)*Math.sin(t/14+k):0;
      g.strokeStyle=hexA(colorOf(wh),.85);g.lineWidth=1.6;g.beginPath();g.moveTo(x,top);g.quadraticCurveTo(x+amp,(top+bot)/2,x,bot);g.stroke();
      SCR[wh]={x,y:(top+bot)/2};dot(g,x,top-12,4,colorOf(wh),age<1.5?1-age/1.5:.2);
      g.save();g.translate(x-7,bot-14);g.rotate(-Math.PI/2);label(g,bodyName(wh)+' · '+nm+' · '+nn(voiceF(wh,r)),0,0,'rgba(233,225,204,.9)',12,'left');g.restore()});
  },
  ptolemy(g,t){
    drawStarsBg(g,.6);const sh={moon:.14,mercury:.27,venus:.4,sun:.52,mars:.65,jupiter:.79,saturn:.93};
    g.fillStyle='rgba(116,171,220,.12)';g.beginPath();g.arc(CX,CY,RR*.07,0,TAU);g.fill();earthAt(g,CX,CY,5);
    const E=P.earth,rot=v=>({x:v.x*Math.cos(S.az)-v.y*Math.sin(S.az),y:v.x*Math.sin(S.az)+v.y*Math.cos(S.az)});const sp=v=>({x:CX+v.x,y:CY-v.y});
    ['moon','sun'].forEach(w=>{const r=RR*sh[w];ring(g,r,hexA(colorOf(w),.3),1)});
    // trails over the last synodic period show the loops
    if(!D_THINK.trail||Math.abs(D_THINK.trail.jd-S.jd)>.5){const tr={jd:S.jd};const SYN={mercury:116,venus:584,mars:780,jupiter:399,saturn:378};
      Object.keys(SYN).forEach(w=>{const b=byId[w],pts=[];for(let k=0;k<=96;k++){const jd=S.jd-SYN[w]*k/96,pp=posAt(b.el,jd),ee=posAt(byId.earth.el,jd);pts.push({x:pp.x-ee.x,y:pp.y-ee.y})}tr[w]=pts});D_THINK.trail=tr}
    ['mercury','venus','mars','jupiter','saturn'].forEach(w=>{
      const b=byId[w],p=P[w],a=b.el.a,inner=a<1,s=RR*sh[w]/(1+a);
      const defR=s*(inner?1:a),epiC=inner?{x:-E.x*s,y:-E.y*s}:{x:p.x*s,y:p.y*s},epiR=s*(inner?a:1);
      ring(g,defR,hexA(b.color,.18),1,[3,4]);const c=sp(rot(epiC));g.strokeStyle=hexA(b.color,.45);g.lineWidth=1;g.beginPath();g.arc(c.x,c.y,epiR,0,TAU);g.stroke();dot(g,c.x,c.y,1.5,hexA(b.color,.7));
      const tr=D_THINK.trail[w];g.strokeStyle=hexA(b.color,.35);g.beginPath();tr.forEach((q,k)=>{const z=sp(rot({x:q.x*s,y:q.y*s}));k?g.lineTo(z.x,z.y):g.moveTo(z.x,z.y)});g.stroke();
      const pos=sp(rot({x:(p.x-E.x)*s,y:(p.y-E.y)*s}));g.strokeStyle=hexA(b.color,.3);g.beginPath();g.moveTo(c.x,c.y);g.lineTo(pos.x,pos.y);g.stroke();
      SCR[w]=pos;dot(g,pos.x,pos.y,4.5,b.color,pulse(w,t));const vv=thinkerVoices().find(x=>x[0]===w);noteTag(g,w,pos,bodyName(w)+' · '+nn(voiceF(w,vv[1])));
    });
    ['moon','sun'].forEach(w=>{const v=geo(w),p=scrPt(lonOf(v),RR*sh[w]);SCR[w]=p;dot(g,p.x,p.y,w==='sun'?7:4.5,colorOf(w),pulse(w,t));const vv=thinkerVoices().find(x=>x[0]===w);noteTag(g,w,p,bodyName(w)+' · '+nn(voiceF(w,vv[1])))});
    SIR.asp.forEach(a=>{const p=SCR[a.a],q=SCR[a.b];if(!p||!q)return;g.strokeStyle=`rgba(201,152,79,${.25+.6*a.str})`;g.lineWidth=1+a.str*2;g.beginPath();g.moveTo(p.x,p.y);g.lineTo(q.x,q.y);g.stroke();label(g,a.sym+'︎',(p.x+q.x)/2,(p.y+q.y)/2,'rgba(201,152,79,1)',15,'center','"GFS Didot",Georgia,serif')});
  },
  boethius(g,t){
    const R=RR*1.0;g.fillStyle='#e6d8b8';g.beginPath();g.arc(CX,CY,R*1.08,0,TAU);g.fill();g.strokeStyle='#8b1e1e';g.lineWidth=3;ring(g,R*1.06,'#8b1e1e',3);ring(g,R*1.02,'#3b2a1a',1);
    const list=thinkerVoices(),order=SIR.boe==='cicero'?['moon','mercury','venus','sun','mars','jupiter','saturn','heaven']:['moon','mercury','venus','sun','mars','jupiter','saturn'];
    const LAT={moon:'Luna',mercury:'Mercurius',venus:'Venus',sun:'Sol',mars:'Mars',jupiter:'Iuppiter',saturn:'Saturnus',heaven:'Caelum'};const radii={};
    order.forEach((w,k)=>{const r=R*(.16+.11*k);radii[w]=r;ring(g,r,'rgba(59,42,26,.55)',1)});
    dot(g,CX,CY,R*.08,'#6b8f5a');label(g,'Terra',CX,CY,'#f3ead2',11,'center','"GFS Didot",Georgia,serif');
    order.forEach(w=>{const vv=list.find(x=>x[0]===w);if(!vv)return;const v=geo(w);const lon=v?lonOf(v):-Math.PI/2+.4;const p=scrPt(lon,radii[w]);SCR[w]=p;
      const a=pulse(w,t);g.fillStyle=`rgba(139,30,30,${.5+.5*a})`;g.beginPath();g.arc(p.x,p.y,4.5,0,TAU);g.fill();
      label(g,LAT[w]+' · '+vv[2],p.x+8,p.y,'#3b2a1a',12,'left','"GFS Didot",Georgia,serif')});
    label(g,'MVSICA MVNDANA',CX,CY-R*1.15,'#c9984f',14,'center','"GFS Didot",Georgia,serif');
  },
  copernicus(g,t){
    drawStarsBg(g,.6);const LAT=[['stars','Stellarum fixarum sphaera immobilis'],['saturn','Saturnus anno XXX revolvitur'],['jupiter','Iovis XII annorum revolutio'],['mars','Martis bima revolutio'],['earth','Telluris cum orbe lunari annua revolutio'],['venus','Venus nono mense reducitur'],['mercury','Mercurius LXXX dierum']];
    const R=RR*1.02,step=R/7.4;
    LAT.forEach(([w,txt],k)=>{const r=R-k*step;ring(g,r,'rgba(233,225,204,.42)',1);g.save();g.translate(CX,CY);label(g,txt,0,-r+step*.5,'rgba(201,152,79,.7)',Math.max(9,Math.min(12,step*.32)),'center','"GFS Didot",Georgia,serif');g.restore();
      if(w!=='stars'){const b=byId[w],p=scrPt(lonOf(P[w]),r-step*.0);SCR[w]=p;dot(g,p.x,p.y,4.5,b.color,S.audition&&S.audition!==w?.15:.6);label(g,b.god+' · '+nn(P[w].f),p.x+8,p.y,'rgba(233,225,204,.85)',11);
        if(w==='earth'){ring2(g,p,step*.32);const m=moonPos(byId.earth,byId.earth.moons[0],S.jd),ml=Math.atan2(m.y,m.x)+S.az;dot(g,p.x+step*.32*Math.cos(ml),p.y-step*.32*Math.sin(ml),2.5,'#cfd6e0')}}});
    const sg=g.createRadialGradient(CX,CY,0,CX,CY,step*.6);sg.addColorStop(0,'rgba(255,240,200,1)');sg.addColorStop(1,'rgba(255,190,90,0)');g.fillStyle=sg;g.beginPath();g.arc(CX,CY,step*.6,0,TAU);g.fill();label(g,'Sol',CX,CY+step*.45,'rgba(255,220,160,.9)',11,'center','"GFS Didot",Georgia,serif');
  },
  fludd(g,t){
    drawStarsBg(g,.5);const list=THINK.fludd.voices,n=list.length,top=CY-RR*.98,bot=CY+RR*.98,x=CX-RR*.12;
    const LAT={earth:'Terra',water:'Aqua',air:'Aer',efire:'Ignis',moon:'Luna',mercury:'Mercurius',venus:'Venus',sun:'Sol',mars:'Mars',jupiter:'Iupiter',saturn:'Saturnus',stars:'Coelum stellatum',emp1:'Empyreum inf.',emp2:'Empyreum med.',emp3:'Empyreum sup.'};
    // the hand that tunes the string, from a cloud
    for(let k=0;k<5;k++){g.fillStyle='rgba(233,225,204,.08)';g.beginPath();g.arc(x+(k-2)*RR*.08,top-RR*.06,RR*.07,0,TAU);g.fill()}
    g.strokeStyle='rgba(201,152,79,.9)';g.lineWidth=3;g.beginPath();g.moveTo(x-8,top);g.lineTo(x+8,top);g.stroke();
    const last=Math.max(...list.map(([w])=>SIR.plk[w]||0)),age=(t-last)/1000,amp=age<2?5*Math.exp(-age*2)*Math.sin(t/12):0;
    g.strokeStyle='rgba(233,225,204,.85)';g.lineWidth=1.4;g.beginPath();g.moveTo(x,bot);g.quadraticCurveTo(x+amp,CY,x,top);g.stroke();
    list.forEach(([w,r,nm],k)=>{const y=bot-(bot-top)*Math.log2(r)/2;const a=pulse(w,t);g.strokeStyle=hexA(colorOf(w),.5+.5*a);g.lineWidth=2;g.beginPath();g.moveTo(x-10,y);g.lineTo(x+10,y);g.stroke();
      SCR[w]={x:x+60,y};label(g,nm,x-16,y,'rgba(201,152,79,.95)',12,'right','"GFS Didot",Georgia,serif');label(g,LAT[w]+'  '+nn(voiceF(w,r)),x+16,y,hexA('#e9e1cc',.55+.45*a),11)});
    const ys=bot-(bot-top)*.5;g.strokeStyle='rgba(201,152,79,.55)';g.lineWidth=1;[[bot,ys,'Diapason materialis'],[ys,top,'Diapason formalis']].forEach(([y1,y2,tx])=>{const bx=x+RR*.62;g.beginPath();g.moveTo(bx,y1);g.lineTo(bx+6,y1);g.lineTo(bx+6,y2);g.lineTo(bx,y2);g.stroke();g.save();g.translate(bx+18,(y1+y2)/2);g.rotate(-Math.PI/2);label(g,tx,0,0,'rgba(201,152,79,.85)',12,'center','"GFS Didot",Georgia,serif');g.restore()});
  },
  kepler(g,t){
    drawStarsBg(g,.6);const rs=r=>RR*.98*Math.pow(r/10.1,.5),ids=['mercury','venus','earth','mars','jupiter','saturn'];
    // the Platonic solids of the Mysterium Cosmographicum, between the spheres
    const SOL=[['saturn','jupiter',4,'cube'],['jupiter','mars',3,'tetrahedron'],['mars','earth',5,'dodecahedron'],['earth','venus',6,'icosahedron'],['venus','mercury',4,'octahedron']];
    SOL.forEach(([o,i,n,nm],k)=>{const r=rs(byId[o].el.a),rot=k*.5+S.az;g.strokeStyle='rgba(201,152,79,.22)';g.lineWidth=1;g.beginPath();for(let j=0;j<=n;j++){const a=rot+TAU*j/n+(n===4&&nm==='octahedron'?Math.PI/4:0);const x=CX+r*Math.cos(a),y=CY-r*Math.sin(a);j?g.lineTo(x,y):g.moveTo(x,y)}g.stroke()});
    ids.forEach(w=>{const b=byId[w];g.strokeStyle=hexA(b.color,.45);g.lineWidth=1;g.beginPath();b.orbit.forEach((o,k)=>{const r=Math.hypot(o.x,o.y),a=Math.atan2(o.y,o.x)+S.az,R=rs(r);const x=CX+R*Math.cos(a),y=CY-R*Math.sin(a);k?g.lineTo(x,y):g.moveTo(x,y)});g.stroke();
      const p=P[w],r=Math.hypot(p.x,p.y),pt=scrPt(Math.atan2(p.y,p.x),rs(r));SCR[w]=pt;dot(g,pt.x,pt.y,4.5,b.color,S.audition&&S.audition!==w?.15:.6);
      const [lo,hi]=kepEnds(b),fr=Math.log(P[w].f/lo)/Math.log(hi/lo);
      g.fillStyle='rgba(233,225,204,.15)';g.fillRect(pt.x+8,pt.y+7,36,3);g.fillStyle=b.color;g.fillRect(pt.x+8,pt.y+7,36*Math.max(0,Math.min(1,fr)),3);
      label(g,b.god+' · '+nn(P[w].f),pt.x+8,pt.y-3,'rgba(233,225,204,.88)',11)});
    const sg=g.createRadialGradient(CX,CY,0,CX,CY,16);sg.addColorStop(0,'rgba(255,240,200,1)');sg.addColorStop(1,'rgba(255,190,90,0)');g.fillStyle=sg;g.beginPath();g.arc(CX,CY,16,0,TAU);g.fill();
  }
};
function ring2(g,p,r){g.strokeStyle='rgba(207,214,224,.4)';g.lineWidth=1;g.beginPath();g.arc(p.x,p.y,r,0,TAU);g.stroke()}
function drawThinker(t){
  const g=cx2;g.setTransform(DPR,0,0,DPR,0,0);g.clearRect(0,0,W,H);
  Object.keys(SCR).forEach(k=>delete SCR[k]);
  const f=D_THINK[S.thinker];if(f)f(g,t);
  screen={};Object.assign(screen,SCR);
}
