import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const pages=[['index.html?notour','#begin'],['dance.html','#play'],['flight.html','#begin']];
const base=process.argv[2]||'http://localhost:8123/cy/';
for(const [pg,start] of pages){
  const p=await b.newPage({viewport:{width:1300,height:900}});const errs=[];p.on('pageerror',e=>errs.push(String(e)));
  await p.addInitScript(()=>{
    window.__midi=[];const out={id:'o1',name:'Test synth',send:(d,t)=>window.__midi.push(Array.from(d))};
    navigator.requestMIDIAccess=async()=>({outputs:new Map([['o1',out]]),onstatechange:null});
    const oc=AudioNode.prototype.connect;AudioNode.prototype.connect=function(t,...r){
      if(t instanceof AudioDestinationNode&&!window.__LR){const c=this.context,sp=c.createChannelSplitter(2),a=c.createAnalyser(),b2=c.createAnalyser();oc.call(this,sp);oc.call(sp,a,0);oc.call(sp,b2,1);window.__LR=[a,b2]}
      return oc.call(this,t,...r)};
  });
  await p.goto(base+pg);await p.waitForTimeout(800);
  if(pg==='flight.html'){const s=await p.$('#begin');if(s)await s.click().catch(()=>{})}else await p.click(start);
  await p.waitForTimeout(3000);
  const lr=async()=>p.evaluate(()=>{const [a,b]=window.__LR,x=new Float32Array(2048),y=new Float32Array(2048);a.getFloatTimeDomainData(x);b.getFloatTimeDomainData(y);let d=0,s=0;for(let i=0;i<2048;i++){d+=(x[i]-y[i])**2;s+=(x[i]+y[i])**2}return [Math.sqrt(s/2048).toFixed(4),Math.sqrt(d/2048).toFixed(4)]});
  const res={};
  await p.click('#stageBtn');await p.waitForTimeout(200);
  for(const m of ['stereo','pa','mono']){await p.click(`#stOut button[data-v="${m}"]`);await p.waitForTimeout(700);let S=0,D=0;for(let k=0;k<6;k++){const [s,d]=await lr();S+=+s;D+=+d;await p.waitForTimeout(150)}res[m]='side/mid '+(D/S).toFixed(3)}
  await p.click('#stMidiGo');await p.waitForTimeout(300);await p.selectOption('#stMidi','o1');await p.check('#stClock');
  await p.waitForTimeout(4000);
  const mi=await p.evaluate(()=>{const m=window.__midi,c={};for(const d of m){const k=d[0]>=0xF0?d[0].toString(16):(d[0]>>4).toString(16)+'/ch'+((d[0]&15)+1);c[k]=(c[k]||0)+1}return c});
  await p.click('#stClose');await p.click('#stageBtn');await p.click('#stProj');await p.waitForTimeout(600);await p.screenshot({path:'proj_'+pg.replace('.html','')+'.png'});
  const cv=await p.evaluate(()=>{const c=['orrery','dial','scene'].map(i=>document.getElementById(i)).find(Boolean).getBoundingClientRect();return [c.width,c.height]});
  await p.keyboard.press('Escape');await p.waitForTimeout(300);const still=await p.evaluate(()=>document.documentElement.classList.contains('mots-proj'));
  console.log(pg,JSON.stringify(res),'\n  midi',JSON.stringify(mi),'\n  projector canvas',cv,'exit ok',!still,'errors',errs.slice(0,3));
  await p.close();
}
await b.close();
