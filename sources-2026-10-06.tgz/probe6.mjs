import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const page = await browser.newPage({viewport:{width:1300,height:950}});
const errs=[];page.on('pageerror',e=>errs.push(String(e)));page.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
await page.addInitScript(()=>{
  const Orig=window.AudioContext;
  window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();this.__an.fftSize=4096;}};
  const oc=AudioNode.prototype.connect;
  AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return res};
  window.__osc=0;const s0=OscillatorNode.prototype.start;OscillatorNode.prototype.start=function(...a){__osc++;this.addEventListener('ended',()=>__osc--);return s0.apply(this,a)};
  // watch frequencies set on oscillators to see the Moon's melody
  window.__fset=[];const st=AudioParam.prototype.setTargetAtTime;
  AudioParam.prototype.setTargetAtTime=function(v,t,c){if(this.__tag)__fset.push([this.__tag,Math.round(v)]);return st.call(this,v,t,c)};
});
await page.goto('file:///home/claude/music-of-the-spheres.html');await page.waitForTimeout(400);
async function rms(secs){return page.evaluate(async(secs)=>{const an=window.__ac.__an,b=new Float32Array(an.fftSize),o=[];for(let k=0;k<secs*4;k++){await new Promise(r=>setTimeout(r,250));an.getFloatTimeDomainData(b);let s=0;for(const x of b)s+=x*x;o.push(Math.sqrt(s/b.length))}return {min:Math.min(...o).toFixed(4),mean:(o.reduce((a,c)=>a+c)/o.length).toFixed(4),osc:window.__osc}},secs)}
await page.click('#begin');await page.waitForTimeout(1000);
await page.click('#voices button[data-v="human"]');await page.waitForTimeout(3000);
console.log('solar human',JSON.stringify(await rms(10)));
await page.click('#voices button[data-v="instrument"]');await page.waitForTimeout(2000);
console.log('solar inst',JSON.stringify(await rms(5)));
await page.click('.vrow[data-id="saturn"] .nm');await page.waitForTimeout(600);await page.click('#sysBtn');await page.waitForTimeout(2000);
const seq=[];for(let k=0;k<12;k++){await page.waitForTimeout(500);seq.push(await page.textContent('#sm_0'))}
console.log('Mimas notes over 6 s:',seq.map(x=>x.split(' · ')[0]).join(', '));
await page.click('#voices button[data-v="human"]');await page.waitForTimeout(2000);
console.log('system human',JSON.stringify(await rms(8)));
console.log('errors',errs);
await browser.close();
