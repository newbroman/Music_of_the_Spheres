import urllib.request, concurrent.futures, os, json, subprocess, re
B='https://gleitz.github.io/midi-js-soundfonts/FluidR3_GM/'
INST={'violin':(55,91,4),'string_ensemble_1':(36,84,4),'contrabass':(28,52,4),'acoustic_bass':(28,56,4),'pizzicato_strings':(40,84,4),
 'french_horn':(41,77,4),'flute':(60,96,4),'orchestral_harp':(36,96,5),'timpani':(38,58,4),'tango_accordion':(41,81,4),
 'acoustic_grand_piano':(33,93,4),'acoustic_guitar_nylon':(40,84,4),'acoustic_guitar_steel':(55,91,4),'trumpet':(55,85,4),
 'muted_trumpet':(55,83,4),'trombone':(40,72,4),'alto_sax':(49,81,4),'tenor_sax':(44,76,4),'vibraphone':(53,89,4),'agogo':(67,79,4),
 'electric_guitar_clean':(48,84,4)}
N=['C','Db','D','Eb','E','F','Gb','G','Ab','A','Bb','B']
nm=lambda m:N[m%12]+str(m//12-1)
jobs=[(i,m) for i,(a,b,s) in INST.items() for m in range(a,b+1,s)]
def get(j):
    i,m=j;os.makedirs(i,exist_ok=True);p=f'{i}/{m}.mp3'
    if not os.path.exists(p):urllib.request.urlretrieve(f'{B}{i}-mp3/{nm(m)}.mp3',p)
    return p
with concurrent.futures.ThreadPoolExecutor(12) as ex:list(ex.map(get,jobs))
man={}
for i,(a,b,s) in INST.items():
    rms=[]
    for m in range(a,b+1,s):
        out=subprocess.run(['ffmpeg','-v','info','-i',f'{i}/{m}.mp3','-t','1.2','-af','volumedetect','-f','null','-'],capture_output=True,text=True).stderr
        rms.append(float(re.search(r'mean_volume: (-?[\d.]+) dB',out).group(1)))
    mean=sum(rms)/len(rms)
    man[i]={'notes':list(range(a,b+1,s)),'gain':round(10**((-20-mean)/20),3)}
json.dump(man,open('manifest.json','w'),separators=(',',':'))
print(len(jobs),'files');print({k:v['gain'] for k,v in man.items()})
