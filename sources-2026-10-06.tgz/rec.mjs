import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const ids=process.argv.slice(2);
for(const mode of ['instrument','human'])for(const id of ids){
  const page=await browser.newPage({viewport:{width:400,height:820},hasTouch:true,isMobile:true,userAgent:'Mozilla/5.0 (Linux; Android 14) Mobile'});
  await page.addInitScript(()=>{
    const Orig=window.AudioContext;
    window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;window.__rec=[];
      const sp=this.createScriptProcessor(4096,2,2);sp.onaudioprocess=e=>{if(window.__recOn)window.__rec.push(new Float32Array(e.inputBuffer.getChannelData(0)))};this.__sp=sp;sp.connect(this.destination);}};
    const oc=AudioNode.prototype.connect;
    AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this!==this.context.__sp&&this.context.__sp)oc.call(this,this.context.__sp);return res};
  });
  await page.goto('file:///home/claude/music-of-the-spheres.html');await page.waitForTimeout(800);
  await page.click('#speak');// no speech, to isolate the music
  await page.click('#begin');await page.click(`#voices button[data-v="${mode}"]`);await page.waitForTimeout(1500);
  await page.click(`.vrow[data-id="${id}"] .nm`);await page.waitForTimeout(3000);
  const r=await page.evaluate(async()=>{window.__recOn=true;await new Promise(r=>setTimeout(r,6000));window.__recOn=false;
    const n=window.__rec.reduce((a,b)=>a+b.length,0),x=new Float32Array(n);let o=0;for(const b of window.__rec){x.set(b,o);o+=b.length}
    // sample-to-sample steps vs the local typical step; count steps over 10x
    const d=new Float32Array(n);for(let i=1;i<n;i++)d[i]=Math.abs(x[i]-x[i-1]);
    const sorted=Array.from(d).sort((a,b)=>a-b),med=sorted[n>>1]||1e-9;let spikes=0,maxR=0;for(let i=1;i<n;i++){const r=d[i]/med;if(r>maxR)maxR=r;if(r>25)spikes++}
    let s=0,hf=0;for(let i=2;i<n;i++){s+=x[i]*x[i];const h=x[i]-2*x[i-1]+x[i-2];hf+=h*h}
    return {sec:(n/window.__ac.sampleRate).toFixed(1),rms:Math.sqrt(s/n).toFixed(4),hfRatio:(Math.sqrt(hf/n)/Math.sqrt(s/n)).toFixed(3),spikesOver25x:spikes,maxStepRatio:maxR.toFixed(0)};
  });
  console.log(mode.padEnd(10),id.padEnd(8),JSON.stringify(r));
  await page.close();
}
await browser.close();
