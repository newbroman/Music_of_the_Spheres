function parseWords(s){return s.trim().split(/\s+/).map(tok=>{const hold=tok.endsWith(':');tok=tok.replace(':','');return {t:tok,hold}})}
const NF=4; // formants per singer: four is enough for vowel identity and keeps the phone's audio thread light
let noiseBus=null, jitBus=null, inhaleBus=null, RETRO=null;
const mkGain=(v,to)=>{const g=AC.createGain();g.gain.value=v;if(to)g.connect(to);return g};

/* ---------- human singer ---------- */
function makeHuman(spec,dest,whisper){
  const h={spec,whisper,next:0,shift:0,words:parseWords(spec.words),srcs:[],taps:[]};
  const tap=(bus,node)=>{bus.connect(node);h.taps.push([bus,node])};
  h.form=FT[spec.type];
  h.out=mkGain(0,dest);h.src=mkGain(1);
  h.bps=[];h.bgs=[];
  for(let k=0;k<NF;k++){const bp=AC.createBiquadFilter();bp.type='bandpass';const g=mkGain(0,h.out);h.src.connect(bp);bp.connect(g);h.bps.push(bp);h.bgs.push(g)}
  setFormants(h,h.form.a,AC.currentTime,.001);
  if(!whisper){
    h.vg=mkGain(1,h.src);
    h.o1=AC.createOscillator();h.o1.setPeriodicWave(glottal(spec.tilt));h.o1.connect(h.vg);h.srcs.push(h.o1);
    h.vib=AC.createOscillator();h.vib.frequency.value=spec.vib[0];h.vibD=mkGain(0);h.vib.connect(h.vibD);h.vibD.connect(h.o1.frequency);h.srcs.push(h.vib);
    h.jit=mkGain(0);tap(jitBus,h.jit);h.jit.connect(h.o1.frequency);
    if((spec.ens||0)>=.2){
      h.o2=AC.createOscillator();h.o2.setPeriodicWave(glottal(spec.tilt));h.o2.detune.value=9;h.o2.connect(mkGain(spec.ens,h.vg));
      h.vibD.connect(h.o2.frequency);h.jit.connect(h.o2.frequency);h.srcs.push(h.o2);
    }
    h.bg=mkGain(spec.breath,h.src);tap(noiseBus,h.bg);
  }else{
    h.vg=mkGain(1,h.src);tap(noiseBus,h.vg);h.bg=h.vg;
  }
  // fricatives and plosive bursts
  h.fin=mkGain(1);tap(noiseBus,h.fin);
  h.fr=AC.createBiquadFilter();h.fr.type='bandpass';h.fr.Q.value=1.2;h.fg=mkGain(0,h.out);h.fin.connect(h.fr);h.fr.connect(h.fg);
  // audible in-breath between phrases
  h.ig=mkGain(0,dest);tap(inhaleBus,h.ig);
  h.srcs.forEach(o=>o.start());
  return h;
}
function killHuman(h){
  const t=AC.currentTime;h.srcs.forEach(o=>{try{o.stop(t+.05)}catch(e){}});
  setTimeout(()=>{h.taps.forEach(([b,n])=>{try{b.disconnect(n)}catch(e){}});try{h.out.disconnect()}catch(e){}try{h.ig.disconnect()}catch(e){}},150);
}
function setFormants(h,tab,t,tc){
  for(let k=0;k<NF;k++){const [F,db,bw]=tab[k];
    h.bps[k].frequency.setTargetAtTime(F,t,tc);h.bps[k].Q.setTargetAtTime(F/bw,t,tc);
    h.bgs[k].gain.setTargetAtTime(Math.pow(10,db/20)*(h.whisper?4:2.6),t,tc);}
}
const FRIC={s:[6500,.35,true],z:[5500,.25,false],f:[2500,.22,true],ph:[2500,.22,true],th:[3800,.22,true],h:[1500,0,true]};
const PLOS={p:[900,true],t:[3500,true],k:[1800,true],d:[3000,false],g:[1600,false],b:[800,false]};
function fitShift(f,type){const [lo,hi]=RANGE[type];return Math.round(Math.log2(Math.sqrt(lo*hi)/f))}
// every gain move inside a phrase uses a time constant of 15 ms or more, so consonants never click
function schedulePhrase(h,t0,f,level){
  const sp=h.spec, vg=h.vg.gain; let t=t0;
  h.shift=fitShift(f,sp.type);
  h.out.gain.setTargetAtTime(level,t0,.07);
  if(!h.whisper){const ff=f*Math.pow(2,h.shift);h.vibD.gain.setTargetAtTime(0,t0,.04);h.vibD.gain.setTargetAtTime(ff*sp.vib[1],t0+.35,.25);h.jit.gain.setTargetAtTime(ff*(sp.jit||.004)*6,t0,.1);}
  h.ig.gain.setTargetAtTime(0,t0,.05);
  h.words.forEach(({t:tok,hold})=>{
    if(FT[sp.type][tok]){
      setFormants(h,h.form[tok],t,.05);vg.setTargetAtTime(1,t,.025);
      if(!h.whisper)h.bg.gain.setTargetAtTime(sp.breath,t,.03);
      t+=sp.syl*(hold?2.4:1)*(.85+Math.random()*.3);
    }else if(FRIC[tok]){
      const [F,amt,unv]=FRIC[tok];
      if(tok==='h'){h.bg.gain.setTargetAtTime(h.whisper?1.5:.5,t,.02);if(!h.whisper)vg.setTargetAtTime(.1,t,.02);h.bg.gain.setTargetAtTime(h.whisper?1:sp.breath,t+.1,.025);}
      else{h.fr.frequency.setValueAtTime(F,t);h.fg.gain.setTargetAtTime(amt,t,.02);h.fg.gain.setTargetAtTime(0,t+.1,.02);if(unv)vg.setTargetAtTime(.1,t,.02);}
      t+=.12;
    }else if(PLOS[tok]){
      const [F,unv]=PLOS[tok];
      vg.setTargetAtTime(unv?.08:.2,t,.015);vg.setTargetAtTime(1,t+.06,.02);
      h.fr.frequency.setValueAtTime(F,t+.04);h.fg.gain.setTargetAtTime(.15,t+.05,.012);h.fg.gain.setTargetAtTime(0,t+.075,.02);
      t+=.08;
    }else if(tok==='m'||tok==='n'||tok==='l'){
      setFormants(h,NASAL[tok],t,.03);vg.setTargetAtTime(tok==='l'?.8:.55,t,.025);t+=tok==='l'?.07:.1;
    }else if(tok==='r'){
      [0,.03,.06].forEach((d,k)=>vg.setTargetAtTime(k%2?1:.55,t+d,.012));t+=.09;
    }
  });
  h.out.gain.setTargetAtTime(0,t,.22);
  const rest=sp.rest*(.7+Math.random()*.6);
  h.ig.gain.setTargetAtTime(.25*level,t+rest-.55,.12);h.ig.gain.setTargetAtTime(0,t+rest-.1,.07);
  h.next=t+.5+rest;
}
function humanTick(h,f,level,now){
  if(!h.whisper){const ff=f*Math.pow(2,h.shift);tgt(h.o1.frequency,ff,.07);if(h.o2)tgt(h.o2.frequency,ff,.07)}
  if(now+.12>=h.next)schedulePhrase(h,Math.max(now+.05,h.next),f,level);
}
// a moon child sings the vowels of its name once, when it completes an orbit
function singMoon(m,dest,f){
  const t=AC.currentTime, [lo,hi]=RANGE.child;while(f<lo)f*=2;while(f>hi)f/=2;
  const o=AC.createOscillator();o.setPeriodicWave(glottal(1.15));o.frequency.setValueAtTime(f*.97,t);o.frequency.setTargetAtTime(f,t,.04);
  const vib=AC.createOscillator();vib.frequency.value=6;const vd=mkGain(0);vd.gain.setValueAtTime(0,t);vd.gain.setTargetAtTime(f*.012,t+.2,.1);vib.connect(vd);vd.connect(o.frequency);
  const env=mkGain(0),amp=.1*(.4+.6*m.sizeN);env.gain.setValueAtTime(0,t);
  const vs=(m.name.toLowerCase().match(/[aeiou]/g)||['a']).slice(0,2), seg=.24;
  const bps=[];
  for(let k=0;k<3;k++){const bp=AC.createBiquadFilter();bp.type='bandpass';const g=mkGain(0,env);o.connect(bp);bp.connect(g);bps.push([bp,g])}
  vs.forEach((v,j)=>{FT.child[v].slice(0,3).forEach(([F,db,bw],k)=>{const [bp,g]=bps[k];bp.frequency.setTargetAtTime(F,t+j*seg,j?.04:.001);bp.Q.setTargetAtTime(F/bw,t+j*seg,.02);g.gain.setTargetAtTime(Math.pow(10,db/20)*3,t+j*seg,.02)})});
  const end=t+seg*vs.length+.3;
  env.gain.linearRampToValueAtTime(amp,t+.06);env.gain.setTargetAtTime(amp*.8,t+.12,.1);env.gain.setTargetAtTime(0,end-.25,.09);
  env.connect(dest);o.start(t);vib.start(t);o.stop(end+.4);vib.stop(end+.4);
  setTimeout(()=>{try{env.disconnect()}catch(e){}},(end-t+.6)*1000);
}

/* ---------- instrument voice ---------- */
function buildInst(b,v,fadeIn){
  const I={srcs:[],taps:[]}, f0=P[b.id].f;
  I.g=mkGain(0,v.vol);I.g.gain.setTargetAtTime(1,AC.currentTime,fadeIn?.15:.001);
  if(b.kind==='comet'){
    const fin=mkGain(1);noiseBus.connect(fin);I.taps.push([noiseBus,fin]);
    I.bp1=AC.createBiquadFilter();I.bp1.type='bandpass';I.bp1.Q.value=9;I.bp1.frequency.value=f0;
    I.bp2=AC.createBiquadFilter();I.bp2.type='bandpass';I.bp2.Q.value=16;I.bp2.frequency.value=f0*2;
    const sum=mkGain(4,I.g), g2=mkGain(.6,sum);
    fin.connect(I.bp1);fin.connect(I.bp2);I.bp1.connect(sum);I.bp2.connect(g2);
  }else{
    I.o1=AC.createOscillator();I.o1.type='sawtooth';I.o1.frequency.value=f0;
    I.o2=AC.createOscillator();I.o2.type='sawtooth';I.o2.frequency.value=f0;I.o2.detune.value=4+16*b.sizeN;
    const src=mkGain(.34);I.o1.connect(src);I.o2.connect(src);I.srcs.push(I.o1,I.o2);
    if(b.sizeN>.85){I.o3=AC.createOscillator();I.o3.type='sawtooth';I.o3.frequency.value=f0;I.o3.detune.value=-(3+12*b.sizeN);I.o3.connect(src);I.srcs.push(I.o3)}
    const form=mkGain(1);
    (VOWELS[b.vowel]||VOWELS.a).forEach(([F,g],k)=>{const bp=AC.createBiquadFilter();bp.type='bandpass';bp.frequency.value=F;bp.Q.value=[7,10,13][k];src.connect(bp);bp.connect(mkGain(g*2.2,form))});
    src.connect(mkGain(.12,form));
    I.lp=AC.createBiquadFilter();I.lp.type='lowpass';I.lp.Q.value=.6;I.lp.frequency.value=2500;form.connect(I.lp);
    const trem=mkGain(.7,I.g);I.lp.connect(trem);
    // retrograde spin: a reversed swell built from four smooth harmonics, so the pulse never jumps
    I.tl=AC.createOscillator();if(b.rot<0)I.tl.setPeriodicWave(RETRO);else I.tl.type='sine';I.tl.frequency.value=v.rate;
    const td=mkGain(b.rot<0?.22:.3);I.tl.connect(td);td.connect(trem.gain);
    I.vib=AC.createOscillator();I.vib.frequency.value=4.4+Math.random()*1.4;I.vd=mkGain(f0*.004);
    I.vib.connect(I.vd);[I.o1,I.o2,I.o3].forEach(o=>o&&I.vd.connect(o.frequency));
    I.srcs.push(I.tl,I.vib);
  }
  I.srcs.forEach(o=>o.start());
  return I;
}
function killPart(part){
  if(!part)return;const t=AC.currentTime;
  part.g.gain.setTargetAtTime(0,t,.08);
  setTimeout(()=>{(part.srcs||[]).forEach(o=>{try{o.stop()}catch(e){}});(part.taps||[]).forEach(([b,n])=>{try{b.disconnect(n)}catch(e){}});(part.hums||[]).forEach(killHuman);try{part.g.disconnect()}catch(e){}},450);
}
function buildHumanPart(b,v){
  const part={g:mkGain(0,v.vol)};part.g.gain.setTargetAtTime(1.25,AC.currentTime,.15);
  const h=makeHuman(b.hv,part.g,b.kind==='comet');h.next=AC.currentTime+.2+Math.random()*2.5;
  part.hums=[h];part.h=h;return part;
}

/* ---------- bodies, sun, moons ---------- */
const PANNERS=[];
function mkPanner(hrtfOK){
  const p=AC.createPanner();p.panningModel=S.hrtf&&hrtfOK?'HRTF':'equalpower';p.distanceModel='linear';
  p.refDistance=1;p.maxDistance=10000;p.rolloffFactor=0;p.coneInnerAngle=360;p.coneOuterAngle=360;
  p.connect(bus);PANNERS.push({p,hrtfOK});return p;
}
function makeVoice(b){
  // only the planets get true 3D (HRTF) panning; everything else uses cheap stereo panning
  const v={pan:mkPanner(b.kind==='planet')};
  v.vol=mkGain(0,v.pan);
  v.rate=Math.min(7,6*Math.pow(3.9/Math.abs(b.rot),.45));
  v.moonBus=mkGain(1);v.moonVol=mkGain(0,v.pan);v.moonBus.connect(v.moonVol);
  (b.moons||[]).forEach(m=>{
    m.out=mkGain(1,v.moonBus);
    m.hum=AC.createOscillator();m.hum.type='sine';m.hum.frequency.value=moonPitch(m.P);
    m.hg=mkGain(0,m.out);m.hum.connect(m.hg);m.hum.start();
  });
  v.mode=null;
  return v;
}
function makeSun(){
  const v={pan:mkPanner(true)};v.vol=mkGain(0,v.pan);v.mode=null;return v;
}
function buildSunInst(v,fadeIn){
  const I={srcs:[]};I.g=mkGain(0,v.vol);I.g.gain.setTargetAtTime(1,AC.currentTime,fadeIn?.15:.001);
  const breath=mkGain(.75);const bl=AC.createOscillator();bl.frequency.value=.07;const bd=mkGain(.25);bl.connect(bd);bd.connect(breath.gain);
  const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=900;breath.connect(lp);lp.connect(I.g);
  I.d1=AC.createOscillator();I.d1.type='triangle';I.d2=AC.createOscillator();I.d2.type='triangle';I.d3=AC.createOscillator();I.d3.type='sine';
  const [a,b2,c]=droneFreqs();I.d1.frequency.value=a;I.d2.frequency.value=b2;I.d3.frequency.value=c;
  I.d1.connect(breath);I.d2.connect(mkGain(.55,breath));I.d3.connect(mkGain(.8,breath));
  I.srcs.push(I.d1,I.d2,I.d3,bl);I.srcs.forEach(o=>o.start());
  return I;
}
function droneFreqs(){const t=C_BASE*PY[S.mode]*8;return [t,t*1.5,t/2]}
const APOLLO=[{type:'bass',tilt:1.25,vib:[4.6,.02],breath:.08,jit:.003,syl:2.0,rest:2.6,ens:.5,words:'a p o l o: n'},{type:'tenor',tilt:1.15,vib:[5.0,.02],breath:.06,jit:.003,syl:2.0,rest:2.6,ens:0,words:'a p o l o: n'}];

// build only the choir in use; the other one is torn down, so the phone never runs both
function applyVoiceMode(){
  if(!AC)return;const mode=S.voices;
  BODIES.forEach(b=>{const v=V[b.id];if(v.mode===mode)return;
    killPart(v.part);v.part=mode==='human'?buildHumanPart(b,v):buildInst(b,v,v.mode!==null);v.mode=mode;});
  if(sunV.mode!==mode){
    killPart(sunV.part);
    if(mode==='human'){const part={g:mkGain(0,sunV.vol)};part.g.gain.setTargetAtTime(.9,AC.currentTime,.15);
      part.hums=APOLLO.map(sp=>{const h=makeHuman(sp,part.g,false);h.next=AC.currentTime+.6;return h});sunV.part=part;}
    else sunV.part=buildSunInst(sunV,sunV.mode!==null);
    sunV.mode=mode;
  }
}
const ensureHuman=applyVoiceMode;

// a small reusable set of panners lets an auditioned planet's moons circle your head
const POOL=[];let poolOwner=null;
function syncPool(){
  if(poolOwner===S.audition)return;
  if(poolOwner){byId[poolOwner].moons.forEach(m=>{if(m.slot!==undefined){try{m.out.disconnect()}catch(e){}m.out.connect(V[poolOwner].moonBus);m.slot=undefined}})}
  poolOwner=S.audition;
  if(poolOwner){byId[poolOwner].moons.slice(0,POOL.length).forEach((m,k)=>{try{m.out.disconnect()}catch(e){}m.out.connect(POOL[k].g);m.slot=k})}
}

function initAudio(){
  AC=new (window.AudioContext||window.webkitAudioContext)();
  master=AC.createGain();master.gain.value=0;
  comp=AC.createDynamicsCompressor();comp.threshold.value=-20;comp.knee.value=14;comp.ratio.value=4;comp.attack.value=.02;comp.release.value=.35;
  bus=AC.createGain();dry=AC.createGain();wet=AC.createGain();conv=AC.createConvolver();conv.buffer=makeIR(3.2);
  bus.connect(dry);dry.connect(comp);bus.connect(conv);conv.connect(wet);wet.connect(comp);comp.connect(master);master.connect(AC.destination);
  setVerb();
  noiseBuf=AC.createBuffer(1,AC.sampleRate*3,AC.sampleRate);const nd=noiseBuf.getChannelData(0);for(let k=0;k<nd.length;k++)nd[k]=Math.random()*2-1;
  // one shared noise source feeds every breath, whisper and consonant
  const ns=AC.createBufferSource();ns.buffer=noiseBuf;ns.loop=true;noiseBus=mkGain(1);ns.connect(noiseBus);ns.start();
  const jl=AC.createBiquadFilter();jl.type='lowpass';jl.frequency.value=7;noiseBus.connect(jl);jitBus=mkGain(1);jl.connect(jitBus);
  const ib=AC.createBiquadFilter();ib.type='bandpass';ib.frequency.value=1600;ib.Q.value=.6;noiseBus.connect(ib);inhaleBus=mkGain(.16);ib.connect(inhaleBus);
  const re=new Float32Array(5),im=new Float32Array(5);for(let n=1;n<5;n++)im[n]=-1/n;RETRO=AC.createPeriodicWave(re,im);
  for(let k=0;k<8;k++){const p=mkPanner(false);POOL.push({p,g:mkGain(0,p)})}
  for(let k=0;k<3;k++)BELTP.push(mkPanner(false));
  computePositions();
  BODIES.forEach(b=>V[b.id]=makeVoice(b));
  sunV=makeSun();
  applyVoiceMode();
}
function setVerb(){if(!AC)return;tgt(wet.gain,S.verb*1.1,.1);tgt(dry.gain,1-S.verb*.35,.1)}

function setListener(ang){
  const l=AC.listener, fx=Math.cos(ang), fz=-Math.sin(ang);
  if(l.forwardX){const t=AC.currentTime;l.forwardX.setTargetAtTime(fx,t,.08);l.forwardY.setTargetAtTime(0,t,.08);l.forwardZ.setTargetAtTime(fz,t,.08);}
  else{l.setOrientation(fx,0,fz,0,1,0)}
}
function setPos(p,x,y,z,tc=.08){
  if(p.positionX){const t=AC.currentTime;p.positionX.setTargetAtTime(x,t,tc);p.positionY.setTargetAtTime(y,t,tc);p.positionZ.setTargetAtTime(z,t,tc);}
  else p.setPosition(x,y,z);
}
function audioDir(src,L){
  const dx=src.x-L.x, dy=src.y-L.y, dz=src.z-L.z, d=Math.hypot(dx,dy,dz);
  if(d<1e-9)return {x:0,y:.5,z:-.87,d:0,self:true};
  return {x:dx/d,y:dz/d,z:-dy/d,d};
}
function distGain(d){return 1-S.dist+S.dist*Math.pow(1/(1+d/2.5),.75)}

function updateAudio(){
  const L=listenerPos(), ang=facingAngle(), now=AC.currentTime;setListener(ang);
  const fwd={x:Math.cos(ang),y:0,z:-Math.sin(ang)};
  syncPool();
  BODIES.forEach(b=>{
    const v=V[b.id], p=P[b.id], aud=S.audition===b.id, I=v.mode==='instrument'?v.part:null, Hp=v.mode==='human'?v.part:null;
    // auditioning: the body sings just ahead of you, at full presence
    const a=aud?{...fwd,d:0}:audioDir(p,L);
    setPos(v.pan,a.x,a.y,a.z);
    const on=audible(b), grp=aud?1:S.groups[b.kind].vol, dg=aud?1:a.self?.55:distGain(a.d);
    const duck=aud&&S.speaking?.3:1;
    if(b.kind==='comet'){
      if(I){tgt(I.bp1.frequency,Math.min(4000,p.f*2),.1);tgt(I.bp2.frequency,Math.min(8000,p.f*3),.1)}
      const act=aud?Math.max(.3,p.act):p.act;
      tgt(v.vol.gain,on?(0.015+0.9*act)*.11*grp*dg*(.6+.4*Math.min(1,b.R/10))*duck:0,.15);
    }else{
      if(I){tgt(I.o1.frequency,p.f,.07);tgt(I.o2.frequency,p.f,.07);if(I.o3)tgt(I.o3.frequency,p.f,.07);tgt(I.vd.gain,p.f*.004,.2);
        const sb=p.r>0?p.z/p.r:0;tgt(I.lp.frequency,Math.max(300,Math.min(12000,2600*Math.pow(2,3*sb))),.2);}
      const base=b.kind==='planet'?.075:.055;
      const g=aud?.1*(.55+.45*b.sizeG):base*b.sizeG*grp*dg;
      tgt(v.vol.gain,on?g*duck:0,.12);
    }
    if(Hp&&on)humanTick(Hp.h,p.f,1,now);
    // moons
    const mOn=on&&(S.groups.moons.on||aud);
    tgt(v.moonVol.gain,mOn&&!aud?S.groups.moons.vol*dg:0,.12);
    (b.moons||[]).forEach(m=>{
      const rate=S.playing?S.speed/Math.abs(m.P):0;
      if(aud&&m.slot!==undefined){
        const slot=POOL[m.slot];tgt(slot.g.gain,mOn?1.4:0,.12);
        // slow moons circle you at their true phase; fast ones hold a place so the panner never whips round
        const th=rate>.5?ang+Math.PI*(.25+m.rank*.27):TAU*((S.jd-J2000)/m.P+m.ph0);
        setPos(slot.p,Math.cos(th),.1,-Math.sin(th),.12);
      }
      tgt(m.hum.frequency,moonPitch(m.P),.1);
      tgt(m.hg.gain,rate>1.2?Math.min(1,(rate-1.2)/4)*.018*(.4+.6*m.sizeN):0,.25);
    });
  });
  POOL.forEach((s,k)=>{if(!poolOwner||k>=byId[poolOwner].moons.length)tgt(s.g.gain,0,.1)});
  // sun
  const sa=audioDir({x:0,y:0,z:0},L);setPos(sunV.pan,sa.x,sa.y,sa.z);
  const [d1,d2,d3]=droneFreqs(), sp=sunV.part;
  if(sunV.mode==='instrument'){tgt(sp.d1.frequency,d1,.3);tgt(sp.d2.frequency,d2,.3);tgt(sp.d3.frequency,d3,.3)}
  else if(sp&&S.drone){humanTick(sp.hums[0],d3,1,now);humanTick(sp.hums[1],d2,1,now)}
  tgt(sunV.vol.gain,S.drone&&!S.solo.size?(S.audition?.025:.07*(sa.self?.7:distGain(sa.d))):0,.3);
}
// the lyre: soft attack, sine body and a gentle octave, folded below 1.1 kHz so it rings rather than ticks
function pluck(b,m){
  if(S.voices==='human'){singMoon(m,m.out,moonPitch(m.P));return}
  let f=moonPitch(m.P);while(f>1100)f/=2;
  const t=AC.currentTime, amp=.08*(.35+.65*m.sizeN);
  const o=AC.createOscillator();o.type='sine';o.frequency.value=f;
  const o2=AC.createOscillator();o2.type='sine';o2.frequency.value=f*2.003;const g2=mkGain(.22);
  const g=mkGain(0);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(amp,t+.015);g.gain.setTargetAtTime(0,t+.03,.5);
  o.connect(g);o2.connect(g2);g2.connect(g);g.connect(m.out);o.start(t);o2.start(t);o.stop(t+2.6);o2.stop(t+2.6);
  setTimeout(()=>{try{g.disconnect()}catch(e){}},2800);
}
const BELTP=[];let beltIx=0;
function beltPing(p,pos){
  const L=listenerPos(), a=audioDir(pos,L), t=AC.currentTime;
  let f=rawPitch(pos.om)*4;while(f>1600)f/=2;f=quantize(f);
  const pan=BELTP[beltIx++%BELTP.length];setPos(pan,a.x,a.y,a.z,.01);
  const o=AC.createOscillator();o.type='sine';o.frequency.value=f;const o2=AC.createOscillator();o2.type='sine';o2.frequency.value=f*2.76;
  const g2=mkGain(.15);const g=mkGain(0);
  const amp=.035*S.groups.belt.vol*distGain(a.d);
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(amp,t+.02);g.gain.setTargetAtTime(0,t+.04,.35);
  o.connect(g);o2.connect(g2);g2.connect(g);g.connect(pan);o.start(t);o2.start(t);o.stop(t+2);o2.stop(t+2);
  setTimeout(()=>{try{g.disconnect()}catch(e){}},2200);
}
