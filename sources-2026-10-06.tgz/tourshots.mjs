import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
import { execSync } from 'child_process';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required','--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});
const id_w=h=>h*1.22;
const R='/home/claude/music_of_the_spheres/tour/';
for(const lang of ['en','pl','cy']){
  const pre=lang==='en'?'':lang+'/';execSync(`mkdir -p ${R}${lang}`);
  const ctx=await b.newContext({viewport:{width:1280,height:800}});
  const shot=async(url,fn,n,cv)=>{const p=await ctx.newPage();await p.goto('http://localhost:8123/'+pre+url);await p.waitForTimeout(900);await fn(p);const f=`/tmp/claude-0/t_${lang}_${n}.png`;let clip;if(cv){const r=await p.evaluate(id=>{const b=document.getElementById(id).getBoundingClientRect();return {x:b.left,y:b.top,h:b.height}},cv);const h=Math.min(r.h,790);clip={x:Math.max(0,r.x-8),y:Math.max(0,r.y-8),width:Math.min(1280-Math.max(0,r.x-8),id_w(h)),height:h+16}}await p.screenshot({path:f,clip});await p.close();
    execSync(`python3 -c "from PIL import Image;im=Image.open('${f}').convert('RGB');im.thumbnail((1200,1200));im.save('${R}${lang}/${n}.webp','WEBP',quality=72,method=6)"`)};
  const dial=async(p,hash)=>{await p.click('#begin');await p.waitForTimeout(2500);await p.evaluate(()=>{const c=document.getElementById('orrery');window.scrollTo(0,c.getBoundingClientRect().top+scrollY-110)});await p.waitForTimeout(800)};
  await shot('index.html#plato',p=>dial(p),1,'orrery');
  await shot('index.html#ptolemy',p=>dial(p),2,'orrery');
  await shot('index.html#today',async p=>{await p.click('#begin');await p.waitForTimeout(2500);await p.evaluate(()=>{const c=document.getElementById('orrery');window.scrollTo(0,c.getBoundingClientRect().top+scrollY-110)});await p.waitForTimeout(800)},3,'orrery');
  await shot('flight.html',async p=>{await p.click('#begin').catch(()=>{});await p.waitForTimeout(4000)},4);
  await shot('dance.html',async p=>{await p.click('#style button[data-v="mozart"]');await p.click('#play');await p.waitForTimeout(3500);await p.evaluate(()=>{const c=document.getElementById('dial');window.scrollTo(0,c.getBoundingClientRect().top+scrollY-20)});await p.waitForTimeout(600)},5,'dial');
  await shot('dance.html',async p=>{await p.click('#play');await p.waitForTimeout(2500);await p.click('#stageBtn');await p.waitForTimeout(500)},6);
  await ctx.close();
}
await b.close();
