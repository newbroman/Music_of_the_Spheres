import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const styles=(process.argv[2]||'trance,waltz,tango,samba,chacha,swing,jive,fandango').split(',');
const url=process.argv[3]||'file:///home/claude/dance.html';
for(const st of styles){
  const page=await browser.newPage({viewport:{width:1300,height:950}});
  const errs=[];page.on('pageerror',e=>errs.push(String(e)));page.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
  await page.addInitScript(()=>{const Orig=window.AudioContext;window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();this.__an.fftSize=2048;}};const oc=AudioNode.prototype.connect;AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return res};});
  await page.goto(url);await page.waitForTimeout(600);
  await page.click(`#style button[data-v="${st}"]`);
  await page.evaluate(()=>{const e=document.getElementById('dpb');e.value=1000;e.dispatchEvent(new Event('input'))});
  await page.click('#play');
  let last='',sum=0,n=0,peak=0,maxr=0;const ch=[];
  for(let k=0;k<110;k++){await page.waitForTimeout(500);
    const sec=await page.textContent('#secTxt'),bar=await page.textContent('#barTxt');
    const [r,p]=await page.evaluate(()=>{const an=__ac.__an,b=new Float32Array(an.fftSize);an.getFloatTimeDomainData(b);let s=0,pk=0;for(const x of b){s+=x*x;pk=Math.max(pk,Math.abs(x))}return [Math.sqrt(s/b.length),pk]});
    sum+=r;n++;peak=Math.max(peak,p);maxr=Math.max(maxr,r);
    if(sec!==last){ch.push(`${sec}@${bar}`);last=sec}
    if(k===8)console.log('  toast:',await page.textContent('#toast'));if(k===30)await page.screenshot({path:`b_${st}.png`});
  }
  const ctxt=await page.evaluate(()=>__ac.state+' '+(__ac.baseLatency||0));
  console.log(st.padEnd(9),'avg rms',(sum/n).toFixed(3),'max rms',maxr.toFixed(3),'peak',peak.toFixed(3),'|',ch.join(' → '),'|',ctxt,'| errors',errs.length?errs:'none');
  await page.close();
}
await browser.close();
