import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
const page = await browser.newPage({viewport:{width:400,height:820},hasTouch:true,isMobile:true});
const errs=[];page.on('pageerror',e=>errs.push(String(e)));
await page.goto('file:///home/claude/flight.html');await page.waitForTimeout(3000);
await page.screenshot({path:'f_phone.png'});console.log('errors',errs);await browser.close();
