import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const page = await browser.newPage();
const errs=[];page.on('pageerror',e=>errs.push(String(e)));page.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
await page.addInitScript(()=>{
  const Orig=window.AudioContext;
  window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();this.__an.fftSize=4096;}};
  const oc=AudioNode.prototype.connect;
  AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return res};
  window.__osc=0;const s0=OscillatorNode.prototype.start;OscillatorNode.prototype.start=function(...a){__osc++;this.addEventListener('ended',()=>__osc--);return s0.apply(this,a)};
});
await page.goto('file:///home/claude/music-of-the-spheres.html');await page.waitForTimeout(400);
const roster=()=>page.evaluate(()=>[...document.querySelectorAll('.vrow')].map(r=>r.dataset.id+':'+r.querySelector('.nt').textContent).join('  '));
async function rms(secs){return page.evaluate(async(secs)=>{const an=window.__ac.__an,b=new Float32Array(an.fftSize),o=[];for(let k=0;k<secs*4;k++){await new Promise(r=>setTimeout(r,250));an.getFloatTimeDomainData(b);let s=0;for(const x of b)s+=x*x;o.push(Math.sqrt(s/b.length))}return {min:Math.min(...o).toFixed(4),mean:(o.reduce((a,c)=>a+c)/o.length).toFixed(4),osc:window.__osc}},secs)}
await page.click('#begin');await page.waitForTimeout(3500);
console.log('SUN instruments',JSON.stringify(await rms(6)));console.log(await roster());
await page.selectOption('#vp','earth');await page.waitForTimeout(4000);
console.log('EARTH instruments',JSON.stringify(await rms(6)));console.log(await roster());
await page.click('#voices button[data-v="human"]');await page.waitForTimeout(3000);
console.log('EARTH human',JSON.stringify(await rms(20)));
await page.click('.vrow[data-id="jupiter"] .nm');await page.waitForTimeout(1500);
console.log('info:',await page.textContent('#i_heard'));
await page.click('.vrow[data-id="uranus"] .nm');await page.waitForTimeout(1500);
console.log('info uranus:',await page.textContent('#i_heard'));
console.log('errors',errs);
await browser.close();
