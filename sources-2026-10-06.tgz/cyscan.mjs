import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const EN=/\b(the|and|of|with|from|this|that|your|you|to|is|are|tap|hear|listen|moons?|sound|voice|singing|days|years|hours|key|bar|stopped|play|pause|back)\b/i;
async function scan(url,acts,name){const p=await b.newPage({viewport:{width:1300,height:1000}});await p.goto('http://localhost:8123/'+url);await p.waitForTimeout(800);for(const a of acts){await a(p);await p.waitForTimeout(900)}
 const t=await p.evaluate(()=>document.body.innerText);const lines=[...new Set(t.split('\n').map(x=>x.trim()).filter(x=>x&&EN.test(x)))];
 console.log('==',name,lines.length);lines.slice(0,40).forEach(l=>console.log('  ',l.slice(0,140)));await p.screenshot({path:'cy_'+name+'.png',fullPage:false});await p.close()}
await scan('cy/index.html',[p=>p.click('#begin')],'2d');
await scan('cy/index.html',[p=>p.click('#begin'),p=>p.click('#timeline button:nth-child(3)')],'plato');
await scan('cy/index.html',[p=>p.click('#begin'),p=>p.click('#timeline button:nth-child(10)')],'copernicus');
await scan('cy/dance.html',[p=>p.click('#play'),p=>p.waitForTimeout(3000)],'dance');
await scan('cy/flight.html',[p=>p.click('#begin'),p=>p.waitForTimeout(2000)],'flight');
await b.close();
