const D={};const signOf=()=>K;let K=0;function rng(seed){let s=seed*9301+49297;return ()=>{s=(s*16807)%2147483647;return (s-1)/2147483646}}
function bachSubject(){
  const key=signOf('venus');if(D.subjKey===key)return D.subj;D.subjKey=key;
  const r=rng(key*41+11),RH=[[1,0,1,0],[1,1,1,1],[1,0,1,1],[1,1,1,0],[1,0,0,0]],CT=[-3,0,2,4,7,9],S=new Array(32).fill(null);
  let cur=[0,2,4][Math.floor(r()*3)],last=null;
  for(let b=0;b<8;b++){const p=b===7?[1,0,0,0]:b===0?[1,0,1,0]:RH[Math.floor(r()*4)];
    for(let i=0;i<4;i++){if(!p[i])continue;
      if(i===0){const near=CT.filter(c=>Math.abs(c-cur)<=2&&c!==cur);cur=b===7?(Math.abs(cur)<Math.abs(cur-7)?0:7):near.length?near[Math.floor(r()*near.length)]:0}
      else cur+=(r()<.55?1:-1)*(r()<.85?1:2);
      cur=Math.max(-3,Math.min(8,cur));if(cur===last&&b<7)cur+=cur<3?1:-1;S[b*4+i]=last=cur}}
  return D.subj=S;
}

const N='ABCDEFG';for(K of [0,3,5,9,11]){D.subjKey=null;const S=bachSubject();console.log('sign',K,': '+S.map((v,i)=>(i%4===0?'| ':'')+(v===null?'-':N[((v%7)+7)%7]+(v>=7?"'":v<0?',':''))).join(' '))}