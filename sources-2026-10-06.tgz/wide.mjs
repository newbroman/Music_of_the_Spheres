import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const R='/home/claude/music_of_the_spheres/store/';
const p=await b.newPage({viewport:{width:1920,height:1080}});
await p.goto('http://localhost:8123/index.html?notour');await p.waitForTimeout(1000);await p.click('#begin');await p.waitForTimeout(4000);
await p.screenshot({path:R+'5-wide-dial.png'});
const q=await b.newPage({viewport:{width:1920,height:1080}});
await q.goto('http://localhost:8123/dance.html?notour');await q.waitForTimeout(1500);await q.click('#play');await q.waitForTimeout(5000);
await q.screenshot({path:R+'6-wide-dance.png'});await b.close();
