import {chromium} from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch();const p=await b.newPage();
await p.goto('http://localhost:8123/dance.html?notour');await p.waitForTimeout(1500);
console.log(await p.evaluate(()=>JSON.stringify({th:S.thinker,interp:S.interp,zk:S.zodiacKey,aud:BODIES.filter(b=>audible(b)).length,all:BODIES.length,ks:keyShift(),prog:D.prog,lh:location.hash})));
await b.close();
