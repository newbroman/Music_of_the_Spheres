import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const style=process.argv[2]||'trance', thr=+process.argv[3]||6;
for(const u of ['old.html','jung.html','new.html']){
  if(style==='jungle'&&u==='old.html')continue;
  const p=await b.newPage({viewport:{width:412,height:860}});
  const cdp=await p.context().newCDPSession(p);await cdp.send('Emulation.setCPUThrottlingRate',{rate:thr});
  await p.goto('http://localhost:8124/'+u+'?notour');await p.waitForTimeout(1500);
  const r=await p.evaluate(async(style)=>{
    const sb=document.querySelector(`#style button[data-v="${style}"]`);if(sb)sb.click();
    document.getElementById('play').click();await new Promise(r=>setTimeout(r,300));
    window.__M=[];
    const L=[];let last=performance.now();const iv=setInterval(()=>{const n=performance.now();L.push(n-last-25);last=n},25);
    await new Promise(r=>setTimeout(r,15000));clearInterval(iv);
    const M=window.__M;M.sort((a,b)=>a-b);L.sort((a,b)=>a-b);const q=(a,x)=>a[Math.floor(a.length*x)]?.toFixed(3);
    return {steps:M.length,late:M.filter(x=>x<0).length,minMargin:q(M,0),p5margin:q(M,.05),timerP95:q(L,.95),timerMax:q(L,.999)};
  },style);
  console.log(u,style,'cpu x'+thr,JSON.stringify(r));await p.close();
}
await b.close();
