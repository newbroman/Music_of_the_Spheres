/* ---- instruments ---- */
const toPan=id=>PAN[id]||drumBus;
// a hammered string: a triangle body with a little sawtooth brightness, the felt closing quickly
function piano(t,f,len,lvl,id){
  const g=mkG(0,toPan(id)),lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.setValueAtTime(Math.min(8000,f*9),t);lp.frequency.setTargetAtTime(Math.max(600,f*2.5),t,.15);
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(lvl,t+.004);g.gain.setTargetAtTime(lvl*.35,t+.004,.09);g.gain.setTargetAtTime(0,t+len,.08);
  const o1=AC.createOscillator(),o2=AC.createOscillator();o1.type='triangle';o2.type='sawtooth';o1.frequency.value=f;o2.frequency.value=f*1.0015;
  o1.connect(lp);o2.connect(mkG(.16,lp));lp.connect(g);g.connect(mkG(.3,revSend));
  const end=t+len+.6;o1.start(t);o2.start(t);o1.stop(end);o2.stop(end);
}
function pchord(t,degs,oct,len,lvl,id){degs.forEach((d,k)=>piano(t+k*.004,noteF(d,oct),len,lvl,id));flash(id,t)}
// a plucked nylon string
function nylon(t,f,lvl,dec,id){
  const o=AC.createOscillator();o.type='sawtooth';o.frequency.value=f;const lp=AC.createBiquadFilter();lp.type='lowpass';lp.Q.value=1;
  lp.frequency.setValueAtTime(Math.min(7000,f*7),t);lp.frequency.setTargetAtTime(f*1.3,t,dec*.25);
  const g=mkG(0,toPan(id));env(g,t,lvl,.002,dec);o.connect(lp);lp.connect(g);g.connect(mkG(.25,revSend));o.start(t);o.stop(t+dec*5+.05);
}
function strum(t,degs,oct,lvl,gap,up,id,dec=.35){const d=up?[...degs].reverse():degs;d.forEach((x,k)=>nylon(t+k*gap,noteF(x,oct),lvl*(up?.8:1),dec,id));flash(id,t)}
// the bandoneon: two reeds a few cents apart and a lower reed, through a soft bellows filter
function reed(t,degs,len,lvl,swell){
  degs.forEach(d=>{const f=noteF(d,4),g=mkG(0,PAN.saturn);g.connect(mkG(.3,revSend));
    const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=2300;lp.Q.value=.7;lp.connect(g);
    [-7,7].forEach(c=>{const o=AC.createOscillator();o.type='sawtooth';o.frequency.value=f;o.detune.value=c;o.connect(lp);o.start(t);o.stop(t+len+.15)});
    if(!LOWPOWER){const sq=AC.createOscillator();sq.type='square';sq.frequency.value=f/2;sq.connect(mkG(.3,lp));sq.start(t);sq.stop(t+len+.15)}
    const a=swell?len*.9:.012;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(lvl,t+a);g.gain.setValueAtTime(lvl,t+Math.max(a,len*.85));g.gain.linearRampToValueAtTime(0,t+len+.03)});
  flash('saturn',t);
}
// a plucked double bass
function abass(t,f,len,lvl=.5){
  const o=AC.createOscillator(),o2=AC.createOscillator();o.type='sine';o2.type='triangle';o.frequency.setValueAtTime(f*1.03,t);o.frequency.setTargetAtTime(f,t,.015);o2.frequency.value=f;
  const g=mkG(0,PAN.jupiter);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(lvl,t+.006);g.gain.setTargetAtTime(lvl*.45,t+.006,.12);g.gain.setTargetAtTime(0,t+len,.05);
  o.connect(g);o2.connect(mkG(.35,g));const end=t+len+.4;o.start(t);o2.start(t);o.stop(end);o2.stop(end);flash('jupiter',t);
}
// percussion
function noiseHit(t,dur,type,f,q,lvl,att,dec,id,rev=.15){const n=noise(t,dur),fl=AC.createBiquadFilter();fl.type=type;fl.frequency.value=f;fl.Q.value=q;const g=mkG(0,toPan(id));env(g,t,lvl,att,dec);n.connect(fl);fl.connect(g);if(rev)g.connect(mkG(rev,revSend))}
function toneHit(t,f0,f1,type,lvl,dec,id,glide=.05){const o=AC.createOscillator();o.type=type;o.frequency.setValueAtTime(f0,t);if(f1!==f0)o.frequency.exponentialRampToValueAtTime(f1,t+glide);const g=mkG(0,toPan(id));env(g,t,lvl,.001,dec);o.connect(g);o.start(t);o.stop(t+dec*6+.05)}
function shaker(t,v){noiseHit(t,.12,'highpass',5200,.7,.13*v,.006,.022,'mercury',.05);flash('mercury',t)}
function castanet(t,v){[0,.013].forEach(d=>noiseHit(t+d,.03,'bandpass',3200,5,.32*v,.0005,.005,'mercury',.1));flash('mercury',t)}
function claves(t,v){toneHit(t,2500,2500,'sine',.2*v,.03,'earth');flash('earth',t)}
function tamborim(t,v){toneHit(t,900,820,'sine',.2*v,.04,'earth');noiseHit(t,.03,'bandpass',4000,2,.14*v,.0005,.006,'earth',0);flash('earth',t)}
function brush(t,v,long){noiseHit(t,long?.3:.15,'bandpass',3600,.6,.16*v,long?.03:.008,long?.09:.035,'earth',.2);flash('earth',t)}
function agogo(t,hi,v){const f=hi?905:678;[[1,.15,.09],[2.74,.05,.03]].forEach(([r,a,d])=>{const o=AC.createOscillator();o.type='sine';o.frequency.value=f*r;const g=mkG(0,PAN.mars);env(g,t,a*v,.001,d);o.connect(g);o.start(t);o.stop(t+.6)});flash('mars',t)}
function conga(t,kind,v){
  if(kind==='slap'){noiseHit(t,.06,'bandpass',1900,1.4,.32*v,.0008,.018,'mars',.1);toneHit(t,420,380,'sine',.14*v,.03,'mars')}
  else toneHit(t,kind==='open'?330:250,kind==='open'?300:230,'sine',(kind==='mute'?.12:.32)*v,kind==='mute'?.03:.13,'mars');
  flash('mars',t);
}
function surdo(t,open,v){toneHit(t,95,58,'sine',(open?.75:.38)*v,open?.28:.07,'sun',.08);noiseHit(t,.03,'lowpass',600,.7,.14*v,.001,.01,'sun',0);flash('sun',t);if(open)duckIt(t)}
function cajon(t,low,v){
  if(low){toneHit(t,120,70,'sine',.7*v,.12,'sun',.04);noiseHit(t,.08,'lowpass',500,.7,.25*v,.001,.03,'sun',.05);flash('sun',t);duckIt(t)}
  else{noiseHit(t,.1,'bandpass',2300,1,.4*v,.0008,.03,'mars',.15);toneHit(t,240,200,'triangle',.12*v,.03,'mars');flash('mars',t)}
}
function ride(t,v){
  noiseHit(t,.5,'highpass',7000,.7,.07*v,.001,.12,'mercury',.15);
  if(!LOWPOWER)[523,797].forEach(f=>{const o=AC.createOscillator();o.type='square';o.frequency.value=f*2.3;const hp=AC.createBiquadFilter();hp.type='highpass';hp.frequency.value=4000;const g=mkG(0,PAN.mercury);env(g,t,.018*v,.001,.15);o.connect(hp);hp.connect(g);o.start(t);o.stop(t+.9)});
  flash('mercury',t);
}
function chick(t,v){noiseHit(t,.05,'highpass',8000,.7,.09*v,.001,.01,'mercury',0)}
function timp(t,f,v){toneHit(t,f*1.03,f,'sine',.42*v,.45,'mars',.06);toneHit(t,f*2.01,f*2,'sine',.09*v,.2,'mars',.06);flash('mars',t)}
function guiro(t,long,v){
  const n=noise(t,long?.2:.08),bp=AC.createBiquadFilter();bp.type='bandpass';bp.Q.value=3;bp.frequency.setValueAtTime(2600,t);bp.frequency.linearRampToValueAtTime(3600,t+(long?.16:.06));
  const am=AC.createGain();am.gain.value=.5;const lfo=AC.createOscillator();lfo.type='square';lfo.frequency.value=46;lfo.connect(mkG(.5,am.gain));
  const g=mkG(0,PAN.mercury);env(g,t,.2*v,.005,long?.07:.025);n.connect(bp);bp.connect(am);am.connect(g);lfo.start(t);lfo.stop(t+(long?.25:.12));flash('mercury',t);
}
// the moons' arpeggio in each style's own instrument
function moonNote(t,f,lvl,dec,id,v){
  if(v==='guitar'){nylon(t,f,lvl*1.6,dec,'jupiter');flash(id,t)}
  else if(v==='piano'){piano(t,f,dec,lvl*1.3,'jupiter');flash(id,t)}
  else pluck(t,f,lvl,v==='vibes'?'sine':'triangle',dec,id);
}

