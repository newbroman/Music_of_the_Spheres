import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const browser = await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
const ids=(process.argv[2]||'pythagoras,philolaus,plato,aristotle,cicero,nicomachus,ptolemy,boethius,copernicus,fludd,kepler,today').split(',');
const page=await browser.newPage({viewport:{width:1300,height:1000}});const errs=[];page.on('pageerror',e=>errs.push(String(e)));page.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
await page.addInitScript(()=>{const Orig=window.AudioContext;window.AudioContext=class extends Orig{constructor(...a){super(...a);window.__ac=this;this.__an=this.createAnalyser();this.__an.fftSize=2048;}};const oc=AudioNode.prototype.connect;AudioNode.prototype.connect=function(t,...r){const res=oc.call(this,t,...r);if(t&&t===this.context.destination&&this.context.__an)oc.call(this,this.context.__an);return res};});
await page.goto('http://localhost:8123/de/index.html?notour');await page.waitForTimeout(800);await page.click('#begin');await page.waitForTimeout(800);
const rms=async()=>{let s=0;for(let k=0;k<15;k++){await page.waitForTimeout(150);s+=await page.evaluate(()=>{const an=__ac.__an,b=new Float32Array(an.fftSize);an.getFloatTimeDomainData(b);let q=0;for(const x of b)q+=x*x;return Math.sqrt(q/b.length)})}return (s/15).toFixed(3)};
for(const id of ids){await page.click(`.tl-chip[data-t="${id}"]`);await page.waitForTimeout(2500);const r=await rms();
  const vis=await page.evaluate(()=>[...document.querySelectorAll('.vrow2')].length);
  await page.screenshot({path:`th_${id}.png`,clip:{x:0,y:0,width:1300,height:1000}});console.log(id.padEnd(11),'rms',r,'voices listed',vis,'errors',errs.splice(0).join(' | ')||'none')}
await browser.close();
